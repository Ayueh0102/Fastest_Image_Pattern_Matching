Sparse orientation proposal study. All formal successes and failures are retained.
Proposal scores are unsigned-gradient similarity, NOT NCC. Final matches use full
NCC and fixed-scale continuous refinement. Source proposal work is CPU; backend1
uses Metal only for resident refinement (plus CPU verification/rescue control).
No image pyramid, GT positions or ROI hints enter the sparse worker.

Offline summary replay (NumPy and OpenCV installed, no GPU needed):
python3 formal/source-snapshot/cpp-core/tools/benchmark_sparse_orientation.py \
 --summarize formal/results.json --output /tmp/replayed-summary.json
Paths in historical protocols describe original provenance. Original sources,
fixtures, worker records and a baseline source archive are preserved; binaries
are omitted but hashed. Setup and first-call costs are separate from warm timing.
