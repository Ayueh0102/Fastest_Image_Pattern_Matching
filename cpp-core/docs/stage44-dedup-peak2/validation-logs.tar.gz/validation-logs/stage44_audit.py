"""Independent stage-44 audit: reads only the committed archives and summaries, never imports the harness.

Recomputes per-arm medians, k3-vs-off and cross-method deltas, block directions, the speed target and the
frames ranking rule; strict GT (own Kuhn matching) on every call; output identity with the round-43 archives.
Usage: stage44_audit.py DOCS_STAGE44 DOCS_STAGE43 WORKDIR
"""
import json
import math
from pathlib import Path
import statistics
import sys
import tarfile

S44, S43, WORK = (Path(arg) for arg in sys.argv[1:4])
checks, problems = 0, []


def check(condition, message):
    global checks
    checks += 1
    if not condition:
        problems.append(message)


def extract(archive, where):
    with tarfile.open(archive) as tar:
        tar.extractall(where, filter='data')


def strict(matches, truth):
    """Maximum one-to-one assignment with position <= 2 px, wrapped angle <= 1 deg, scale ratio in [.98, 1.02]."""
    edges = []
    for t in truth:
        row = []
        for j, m in enumerate(matches):
            ok = all(math.isfinite(m[k]) for k in ('pos_x', 'pos_y', 'angle', 'scale')) and m['scale'] > 0
            ratio = m['scale']/t['scale'] if ok else 0
            if ok and math.hypot(m['pos_x']-t['pos_x'], m['pos_y']-t['pos_y']) <= 2 and \
                    abs((m['angle']-t['angle']+180) % 360-180) <= 1 and .98 <= ratio <= 1.02:
                row.append(j)
        edges.append(row)
    owner = {}

    def augment(i, seen):
        for j in edges[i]:
            if j not in seen:
                seen.add(j)
                if j not in owner or augment(owner[j], seen):
                    owner[j] = i
                    return True
        return False
    tp = sum(augment(i, set()) for i in range(len(truth)))
    return tp, len(matches)-tp, len(truth)-tp


def outputs(record):
    return record['matches'], record['proposals']


def drop_times(value):
    if isinstance(value, dict):
        return {k: drop_times(v) for k, v in value.items() if not k.endswith('_ms')}
    if isinstance(value, list):
        return [drop_times(v) for v in value]
    return value


def r43_results(archive, phase, suffix):
    found = {}
    with tarfile.open(archive) as tar:
        for member in tar.getmembers():
            parts = Path(member.name).parts
            if len(parts) == 4 and parts[1:3] == (phase, 'results') and not parts[3].startswith('._') and parts[3].endswith(suffix+'.json'):
                case, path, arm = parts[3][:-len(suffix+'.json')].rsplit('-', 2)
                found[(case, path, arm)] = json.load(tar.extractfile(member))['first']
    return found


for name in ('raw-results-gt.tar.gz', 'raw-results-pilot-profile.tar.gz', 'raw-results-formal-static.tar.gz',
             'raw-results-formal-frames-hybrid.tar.gz', 'raw-results-formal-frames-gpu.tar.gz'):
    extract(S44/name, WORK)
RAW = WORK/'stage44-dedup-peak2'
PATH = {'hybrid_best': 'hybrid', 'full_gpu_parallel': 'full_gpu'}

# ---- formal ----
manifest = json.loads((RAW/'formal/manifest.json').read_text())
summary = json.loads((S44/'formal-summary.json').read_text())
ref = r43_results(S43/'raw-results-timing.tar.gz', 'formal', '-b0')
cases = {c['name']: c for c in manifest['cases']}
check(len(manifest['executions']) == 192 and manifest['complete'] and manifest['unchanged'], 'formal manifest incomplete')
arms = manifest['arms']
check(len(arms) == 8, 'formal arms')
blocks, measured = manifest['blocks'], manifest['measured_calls']
values, block_medians, all_calls = {}, {}, {}
for entry in manifest['executions']:
    worker = json.loads((RAW/'formal'/entry['result']).read_text())
    case, arm, block = entry['case'], entry['arm'], entry['block']
    method, mode, dedup = arm.rsplit('_', 2)
    if mode == 'frames':
        warmup = manifest['frame_warmup_calls'][case]
        rows = worker['runs']
        check(len(rows) == 1+warmup+measured, f'frames call count {case} {arm} {block}')
        timed = [row['frame_wall_ms'] for row in rows[1+warmup:]]
        check(rows[warmup]['elapsed_ms']-rows[0]['elapsed_ms'] >= 1000, f'warm-up below 1 s {case} {arm} {block}')
        calls = rows
    else:
        timed = [row['total_ms'] for row in worker['runs']]
        check(len(timed) == measured, f'static measured count {case} {arm} {block}')
        calls = [worker['first'], *worker['runs']]
    values.setdefault((case, arm), []).extend(timed)
    block_medians.setdefault((case, arm), {})[block] = statistics.median(timed)
    all_calls.setdefault((case, arm), []).extend(calls)
    for call in calls:
        tp, fp, fn = strict(call['matches'], cases[case]['truth'])
        check(fp == 0 and fn == 0, f'GT {case} {arm} {block}: {tp}/{fp}/{fn}')
        check(outputs(call) == outputs(ref[(case, PATH[method], dedup)]), f'round-43 identity {case} {arm} {block}')
        if method == 'full_gpu_parallel':
            check(call['full_gpu']['peak_mode'] == 2 and 1 <= call['full_gpu']['peak_batch_maps'] <= 8, f'peak route {case} {arm}')
        check(call['candidate_dedup']['top_k'] == (3 if dedup == 'k3' else 0), f'dedup arm {case} {arm}')

rows = {row['name']: row for row in summary['cases']}
recount = {}
for (case, arm), samples in values.items():
    metric = 'frame_wall_ms' if '_frames_' in arm else 'total_ms'
    median = statistics.median(samples)
    recount[(case, arm)] = median
    check(abs(median-rows[case]['arms'][arm][metric]['median']) < 1e-9, f'median {case} {arm}: {median} vs summary')
    check(len(samples) == blocks*measured, f'sample count {case} {arm}')


def compare(case, base, cand):
    a, b = recount[(case, base)], recount[(case, cand)]
    pairs = [(block_medians[(case, base)][k], block_medians[(case, cand)][k]) for k in range(blocks)]
    pooled = (b > a)-(b < a)
    consistent = pooled != 0 and {(y > x)-(y < x) for x, y in pairs} == {pooled}
    return 100*(b/a-1), sum(y < x for x, y in pairs), consistent


table = {}
for case in cases:
    for method in PATH:
        for mode in ('static', 'frames'):
            delta, faster, consistent = compare(case, f'{method}_{mode}_off', f'{method}_{mode}_k3')
            got = rows[case]['comparisons'][f'{method}_{mode}_k3_vs_off']
            check(abs(delta-got['delta_percent']) < 1e-9 and faster == got['candidate_faster_blocks'] and consistent == got['consistent_direction'],
                  f'k3 vs off {case} {method} {mode}')
            table[(case, method, mode)] = (delta, faster, consistent)
    frames = [arm for arm in arms if '_frames_' in arm]
    order = sorted(frames, key=lambda arm: recount[(case, arm)])
    beats = [compare(case, other, order[0]) for other in order[1:]]
    fastest = order[0] if all(delta < 0 and consistent for delta, _, consistent in beats) else None
    check(fastest == summary['frames_fastest'][case], f'fastest {case}: {fastest} vs {summary["frames_fastest"][case]}')
    table[(case, 'fastest')] = (fastest, order, [round(b[0], 2) for b in beats])
target = all(table[(case, 'full_gpu_parallel', 'static')][0] <= -10 and table[(case, 'full_gpu_parallel', 'static')][2]
             for case in ('many128_pose', 'many512_pose'))
check(target == summary['primary_target_met'] is True, 'speed target')

# ---- GT phase ----
gt = json.loads((RAW/'gt/manifest.json').read_text())
gt_summary = json.loads((S44/'gt-summary.json').read_text())
gt_ref = r43_results(S43/'raw-results-gt.tar.gz', 'gt', '')
gt_cases = {c['name']: c for c in gt['cases']}
check(len(gt['executions']) == 158 == 2*len(gt_cases) and all(e['returncode'] == 0 for e in gt['executions']), 'GT workers')
counts = {}
for entry in gt['executions']:
    worker = json.loads((RAW/'gt'/entry['result']).read_text())
    calls = [worker['first'], *worker['runs']]
    key = (entry['case'], entry['arm'])
    counts[key] = [strict(call['matches'], gt_cases[key[0]]['truth']) for call in calls]
    check(len(set(counts[key])) == 1, f'GT repeat counts {key}')
    old = gt_ref[(key[0], 'full_gpu', key[1])]
    for call in calls:
        check(outputs(call) == outputs(old) and drop_times(call['candidate_dedup']) == drop_times(old['candidate_dedup']), f'GT round-43 identity {key}')
        check(call['full_gpu']['peak_mode'] == 2, f'GT peak mode {key}')
regressions = [name for name in gt_cases if counts[(name, 'k3')][0][0] < counts[(name, 'off')][0][0] or counts[(name, 'k3')][0][1] > counts[(name, 'off')][0][1]]
check(regressions == [] and gt_summary['gt_neutral'] is True, f'GT regressions {regressions}')
for row in gt_summary['cases']:
    for arm, cell in row['arms'].items():
        tp, fp, fn = counts[(row['case'], arm)][0]
        check(cell['strict'][0] == dict(tp=tp, fp=fp, fn=fn), f'GT counts differ from summary {row["case"]} {arm}')

result = dict(checks=checks, problems=problems,
    formal={f'{case}|{method}|{mode}': dict(delta_percent=round(d, 3), k3_faster_blocks=f, consistent=c)
            for (case, method, mode), (d, f, c) in ((k, v) for k, v in table.items() if len(k) == 3)},
    fastest={case: table[(case, 'fastest')][0] for case in cases}, speed_target_met=target,
    gt=dict(case_variants=len(gt_cases), regressions=regressions,
            strict_totals={arm: [sum(counts[(n, arm)][0][i] for n in gt_cases) for i in range(3)] for arm in ('off', 'k3')}))
print(json.dumps(result, indent=1))
sys.exit(1 if problems else 0)
