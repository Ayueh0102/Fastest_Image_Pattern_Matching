"""Package stage-44 evidence into cpp-core/docs/stage44-dedup-peak2 (summaries, inputs, raw archives, decision)."""
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

BUILD = Path('/Users/Ayueh/Fastest_Image_Pattern_Matching/build')
RAW = BUILD/'stage44-dedup-peak2'
DOCS = Path('/Users/Ayueh/Fastest_Image_Pattern_Matching/.claude/worktrees/round44-dedup-peak2/cpp-core/docs/stage44-dedup-peak2')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def archive(name, members):
    target = DOCS/name
    with tarfile.open(target, 'w:gz', compresslevel=9) as tar:
        for path in sorted(members):
            info = tar.gettarinfo(str(path), arcname=str(path.relative_to(BUILD)))
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            with open(path, 'rb') as handle:
                tar.addfile(info, handle)
    return target


def files(*folders, keep=lambda path: True):
    return [path for folder in folders for path in (RAW/folder).rglob('*') if path.is_file() and keep(path)]


summaries = {phase: json.loads((RAW/f'{phase}-summary.json').read_text()) for phase in ('gt', 'pilot', 'formal', 'profile')}
manifests = {phase: json.loads((RAW/phase/'manifest.json').read_text()) for phase in summaries}
for phase in summaries:
    shutil.copyfile(RAW/f'{phase}-summary.json', DOCS/f'{phase}-summary.json')
inputs = {}
for phase, manifest in manifests.items():
    for path, digest in manifest['input_sha256'].items():
        if inputs.setdefault(path, digest) != digest:
            raise ValueError('Input hash differs between phases: '+path)
(DOCS/'input-sha256.json').write_text(json.dumps(dict(version=1, note='Every source/template read by any stage-44 worker, from the phase manifests '
    '(identical across phases). The two round-43 control scenes are regenerated under gt/inputs and are byte-identical to round 43.',
    inputs=dict(sorted(inputs.items()))), indent=1)+'\n')

archives = {
    'raw-results-gt.tar.gz': files('gt'),
    'raw-results-pilot-profile.tar.gz': files('pilot', 'profile'),
    'raw-results-formal-static.tar.gz': [RAW/'formal/manifest.json'] + files('formal/jobs', 'formal/results', keep=lambda p: '_static_' in p.name),
    'raw-results-formal-frames-hybrid.tar.gz': files('formal/jobs', 'formal/results', keep=lambda p: 'hybrid_best_frames' in p.name),
    'raw-results-formal-frames-gpu.tar.gz': files('formal/jobs', 'formal/results', keep=lambda p: 'full_gpu_parallel_frames' in p.name),
}
covered = [path for members in archives.values() for path in members]
everything = files('gt', 'pilot', 'profile', 'formal')
if sorted(covered) != sorted(everything) or len(set(covered)) != len(covered):
    raise ValueError('Archives do not cover every raw file exactly once')
for name, members in archives.items():
    target = archive(name, members)
    print(name, len(members), 'files', target.stat().st_size, 'bytes')
    if target.stat().st_size >= 100*1000*1000:
        raise ValueError('Archive at or above 100 MB: '+name)

formal, gt = summaries['formal'], summaries['gt']
rows = {row['name']: row for row in formal['cases']}
def comparison(case, key):
    c = rows[case]['comparisons'][key]
    return dict(baseline_median_ms=c['baseline_median_ms'], candidate_median_ms=c['candidate_median_ms'], delta_percent=c['delta_percent'],
                candidate_faster_blocks=c['candidate_faster_blocks'], blocks=c['blocks'], consistent_direction=c['consistent_direction'])
decision = dict(stage=44, protocol_sha256=manifests['formal']['protocol_sha256'],
    q1=dict(question='full_gpu_parallel static k3 at least 10% below off on many128_pose and many512_pose, 6/6 blocks',
            gt_neutral=gt['gt_neutral'], gt_case_variants=gt['aggregate']['cases'], gt_regressions=len(gt['aggregate']['regressions']),
            gt_outputs_equal_round43=gt['all_exact_round43'], formal_outputs_equal_round43=formal['all_exact_round43'],
            speed={case: comparison(case, 'full_gpu_parallel_static_k3_vs_off') for case in ('many128_pose', 'many512_pose')},
            speed_target_met=formal['primary_target_met'],
            suitable=bool(gt['gt_neutral'] and gt['all_exact_round43'] and formal['all_exact_round43'] and formal['primary_target_met'])),
    q2=dict(question='fastest of the four per-new-frame arms, named only when faster than each other arm in all 6 blocks',
            fastest=formal['frames_fastest'],
            ranking={case: rows[case]['comparisons']['frames_ranking'] for case in rows}),
    defaults='unchanged: GUI, core and research defaults keep candidate_dedup_top_k=0 and the hybrid/CPU paths',
    failures=dict(gt=[dict(f, diagnosis='Only source/template paths differ: the control scenes are regenerated into this round\'s '
                              'gt/inputs; their SHA-256 equal round 43\'s input-sha256.json and every output equals the round-43 archive. '
                              'The gate compares paths, not content; kept as a failure as pre-registered.')
                         if f['gate'] == 'job_equals_round43' else f for f in gt['failures']],
                  pilot=summaries['pilot']['failed_gates'], formal=formal['failed_gates'], profile=summaries['profile']['failed_gates']),
    notes=['Pilot (screening only) showed 8K k3 slower than off (GPU 59.8 vs 66.6 ms, hybrid 252.1 vs 291.1 ms per frame, one block); '
           'formal gives no consistent direction on 8K (GPU frames -0.3%, 3/6 blocks; hybrid frames +0.2%, 3/6).',
           'controlled6 per frame: full-GPU off against hybrid off is -0.5% with 3/6 blocks (no direction); round 42 reported hybrid 1.5% faster.'])
(DOCS/'decision-and-failures.json').write_text(json.dumps(decision, indent=1)+'\n')
print('suitable', decision['q1']['suitable'], 'fastest', decision['q2']['fastest'])
