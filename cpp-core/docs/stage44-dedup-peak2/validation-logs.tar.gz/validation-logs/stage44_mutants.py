"""Stage-44 tool mutants: each must make tests/test_dedup_peak2_harness.py fail. Restores the tool afterwards."""
import subprocess, sys
PY = '/Users/Ayueh/Fastest_Image_Pattern_Matching/python-port/venv/bin/python'
p = 'cpp-core/tools/benchmark_dedup_peak2.py'
orig = open(p).read()
mutants = [
 ('T1 archive identity ignored', "row['exact_vs_round43_archive'] = archived is not None and \\\n                all(", "row['exact_vs_round43_archive'] = True or all("),
 ('T2 speed target ignores block direction', "result['primary_target_met'] = result['consistent_direction'] and result['delta_percent'] <= SPEED_TARGET", "result['primary_target_met'] = result['delta_percent'] <= SPEED_TARGET"),
 ('T3 speed target sign flipped', "result['delta_percent'] <= SPEED_TARGET\n", "result['delta_percent'] >= SPEED_TARGET\n"),
 ('T4 fastest named by median only', "fastest=order[0] if all(result['faster'] == order[0] for result in versus) else None", "fastest=order[0]"),
 ('T5 GT regression not recorded', "                failures.append(dict(gate='gt_regression'", "                0 and failures.append(dict(gate='gt_regression'"),
 ('T6 peak route always true', "    return metrics['peak_mode'] == METHODS[GPU]['full_gpu_peak_mode'] and \\", "    return True or metrics['peak_mode'] == METHODS[GPU]['full_gpu_peak_mode'] and \\"),
 ('T7 min_area exempt from job check', "JOB_EXEMPT = ('full_gpu_peak_mode', 'full_gpu_peak_batch', 'repeats')", "JOB_EXEMPT = ('full_gpu_peak_mode', 'full_gpu_peak_batch', 'repeats', 'min_area')"),
 ('T8 time budget skipped', "                        if not pair['within_regression_budget']:\n                            failures.append(dict(case=name, arm=k3, baseline=off, gate='time_budget'", "                        if False:\n                            failures.append(dict(case=name, arm=k3, baseline=off, gate='time_budget'"),
 ('T9 GT dedup counts not compared', "            without_times(call['candidate_dedup']) == without_times(archived['first']['candidate_dedup']) for call in calls)", "            True for call in calls)"),
 ('T10 frames parity skipped', "row['same_arm_output_parity'] = all(stage42.outputs(call) == own for call in calls[arm])", "row['same_arm_output_parity'] = True"),
]
survived = 0
try:
    for name, old, new in mutants:
        assert orig.count(old) == 1, name
        open(p, 'w').write(orig.replace(old, new))
        r = subprocess.run([PY, '-m', 'unittest', 'cpp-core/tests/test_dedup_peak2_harness.py'], capture_output=True, text=True)
        failed = [l.split(' (')[0].split(': ')[1] for l in r.stderr.splitlines() if l.startswith(('FAIL:', 'ERROR:'))]
        survived += r.returncode == 0
        print(name, 'KILLED' if r.returncode else 'SURVIVED', failed, flush=True)
finally:
    open(p, 'w').write(orig)
r = subprocess.run([PY, '-m', 'unittest', 'cpp-core/tests/test_dedup_peak2_harness.py'], capture_output=True, text=True)
print('restored:', r.stderr.strip().splitlines()[-1], 'survived:', survived)
sys.exit(1 if survived or r.returncode else 0)
