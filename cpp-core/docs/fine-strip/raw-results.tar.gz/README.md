# Stage 28: Metal fine NCC strip reuse evidence

Read docs/FINE_NCC_STRIP_zh-TW.md for results, limits and decisions. This archive contains the full current C++/Metal implementation, tests and tools, frozen stage27 source and binaries, ten hashed input images, all 120 formal worker jobs/results/stderr files, the predeclared protocol, final manifest and summary, validation logs, negative controls and failed packaging/fixture attempts. No formal sample was removed.

## Offline replay

From this extracted directory, with Python 3 and NumPy available:

```sh
python source/cpp-core/tools/benchmark_fine_strip.py --summarize formal.json --output replay-summary.json
```

The result is byte-identical to summary.json. It does not read the original image paths or require Metal. content-sha256.json hashes every archived file except itself. Source and binary hashes in formal.json are those recorded before the formal measurement. The binary paths in that record are historical; matching copies are in binaries/.

## Source rebuild

On the measured Apple macOS platform with Command Line Tools, CMake, Qt6 and OpenCV available:

```sh
DEVELOPER_DIR=/Library/Developer/CommandLineTools cmake -S source/cpp-core -B rebuilt -DCMAKE_BUILD_TYPE=Release -DFPM_BUILD_EXPERIMENTS=ON -DFPM_BUILD_TESTS=ON -DFPM_BUILD_GUI=ON -DFPM_WITH_OPENCV=ON
DEVELOPER_DIR=/Library/Developer/CommandLineTools cmake --build rebuilt -j 6
ctest --test-dir rebuilt --output-on-failure
```

The staging copy of this source was rebuilt with tests OFF and the two native runners checked; see rebuild-checks/ and logs/archive-build.log. The formal tested build used tests ON. Rebuilt binary hashes may differ due to build paths. Bundled binaries depend on the recorded system/library versions and are not portable distributions. Dependencies are not vendored; algorithm source is preserved. frozen-source/ was extracted from commit 57bd600be410aba34fc50bf60007c525d88d2942; no claim is made that its binaries were rebuilt here.

## Re-run an individual search

Use a copy of a full jobs/*.json file, map source/template through input-paths.json to the extracted inputs/ directory, and pass it to rebuilt/experiments/fpm_native_pipeline_runner. Preserve the historical job file itself for hash-checked replay. For a micro job, pass its arguments array to rebuilt/experiments/fpm_fine_reuse_probe. GT remains in the parent manifest, never the native worker job. Full benchmark orchestration also accepts --previous with a relocated cases description and --baseline-protocol frozen-protocol.json; frozen binaries must pass the original SHA checks. This archive validates one rebuild scene, not a second full performance benchmark.

Failed attempts are retained in additional-validation-attempt1.json (negative-control fixture), archive-staging-attempt1.json (untracked historical AGENTS.md path), and negative-controls.json (expected rejection details). The fixed fixture changed no measured implementation or summarizer source.
