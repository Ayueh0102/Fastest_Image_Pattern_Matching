# Repository Guidelines

## Project Structure & Module Organization
- `MatchTool/`: C++17 MFC app (UI, dialogs, resources). Primary sources: `MatchTool*.{cpp,h}`, resources in `res/` and `MatchTool.rc`.
- `Test Images/` and `Result Images/`: sample inputs and expected visual outputs.
- `Manual Image/`, `Manual Gif/`: documentation assets used by `README.md`.
- Root: `CMakeLists.txt` (CMake build), `vcpkg.json` (OpenCV 4 manifest), `README.md`, `LICENSE`.

## Build, Test, and Development Commands
- Visual Studio (Windows, MFC): open `MatchTool/MatchTool.vcxproj`, select `Release` (or `Release_4.X` for OpenCV4), build. Ensure your OpenCV dirs and DLLs are configured per README.
- CMake + vcpkg (manifest mode):
  - `cmake -S . -B build -DCMAKE_TOOLCHAIN_FILE="<vcpkg_root>/scripts/buildsystems/vcpkg.cmake" -DCMAKE_BUILD_TYPE=Release`
  - `cmake --build build --config Release`
  The build produces `MatchTool.exe`; `MatchTool/MatchTool.Lang` is copied to the output folder automatically.
- Run locally: launch the built executable and use images from `Test Images/` to validate behavior.

## Coding Style & Naming Conventions
- Language: C++17 with MFC and OpenCV 4.
- Indentation: follow existing files (tabs are common). Do not mass‑reformat; keep diffs surgical.
- Naming: classes/types `PascalCase` (e.g., `CMatchToolDlg`), functions `camelCase`/`PascalCase`, constants/macros `UPPER_SNAKE_CASE`.
- Headers: prefer local includes first, then system. Keep includes minimal.

## Testing Guidelines
- No formal unit tests yet. Validate changes by:
  - Visual checks: run UI with `Test Images/` and compare to `Result Images/`.
  - Performance: build `Release`, measure timing-sensitive paths and note SIMD-related changes.
- If adding tests, prefer GoogleTest in a `tests/` folder; name files `*_test.cpp` and keep them platform‑agnostic.

## Commit & Pull Request Guidelines
- Commits: concise, imperative, scoped. Example: `Fix NCC rotation precision at pyramid top` or `CMake: add vcpkg manifest and copy Lang file`.
- PRs: include description, build/run steps, platform/toolchain (e.g., VS version, OpenCV), screenshots of results, and linked issues. Call out any performance deltas.

## Security & Configuration Tips
- Dependencies via `vcpkg.json`; prefer manifest mode to get the pinned OpenCV. Match OpenCV runtime DLLs with build config.
- Known quirk: if `RotatedRect` assertion triggers, follow the README’s note to adjust the check and rebuild.
