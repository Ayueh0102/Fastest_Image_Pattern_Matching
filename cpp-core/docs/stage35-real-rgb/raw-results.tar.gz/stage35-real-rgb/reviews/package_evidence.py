"""Package frozen stage35 evidence without redistributing FSC photographs."""
from pathlib import Path
import json, shutil, hashlib, subprocess

root=Path(__file__).resolve().parents[3]
stage=root/'build/stage35-real-rgb';bundle=stage/'bundle'
def copy(src,rel):
    dest=bundle/rel
    if src.is_dir(): shutil.copytree(src,dest,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','.DS_Store'))
    else: dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
for folder in ('formal','pilot','pilot-diagnosis'):
    for src in (stage/folder).rglob('*'):
        if src.is_file() and src.suffix in ('.json','.txt','.log','.py'):
            copy(src,Path('evidence')/folder/src.relative_to(stage/folder))
for folder in ('inputs','frozen-inputs','protocol-inputs'):
    for src in (stage/folder).glob('*.json'):copy(src,Path('evidence/scene-manifests')/folder/src.name)
for src in stage.glob('*.log'):copy(src,Path('logs')/src.name)
copy(stage/'logs','logs')
copy(stage/'data/visa','data/visa')
copy(stage/'data/fsc/manifest.json','data/fsc/manifest.json')
for src in (stage/'protocol-inputs').glob('visa-*.png'):copy(src,Path('data/visa-templates')/src.name)
for src in (stage/'reviews').iterdir():
    if src.is_file():copy(src,Path('reviews')/src.name)
for src in (stage/'compiled/experiments').iterdir():
    if src.name=='fpm_color_verify_runner' or src.suffix=='.dylib':copy(src,Path('binaries')/src.name)
copy(stage/'compiled/CMakeCache.txt','build-provenance/CMakeCache.txt')
manifest=json.loads((stage/'formal/protocol.json').read_text())
mapping={}
for case in manifest['cases']:
    for key in ('source','template','mask','mask_gt'):
        if key not in case:continue
        path=Path(case[key])
        if '/data/visa/' in str(path):
            mapping[str(path)]=str(Path('data/visa')/path.relative_to(stage/'data/visa'))
        elif path.name.startswith('visa-'):
            mapping[str(path)]=str(Path('data/visa-templates')/path.name)
(bundle/'input-paths.json').write_text(json.dumps(mapping,indent=2)+'\n')
(bundle/'build-provenance/parent-commit.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True))
(bundle/'build-provenance/toolchain.txt').write_text(subprocess.check_output(['clang++','--version'],text=True)+subprocess.check_output(['cmake','--version'],text=True))
(bundle/'data/README.txt').write_text('VisA RGB images and official masks: Yang Zou, Jongheon Jeong, Latha Pemula, Dongqing Zhang, Onkar Dabeer / Amazon Science / ECCV 2022. CC BY 4.0: https://creativecommons.org/licenses/by/4.0/ . Source: https://github.com/amazon-science/spot-diff . Original JPG and masks unchanged; derived previews/masks and template crops explicitly identified. See data/visa/provenance/LICENSE-DATASET and data/visa/manifest.json.\nFSC photographs and derived controls are excluded because photo redistribution terms were not established. Metadata, input hashes, analytic poses and reproducible pinned download/render source are retained. Offline result replay needs only archived VisA GT masks.\n')
print('Prepared evidence bundle',bundle)
