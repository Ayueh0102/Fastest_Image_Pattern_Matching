#!/usr/bin/env python3
"""Review frozen Stage 35 outputs. Does not invoke or alter the algorithm."""

import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Circle
import numpy as np
from PIL import Image


ROOT = Path(__file__).resolve().parents[3]
RUN = ROOT / "build/stage35-real-rgb"
FORMAL = RUN / "formal"
OUT = ROOT / "cpp-core/docs/stage35-real-rgb/visa-results.png"
REVIEW = RUN / "reviews"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    summary = json.loads((FORMAL / "summary.json").read_text())
    protocol = json.loads((FORMAL / "protocol.json").read_text())
    assert summary["complete"] and summary["integrity_passed"]
    outcomes = {case["name"]: case for case in summary["cases"]}
    inputs = {case["name"]: case for case in protocol["cases"]}
    selected = ["capsules_normal_100", "capsules_anomaly_033"]
    figure, axes = plt.subplots(1, 2, figsize=(20, 10))
    figure.patch.set_facecolor("white")
    figure.suptitle("Real-scene failure: no candidates in heldout anomaly images", fontsize=22, weight="bold", y=0.965)
    figure.text(0.5, 0.918,
                "Frozen C++ search outputs. Adding color verification cannot recover a missing search candidate.",
                ha="center", fontsize=12, color="#444444")
    candidate_color = "#00e5ff"
    gt_color = "#ff3055"
    sources = []
    for index, (axis, name) in enumerate(zip(axes, selected)):
        params = inputs[name]
        result = outcomes[name]["methods"]["geometry"]
        matches = result["reference_matches"]
        assert digest(params["source"]) == params["input_sha256"]["source"]
        with Image.open(params["source"]) as image:
            axis.imshow(image)
        for number, match in enumerate(matches, 1):
            axis.add_patch(Polygon(match["corners"], closed=True, fill=False,
                                   edgecolor=candidate_color, linewidth=2.5))
            axis.text(match["corners"][0][0], match["corners"][0][1] - 17,
                      f"C++ #{number}: NCC {match['score']:.3f}", fontsize=11,
                      color=candidate_color, weight="bold",
                      bbox={"facecolor": "black", "alpha": 0.7, "edgecolor": "none", "pad": 3})
        if "mask_gt" in params:
            assert digest(params["mask_gt"]) == params["input_sha256"]["mask_gt"]
            with Image.open(params["mask_gt"]) as image:
                mask = np.array(image) == 2
            yy, xx = np.where(mask)
            assert int(mask.sum()) == result["accuracy"]["discolor_pixels"]
            x, y = float(xx.mean()), float(yy.mean())
            axis.contour(mask, levels=[0.5], colors=[gt_color], linewidths=1.5)
            axis.add_patch(Circle((x, y), 45, fill=False, edgecolor=gt_color, linewidth=2.0))
            axis.annotate("OFFICIAL GT ONLY\nDiscolor: 173 pixels\nNot a prediction",
                          xy=(x - 40, y), xytext=(80, 690), color="white", fontsize=11,
                          bbox={"facecolor": "#8e1630", "alpha": 0.93, "edgecolor": "white", "pad": 7},
                          arrowprops={"arrowstyle": "->", "color": gt_color, "linewidth": 2})
        axis.set_xlim(-0.5, 1499.5)
        axis.set_ylim(999.5, -0.5)
        axis.axis("off")
        if index == 0:
            title = "Normal 100: 2 C++ candidates"
            note = ("Cyan polygons are actual detections, visually on capsules.\n"
                    "RGB CPU / Metal: normal. Geometry / chroma: false alarm.\n"
                    "No complete instance annotations: no object-recall claim.")
        else:
            title = "Anomaly 033: 0 C++ candidates — missed anomaly"
            note = ("No valid candidate: the system abstains; this counts as a missed anomaly.\n"
                    "Red contour / circle mark official ID 2 for evaluation only.\n"
                    "Official image labels include both Bubble and Discolor.")
        axis.set_title(title, fontsize=15, weight="bold", pad=15)
        axis.text(0, -0.06, note, transform=axis.transAxes, va="top", fontsize=11,
                  linespacing=1.6, color="#222222")
        sources.append({"sample": name, "source": params["source"],
                        "source_sha256": params["input_sha256"]["source"],
                        "mask_gt": params.get("mask_gt"), "mask_gt_sha256": params["input_sha256"].get("mask_gt")})
    figure.text(0.5, 0.092,
                "Heldout: 3/3 anomalous images have zero candidates; 4/6 images abstain. Thresholds are provisional (only 1/3 calibration normal images produced candidates).",
                ha="center", fontsize=11, weight="bold", color="#8e1630")
    figure.text(0.5, 0.052,
                "Images / ground truth: VisA, Yang Zou, Jongheon Jeong, Latha Pemula, Dongqing Zhang, Onkar Dabeer; Amazon Science, ECCV 2022.\n"
                "CC BY 4.0 — https://creativecommons.org/licenses/by/4.0/  |  Source: https://github.com/amazon-science/spot-diff\n"
                "This project added titles, actual output polygons and clearly identified evaluation-only annotations. Full source scenes are shown without cropping.",
                ha="center", va="center", fontsize=9, color="#555555", linespacing=1.5)
    figure.subplots_adjust(left=0.025, right=0.975, top=0.855, bottom=0.245, wspace=0.055)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(OUT, dpi=150, facecolor="white")
    plt.close(figure)

    heldout = []
    for case in summary["cases"]:
        if not case["name"].startswith("capsules_") or case["split"] != "heldout":
            continue
        methods = {}
        for method, values in case["methods"].items():
            accuracy = values["accuracy"]
            methods[method] = {key: accuracy.get(key) for key in
                               ["candidate_count", "abstained", "image_value", "threshold", "predicted_anomaly",
                                "tp", "fp", "tn", "fn", "localized_color_tp"]}
        heldout.append({"name": case["name"], "methods": methods,
                        "geometry_matches": case["methods"]["geometry"]["reference_matches"]})
    review = {
        "summary_sha256": digest(FORMAL / "summary.json"),
        "protocol_sha256": digest(FORMAL / "protocol.json"),
        "figure": str(OUT.relative_to(ROOT)), "figure_sha256": digest(OUT),
        "figure_sources": sources, "heldout": heldout,
        "visual_findings": {
            "capsules_normal_100": "Both output polygons enclose visible upright capsules, not background.",
            "capsules_normal_500": "The single output polygon encloses a visible upright capsule, not background.",
        },
        "interpretation": "The frozen protocol fails to propose candidates in all three anomalous heldout scenes; downstream RGB/chroma verification cannot repair that omission. There are no instance labels, so no object-level recall or precision is inferred. Thresholds are provisional because only one calibration normal image has valid candidates.",
        "no_algorithm_runs": True,
    }
    (REVIEW / "visa-visual-review.json").write_text(json.dumps(review, indent=2) + "\n")
    print(json.dumps({"figure": str(OUT), "review": str(REVIEW / "visa-visual-review.json")}))


if __name__ == "__main__":
    main()
