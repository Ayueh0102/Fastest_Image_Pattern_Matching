"""Make deterministic evidence archives and a separate content manifest."""
from pathlib import Path
import gzip,hashlib,json,tarfile,shutil

root=Path(__file__).resolve().parents[3];stage=root/'build/stage35-real-rgb'
bundle=stage/'bundle';dest=root/'cpp-core/docs/stage35-real-rgb'
shutil.copy2(__file__,bundle/'reviews/make_archives.py')
files=sorted(p for p in bundle.rglob('*') if p.is_file() and p.name!='content-sha256.json' and p.name!='.DS_Store')
inventory={str(p.relative_to(bundle)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(bundle/'content-sha256.json').write_text(json.dumps({'schema_version':1,'files':inventory},indent=2)+'\n')
result={}
for name,source in [('source-and-fixtures.tar.gz',True),('raw-results.tar.gz',False)]:
    output=dest/name
    with output.open('wb') as handle,gzip.GzipFile(filename='',mode='wb',fileobj=handle,mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
        included=[]
        for path in sorted(p for p in bundle.rglob('*') if p.is_file() and p.name!='.DS_Store'):
            rel=path.relative_to(bundle)
            if (rel.parts[0]=='source')!=source:continue
            info=tar.gettarinfo(str(path),str(Path('stage35-real-rgb')/rel))
            info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
            with path.open('rb') as f:tar.addfile(info,f)
            included.append(str(rel))
    result[name]=dict(bytes=output.stat().st_size,sha256=hashlib.sha256(output.read_bytes()).hexdigest(),files=len(included))
result.update(content_files=len(inventory),content_manifest_sha256=hashlib.sha256((bundle/'content-sha256.json').read_bytes()).hexdigest(),
    frozen_source_files=json.loads((bundle/'source-snapshot.json').read_text())['frozen_protocol_sources'],
    source_files=len(json.loads((bundle/'source-snapshot.json').read_text())['files']),
    note='Extract both archives into the same directory. FSC photograph bytes and derived control images excluded; offline statistics fully replayable, algorithm rerun requires pinned fetch/render.')
(dest/'archive.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
