"""Post-measurement plots from frozen stage35 outputs; no benchmark runs."""
import json
from pathlib import Path
import argparse
import numpy as np
import cv2
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path.cwd());args=p.parse_args()
stage=args.root/'build/stage35-real-rgb'
summary=json.loads((stage/'formal/summary.json').read_text())
cases={c['name']:c for c in summary['cases']}
inputs={c['name']:c for c in json.loads((stage/'formal/protocol.json').read_text())['cases']}
dest=args.root/'cpp-core/docs/stage35-real-rgb';dest.mkdir(parents=True,exist_ok=True)
methods=['geometry_original','geometry','rgb_cpu','rgb_metal','chroma']
labels=['Original search','Adjusted search','+ RGB CPU','+ RGB Metal','+ Chroma CPU']
colors=['#9ca3af','#2563eb','#7c3aed','#06b6d4','#e07020']
fig,axes=plt.subplots(2,3,figsize=(14,8),layout='constrained')
for row,name in enumerate(['development_one_offset','heldout_one_offset']):
    c=cases[name]
    for col,(metric,title,unit) in enumerate([
        ('pipeline_ms','Complete warm pipeline','ms'),
        ('verification_ms','Added candidate verification','ms'),
        ('rss','Whole-process peak RSS','MiB')]):
        ax=axes[row,col]
        for i,m in enumerate(methods):
            d=c['methods'][m]['peak_rss_bytes'] if metric=='rss' else c['methods'][m]['timing']['repeat'][metric]
            scale=2**20 if metric=='rss' else 1
            v=d['median']/scale
            ax.bar(i,v,color=colors[i],width=.65)
            ax.errorbar(i,v,yerr=[[v-d['min']/scale],[d['max']/scale-v]],fmt='none',ecolor='#111827',capsize=3,lw=.9)
            ax.text(i,v+(d['max']/scale*.03 if v else .01),f'{v:.2f}',ha='center',va='bottom',fontsize=8)
        ax.set(title=title+(' — development 43×30' if row==0 else ' — heldout 58×71'),ylabel=unit)
        ax.set_xticks(range(5),labels,rotation=35,ha='right',fontsize=8)
        ax.set_ylim(0,ax.get_ylim()[1]*1.16);ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
fig.suptitle('Stage 35 | 49 rotated RGB objects, one color-offset target\n4 fresh processes per method; bars = median, whiskers = min–max',fontsize=14)
fig.savefig(dest/'performance.png',dpi=150);plt.close(fig)

# Local-only photographic derivatives: FSC photograph license was not resolved.
# They remain outside the distributable archive, while this renderer is retained.
fig,axes=plt.subplots(2,3,figsize=(13,9),layout='constrained')
for row,name in enumerate(['development_one_offset','heldout_one_offset']):
    c=cases[name];source=cv2.cvtColor(cv2.imread(inputs[name]['source']),cv2.COLOR_BGR2RGB)
    for ax,m,title in zip(axes[row],['geometry_original','rgb_metal','chroma'],['Original geometry','Adjusted search + RGB NCC','Adjusted search + chroma']):
        ax.imshow(source)
        result=c['methods'][m];acc=result['accuracy']
        for match,score in zip(result['reference_matches'],result['first_scores']):
            flag=(score['status']==0 and score['changed_fraction']>.1) if m=='chroma' else 1-score>.2
            poly=np.asarray(match['corners']);poly=np.vstack([poly,poly[0]])
            ax.plot(poly[:,0],poly[:,1],color='#e62727' if flag else '#10b981',lw=.8)
        target=inputs[name]['truth'][24];ax.plot(target['pos_x'],target['pos_y'],'o',ms=27,mfc='none',mec='#ffe04b',mew=2)
        ax.set_title(f'{title}\npose {acc["geometry"]["strict"]["tp"]}/49; color TP/FP/FN {acc["color_tp"]}/{acc["color_fp"]}/{acc["color_fn"]}',fontsize=10)
        ax.axis('off')
fig.suptitle('Semi-synthetic control from real stamp crops | green: detection, red: color flag\nYellow circle = known changed target (evaluation only); not real-photo accuracy',fontsize=12)
fig.savefig(stage/'control-results-local.png',dpi=150);plt.close(fig)
print(dest/'performance.png');print(stage/'control-results-local.png')
