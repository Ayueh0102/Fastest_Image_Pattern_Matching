"""Verify archive members and recompute frozen results without original paths/GPU."""
import argparse, hashlib, json, sys
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--output',type=Path)
a=p.parse_args();root=a.root.resolve()
inventory=json.loads((root/'content-sha256.json').read_text())
for relative,expected in inventory['files'].items():
    path=root/relative
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
        raise ValueError('Missing or altered archive content: '+relative)
sys.path.insert(0,str(root/'source/cpp-core/tools'))
from benchmark_real_rgb import summarize
mapping={k:str(root/v) for k,v in json.loads((root/'input-paths.json').read_text()).items()}
base=root/'evidence/formal'
summary=summarize(json.loads((base/'formal.json').read_text()),base,mapping)
expected=json.loads((base/'summary.json').read_text())
if summary!=expected:raise ValueError('Replayed summary differs')
report=dict(archive_hashes_passed=True,files_verified=len(inventory['files']),summary_exact=True,
    workers=summary['workers'],algorithm_calls=summary['algorithm_calls'],integrity_passed=summary['integrity_passed'],
    performance_failure_pairs=len(summary['performance_failures']),real_color_accuracy_passed=False,
    note='Evidence and replay pass while documented accuracy/performance failures remain unchanged.')
if a.output:a.output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
