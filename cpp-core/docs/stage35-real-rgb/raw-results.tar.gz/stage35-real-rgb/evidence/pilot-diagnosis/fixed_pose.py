import json,subprocess,math
from pathlib import Path
root=Path('/Users/Ayueh/Fastest_Image_Pattern_Matching')
out=root/'build/stage35-real-rgb/pilot-diagnosis'
cases={c['name']:c for c in json.loads((root/'build/stage35-real-rgb/frozen-inputs/cases.json').read_text())}
report=[]
for name in ('development_clean','fsc_2933'):
 c=cases[name]
 integrated=json.loads((root/f'build/stage35-real-rgb/pilot/{name}-geometry.raw.json').read_text())
 sw,sh=integrated['source_size']; tw,th=integrated['template_size']
 if 'truth' in c:
  poses=[[m['pos_x']-sw/2,sh/2-m['pos_y'],m['angle'],math.log(m['scale'])] for m in c['truth']]
 else:
  x0,y0,x1,y1=c['template_crop_xyxy'];poses=[[(x0+x1-sw)/2,(sh-y0-y1)/2,0,0]]
 job=dict(source=c['source'],template=c['template'],poses=poses,method='gray_ncc',backend='cpu',threads=1,warmups=0,repeats=1)
 path=out/f'{name}-gt-pose.job.json';path.write_text(json.dumps(job,indent=2))
 result=subprocess.run([str(root/'build/stage35-color/experiments/fpm_color_verify_runner'),str(path)],text=True,capture_output=True,timeout=60)
 if result.returncode:raise RuntimeError(result.stderr)
 (out/f'{name}-gt-pose.raw.json').write_text(result.stdout)
 scores=json.loads(result.stdout)['first']['scores']
 row=dict(case=name,scope='GT poses diagnostic only, never end-to-end search accuracy',scores=scores,min_score=min(scores),max_score=max(scores),above_final=sum(s>=c['search']['score'] for s in scores),count=len(scores),angles=[p[2] for p in poses])
 report.append(row);print(json.dumps(row),flush=True)
(out/'fixed-gt-pose-comparison.json').write_text(json.dumps(report,indent=2))
