import json,subprocess
from pathlib import Path
root=Path('/Users/Ayueh/Fastest_Image_Pattern_Matching');out=root/'build/stage35-real-rgb/pilot-diagnosis'
cases={c['name']:c for c in json.loads((root/'build/stage35-real-rgb/frozen-inputs/cases.json').read_text())}
report=[]
for name in ('capsules_normal_000','capsules_normal_050','capsules_normal_200','capsules_normal_400'):
 job=cases[name]
 for variant,changes in [('area512',dict(min_area=512)),('area512_prop25_cap300',dict(min_area=512,proposal_score=.25,limit=300))]:
  request=dict(job['search'],source=job['source'],template=job['template'],repeats=1,warmup_seconds=0)
  request.update(changes)
  path=out/f'{name}-{variant}.job.json';path.write_text(json.dumps(request,indent=2))
  result=subprocess.run([str(root/'build/stage34-closure/experiments/fpm_native_pipeline_runner'),str(path)],text=True,capture_output=True,timeout=300)
  (out/f'{name}-{variant}.stderr.txt').write_text(result.stderr)
  if result.returncode:raise RuntimeError(result.stderr)
  (out/f'{name}-{variant}.raw.json').write_text(result.stdout)
  data=json.loads(result.stdout);first=data['first']
  row=dict(case=name,variant=variant,matches=len(first['matches']),proposals=len(first['proposals']),first_ms=first['total_ms'],repeat_ms=data['runs'][0]['total_ms'],scores=[round(m['score'],4) for m in first['matches']])
  report.append(row);print(json.dumps(row),flush=True)
(out/'capsule-bounded.json').write_text(json.dumps(report,indent=2))
