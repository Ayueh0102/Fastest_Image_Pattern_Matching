import json,subprocess
from pathlib import Path
root=Path('/Users/Ayueh/Fastest_Image_Pattern_Matching');out=root/'build/stage35-real-rgb/pilot-diagnosis'
variants=[('coarse_ncc0',dict(ncc_mode=0)),('coarse_ncc1',dict(ncc_mode=1)),('fine_unfused',dict(fine_fused=False)),('fine_noreuse',dict(fine_angle_reuse=False)),('cpu_front',dict(backend=0,ncc_mode=0,fine_ncc_mode=0,fine_fused=False,fine_angle_reuse=False)),('no_pyramid',dict(min_area=2000)),('proposal25',dict(proposal_score=.25))]
report=[]
for name in ('development_clean','fsc_2933'):
 job=json.loads((root/f'build/stage35-real-rgb/pilot/{name}-geometry.json').read_text())
 for variant,changes in variants:
  request=dict(job['search'],source=job['source'],template=job['template'],repeats=1,warmup_seconds=0)
  request.update(changes)
  path=out/f'{name}-{variant}.job.json';path.write_text(json.dumps(request,indent=2))
  result=subprocess.run([str(root/'build/stage34-closure/experiments/fpm_native_pipeline_runner'),str(path)],text=True,capture_output=True,timeout=300)
  (out/f'{name}-{variant}.stderr.txt').write_text(result.stderr)
  if result.returncode:raise RuntimeError(result.stderr)
  (out/f'{name}-{variant}.raw.json').write_text(result.stdout)
  data=json.loads(result.stdout);first=data['first']
  row=dict(case=name,variant=variant,matches=len(first['matches']),proposals=len(first['proposals']),pipeline_ms=first['total_ms'],angles=[round(m['angle'],2) for m in first['matches']])
  report.append(row);print(json.dumps(row),flush=True)
(out/'proposal-ablation.json').write_text(json.dumps(report,indent=2))
