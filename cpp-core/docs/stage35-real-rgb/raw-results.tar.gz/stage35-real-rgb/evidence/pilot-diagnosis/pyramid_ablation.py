import json,subprocess
from pathlib import Path
root=Path('/Users/Ayueh/Fastest_Image_Pattern_Matching');out=root/'build/stage35-real-rgb/pilot-diagnosis'
variants=[('area512',dict(min_area=512)),('area1024',dict(min_area=1024)),('area1000000',dict(min_area=1000000)),('proposal25_cap300',dict(proposal_score=.25,limit=300)),('area512_proposal25_cap300',dict(min_area=512,proposal_score=.25,limit=300))]
report=[]
for name in ('development_clean','fsc_2933'):
 job=json.loads((root/f'build/stage35-real-rgb/pilot/{name}-geometry.json').read_text())
 for variant,changes in variants:
  request=dict(job['search'],source=job['source'],template=job['template'],repeats=1,warmup_seconds=0)
  request.update(changes)
  path=out/f'{name}-{variant}.job.json';path.write_text(json.dumps(request,indent=2))
  result=subprocess.run([str(root/'build/stage34-closure/experiments/fpm_native_pipeline_runner'),str(path)],text=True,capture_output=True,timeout=300)
  (out/f'{name}-{variant}.stderr.txt').write_text(result.stderr)
  if result.returncode:raise RuntimeError(result.stderr)
  (out/f'{name}-{variant}.raw.json').write_text(result.stdout)
  data=json.loads(result.stdout);first=data['first']
  row=dict(case=name,variant=variant,matches=len(first['matches']),proposals=len(first['proposals']),pipeline_ms=first['total_ms'],proposal_ms=first['proposal_ms'],refine_ms=first['refine_ms'])
  report.append(row);print(json.dumps(row),flush=True)
(out/'pyramid-ablation.json').write_text(json.dumps(report,indent=2))
