import json,subprocess
from pathlib import Path
root=Path('/Users/Ayueh/Fastest_Image_Pattern_Matching')
out=root/'build/stage35-real-rgb/pilot-diagnosis'
report=[]
for name in ('development_clean','fsc_2933','capsules_normal_000'):
 job=json.loads((root/f'build/stage35-real-rgb/pilot/{name}-geometry.json').read_text())
 integrated=json.loads((root/f'build/stage35-real-rgb/pilot/{name}-geometry.raw.json').read_text())
 for stop in (1,0):
  request=dict(job['search'],source=job['source'],template=job['template'],repeats=1,warmup_seconds=0,stop_layer=stop)
  path=out/f'{name}-native-stop{stop}.job.json';path.write_text(json.dumps(request,indent=2))
  result=subprocess.run([str(root/'build/stage34-closure/experiments/fpm_native_pipeline_runner'),str(path)],text=True,capture_output=True,timeout=300)
  (out/f'{name}-native-stop{stop}.stderr.txt').write_text(result.stderr)
  if result.returncode: raise RuntimeError(result.stderr)
  (out/f'{name}-native-stop{stop}.raw.json').write_text(result.stdout)
  data=json.loads(result.stdout);first=data['first']
  summary=dict(case=name,stop_layer=stop,matches=len(first['matches']),proposals=len(first['proposals']),angles=[round(m['angle'],2) for m in first['matches']],proposal_scores=[round(m['score'],3) for m in first['proposals']],pipeline_ms=first['total_ms'],integrated_exact=(first['matches']==integrated['first']['search_matches']) if stop==1 else None)
  report.append(summary);print(json.dumps(summary),flush=True)
(out/'native-comparison.json').write_text(json.dumps(report,indent=2))
