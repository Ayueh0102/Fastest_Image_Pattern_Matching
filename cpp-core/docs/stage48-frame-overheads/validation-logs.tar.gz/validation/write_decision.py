"""Collate stage-48 verdicts, key effects and every failed gate from the published summaries.

Run from the worktree root. Reads only cpp-core/docs/stage48-frame-overheads/*-summary.json.
"""
import json
from pathlib import Path
out = Path('cpp-core/docs/stage48-frame-overheads')
PHASES = ('pilot', 'formal', 'dose', 'profile')
summaries = {phase: json.loads((out/f'{phase}-summary.json').read_text()) for phase in PHASES}
formal = summaries['formal']
KEY = {'hybrid_best': ('total_ms', 'frame_wall_ms', 'proposal_ms', 'coarse_device_ms', 'fine_wait_ms', 'prepare_ms', 'refine_ms',
                       'pose_create_ms', 'refine_minus_pose_ms', 'refinement_device_ms'),
       'full_gpu_simd': ('total_ms', 'frame_wall_ms', 'device_ms', 'upload_ms'),
       'full_gpu_parallel': ('total_ms', 'frame_wall_ms', 'device_ms', 'upload_ms')}
def compact(effect):
    return dict(delta_ms=effect['delta_ms'], delta_percent=effect.get('delta_percent'), direction=effect['direction'],
                block_deltas_ms=[row['delta_ms'] for row in effect['paired']])
effects = {case['name']: {method: {contrast: {metric: compact(values[metric]) for metric in KEY[method]} for contrast, values in contrasts.items()}
                          for method, contrasts in case['effects'].items()} for case in formal['cases']}
medians = {case['name']: {arm: {metric: (row['metrics'][metric] or {}).get('median') for metric in KEY[row['spec']['method']]}
                          for arm, row in case['arms'].items()} for case in formal['cases']}
dose = {case['name']: {method: {key: value for key, value in row.items() if key not in ('total_ms',)} for method, row in case['dose'].items()}
        for case in summaries['dose']['cases']}
for case in dose.values():
    for row in case.values():
        row[row['metric']] = [level['median'] for level in row[row['metric']]]
        row['top_vs_none'] = compact(row['top_vs_none'])
profile = {case['name']: {arm: {stage: values['median'] for stage, values in row.get('profile_stages', {}).items()}
                          for arm, row in case['arms'].items()} for case in summaries['profile']['cases']}
failures = [dict(gate, dataset=phase) for phase, summary in summaries.items() for gate in summary['failed_gates']]
counts = {}
for gate in failures:
    key = f"{gate['dataset']}:{gate['gate']}"
    counts[key] = counts.get(key, 0)+1
decision = dict(stage=48, date='2026-10-26',
    question='Do the round-41 per-new-frame overheads come from the gap before each call, from the update itself, or from neither?',
    formal_decision_eligible=formal['formal_decision_eligible'],
    verdicts={name: row.get('verdict', row.get('reproduced')) for name, row in formal['hypotheses'].items()},
    hypotheses=formal['hypotheses'], pilot_verdicts={name: row.get('verdict', row.get('reproduced')) for name, row in summaries['pilot']['hypotheses'].items()},
    effects=effects, arm_medians=medians, attribution={case['name']: case['attribution'] for case in formal['cases']},
    dose=dose, profile_stage_medians_ms=profile,
    accuracy=dict(direct_gt_calls={phase: summary['counts']['gt_evaluated_calls'] for phase, summary in summaries.items()},
                  total_direct_gt_calls=sum(summary['counts']['gt_evaluated_calls'] for summary in summaries.values()),
                  all_zero_fp_fn=all(summary['all_accuracy_pass'] for summary in summaries.values())),
    all_routes_pass=all(summary['all_routes_pass'] for summary in summaries.values()),
    all_repeat_exact=all(summary['all_repeat_exact'] for summary in summaries.values()),
    all_failed_gates=failures, failed_gate_counts=counts,
    defaults_changed=False, gui_default_changed=False,
    note='Diagnosis only. Verdicts follow the pre-registered rules on formal effects; pilot verdicts are a screen.')
(out/'decision-and-failures.json').write_text(json.dumps(decision, indent=2, ensure_ascii=False, allow_nan=False)+'\n')
print(json.dumps(dict(verdicts=decision['verdicts'], failures=counts, gt=decision['accuracy']), indent=2))
