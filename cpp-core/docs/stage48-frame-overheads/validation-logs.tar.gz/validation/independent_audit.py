#!/usr/bin/env python3
"""Independent audit of the stage-48 frame-overheads experiment (round 48).

Everything is recomputed from the raw worker outputs and the manifests:
integrity, schedule order, job contents, strict ground truth, pooled and
per-block medians, contrasts, verdicts, the sequence/gap contract, output
exactness, host gates and counts.  The published summaries are only read
at the end, to be compared against.

Independence: only the Python standard library is used.  Nothing under
cpp-core/tools is imported or copied, and the checks follow the protocol
(cpp-core/docs/stage48-frame-overheads/protocol.json), not the harness.
No build, test, GPU program or native runner is started; the only
subprocesses are read-only git queries (GIT_OPTIONAL_LOCKS=0).

Run from the worktree root:
    python -I build/stage48-frame-overheads/validation/independent_audit.py
"""
import datetime
import hashlib
import json
import math
import os
import re
import statistics
import subprocess
import sys
import tarfile
import time
from collections import Counter, defaultdict

ROOT = os.path.abspath(os.getcwd())
STAGE = os.path.join(ROOT, 'build', 'stage48-frame-overheads')
DOCS = os.path.join(ROOT, 'cpp-core', 'docs', 'stage48-frame-overheads')
PROTOCOL_PATH = os.path.join(DOCS, 'protocol.json')
OUT_PATH = os.path.join(STAGE, 'validation', 'independent-audit.json')
PHASES = ('pilot', 'formal', 'dose', 'profile')
TOL = 1e-9
GIT_ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
STARTED = time.time()


# ----------------------------------------------------------------- helpers
def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def read_bytes(path):
    with open(path, 'rb') as f:
        return f.read()


def load_json(path):
    return json.loads(read_bytes(path))


def canon_hash(obj):
    text = json.dumps(obj, sort_keys=True, separators=(',', ':'))
    return hashlib.sha256(text.encode()).hexdigest()


def git(*args, input_bytes=None):
    p = subprocess.run(['git', *args], cwd=ROOT, input=input_bytes,
                       capture_output=True, env=GIT_ENV)
    return p.returncode, p.stdout, p.stderr


def git_blob_hashes(rev, paths):
    """SHA256 of each path's committed bytes at rev (None if absent)."""
    if not paths:
        return {}
    data = ''.join(f'{rev}:{p}\n' for p in paths).encode()
    code, out, err = git('cat-file', '--batch', input_bytes=data)
    if code != 0:
        raise RuntimeError('git cat-file failed: ' + err.decode(errors='replace'))
    result = {}
    pos = 0
    for p in paths:
        nl = out.index(b'\n', pos)
        header = out[pos:nl].decode(errors='replace')
        pos = nl + 1
        if header.endswith(' missing') or header.endswith(' ambiguous'):
            result[p] = None
            continue
        _sha, kind, size = header.rsplit(' ', 2)
        size = int(size)
        content = out[pos:pos + size]
        pos += size + 1
        result[p] = sha256_bytes(content) if kind == 'blob' else None
    return result


def utc_parse(text):
    return datetime.datetime.fromisoformat(text)


def median(xs):
    return statistics.median(xs)


def stats(values):
    return {'median': median(values), 'min': min(values), 'max': max(values),
            'values': list(values)}


def direction(delta, paired):
    if delta > 0 and all(p > 0 for p in paired):
        return 'up'
    if delta < 0 and all(p < 0 for p in paired):
        return 'down'
    return None


def wrapped_angle_diff(a, b):
    return abs((a - b + 180.0) % 360.0 - 180.0)


# ------------------------------------------------------- ground truth match
def gt_match(preds, truths, pos_tol, ang_tol, rel_scale):
    """Maximum one-to-one matching under the strict thresholds.

    Truths are bucketed on a grid of cell size 2*pos_tol so only the 3x3
    neighbouring cells can hold a truth within pos_tol.  Kuhn's augmenting
    path algorithm (iterative) gives a maximum cardinality matching.
    """
    lo, hi = 1.0 - rel_scale, 1.0 + rel_scale
    cell = 2.0 * pos_tol
    buckets = defaultdict(list)
    for j, t in enumerate(truths):
        buckets[(math.floor(t['pos_x'] / cell), math.floor(t['pos_y'] / cell))].append(j)
    adj = []
    truth_degree = Counter()
    for p in preds:
        px, py = float(p['pos_x']), float(p['pos_y'])
        cx, cy = math.floor(px / cell), math.floor(py / cell)
        cand = []
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for j in buckets.get((cx + dx, cy + dy), ()):
                    t = truths[j]
                    d = math.hypot(px - t['pos_x'], py - t['pos_y'])
                    if d > pos_tol:
                        continue
                    da = wrapped_angle_diff(float(p['angle']), float(t['angle']))
                    if da > ang_tol:
                        continue
                    ratio = float(p['scale']) / float(t['scale'])
                    if ratio < lo or ratio > hi:
                        continue
                    cand.append((d, j, da, abs(ratio - 1.0)))
        cand.sort()
        for c in cand:
            truth_degree[c[1]] += 1
        adj.append(cand)
    match_t = [-1] * len(truths)
    match_p = [-1] * len(preds)
    for i in range(len(preds)):
        if not adj[i]:
            continue
        visited = set()
        parent = {}
        stack = [(i, iter(adj[i]))]
        found = None
        while stack and found is None:
            u, it = stack[-1]
            advanced = False
            for c in it:
                j = c[1]
                if j in visited:
                    continue
                visited.add(j)
                parent[j] = u
                if match_t[j] == -1:
                    found = j
                else:
                    stack.append((match_t[j], iter(adj[match_t[j]])))
                    advanced = True
                break
            if found is None and not advanced:
                stack.pop()
        if found is not None:
            j = found
            while True:
                u = parent[j]
                prev = match_p[u]
                match_p[u] = j
                match_t[j] = u
                if u == i:
                    break
                j = prev
    tp = 0
    max_pos = max_ang = max_scale = 0.0
    for i, j in enumerate(match_p):
        if j < 0:
            continue
        tp += 1
        for d, jj, da, ds in adj[i]:
            if jj == j:
                max_pos = max(max_pos, d)
                max_ang = max(max_ang, da)
                max_scale = max(max_scale, ds)
                break
    ambiguous_preds = sum(1 for a in adj if len(a) > 1)
    ambiguous_truths = sum(1 for v in truth_degree.values() if v > 1)
    return {'tp': tp, 'fp': len(preds) - tp, 'fn': len(truths) - tp,
            'max_pos': max_pos, 'max_ang': max_ang, 'max_scale': max_scale,
            'ambiguous_preds': ambiguous_preds, 'ambiguous_truths': ambiguous_truths}


# -------------------------------------------------------------- comparator
class Comparator:
    def __init__(self):
        self.count = 0
        self.mismatches = []

    def _add(self, path, mine, pub, category, note=None):
        entry = {'path': path, 'recomputed': mine, 'published': pub, 'category': category}
        if isinstance(mine, (int, float)) and isinstance(pub, (int, float)) \
                and not isinstance(mine, bool) and not isinstance(pub, bool):
            entry['abs_diff'] = abs(mine - pub)
        if note:
            entry['note'] = note
        self.mismatches.append(entry)

    def num(self, path, mine, pub, category='protocol'):
        self.count += 1
        if isinstance(mine, bool) or isinstance(pub, bool):
            if mine is not pub and mine != pub:
                self._add(path, mine, pub, category)
            return
        if mine is None or pub is None:
            if mine is not pub:
                self._add(path, mine, pub, category)
            return
        if not isinstance(mine, (int, float)) or not isinstance(pub, (int, float)):
            if mine != pub:
                self._add(path, mine, pub, category)
            return
        if abs(mine - pub) > TOL:
            self._add(path, mine, pub, category)

    def seq(self, path, mine, pub, category='protocol'):
        if not isinstance(pub, list) or len(pub) != len(mine):
            self.count += 1
            self._add(path + '.length', len(mine), len(pub) if isinstance(pub, list) else pub, category)
            return
        for i, (a, b) in enumerate(zip(mine, pub)):
            self.num(f'{path}[{i}]', a, b, category)

    def stats(self, path, mine, pub, category='protocol'):
        if mine is None:
            self.count += 1
            self._add(path, None, 'stats' if isinstance(pub, dict) else pub, category,
                      'recomputed value unavailable (None in raw rows)')
            return
        if not isinstance(pub, dict):
            self.count += 1
            self._add(path, 'stats', pub, category, 'published entry missing')
            return
        for k in ('median', 'min', 'max'):
            self.num(f'{path}.{k}', mine[k], pub.get(k), category)
        self.seq(f'{path}.values', mine['values'], pub.get('values'), category)

    def eq(self, path, mine, pub, category='protocol'):
        self.count += 1
        if mine != pub:
            self._add(path, mine, pub, category)


# ------------------------------------------------------------ protocol model
def parse_protocol(proto):
    model = {}
    conds = list(proto['conditions'].keys())
    model['conditions'] = conds
    model['contrasts'] = {}
    for name in ('round41', 'update', 'decode_gap', 'sleep_gap', 'gap_on_update'):
        arm_c, base_c = [x.strip() for x in proto['contrasts'][name].split(' - ')]
        model['contrasts'][name] = (arm_c, base_c)
    fp = proto['cases']['formal_and_pilot']
    model['case_order'] = list(fp.keys())
    sleep_text = proto['conditions']['static_sleep']
    nums = [int(x) for x in re.search(r'(\d+)/(\d+)/(\d+) ms', sleep_text).groups()]
    model['sleep_ms'] = dict(zip(model['case_order'], nums))
    dose_levels = [int(x) for x in re.findall(r'\d+', proto['cases']['dose']['conditions'])]
    model['dose_levels'] = [0] + dose_levels
    model['phase_cases'] = {
        'pilot': {c: list(v) for c, v in fp.items()},
        'formal': {c: list(v) for c, v in fp.items()},
        'dose': {c: list(v) for c, v in proto['cases']['dose'].items() if c != 'conditions'},
        'profile': {c: list(v) for c, v in proto['cases']['profile'].items() if c != 'conditions'},
    }
    model['phase_conditions'] = {
        'pilot': conds, 'formal': conds, 'profile': conds,
        'dose': ['static_none'] + [f'static_sleep{n}' for n in dose_levels],
    }
    model['warmup'] = proto['schedule']['warmup_calls']
    model['measured'] = proto['schedule']['measured_calls_per_process']
    model['blocks'] = proto['schedule']['blocks']
    model['metrics_hybrid'] = [m.split(' ')[0] for m in proto['metrics']['hybrid']]
    model['metrics_gpu'] = list(proto['metrics']['full_gpu'])
    acc = proto['accuracy']
    model['pos_tol'] = float(acc['position_px'])
    model['ang_tol'] = float(acc['angle_deg'])
    model['rel_scale'] = float(acc['relative_scale'])
    model['warmup_gate_ms'] = 1000.0
    model['sleep_slack_ms'] = 50.0
    model['nogap_max_ms'] = 1.0
    model['load_limit'] = 4.0
    return model


def expected_spec(model, phase, case, arm):
    method, cond = arm.split('__', 1)
    mode, gap = cond.split('_', 1)
    sleep_ms = 0
    if gap.startswith('sleep'):
        rest = gap[len('sleep'):]
        sleep_ms = int(rest) if rest else model['sleep_ms'][case]
        gap = 'sleep'
    return {'method': method, 'mode': mode, 'gap': gap, 'sleep_ms': sleep_ms}


# metrics where the protocol (or the audit brief) gives the definition
PROTOCOL_DEFINED = {'total_ms', 'frame_wall_ms', 'prepare_ms', 'proposal_ms', 'refine_ms',
                    'pose_create_ms', 'refinement_device_ms', 'coarse_device_ms',
                    'cpu_normalization_ms', 'device_ms', 'upload_ms', 'source_update_ms'}


def metric_category(metric):
    return 'protocol' if metric in PROTOCOL_DEFINED else 'inferred_definition'


def row_metric(r, metric):
    return r['m'].get(metric)


# ------------------------------------------------------------ row extraction
def extract_row(row):
    work = row.get('work') or []
    fg = row.get('full_gpu') or {}
    m = {}
    for k in ('total_ms', 'frame_wall_ms', 'gap_ms', 'source_decode_ms', 'prepare_ms',
              'proposal_ms', 'refine_ms', 'pose_create_ms', 'refinement_device_ms',
              'source_update_ms'):
        m[k] = row.get(k)

    def wsum(key):
        vals = [w.get(key) for w in work]
        if any(v is None for v in vals):
            return None
        return sum(vals)
    m['coarse_device_ms'] = wsum('device_ms')
    m['coarse_wait_ms'] = wsum('wait_ms')
    m['fine_wait_ms'] = wsum('fine_wait_ms')
    m['fine_ncc_ms'] = wsum('fine_ncc_ms')
    m['cpu_normalization_ms'] = wsum('normalization_ms')
    if row.get('refine_ms') is not None and row.get('pose_create_ms') is not None:
        m['refine_minus_pose_ms'] = row['refine_ms'] - row['pose_create_ms']
    else:
        m['refine_minus_pose_ms'] = None
    for k in ('device_ms', 'wait_ms', 'upload_ms', 'encode_ms'):
        m[k] = fg.get(k)
    stages = defaultdict(float)
    for st in fg.get('stages') or []:
        stages[st['name']] += st['gpu_ms']
    mem = row.get('memory') or {}
    return {
        'call': row.get('call'),
        'sequence_gap': row.get('sequence_gap'),
        'elapsed_ms': row.get('elapsed_ms'),
        'source_generation': row.get('source_generation'),
        'source_copy_bytes': row.get('source_copy_bytes'),
        'pose_invalidated': row.get('pose_invalidated'),
        'source_index': row.get('source_index'),
        'source_path': row.get('source_path'),
        'm': m,
        'current_rss': mem.get('current_rss_bytes'),
        'peak_rss': mem.get('peak_rss_bytes'),
        'gpu_bytes': fg.get('gpu_bytes'),
        'frame_gpu_bytes': (row.get('frame_coarse_gpu_bytes') or 0) + (row.get('frame_fine_gpu_bytes') or 0),
        'pose_gpu_bytes': row.get('pose_gpu_bytes'),
        'route': {
            'fg_enabled': fg.get('enabled'), 'fg_peak_mode': fg.get('peak_mode'),
            'fg_fine_mode': fg.get('fine_mode'), 'fg_fine_effective_mode': fg.get('fine_effective_mode'),
            'fg_peak_batch_maps': fg.get('peak_batch_maps'), 'fg_command_buffers': fg.get('command_buffers'),
            'fg_cpu_waits': fg.get('cpu_waits'), 'fg_intermediate_readbacks': fg.get('intermediate_readbacks'),
            'fg_cpu_algorithm_steps': fg.get('cpu_algorithm_steps'),
            'fg_device_timestamp_available': fg.get('device_timestamp_available'),
            'fg_profile_requested': fg.get('profile_requested'), 'fg_profile_available': fg.get('profile_available'),
            'fg_profile_status': fg.get('profile_status'),
            'selected_refinement_backend': row.get('selected_refinement_backend'),
            'configured_refinement_backend': row.get('configured_refinement_backend'),
            'n_work': len(work),
            'work_device_ok': all(w.get('device_ms') is not None and w.get('device_ms') >= 0 for w in work),
        },
        'stages': dict(stages),
        'profile_gpu_ms': fg.get('profile_gpu_ms'),
        'mhash': canon_hash(row.get('matches')),
        'phash': canon_hash(row.get('proposals')),
        'n_matches': len(row.get('matches') or []),
        'n_proposals': len(row.get('proposals') or []),
    }


TRUTH_KEY_HINTS = ('truth', 'ground', 'expected', 'pos_x', 'pos_y', 'objects', 'metadata', 'corners')


def find_truth_leaks(obj, path='job'):
    leaks = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            lk = str(k).lower()
            if any(h in lk for h in TRUTH_KEY_HINTS) or lk == 'gt':
                leaks.append(f'{path}.{k}')
            leaks.extend(find_truth_leaks(v, f'{path}.{k}'))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            leaks.extend(find_truth_leaks(v, f'{path}[{i}]'))
    elif isinstance(obj, str):
        if obj.lower().endswith('.json'):
            leaks.append(f'{path}={obj}')
    return leaks


# ------------------------------------------------------------- source check
SOURCE_CACHE = {}


def source_report(paths, frozen_commit, phase_finished):
    key = tuple(sorted(paths.items()))
    if key in SOURCE_CACHE:
        return SOURCE_CACHE[key]
    names = sorted(paths)
    frozen = git_blob_hashes(frozen_commit, names)
    head = git_blob_hashes('HEAD', names)
    worktree_diff = []
    frozen_diff = []
    for p in names:
        full = os.path.join(ROOT, p)
        now = sha256_file(full) if os.path.isfile(full) else None
        if frozen.get(p) != paths[p]:
            frozen_diff.append({'path': p, 'manifest': paths[p], 'frozen_commit': frozen.get(p)})
        if now != paths[p]:
            code, out, _ = git('log', '--format=%h %cI %s', f'{frozen_commit}..HEAD', '--', p)
            later = [ln for ln in out.decode(errors='replace').splitlines() if ln.strip()]
            mtime = None
            if now is not None:
                mtime = datetime.datetime.fromtimestamp(os.path.getmtime(full), datetime.timezone.utc).isoformat()
            worktree_diff.append({
                'path': p, 'manifest': paths[p], 'worktree': now, 'head_commit': head.get(p),
                'frozen_commit': frozen.get(p),
                'head_equals_manifest': head.get(p) == paths[p],
                'uncommitted_worktree_change': now != head.get(p),
                'later_commits_touching_file': later,
                'worktree_mtime_utc': mtime,
                'modified_after_last_phase_finished': (mtime is not None and phase_finished is not None
                                                       and utc_parse(mtime) > phase_finished),
                'is_python': p.endswith('.py'),
            })
    rep = {'files': len(names), 'frozen_commit': frozen_commit,
           'manifest_equals_frozen_commit_bytes': not frozen_diff,
           'manifest_vs_frozen_commit_differences': frozen_diff,
           'worktree_differences': worktree_diff,
           'worktree_non_python_differences': [d['path'] for d in worktree_diff if not d['is_python']]}
    SOURCE_CACHE[key] = rep
    return rep


# ------------------------------------------------------------- phase audit
def audit_phase(phase, model, proto, glob):
    t0 = time.time()
    pdir = os.path.join(STAGE, phase)
    man = load_json(os.path.join(pdir, 'manifest.json'))
    pub_path = os.path.join(DOCS, f'{phase}-summary.json')
    pub = load_json(pub_path)
    failures = []          # protocol-defined failures
    notes = []             # observations that are not failures
    out = {'manifest': os.path.relpath(os.path.join(pdir, 'manifest.json'), ROOT),
           'published_summary': os.path.relpath(pub_path, ROOT)}

    cases = {c['name']: c for c in man['cases']}
    B = man['blocks']
    M = man['measured_calls']
    Wof = man['warmup_calls']

    # ---------------------------------------------------------- integrity
    integ = {}
    integ['complete'] = man.get('complete')
    integ['unchanged'] = man.get('unchanged')
    if man.get('complete') is not True:
        failures.append(f'{phase}: manifest complete is not true')
    if man.get('unchanged') is not True:
        failures.append(f'{phase}: manifest unchanged is not true')
    after = man.get('after_sha256') or {}
    for key in ('source_sha256', 'binary_sha256', 'input_sha256'):
        ok = man.get(key) == after.get(key) and man.get(key) is not None
        integ[f'{key}_before_equals_after'] = ok
        if not ok:
            failures.append(f'{phase}: {key} before != after')
    inp_bad = []
    for p, h in man['input_sha256'].items():
        now = sha256_file(p) if os.path.isfile(p) else None
        if now != h:
            inp_bad.append({'path': p, 'manifest': h, 'now': now})
    integ['inputs_rehashed'] = len(man['input_sha256'])
    integ['input_mismatches'] = inp_bad
    if inp_bad:
        failures.append(f'{phase}: {len(inp_bad)} input file hash mismatch(es)')
    bin_bad = []
    for p, h in man['binary_sha256'].items():
        now = sha256_file(p) if os.path.isfile(p) else None
        if now != h:
            bin_bad.append({'path': p, 'manifest': h, 'now': now})
    integ['binaries_rehashed'] = len(man['binary_sha256'])
    integ['binary_mismatches'] = bin_bad
    if bin_bad:
        failures.append(f'{phase}: {len(bin_bad)} binary hash mismatch(es)')
    fx = man.get('fixtures_manifest')
    fx_now = sha256_file(fx) if fx and os.path.isfile(fx) else None
    integ['fixtures_manifest_sha256_ok'] = fx_now == man.get('fixtures_manifest_sha256')
    if not integ['fixtures_manifest_sha256_ok']:
        failures.append(f'{phase}: fixtures manifest hash mismatch')
    src = source_report(man['source_sha256'], glob['frozen_commit_full'], glob['last_phase_finished'])
    integ['source'] = {k: src[k] for k in ('files', 'frozen_commit', 'manifest_equals_frozen_commit_bytes',
                                           'worktree_non_python_differences')}
    integ['source']['worktree_differences'] = src['worktree_differences']
    integ['source']['manifest_vs_frozen_commit_differences'] = src['manifest_vs_frozen_commit_differences']
    if not src['manifest_equals_frozen_commit_bytes']:
        failures.append(f'{phase}: manifest source hashes differ from the frozen commit for '
                        f'{len(src["manifest_vs_frozen_commit_differences"])} file(s)')
    # worktree differences are judged once, globally (same file list in every phase)
    snap = glob['snapshot_hashes']
    snap_bad = [p for p, h in man['source_sha256'].items() if snap.get(p) != h]
    integ['manifest_sources_equal_source_sha256_json'] = not snap_bad
    integ['manifest_sources_missing_or_different_in_source_sha256_json'] = snap_bad
    if snap_bad:
        failures.append(f'{phase}: {len(snap_bad)} manifest source hash(es) differ from source-sha256.json')
    integ['binary_sha256_same_as_formal'] = None  # filled in by the caller

    ex_list = man['executions']
    job_bad, res_bad, stdout_diff, stderr_nonempty = [], [], [], []
    files_jobs = sorted(f for f in os.listdir(os.path.join(pdir, 'jobs'))
                        if f.endswith('.json'))
    files_res = sorted(os.listdir(os.path.join(pdir, 'results')))
    listed_jobs = sorted(os.path.basename(e['job']) for e in ex_list)
    listed_res = sorted(os.path.basename(e['result']) for e in ex_list)
    integ['job_files_on_disk_match_manifest'] = files_jobs == listed_jobs
    integ['result_files_on_disk_match_manifest'] = files_res == listed_res
    if files_jobs != listed_jobs or files_res != listed_res:
        failures.append(f'{phase}: job/result files on disk do not match the manifest list')

    # summary embedded in the manifest vs the published copy
    integ['published_summary_equals_manifest_summary'] = (man.get('summary') == pub)
    if man.get('summary') != pub:
        failures.append(f'{phase}: published summary differs from manifest["summary"]')

    # ------------------------------------------------- order and job checks
    order = {}
    oj_fail = []
    exp_cases = model['phase_cases'][phase]
    exp_conds = model['phase_conditions'][phase]
    order['cases_match_protocol'] = sorted(cases) == sorted(exp_cases)
    if not order['cases_match_protocol']:
        oj_fail.append(f'cases {sorted(cases)} != protocol {sorted(exp_cases)}')
    if B != model['blocks'][phase]:
        oj_fail.append(f'blocks {B} != protocol {model["blocks"][phase]}')
    if M != model['measured']:
        oj_fail.append(f'measured_calls {M} != protocol {model["measured"]}')
    for c in cases:
        if Wof.get(c) != model['warmup'].get(c):
            oj_fail.append(f'warmup_calls[{c}] {Wof.get(c)} != protocol {model["warmup"].get(c)}')
        if man['sleep_ms'].get(c) != model['sleep_ms'].get(c):
            oj_fail.append(f'sleep_ms[{c}] {man["sleep_ms"].get(c)} != protocol {model["sleep_ms"].get(c)}')
        exp_arms = [f'{m}__{cond}' for cond in exp_conds for m in exp_cases.get(c, [])]
        if man['arms'].get(c) != exp_arms:
            oj_fail.append(f'arms[{c}] not "conditions outer, methods inner": {man["arms"].get(c)}')
        for arm in man['arms'].get(c, []):
            es = expected_spec(model, phase, c, arm)
            if man['arm_specs'][c].get(arm) != es:
                oj_fail.append(f'arm_specs[{c}][{arm}] {man["arm_specs"][c].get(arm)} != {es}')
    if bool(man.get('profiling')) != (phase == 'profile'):
        oj_fail.append(f'manifest profiling={man.get("profiling")} for phase {phase}')

    triple_count = Counter((e['case'], e['arm'], e['block']) for e in ex_list)
    expected_triples = {(c, a, b) for c in cases for a in man['arms'][c] for b in range(B)}
    dup = [list(k) for k, v in triple_count.items() if v != 1]
    missing = sorted(list(t) for t in expected_triples - set(triple_count))
    extra = sorted(list(t) for t in set(triple_count) - expected_triples)
    order['executions'] = len(ex_list)
    order['duplicates'] = dup
    order['missing'] = missing
    order['unexpected'] = extra
    if dup or missing or extra:
        oj_fail.append(f'execution coverage: {len(dup)} duplicate, {len(missing)} missing, {len(extra)} unexpected')
    seq_by_cb = defaultdict(list)
    for e in ex_list:
        seq_by_cb[(e['case'], e['block'])].append(e['arm'])
    bad_order = []
    for (c, b), arms in seq_by_cb.items():
        exp = list(man['arms'][c]) if b % 2 == 0 else list(reversed(man['arms'][c]))
        if arms != exp:
            bad_order.append({'case': c, 'block': b, 'executed': arms, 'expected': exp})
    order['case_block_order_ok'] = not bad_order
    order['case_block_order_failures'] = bad_order
    if bad_order:
        oj_fail.append(f'{len(bad_order)} case/block arm sequences not forward/reversed as required')
    # layout of the whole run (informational)
    layout = []
    for e in ex_list:
        key = (e['case'], e['block'])
        if not layout or layout[-1] != key:
            layout.append(key)
    order['contiguous_case_block_groups'] = len(layout) == len(set(layout))
    order['group_sequence'] = [f'{c}:b{b}' for c, b in layout]
    utcs = [utc_parse(e['host']['utc']) for e in ex_list]
    order['host_utc_strictly_increasing'] = all(a < b for a, b in zip(utcs, utcs[1:]))
    if not order['host_utc_strictly_increasing']:
        oj_fail.append('host utc records are not strictly increasing in execution order')
    order['first_worker_after_protocol_revision_commit'] = utcs[0] > glob['revision_commit_time']
    if not order['first_worker_after_protocol_revision_commit']:
        oj_fail.append('a worker ran before the protocol revision commit')

    # ------------------------------------------- per execution processing
    jobs_by = {}
    arm_rows = defaultdict(dict)        # (case, arm) -> block -> list(rows)
    arm_proc = defaultdict(dict)        # (case, arm) -> block -> process info
    job_fail = []
    seq_fail = []
    gt_fail = []
    route_fail = []
    gt_tot = Counter()
    gt_max = {'max_pos': 0.0, 'max_ang': 0.0, 'max_scale': 0.0}
    gt_amb = Counter()
    arm_gt = defaultdict(lambda: {'counts': set(), 'max_pos': 0.0, 'max_ang': 0.0, 'max_scale': 0.0,
                                  'rows': 0, 'fail_rows': 0})
    info_seq = defaultdict(Counter)
    margins = {'sleep_gap_minus_sleep_ms_min': None, 'sleep_gap_minus_sleep_ms_max': None,
               'nogap_gap_ms_max': None, 'decode_ms_min': None, 'decode_ms_max': None}

    def upd(key, val, fn):
        margins[key] = val if margins[key] is None else fn(margins[key], val)
    job_key_patterns = defaultdict(set)
    warm_fail = []
    prof_sum_diff = 0.0
    for e in ex_list:
        c, arm, b = e['case'], e['arm'], e['block']
        case = cases[c]
        spec = man['arm_specs'][c][arm]
        method = spec['method']
        W = Wof[c]
        refine_case = case.get('workflow') == 'full_rescue'
        jpath = os.path.join(pdir, e['job'])
        rpath = os.path.join(pdir, e['result'])
        jb = read_bytes(jpath)
        rb = read_bytes(rpath)
        if sha256_bytes(jb) != e['job_sha256']:
            job_bad.append(e['job'])
        if sha256_bytes(rb) != e['result_sha256']:
            res_bad.append(e['result'])
        job = json.loads(jb)
        res = json.loads(rb)
        so = jpath[:-len('.json')] + '.stdout.txt'
        se = jpath[:-len('.json')] + '.stderr.txt'
        if os.path.isfile(so):
            try:
                if json.loads(read_bytes(so)) != res:
                    stdout_diff.append(e['result'])
            except ValueError:
                stdout_diff.append(e['result'] + ' (stdout not JSON)')
        else:
            stdout_diff.append(e['result'] + ' (no stdout file)')
        if os.path.isfile(se) and os.path.getsize(se) > 0:
            stderr_nonempty.append(os.path.relpath(se, pdir))
        jobs_by[(c, arm, b)] = job
        tag = f'{c}/{arm}/b{b}'

        # job checks
        errs = []
        leaks = find_truth_leaks(job)
        if leaks:
            errs.append(f'ground-truth-like content: {leaks}')
        if job.get('warmup_seconds') != 0:
            errs.append(f'warmup_seconds={job.get("warmup_seconds")}')
        sf = job.get('source_frames')
        if not (isinstance(sf, list) and len(sf) == 1):
            errs.append(f'source_frames={sf}')
        elif sf[0] != case['source']:
            errs.append(f'source_frames[0] {sf[0]} != case source')
        if job.get('repeats') != 1 + W + M:
            errs.append(f'repeats={job.get("repeats")} != {1 + W + M}')
        if job.get('template') != case['template']:
            errs.append('template differs from case')
        for k in ('scales', 'angle', 'limit', 'score', 'overlap', 'stop_layer'):
            if job.get(k) != case.get(k):
                errs.append(f'{k} {job.get(k)} != case {case.get(k)}')
        if bool(job.get('subpixel')) != bool(case.get('subpixel')):
            errs.append('subpixel differs from case')
        if job.get('refine') is not refine_case:
            errs.append(f'refine={job.get("refine")} but workflow={case.get("workflow")}')
        if 'proposal_score' in case and job.get('proposal_score') != case['proposal_score']:
            errs.append('proposal_score differs from case')
        for k, v in man['method_options'][method].items():
            if job.get(k) != v:
                errs.append(f'{k}={job.get(k)} != method option {v}')
        if method == 'full_gpu_simd':
            if not (job.get('full_gpu') is True and job.get('full_gpu_peak_mode') == 1
                    and job.get('full_gpu_fine_mode') == 4):
                errs.append('full_gpu_simd is not full_gpu peak 1 fine 4')
        elif method == 'full_gpu_parallel':
            if not (job.get('full_gpu') is True and job.get('full_gpu_peak_mode') == 2
                    and job.get('full_gpu_peak_batch') == 8 and job.get('full_gpu_fine_mode') == 4):
                errs.append('full_gpu_parallel is not full_gpu peak 2 batch 8 fine 4')
        elif method == 'hybrid_best':
            if not (job.get('full_gpu') is False and job.get('coarse_peak_mode') == 1):
                errs.append('hybrid_best is not CPU/Metal hybrid with coarse_peak_mode 1')
        if bool(job.get('full_gpu_profiling', False)) != (phase == 'profile'):
            errs.append(f'full_gpu_profiling={job.get("full_gpu_profiling")} in phase {phase}')
        mode_eff = job.get('sequence_mode', 'reuse')
        gap_eff = job.get('sequence_gap', 'decode')
        if mode_eff != spec['mode']:
            errs.append(f'sequence_mode {mode_eff} != spec {spec["mode"]}')
        if gap_eff != spec['gap']:
            errs.append(f'sequence_gap {gap_eff} != spec {spec["gap"]}')
        if spec['mode'] == 'static' and job.get('sequence_mode') != 'static':
            errs.append('static job without sequence_mode static')
        if spec['mode'] == 'reuse' and spec['gap'] == 'decode' and 'sequence_gap' in job:
            errs.append('reuse+decode job carries a sequence_gap key')
        if spec['gap'] == 'sleep':
            if job.get('sequence_gap_sleep_ms') != spec['sleep_ms']:
                errs.append(f'sequence_gap_sleep_ms {job.get("sequence_gap_sleep_ms")} != {spec["sleep_ms"]}')
        elif 'sequence_gap_sleep_ms' in job:
            errs.append('sequence_gap_sleep_ms present for a non-sleep arm')
        job_key_patterns[f'{spec["mode"]}_{spec["gap"]}'].add(
            json.dumps({k: job[k] for k in ('sequence_mode', 'sequence_gap', 'sequence_gap_sleep_ms') if k in job},
                       sort_keys=True))
        for x in errs:
            job_fail.append(f'{tag}: {x}')

        # top-level worker output
        runs = res.get('runs') or []
        top_errs = []
        if res.get('sequence_mode') != spec['mode']:
            top_errs.append(f'result sequence_mode {res.get("sequence_mode")}')
        if res.get('sequence_gap') != spec['gap']:
            top_errs.append(f'result sequence_gap {res.get("sequence_gap")}')
        exp_sleep = spec['sleep_ms'] if spec['gap'] == 'sleep' else None
        if res.get('sequence_gap_sleep_ms') != exp_sleep:
            top_errs.append(f'result sequence_gap_sleep_ms {res.get("sequence_gap_sleep_ms")} != {exp_sleep}')
        if res.get('exact_sequence_repeat') is not True:
            top_errs.append('result exact_sequence_repeat is not true')
        if res.get('drained') is not True:
            top_errs.append('result drained is not true')
        if res.get('calls') != 1 + W + M or len(runs) != 1 + W + M:
            top_errs.append(f'calls={res.get("calls")} rows={len(runs)} != {1 + W + M}')
        if res.get('source_frames') != job.get('source_frames'):
            top_errs.append('result source_frames differ from the job')
        for x in top_errs:
            seq_fail.append(f'{tag}: {x}')

        rows = []
        truths = case['truth']
        for idx, row in enumerate(runs):
            r = extract_row(row)
            rows.append(r)
            # ground truth on every row
            g = gt_match(row.get('matches') or [], truths, model['pos_tol'], model['ang_tol'], model['rel_scale'])
            r['gt'] = (g['tp'], g['fp'], g['fn'])
            gt_tot['rows'] += 1
            gt_tot['tp'] += g['tp']
            gt_tot['fp'] += g['fp']
            gt_tot['fn'] += g['fn']
            gt_tot['predictions'] += g['tp'] + g['fp']
            gt_tot['truths'] += g['tp'] + g['fn']
            gt_amb['ambiguous_predictions'] += g['ambiguous_preds']
            gt_amb['ambiguous_truths'] += g['ambiguous_truths']
            for k in ('max_pos', 'max_ang', 'max_scale'):
                gt_max[k] = max(gt_max[k], g[k])
            ag = arm_gt[(c, arm)]
            ag['counts'].add((g['tp'], g['fp'], g['fn']))
            ag['rows'] += 1
            for k in ('max_pos', 'max_ang', 'max_scale'):
                ag[k] = max(ag[k], g[k])
            if g['fp'] or g['fn']:
                ag['fail_rows'] += 1
                gt_fail.append(f'{tag} call {idx}: TP {g["tp"]} FP {g["fp"]} FN {g["fn"]}')
            # sequence / gap contract
            if r['call'] != idx:
                seq_fail.append(f'{tag} row {idx}: call={r["call"]}')
            if r['sequence_gap'] != spec['gap']:
                seq_fail.append(f'{tag} row {idx}: row sequence_gap {r["sequence_gap"]}')
            gap_ms = r['m']['gap_ms']
            dec_ms = r['m']['source_decode_ms']
            if idx == 0:
                if gap_ms != 0 or dec_ms != 0 or r['source_generation'] != 0:
                    seq_fail.append(f'{tag} cold row: gap {gap_ms} decode {dec_ms} gen {r["source_generation"]}')
                continue
            if spec['mode'] == 'static':
                if r['source_generation'] != 0:
                    seq_fail.append(f'{tag} row {idx}: static source_generation {r["source_generation"]}')
                if r['source_copy_bytes'] != 0:
                    seq_fail.append(f'{tag} row {idx}: static source_copy_bytes {r["source_copy_bytes"]}')
                if r['pose_invalidated'] is not False:
                    seq_fail.append(f'{tag} row {idx}: static pose_invalidated {r["pose_invalidated"]}')
                if method == 'hybrid_best' and refine_case and r['m']['pose_create_ms'] != 0:
                    seq_fail.append(f'{tag} row {idx}: static hybrid pose_create_ms {r["m"]["pose_create_ms"]}')
            else:
                if r['source_generation'] != idx:
                    seq_fail.append(f'{tag} row {idx}: reuse source_generation {r["source_generation"]} != call')
                if method == 'hybrid_best' and refine_case and not (r['m']['pose_create_ms'] > 0):
                    seq_fail.append(f'{tag} row {idx}: reuse hybrid pose_create_ms {r["m"]["pose_create_ms"]}')
            info_seq[f'{method}/{spec["mode"]}'][f'copy_bytes={r["source_copy_bytes"]}'] += 1
            info_seq[f'{method}/{spec["mode"]}'][f'pose_invalidated={r["pose_invalidated"]}'] += 1
            info_seq[f'{method}/{spec["mode"]}'][f'source_update_ms>0={r["m"]["source_update_ms"] > 0}'] += 1
            if spec['gap'] == 'decode':
                if not (dec_ms is not None and dec_ms > 0):
                    seq_fail.append(f'{tag} row {idx}: decode gap with source_decode_ms {dec_ms}')
                info_seq['decode']['gap_ms>=decode_ms' if gap_ms >= dec_ms else 'gap_ms<decode_ms'] += 1
                if dec_ms is not None:
                    upd('decode_ms_min', dec_ms, min)
                    upd('decode_ms_max', dec_ms, max)
            elif spec['gap'] == 'sleep':
                s = spec['sleep_ms']
                if not (s <= gap_ms <= s + model['sleep_slack_ms']):
                    seq_fail.append(f'{tag} row {idx}: sleep gap {gap_ms} outside [{s}, {s + 50}]')
                if dec_ms != 0:
                    seq_fail.append(f'{tag} row {idx}: sleep gap with decode {dec_ms}')
                upd('sleep_gap_minus_sleep_ms_min', gap_ms - s, min)
                upd('sleep_gap_minus_sleep_ms_max', gap_ms - s, max)
            else:
                upd('nogap_gap_ms_max', gap_ms, max)
                if not (gap_ms <= model['nogap_max_ms']):
                    seq_fail.append(f'{tag} row {idx}: no-gap gap_ms {gap_ms} > 1')
                if dec_ms != 0:
                    seq_fail.append(f'{tag} row {idx}: no-gap row with decode {dec_ms}')
            # requested algorithm / route (best effort, every row)
        for idx, r in enumerate(rows):
            rt = r['route']
            errs = []
            if method in ('full_gpu_simd', 'full_gpu_parallel'):
                exp_peak = 1 if method == 'full_gpu_simd' else 2
                exp_batch = 1 if method == 'full_gpu_simd' else 8
                if rt['fg_enabled'] is not True:
                    errs.append('requested_algorithm: full_gpu not enabled')
                if rt['fg_peak_mode'] != exp_peak:
                    errs.append(f'requested_algorithm: peak_mode {rt["fg_peak_mode"]}')
                if rt['fg_fine_mode'] != 4 or rt['fg_fine_effective_mode'] != 4:
                    errs.append(f'requested_algorithm: fine {rt["fg_fine_mode"]}/{rt["fg_fine_effective_mode"]}')
                if rt['fg_peak_batch_maps'] != exp_batch:
                    errs.append(f'requested_algorithm: peak_batch_maps {rt["fg_peak_batch_maps"]}')
                if rt['fg_device_timestamp_available'] is not True:
                    errs.append('device_timestamp_unavailable')
                if (rt['fg_intermediate_readbacks'] != 0 or rt['fg_cpu_algorithm_steps'] != 0
                        or rt['n_work'] != 0 or rt['fg_command_buffers'] != 1 or rt['fg_cpu_waits'] != 1):
                    errs.append('route_and_residency(best effort): '
                                f'cb {rt["fg_command_buffers"]} waits {rt["fg_cpu_waits"]} '
                                f'readbacks {rt["fg_intermediate_readbacks"]} cpu_steps {rt["fg_cpu_algorithm_steps"]} '
                                f'work {rt["n_work"]}')
                if rt['fg_profile_requested'] is not (phase == 'profile'):
                    errs.append(f'requested_algorithm: profile_requested {rt["fg_profile_requested"]}')
                if phase == 'profile' and rt['fg_profile_available'] is not True:
                    errs.append('profile requested but not available')
            else:
                if rt['fg_enabled'] is not False:
                    errs.append('requested_algorithm: hybrid row ran full_gpu')
                if rt['n_work'] != len(case['scales']):
                    errs.append(f'route(best effort): {rt["n_work"]} coarse work models for {len(case["scales"])} scales')
                if not rt['work_device_ok']:
                    errs.append('device_timestamp_unavailable: coarse device_ms missing')
                if refine_case and (rt['selected_refinement_backend'] != rt['configured_refinement_backend']
                                    or rt['configured_refinement_backend'] != 1):
                    errs.append(f'requested_algorithm: refinement backend {rt["selected_refinement_backend"]}'
                                f'/{rt["configured_refinement_backend"]}')
                if refine_case and not (r['m']['refinement_device_ms'] and r['m']['refinement_device_ms'] > 0):
                    errs.append('device_timestamp_unavailable: refinement_device_ms not positive')
            for x in errs:
                route_fail.append(f'{tag} row {idx}: {x}')
            if phase == 'profile' and r['stages'] and r['profile_gpu_ms'] is not None:
                prof_sum_diff = max(prof_sum_diff, abs(sum(r['stages'].values()) - r['profile_gpu_ms']))
        warm_ms = rows[W]['elapsed_ms'] - rows[0]['elapsed_ms'] if len(rows) > W else None
        if warm_ms is None or warm_ms < model['warmup_gate_ms']:
            warm_fail.append(f'{tag}: warm-up wall {warm_ms} ms < 1000')
        arm_rows[(c, arm)][b] = rows
        arm_proc[(c, arm)][b] = {
            'warmup_wall_ms': warm_ms,
            'final_peak_rss': (res.get('final_memory') or {}).get('peak_rss_bytes'),
            'max_row_peak_rss': max((r['peak_rss'] or 0) for r in rows),
            'after_release_peak_rss': (res.get('after_release_memory') or {}).get('peak_rss_bytes'),
            'host': e['host'],
        }

    integ['jobs_hashed'] = len(ex_list)
    integ['job_sha256_mismatches'] = job_bad
    integ['result_sha256_mismatches'] = res_bad
    integ['stdout_differs_from_result'] = stdout_diff
    integ['stderr_nonempty'] = stderr_nonempty
    if job_bad or res_bad:
        failures.append(f'{phase}: {len(job_bad)} job and {len(res_bad)} result SHA256 mismatch(es)')
    if stdout_diff:
        notes.append(f'{phase}: {len(stdout_diff)} result file(s) differ from the captured stdout')
    if stderr_nonempty:
        notes.append(f'{phase}: {len(stderr_nonempty)} non-empty stderr file(s)')
    integ['pass'] = not any(f.startswith(f'{phase}:') for f in failures)
    out['integrity'] = integ

    # jobs identical across blocks; arms of a method differ only in sequence keys
    seq_keys = {'sequence_mode', 'sequence_gap', 'sequence_gap_sleep_ms'}
    for c in cases:
        by_method = defaultdict(list)
        for arm in man['arms'][c]:
            js = [jobs_by.get((c, arm, b)) for b in range(B)]
            if any(j != js[0] for j in js):
                job_fail.append(f'{c}/{arm}: job differs between blocks')
            by_method[man['arm_specs'][c][arm]['method']].append(js[0])
        for meth, js in by_method.items():
            base = {k: v for k, v in js[0].items() if k not in seq_keys}
            for j in js[1:]:
                if {k: v for k, v in j.items() if k not in seq_keys} != base:
                    job_fail.append(f'{c}/{meth}: arms differ outside the sequence keys')
    order['job_failures'] = job_fail
    order['other_failures'] = oj_fail
    order['jobs_checked'] = len(jobs_by)
    order['job_sequence_key_patterns'] = {k: sorted(v) for k, v in job_key_patterns.items()}
    order['pass'] = not job_fail and not oj_fail
    if not order['pass']:
        failures.extend(f'{phase}: order/jobs: {x}' for x in oj_fail + job_fail)
    out['order_and_jobs'] = order

    # ------------------------------------------------------ ground truth
    gtr = {'rows_evaluated': gt_tot['rows'], 'predictions': gt_tot['predictions'],
           'truths': gt_tot['truths'], 'true_positives': gt_tot['tp'],
           'false_positives': gt_tot['fp'], 'false_negatives': gt_tot['fn'],
           'max_position_error_px': gt_max['max_pos'], 'max_angle_error_deg': gt_max['max_ang'],
           'max_relative_scale_error': gt_max['max_scale'],
           'ambiguous_predictions_with_more_than_one_truth_candidate': gt_amb['ambiguous_predictions'],
           'ambiguous_truths_with_more_than_one_prediction_candidate': gt_amb['ambiguous_truths'],
           'thresholds': {'position_px': model['pos_tol'], 'angle_deg': model['ang_tol'],
                          'relative_scale': model['rel_scale']},
           'failures': gt_fail}
    gtr['pass'] = not gt_fail
    if gt_fail:
        failures.append(f'{phase}: {len(gt_fail)} ground-truth row failure(s)')
    out['ground_truth'] = gtr

    # ------------------------------------------------------ recompute
    def method_metrics(method):
        return model['metrics_hybrid'] if method == 'hybrid_best' else model['metrics_gpu']

    arm_rec = {}
    for (c, arm), blocks in arm_rows.items():
        spec = man['arm_specs'][c][arm]
        W = Wof[c]
        metrics = method_metrics(spec['method'])
        pooled = {}
        per_block = {}
        for metric in metrics + ['gap_ms', 'source_decode_ms']:
            vals = []
            pb = []
            for b in range(B):
                bv = [row_metric(r, metric) for r in blocks[b][W + 1:W + 1 + M]]
                vals.extend(bv)
                pb.append(median(bv) if all(v is not None for v in bv) else None)
            if any(v is None for v in vals):
                pooled[metric] = None
            else:
                pooled[metric] = stats(vals)
            per_block[metric] = pb
        cur_rss = []
        for b in range(B):
            cur_rss.extend(r['current_rss'] for r in blocks[b][W + 1:W + 1 + M])
        arm_rec[(c, arm)] = {'pooled': pooled, 'per_block': per_block, 'current_rss': stats(cur_rss),
                             'spec': spec}

    def eff(c, method, arm_cond, base_cond, metric):
        a = arm_rec[(c, f'{method}__{arm_cond}')]
        z = arm_rec[(c, f'{method}__{base_cond}')]
        am, bm = a['pooled'][metric]['median'], z['pooled'][metric]['median']
        delta = am - bm
        paired = [{'block': b, 'delta_ms': a['per_block'][metric][b] - z['per_block'][metric][b]} for b in range(B)]
        return {'baseline_ms': bm, 'arm_ms': am, 'delta_ms': delta,
                'delta_percent': (100.0 * delta / bm) if bm != 0 else None,
                'paired': paired, 'direction': direction(delta, [p['delta_ms'] for p in paired])}

    effects = {}
    attribution = {}
    if phase in ('pilot', 'formal', 'profile'):
        for c in cases:
            effects[c] = {}
            attribution[c] = {}
            for method in exp_cases[c]:
                effects[c][method] = {}
                for cname, (ac, bc) in model['contrasts'].items():
                    effects[c][method][cname] = {m: eff(c, method, ac, bc, m) for m in method_metrics(method)}
                e_ = effects[c][method]
                r41 = e_['round41']['total_ms']['delta_ms']
                upd = e_['update']['total_ms']['delta_ms']
                dec = e_['decode_gap']['total_ms']['delta_ms']
                attribution[c][method] = {'round41_ms': r41, 'update_ms': upd, 'decode_gap_ms': dec,
                                          'sum_update_and_decode_gap_ms': upd + dec,
                                          'residual_ms': r41 - (upd + dec),
                                          'pose_create_ms': e_['update']['pose_create_ms']['delta_ms']}

    dose = {}
    if phase == 'dose':
        for c in cases:
            dose[c] = {}
            for method in exp_cases[c]:
                metric = 'coarse_device_ms' if method == 'hybrid_best' else 'device_ms'
                levels = model['dose_levels']
                arms_l = [f'{method}__static_none' if lv == 0 else f'{method}__static_sleep{lv}' for lv in levels]
                mstats = [arm_rec[(c, a)]['pooled'][metric] for a in arms_l]
                tstats = [arm_rec[(c, a)]['pooled']['total_ms'] for a in arms_l]
                meds = [s['median'] for s in mstats]
                dose[c][method] = {
                    'levels_ms': levels, 'metric': metric, metric: mstats, 'total_ms': tstats,
                    'monotone_nondecreasing': all(x <= y for x, y in zip(meds, meds[1:])),
                    'total_ms_monotone_nondecreasing': all(x['median'] <= y['median'] for x, y in zip(tstats, tstats[1:])),
                    'top_vs_none': eff(c, method, f'static_sleep{levels[-1]}', 'static_none', metric),
                    'top_vs_none_total_ms': eff(c, method, f'static_sleep{levels[-1]}', 'static_none', 'total_ms'),
                }

    profile_stages = {}
    if phase == 'profile':
        for (c, arm), blocks in arm_rows.items():
            W = Wof[c]
            names = sorted({n for b in range(B) for r in blocks[b] for n in r['stages']})
            all_rows = {n: [] for n in names}
            meas = {n: [] for n in names}
            avail = 0
            for b in range(B):
                for i, r in enumerate(blocks[b]):
                    if r['route']['fg_profile_available']:
                        avail += 1
                    for n in names:
                        if n in r['stages']:
                            all_rows[n].append(r['stages'][n])
                            if W + 1 <= i < W + 1 + M:
                                meas[n].append(r['stages'][n])
            profile_stages[(c, arm)] = {'all_rows': {n: stats(v) for n, v in all_rows.items()},
                                        'measured_only': {n: stats(v) for n, v in meas.items()},
                                        'profile_available_calls': avail}

    # ------------------------------------------------------ verdicts
    verdicts = None
    if phase in ('pilot', 'formal'):
        c128, c512, c8k = model['case_order']

        def up(c, method, contrast, metric):
            return effects[c][method][contrast][metric]['direction'] == 'up'
        r41 = {'hybrid_128_total': up(c128, 'hybrid_best', 'round41', 'total_ms'),
               'hybrid_512_total': up(c512, 'hybrid_best', 'round41', 'total_ms'),
               'full_gpu_8k_device': up(c8k, 'full_gpu_simd', 'round41', 'device_ms')}
        sl = {'hybrid_512_coarse': up(c512, 'hybrid_best', 'sleep_gap', 'coarse_device_ms'),
              'full_gpu_8k_device': up(c8k, 'full_gpu_simd', 'sleep_gap', 'device_ms')}
        dc = {'hybrid_512_coarse': up(c512, 'hybrid_best', 'decode_gap', 'coarse_device_ms'),
              'full_gpu_8k_device': up(c8k, 'full_gpu_simd', 'decode_gap', 'device_ms')}
        if all(sl.values()):
            h1 = 'supported'
        elif all(dc.values()) and not any(sl.values()):
            h1 = 'decode_only'
        elif not any(sl.values()) and not any(dc.values()):
            h1 = 'rejected'
        else:
            h1 = 'mixed'

        def h23(metric):
            u = up(c512, 'hybrid_best', 'update', metric)
            g = up(c512, 'hybrid_best', 'decode_gap', metric) or up(c512, 'hybrid_best', 'sleep_gap', metric)
            v = 'rejected' if not u else ('confounded' if g else 'supported')
            return v, {'update': u, 'gap': g}

        def h4(method):
            u = up(c8k, method, 'update', 'device_ms')
            g = up(c8k, method, 'sleep_gap', 'device_ms') or up(c8k, method, 'decode_gap', 'device_ms')
            v = 'both' if (u and g) else ('update' if u else ('gap' if g else 'neither'))
            return v, {'update': u, 'gap': g}
        h2v, h2i = h23('refinement_device_ms')
        h3v, h3i = h23('prepare_ms')
        h4v, h4i = h4('full_gpu_simd')
        s1v, s1i = h4('full_gpu_parallel')
        verdicts = {
            'round41_reproduced': {'reproduced': all(r41.values()), 'inputs': r41},
            'H1_gap_slows_first_gpu_stage': {'verdict': h1, 'inputs': {'sleep': sl, 'decode': dc}},
            'H2_new_pose_buffers_slow_refinement': {'verdict': h2v, 'inputs': h2i},
            'H3_new_source_slows_frame_prepare': {'verdict': h3v, 'inputs': h3i},
            'H4_8k_full_gpu_attribution': {'verdict': h4v, 'inputs': h4i},
            'S1_8k_peak2_attribution': {'verdict': s1v, 'inputs': s1i},
        }

    # ------------------------------------------------------ exactness
    exact = {'within_arm_failures': [], 'cross_arm_failures': [], 'peak2_vs_peak1_failures': []}
    refs = {}
    calls_compared = 0
    for (c, arm), blocks in arm_rows.items():
        ref = (blocks[0][0]['mhash'], blocks[0][0]['phash'])
        refs[(c, arm)] = ref
        for b in range(B):
            for i, r in enumerate(blocks[b]):
                calls_compared += 1
                if (r['mhash'], r['phash']) != ref:
                    exact['within_arm_failures'].append(f'{c}/{arm}/b{b} call {i}')
    for c in cases:
        by_method = defaultdict(list)
        for arm in man['arms'][c]:
            by_method[man['arm_specs'][c][arm]['method']].append(arm)
        for meth, arms in by_method.items():
            r0 = refs[(c, arms[0])]
            for a in arms[1:]:
                if refs[(c, a)] != r0:
                    exact['cross_arm_failures'].append(f'{c}/{a} != {c}/{arms[0]}')
        if 'full_gpu_parallel' in by_method and 'full_gpu_simd' in by_method:
            simd_ref = refs[(c, by_method['full_gpu_simd'][0])]
            for a in by_method['full_gpu_parallel']:
                for b in range(B):
                    for i, r in enumerate(arm_rows[(c, a)][b]):
                        if (r['mhash'], r['phash']) != simd_ref:
                            exact['peak2_vs_peak1_failures'].append(f'{c}/{a}/b{b} call {i}')
            exact.setdefault('peak2_vs_peak1_compared_cases', []).append(c)
    exact['calls_compared'] = calls_compared
    exact['reference_hashes'] = {f'{c}/{a}': {'matches_sha256': h[0], 'proposals_sha256': h[1]}
                                 for (c, a), h in refs.items()}
    exact['pass'] = not (exact['within_arm_failures'] or exact['cross_arm_failures']
                         or exact['peak2_vs_peak1_failures'])
    if not exact['pass']:
        failures.append(f'{phase}: exactness failures within {len(exact["within_arm_failures"])}, '
                        f'cross {len(exact["cross_arm_failures"])}, peak2 {len(exact["peak2_vs_peak1_failures"])}')
    out['exactness'] = exact

    # ------------------------------------------------------ sequence
    seqr = {'failures': seq_fail, 'warmup_failures': warm_fail,
            'warmup_wall_ms_min': min(p['warmup_wall_ms'] for v in arm_proc.values() for p in v.values()),
            'gap_margins': margins,
            'info_value_counts': {k: dict(v) for k, v in info_seq.items()}}
    seqr['pass'] = not seq_fail and not warm_fail
    if seq_fail or warm_fail:
        failures.append(f'{phase}: {len(seq_fail)} sequence/gap failure(s), {len(warm_fail)} warm-up failure(s)')
    out['sequence'] = seqr
    out['route_best_effort'] = {'failures': route_fail, 'pass': not route_fail,
                                'note': 'protocol names route_and_residency/requested_algorithm/'
                                        'device_timestamp gates without definitions; these checks '
                                        'compare row fields with the job request'}
    if phase == 'profile':
        out['route_best_effort']['max_abs_diff_stage_sum_vs_profile_gpu_ms'] = prof_sum_diff
    if route_fail:
        failures.append(f'{phase}: {len(route_fail)} route/requested-algorithm row failure(s)')

    # ------------------------------------------------------ host gates
    host = {'executions': []}
    derived = set()
    for e in ex_list:
        h = e['host']
        busy = bool(h.get('competing_processes'))
        load1 = h['load_average'][0]
        high = load1 > model['load_limit']
        host['executions'].append({'case': e['case'], 'arm': e['arm'], 'block': e['block'],
                                   'utc': h['utc'], 'load_1min': load1,
                                   'competing_processes': h.get('competing_processes'),
                                   'host_busy': busy, 'host_load_high': high})
        if busy:
            derived.add((e['case'], e['arm'], e['block'], 'host_busy'))
        if high:
            derived.add((e['case'], e['arm'], e['block'], 'host_load_high'))
    hb = man['host']['before']
    host['phase_start_host_quiet'] = (not hb.get('competing_processes')) and hb['load_average'][0] <= model['load_limit']
    if not host['phase_start_host_quiet']:
        failures.append(f'{phase}: phase started on a non-quiet host')
    # other gates derived from this audit
    other = set()
    for x in gt_fail:
        other.add(('independent_ground_truth', x.split(' call ')[0]))
    for x in exact['within_arm_failures']:
        other.add(('exact_repeat', x))
    for x in exact['cross_arm_failures']:
        other.add(('cross_arm_output_parity', x))
    for x in exact['peak2_vs_peak1_failures']:
        other.add(('peak2_equals_peak1', x))
    for x in warm_fail:
        other.add(('warmup_shorter_than_1s', x))
    for x in seq_fail:
        other.add(('gap_contract_or_sequence_route', x))
    for x in route_fail:
        other.add(('route_requested_algorithm_or_device_timestamp', x))
    pub_gates = {(g['case'], g['arm'], g['block'], g['gate']) for g in pub.get('failed_gates') or []}
    pub_host = {g for g in pub_gates if g[3] in ('host_busy', 'host_load_high')}
    pub_other = pub_gates - pub_host
    host['derived_host_gates'] = sorted([list(g) for g in derived])
    host['published_host_gates'] = sorted([list(g) for g in pub_host])
    host['missing_from_published'] = sorted([list(g) for g in derived - pub_host])
    host['extra_in_published'] = sorted([list(g) for g in pub_host - derived])
    host['published_non_host_gates'] = sorted([list(g) for g in pub_other])
    host['derived_non_host_gate_failures'] = sorted([list(g) for g in other])
    host['host_gates_match'] = derived == pub_host
    host['non_host_gates_match'] = (not pub_other) and (not other)
    host['pass'] = host['host_gates_match'] and host['non_host_gates_match']
    if not host['host_gates_match']:
        failures.append(f'{phase}: host gates differ from published failed_gates')
    if pub_other and not other:
        failures.append(f'{phase}: published non-host gate failures not reproduced: {sorted(pub_other)}')
    out['host_gates'] = host

    # ------------------------------------------------------ counts
    n_proc = len(ex_list)
    warm_calls = sum(Wof[e['case']] for e in ex_list)
    meas_calls = M * n_proc
    rows_total = sum(len(rows) for blocks in arm_rows.values() for rows in blocks.values())
    counts = {'fresh_processes': n_proc, 'cold_calls': n_proc, 'warmup_calls': warm_calls,
              'measured_calls': meas_calls, 'gt_evaluated_calls': rows_total}
    pub_counts = pub.get('counts') or {}
    counts_match = all(pub_counts.get(k) == v for k, v in counts.items()) and set(pub_counts) == set(counts)
    out['counts'] = {'recomputed': counts, 'published': pub_counts, 'match': counts_match}
    if not counts_match:
        failures.append(f'{phase}: counts differ from published')

    # ------------------------------------------------------ comparisons
    cmp = Comparator()
    pcases = {pc['name']: pc for pc in pub.get('cases') or []}
    cmp.eq('phase', phase, pub.get('phase'))
    cmp.eq('profiling', phase == 'profile', pub.get('profiling'))
    cmp.eq('accuracy_thresholds', {'position_px': model['pos_tol'], 'angle_deg': model['ang_tol'],
                                   'relative_scale': model['rel_scale']}, pub.get('accuracy_thresholds'))
    cmp.eq('all_accuracy_pass', gtr['pass'], pub.get('all_accuracy_pass'))
    cmp.eq('all_repeat_exact', exact['pass'], pub.get('all_repeat_exact'))
    cmp.eq('all_routes_pass', not route_fail, pub.get('all_routes_pass'), 'inferred_definition')
    cmp.eq('case_names', sorted(cases), sorted(pcases))
    for c in cases:
        pc = pcases.get(c)
        if pc is None:
            continue
        base = f'cases[{c}]'
        cmp.eq(base + '.truth_count', len(cases[c]['truth']), pc.get('truth_count'))
        cmp.eq(base + '.refine', cases[c].get('workflow') == 'full_rescue', pc.get('refine'))
        cmp.eq(base + '.warmup_calls', Wof[c], pc.get('warmup_calls'))
        cmp.eq(base + '.sleep_ms', man['sleep_ms'][c], pc.get('sleep_ms'))
        cmp.eq(base + '.arm_names', list(man['arms'][c]), list((pc.get('arms') or {}).keys()))
        for arm in man['arms'][c]:
            pa = (pc.get('arms') or {}).get(arm)
            if pa is None:
                continue
            ab = f'{base}.arms[{arm}]'
            rec = arm_rec[(c, arm)]
            spec = man['arm_specs'][c][arm]
            W = Wof[c]
            cmp.eq(ab + '.spec', spec, pa.get('spec'))
            mlist = method_metrics(spec['method'])
            cmp.eq(ab + '.metric_names', mlist, list((pa.get('metrics') or {}).keys()))
            for metric in mlist:
                cat = metric_category(metric)
                cmp.stats(f'{ab}.metrics.{metric}', rec['pooled'][metric], (pa.get('metrics') or {}).get(metric), cat)
            cmp.stats(f'{ab}.gap_ms', rec['pooled']['gap_ms'], pa.get('gap_ms'), 'protocol')
            cmp.stats(f'{ab}.source_decode_ms', rec['pooled']['source_decode_ms'], pa.get('source_decode_ms'),
                      'inferred_definition')
            cmp.stats(f'{ab}.measured_current_rss_bytes', rec['current_rss'], pa.get('measured_current_rss_bytes'),
                      'inferred_definition')
            pblocks = pa.get('blocks') or []
            cmp.eq(ab + '.blocks.length', B, len(pblocks))
            for b in range(min(B, len(pblocks))):
                pbk = pblocks[b]
                bb = f'{ab}.blocks[{b}]'
                cmp.eq(bb + '.block', b, pbk.get('block'))
                cmp.eq(bb + '.warmup_calls', W, pbk.get('warmup_calls'))
                cmp.num(bb + '.warmup_wall_ms', arm_proc[(c, arm)][b]['warmup_wall_ms'], pbk.get('warmup_wall_ms'))
                for metric in mlist:
                    cmp.num(f'{bb}.medians.{metric}', rec['per_block'][metric][b],
                            (pbk.get('medians') or {}).get(metric), metric_category(metric))
                pr = arm_proc[(c, arm)][b]
                cand = {'final_memory.peak_rss_bytes': pr['final_peak_rss'],
                        'max(row memory.peak_rss_bytes)': pr['max_row_peak_rss'],
                        'after_release_memory.peak_rss_bytes': pr['after_release_peak_rss']}
                hit = [k for k, v in cand.items() if v == pbk.get('peak_rss_bytes')]
                cmp.count += 1
                glob['peak_rss_definitions']['blocks'] += 1
                if not hit:
                    cmp._add(bb + '.peak_rss_bytes', cand, pbk.get('peak_rss_bytes'), 'inferred_definition',
                             'no candidate definition matched')
                else:
                    glob['peak_rss_definitions'].update(hit)
            blk_peaks = [pbk.get('peak_rss_bytes') for pbk in pblocks]
            cmp.num(ab + '.peak_rss_bytes(max of block values)', max(blk_peaks) if blk_peaks else None,
                    pa.get('peak_rss_bytes'), 'inferred_definition')
            # memory scopes
            rows_all = [r for b in range(B) for r in arm_rows[(c, arm)][b]]
            rows_meas = [r for b in range(B) for r in arm_rows[(c, arm)][b][W + 1:W + 1 + M]]
            if spec['method'] == 'hybrid_best':
                cand_named, cand_frame, cand_pose = None, sorted({r['frame_gpu_bytes'] for r in rows_meas}), \
                    sorted({r['pose_gpu_bytes'] for r in rows_meas})
            else:
                cand_named, cand_frame, cand_pose = sorted({r['gpu_bytes'] for r in rows_meas}), None, None
            cmp.eq(ab + '.named_gpu_bytes', cand_named, pa.get('named_gpu_bytes'), 'inferred_definition')
            cmp.eq(ab + '.frame_gpu_bytes', cand_frame, pa.get('frame_gpu_bytes'), 'inferred_definition')
            cmp.eq(ab + '.pose_gpu_bytes', cand_pose, pa.get('pose_gpu_bytes'), 'inferred_definition')
            # accuracy
            ag = arm_gt[(c, arm)]
            cmp.eq(ab + '.all_gt_pass', ag['fail_rows'] == 0, pa.get('all_gt_pass'))
            cmp.eq(ab + '.accuracy_counts', sorted([list(x) for x in ag['counts']]),
                   sorted(pa.get('accuracy_counts') or []))
            me = pa.get('max_errors') or {}
            cmp.num(ab + '.max_errors.position_px', ag['max_pos'], me.get('position_px'), 'inferred_definition')
            cmp.num(ab + '.max_errors.angle_deg', ag['max_ang'], me.get('angle_deg'), 'inferred_definition')
            cmp.num(ab + '.max_errors.relative_scale', ag['max_scale'], me.get('relative_scale'), 'inferred_definition')
            tag_prefix = f'{c}/{arm}/'
            arm_seq_fail = any(x.startswith(tag_prefix) for x in seq_fail + warm_fail)
            arm_gap_fail = any(x.startswith(tag_prefix) and ('gap' in x or 'decode' in x) for x in seq_fail)
            arm_route_fail = any(x.startswith(tag_prefix) for x in route_fail)
            arm_alg_fail = any(x.startswith(tag_prefix) and 'requested_algorithm' in x for x in route_fail)
            arm_rep_fail = any(x.startswith(tag_prefix) for x in exact['within_arm_failures'])
            cmp.eq(ab + '.sequence_route_valid', not arm_seq_fail, pa.get('sequence_route_valid'))
            cmp.eq(ab + '.gap_contract_valid', not arm_gap_fail, pa.get('gap_contract_valid'))
            cmp.eq(ab + '.repeat_exact', not arm_rep_fail, pa.get('repeat_exact'))
            cmp.eq(ab + '.route_valid', not arm_route_fail, pa.get('route_valid'), 'inferred_definition')
            cmp.eq(ab + '.requested_algorithm_executed', not arm_alg_fail, pa.get('requested_algorithm_executed'),
                   'inferred_definition')
            cmp.eq(ab + '.cold_calls', B, pa.get('cold_calls'))
            cmp.eq(ab + '.warmup_calls', B * W, pa.get('warmup_calls'))
            cmp.eq(ab + '.measured_calls', B * M, pa.get('measured_calls'))
            cmp.eq(ab + '.gt_evaluated_calls', len(rows_all), pa.get('gt_evaluated_calls'))
            if phase == 'profile':
                ps = profile_stages[(c, arm)]
                pps = pa.get('profile_stages') or {}
                cmp.eq(ab + '.profile_stages.names', sorted(ps['all_rows']), sorted(pps))
                for n, st in ps['all_rows'].items():
                    cmp.stats(f'{ab}.profile_stages.{n}', st, pps.get(n), 'inferred_definition')
                cmp.eq(ab + '.profile_available_calls', ps['profile_available_calls'],
                       pa.get('profile_available_calls'), 'inferred_definition')
        # effects
        if phase in ('pilot', 'formal', 'profile'):
            pe = pc.get('effects') or {}
            cmp.eq(base + '.effects.methods', list(exp_cases[c]), list(pe.keys()))
            for method in exp_cases[c]:
                for cname in model['contrasts']:
                    for metric, mine in effects[c][method][cname].items():
                        p = ((pe.get(method) or {}).get(cname) or {}).get(metric)
                        eb = f'{base}.effects.{method}.{cname}.{metric}'
                        cat = metric_category(metric)
                        if p is None:
                            cmp.count += 1
                            cmp._add(eb, 'effect', None, cat, 'published effect missing')
                            continue
                        for k in ('baseline_ms', 'arm_ms', 'delta_ms', 'delta_percent'):
                            cmp.num(f'{eb}.{k}', mine[k], p.get(k), cat)
                        pp = p.get('paired') or []
                        cmp.eq(f'{eb}.paired.blocks', [x['block'] for x in mine['paired']], [x.get('block') for x in pp], cat)
                        cmp.seq(f'{eb}.paired.delta_ms', [x['delta_ms'] for x in mine['paired']],
                                [x.get('delta_ms') for x in pp], cat)
                        cmp.eq(f'{eb}.direction', mine['direction'], p.get('direction'), cat)
                pa_ = (pc.get('attribution') or {}).get(method) or {}
                for k, v in attribution[c][method].items():
                    cmp.num(f'{base}.attribution.{method}.{k}', v, pa_.get(k), 'inferred_definition')
        if phase == 'dose':
            pdz = pc.get('dose') or {}
            cmp.eq(base + '.dose.methods', list(exp_cases[c]), list(pdz.keys()))
            for method, mine in dose[c].items():
                p = pdz.get(method) or {}
                db = f'{base}.dose.{method}'
                cmp.eq(db + '.levels_ms', mine['levels_ms'], p.get('levels_ms'))
                cmp.eq(db + '.metric', mine['metric'], p.get('metric'))
                for key in (mine['metric'], 'total_ms'):
                    pl = p.get(key) or []
                    cmp.eq(f'{db}.{key}.length', len(mine[key]), len(pl))
                    for i, st in enumerate(mine[key]):
                        cmp.stats(f'{db}.{key}[{i}]', st, pl[i] if i < len(pl) else None)
                cmp.eq(db + '.monotone_nondecreasing', mine['monotone_nondecreasing'], p.get('monotone_nondecreasing'))
                tv = p.get('top_vs_none') or {}
                for k in ('baseline_ms', 'arm_ms', 'delta_ms', 'delta_percent'):
                    cmp.num(f'{db}.top_vs_none.{k}', mine['top_vs_none'][k], tv.get(k))
                cmp.seq(f'{db}.top_vs_none.paired.delta_ms', [x['delta_ms'] for x in mine['top_vs_none']['paired']],
                        [x.get('delta_ms') for x in tv.get('paired') or []])
                cmp.eq(f'{db}.top_vs_none.direction', mine['top_vs_none']['direction'], tv.get('direction'))
    # verdicts
    pub_h = pub.get('hypotheses')
    vcmp = {}
    if verdicts is None:
        cmp.eq('hypotheses', None, pub_h)
    else:
        for name, mine in verdicts.items():
            p = (pub_h or {}).get(name) or {}
            if 'reproduced' in mine:
                cmp.eq(f'hypotheses.{name}.reproduced', mine['reproduced'], p.get('reproduced'))
                vcmp[name] = {'recomputed': mine['reproduced'], 'published': p.get('reproduced')}
            else:
                cmp.eq(f'hypotheses.{name}.verdict', mine['verdict'], p.get('verdict'))
                vcmp[name] = {'recomputed': mine['verdict'], 'published': p.get('verdict')}
            cmp.eq(f'hypotheses.{name}.inputs', mine['inputs'], p.get('inputs'))
        extra_h = sorted(set(pub_h or {}) - set(verdicts))
        if extra_h:
            cmp.count += 1
            cmp._add('hypotheses.extra_published', [], extra_h, 'protocol')
    # failed gates as a whole
    cmp.eq('failed_gates(set)', sorted([list(g) for g in derived]), sorted([list(g) for g in pub_gates]))

    proto_mm = [m for m in cmp.mismatches if m['category'] == 'protocol']
    inf_mm = [m for m in cmp.mismatches if m['category'] != 'protocol']
    out['comparisons'] = {'numbers_and_fields_compared': cmp.count, 'tolerance': TOL,
                          'protocol_mismatches': proto_mm, 'inferred_definition_mismatches': inf_mm,
                          'mismatch_count': len(cmp.mismatches)}
    if proto_mm:
        failures.append(f'{phase}: {len(proto_mm)} protocol-defined value mismatch(es) with the published summary')

    # ------------------------------------------------------ recomputed (compact)
    rec_out = {}
    for (c, arm), rec in arm_rec.items():
        rec_out.setdefault(c, {})[arm] = {
            'pooled_median': {k: (v['median'] if v else None) for k, v in rec['pooled'].items()},
            'pooled_min_max': {k: ([v['min'], v['max']] if v else None) for k, v in rec['pooled'].items()},
            'block_medians': rec['per_block'],
            'warmup_wall_ms': [arm_proc[(c, arm)][b]['warmup_wall_ms'] for b in range(B)],
            'gt_counts_distinct': sorted([list(x) for x in arm_gt[(c, arm)]['counts']]),
        }
    out['recomputed'] = {'arms': rec_out}
    if effects:
        out['recomputed']['effects'] = effects
        out['recomputed']['attribution'] = attribution
    if dose:
        out['recomputed']['dose'] = {c: {m: {k: (v if not isinstance(v, list) or k == 'levels_ms'
                                                 else [s['median'] for s in v])
                                             for k, v in d.items()} for m, d in dd.items()}
                                     for c, dd in dose.items()}
    if profile_stages:
        prof = {}
        for (c, arm), ps in profile_stages.items():
            prof.setdefault(c, {})[arm] = {
                'profile_available_calls': ps['profile_available_calls'],
                'all_rows_median': {n: s['median'] for n, s in ps['all_rows'].items()},
                'measured_only_median': {n: s['median'] for n, s in ps['measured_only'].items()},
                'all_rows_values': len(next(iter(ps['all_rows'].values()))['values']) if ps['all_rows'] else 0,
                'measured_only_values': len(next(iter(ps['measured_only'].values()))['values']) if ps['measured_only'] else 0,
            }
        out['recomputed']['profile_stages'] = prof
        notes.append('profile: published profile_stages pool every call of each process '
                     '(cold + warm-up + measured), not measured calls only; recomputed both scopes')
    if verdicts is not None:
        # which flagged executions (published failed_gates) feed a verdict input
        c128, c512, c8k = model['case_order']
        feeds = {
            'round41_reproduced': [(c128, 'hybrid_best', 'round41'), (c512, 'hybrid_best', 'round41'),
                                   (c8k, 'full_gpu_simd', 'round41')],
            'H1_gap_slows_first_gpu_stage': [(c512, 'hybrid_best', 'sleep_gap'), (c512, 'hybrid_best', 'decode_gap'),
                                             (c8k, 'full_gpu_simd', 'sleep_gap'), (c8k, 'full_gpu_simd', 'decode_gap')],
            'H2_new_pose_buffers_slow_refinement': [(c512, 'hybrid_best', x) for x in ('update', 'sleep_gap', 'decode_gap')],
            'H3_new_source_slows_frame_prepare': [(c512, 'hybrid_best', x) for x in ('update', 'sleep_gap', 'decode_gap')],
            'H4_8k_full_gpu_attribution': [(c8k, 'full_gpu_simd', x) for x in ('update', 'sleep_gap', 'decode_gap')],
            'S1_8k_peak2_attribution': [(c8k, 'full_gpu_parallel', x) for x in ('update', 'sleep_gap', 'decode_gap')],
        }
        flagged = {(g[0], g[1]) for g in pub_gates}
        touch = {}
        for name, lst in feeds.items():
            arms_used = set()
            for c, meth, con in lst:
                ac, bc = model['contrasts'][con]
                arms_used.update({(c, f'{meth}__{ac}'), (c, f'{meth}__{bc}')})
            touch[name] = sorted([list(x) for x in arms_used & flagged])
        out['verdict_inputs_using_flagged_executions'] = touch
    out['verdicts_recomputed'] = verdicts
    out['verdicts_published'] = pub_h
    out['verdicts_comparison'] = vcmp
    out['verdicts_match'] = all(v['recomputed'] == v['published'] for v in vcmp.values()) if vcmp else (pub_h is None)
    out['published_flags'] = {k: pub.get(k) for k in ('formal_decision_eligible', 'all_accuracy_pass',
                                                     'all_routes_pass', 'all_repeat_exact', 'profiling')}
    if phase == 'formal' and pub.get('failed_gates'):
        notes.append(f'formal: published formal_decision_eligible={pub.get("formal_decision_eligible")} '
                     f'with {len(pub.get("failed_gates"))} failed host gate(s); the protocol does not '
                     'state what a failed host gate does to eligibility')
    out['failures'] = failures
    out['notes'] = notes
    out['pass'] = not failures
    out['seconds'] = round(time.time() - t0, 2)
    return out, {'effects': effects, 'refs': refs, 'man': man}


# ----------------------------------------------------------------- main
def main():
    if not os.path.isfile(PROTOCOL_PATH):
        sys.exit('run from the worktree root (protocol.json not found)')
    proto = load_json(PROTOCOL_PATH)
    model = parse_protocol(proto)
    report = {'independent': True, 'harness_imported': False, 'gpu_launched': False,
              'native_runner_launched': False, 'builds_or_tests_run': False,
              'generated_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'python': sys.version.split()[0], 'stdlib_only': True,
              'worktree': ROOT, 'protocol': os.path.relpath(PROTOCOL_PATH, ROOT)}
    global_failures = []
    global_notes = []

    # protocol and revision checks
    code, out, _ = git('rev-parse', proto['source']['frozen_commit'])
    frozen_full = out.decode().strip()
    pchk = {'frozen_commit': proto['source']['frozen_commit'], 'frozen_commit_full': frozen_full}
    rev = proto['revisions'][0]
    code, out, _ = git('log', '-1', '--format=%cI', '--', 'cpp-core/docs/stage48-frame-overheads/protocol.json')
    rev_commit_time = utc_parse(out.decode().strip())
    pchk['protocol_last_commit_time'] = rev_commit_time.isoformat()
    code, out, _ = git('log', '-1', '--format=%cI', frozen_full)
    frozen_time = utc_parse(out.decode().strip())
    pchk['frozen_commit_time'] = frozen_time.isoformat()
    # protocol semantic diff against the pre-registration commit
    code, out, _ = git('log', '--format=%H', '--diff-filter=A', '--',
                       'cpp-core/docs/stage48-frame-overheads/protocol.json')
    first = out.decode().split()[-1] if out.decode().split() else None
    code, prev_bytes, _ = git('show', f'{first}:cpp-core/docs/stage48-frame-overheads/protocol.json')
    prev = json.loads(prev_bytes) if code == 0 else {}

    def flat(o, pre=''):
        res = {}
        if isinstance(o, dict):
            for k, v in o.items():
                res.update(flat(v, f'{pre}.{k}' if pre else k))
        else:
            res[pre] = o
        return res
    fa, fb = flat(prev), flat(proto)
    diff_keys = sorted(k for k in set(fa) | set(fb) if fa.get(k) != fb.get(k))
    pchk['pre_registration_commit'] = first
    pchk['changed_keys_since_pre_registration'] = diff_keys
    allowed = {'source.frozen_commit', 'source.negative_controls', 'revisions'}
    pchk['only_revision_keys_changed'] = set(diff_keys) <= allowed
    if not pchk['only_revision_keys_changed']:
        global_failures.append(f'protocol keys changed beyond the revision: {sorted(set(diff_keys) - allowed)}')
    pchk['revision_previous_frozen_commit_matches_pre_registration'] = \
        prev.get('source', {}).get('frozen_commit') == rev.get('previous_frozen_commit')
    code, head_proto, _ = git('show', 'HEAD:cpp-core/docs/stage48-frame-overheads/protocol.json')
    pchk['worktree_protocol_equals_HEAD'] = head_proto == read_bytes(PROTOCOL_PATH)
    if not pchk['worktree_protocol_equals_HEAD']:
        global_failures.append('worktree protocol.json differs from HEAD')
    code, out, _ = git('diff', '--name-only', rev['previous_frozen_commit'], frozen_full)
    changed = [x for x in out.decode().splitlines() if x.strip()]
    measured_sources = set(load_json(os.path.join(STAGE, 'formal', 'manifest.json'))['source_sha256'])
    changed_measured = [x for x in changed if x in measured_sources]
    pchk['files_changed_previous_to_frozen_commit'] = changed
    pchk['measured_source_files_changed_previous_to_frozen_commit'] = changed_measured
    pchk['stage48_docs_changed_previous_to_frozen_commit'] = [
        x for x in changed if x.startswith('cpp-core/docs/stage48-frame-overheads/')]
    # the binary was built before the revision; only Python harness files may differ
    pchk['revision_changed_only_python_harness_files'] = all(x.endswith('.py') for x in changed_measured) and \
        all(x in measured_sources or x.startswith('cpp-core/docs/stage48-frame-overheads/') for x in changed)
    if not pchk['revision_changed_only_python_harness_files']:
        global_failures.append(f'measured sources changed between the previous and current frozen commit '
                               f'beyond Python harness files: {changed}')
    ss = load_json(os.path.join(DOCS, 'source-sha256.json'))
    pchk['source_sha256_json_commit_equals_frozen'] = ss.get('commit') == frozen_full
    if not pchk['source_sha256_json_commit_equals_frozen']:
        global_failures.append('source-sha256.json commit differs from the frozen commit')
    # snapshot archive vs source-sha256.json
    snap_bad = []
    with tarfile.open(os.path.join(DOCS, 'source-snapshot.tar.gz')) as t:
        members = {}
        for m in t.getmembers():
            if m.isfile():
                members[m.name] = sha256_bytes(t.extractfile(m).read())
    for p, h in ss['files'].items():
        if members.get(p) != h:
            snap_bad.append(p)
    extra_members = sorted(set(members) - set(ss['files']))
    pchk['snapshot_members'] = len(members)
    pchk['snapshot_vs_source_sha256_json_mismatches'] = snap_bad
    pchk['snapshot_members_not_in_source_sha256_json'] = extra_members
    if snap_bad:
        global_failures.append(f'{len(snap_bad)} snapshot member(s) differ from source-sha256.json')
    frozen_hashes = git_blob_hashes(frozen_full, sorted(ss['files']))
    fz_bad = [p for p, h in ss['files'].items() if frozen_hashes.get(p) != h]
    pchk['source_sha256_json_equals_frozen_commit_bytes'] = not fz_bad
    pchk['source_sha256_json_vs_frozen_commit_mismatches'] = fz_bad
    if fz_bad:
        global_failures.append(f'{len(fz_bad)} source-sha256.json entries differ from the frozen commit')
    report['protocol_checks'] = pchk

    # fixture provenance: truth and inputs against the stage-37/40 records
    fixtures = {}
    m_formal = load_json(os.path.join(STAGE, 'formal', 'manifest.json'))
    fx_man = load_json(m_formal['fixtures_manifest'])
    fx_cases = {c['name']: c for c in fx_man['cases']}
    arch = {}
    arch_path = os.path.join(ROOT, 'cpp-core', 'docs', 'stage40-ncc-closure', 'fixtures.tar.gz')
    with tarfile.open(arch_path) as t:
        for m in t.getmembers():
            if m.isfile() and m.name.endswith('.png'):
                arch[m.name] = sha256_bytes(t.extractfile(m).read())
    code, out, _ = git('rev-parse', '--path-format=absolute', '--git-common-dir')
    main_root = os.path.dirname(out.decode().strip().rstrip('/'))
    fixtures['main_repository_root'] = main_root
    fx_fail = []
    for c in m_formal['cases']:
        name = c['name']
        f = fx_cases.get(name)
        if f is None or f.get('truth') != c['truth']:
            fx_fail.append(f'{name}: truth differs from the stage-37 fixtures manifest')
        md = c.get('metadata')
        if md:
            mdj = load_json(md)
            if mdj.get('truth') != c['truth']:
                fx_fail.append(f'{name}: truth differs from scene metadata {md}')
            if mdj.get('source_png_sha256') != m_formal['input_sha256'].get(c['source']):
                fx_fail.append(f'{name}: metadata source_png_sha256 differs from the input hash')
            if mdj.get('object_count') != len(c['truth']):
                fx_fail.append(f'{name}: metadata object_count {mdj.get("object_count")} != {len(c["truth"])}')
    for p, h in m_formal['input_sha256'].items():
        rel = os.path.relpath(p, main_root)
        if arch.get(rel) != h:
            fx_fail.append(f'{rel}: not byte-identical in stage40-ncc-closure/fixtures.tar.gz')
        if fx_man['input_sha256'].get(p) != h:
            fx_fail.append(f'{rel}: differs from the stage-37 fixtures manifest input hash')
    fixtures['checked_cases'] = [c['name'] for c in m_formal['cases']]
    fixtures['inputs_checked_against_stage40_archive'] = sorted(m_formal['input_sha256'])
    fixtures['failures'] = fx_fail
    fixtures['pass'] = not fx_fail
    if fx_fail:
        global_failures.extend(fx_fail)
    report['fixture_provenance'] = fixtures

    # phases
    last_finished = max(utc_parse(load_json(os.path.join(STAGE, p, 'manifest.json'))['finished_utc'])
                        for p in PHASES)
    glob = {'frozen_commit_full': frozen_full, 'revision_commit_time': rev_commit_time,
            'snapshot_hashes': ss['files'], 'last_phase_finished': last_finished,
            'peak_rss_definitions': Counter()}
    report['phases'] = {}
    phase_aux = {}
    for phase in PHASES:
        print(f'auditing {phase} ...', flush=True)
        res, aux = audit_phase(phase, model, proto, glob)
        report['phases'][phase] = res
        phase_aux[phase] = aux
    # same binaries / sources across phases
    same_bin = all(phase_aux[p]['man']['binary_sha256'] == phase_aux['formal']['man']['binary_sha256'] for p in PHASES)
    same_src = all(phase_aux[p]['man']['source_sha256'] == phase_aux['formal']['man']['source_sha256'] for p in PHASES)
    for p in PHASES:
        report['phases'][p]['integrity']['binary_sha256_same_as_formal'] = \
            phase_aux[p]['man']['binary_sha256'] == phase_aux['formal']['man']['binary_sha256']
    cross = {'same_binaries_all_phases': same_bin, 'same_sources_all_phases': same_src}
    if not same_bin:
        global_failures.append('binary fingerprints differ between phases')
    if not same_src:
        global_failures.append('source fingerprints differ between phases')
    # informational: outputs identical across phases for the same case and method
    by_cm = defaultdict(set)
    for p in PHASES:
        for (c, arm), h in phase_aux[p]['refs'].items():
            by_cm[(c, arm.split('__')[0])].add(h)
    cross['outputs_identical_across_phases'] = {f'{c}/{m}': len(v) == 1 for (c, m), v in by_cm.items()}
    report['cross_phase'] = cross
    report['peak_rss_block_definition_hits'] = dict(glob['peak_rss_definitions'])

    # worktree state of the measured source files (same list in every phase)
    wt = report['phases']['formal']['integrity']['source']['worktree_differences']
    worktree_failures = []
    wt_rows = []
    for d in wt:
        explained = d['is_python'] and bool(d['later_commits_touching_file'])
        wt_rows.append({'path': d['path'], 'python': d['is_python'], 'explained_by_later_commit': explained,
                        'uncommitted_worktree_change': d['uncommitted_worktree_change'],
                        'head_and_frozen_commit_equal_manifest': d['head_equals_manifest']
                        and d['frozen_commit'] == d['manifest'],
                        'worktree_mtime_utc': d['worktree_mtime_utc'],
                        'modified_after_last_phase_finished': d['modified_after_last_phase_finished']})
        if not explained:
            worktree_failures.append(
                f'worktree file {d["path"]} differs from the measured hash without a later commit '
                f'(uncommitted edit, mtime {d["worktree_mtime_utc"]}; frozen-commit and HEAD bytes equal the manifest)')
    report['worktree_source_state'] = {'differences': wt_rows, 'failures': worktree_failures,
                                       'rule': 'Python harness files may differ only if later commits changed them'}

    # headline numbers for the reply
    f_eff = phase_aux['formal']['effects']
    headline = {}
    for c, mm in f_eff.items():
        for method, e in mm.items():
            headline[f'{c}/{method}'] = {
                'sleep_gap_total_ms': {'delta_ms': e['sleep_gap']['total_ms']['delta_ms'],
                                       'direction': e['sleep_gap']['total_ms']['direction'],
                                       'paired': [x['delta_ms'] for x in e['sleep_gap']['total_ms']['paired']]},
                'update_total_ms': {'delta_ms': e['update']['total_ms']['delta_ms'],
                                    'direction': e['update']['total_ms']['direction'],
                                    'paired': [x['delta_ms'] for x in e['update']['total_ms']['paired']]},
            }
    report['formal_headline_effects_total_ms'] = headline

    evidence_fail = list(global_failures)
    for p in PHASES:
        evidence_fail.extend(report['phases'][p]['failures'])
    all_fail = evidence_fail + worktree_failures
    report['global_failures'] = global_failures
    report['global_notes'] = global_notes
    report['all_failures'] = all_fail
    report['evidence_checks_pass'] = not evidence_fail
    report['inferred_definition_mismatch_total'] = sum(
        len(report['phases'][p]['comparisons']['inferred_definition_mismatches']) for p in PHASES)
    report['protocol_mismatch_total'] = sum(
        len(report['phases'][p]['comparisons']['protocol_mismatches']) for p in PHASES)
    report['numbers_and_fields_compared_total'] = sum(
        report['phases'][p]['comparisons']['numbers_and_fields_compared'] for p in PHASES)
    report['all_checks_pass'] = not all_fail
    report['all_checks_pass_scope'] = ('every check, including the worktree state of the measured source files; '
                                       'evidence_checks_pass excludes only the worktree state. Mismatches on '
                                       'fields whose definition the audit had to infer are listed separately '
                                       '(inferred_definition_mismatch_total)')
    report['runtime_seconds'] = round(time.time() - STARTED, 1)
    os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
    with open(OUT_PATH, 'w') as f:
        json.dump(report, f, indent=1, sort_keys=False, default=list)
        f.write('\n')

    # console summary
    print(f'wrote {os.path.relpath(OUT_PATH, ROOT)} in {report["runtime_seconds"]} s')
    for p in PHASES:
        r = report['phases'][p]
        g = r['ground_truth']
        print(f'{p}: pass={r["pass"]} rows={g["rows_evaluated"]} TP={g["true_positives"]} FP={g["false_positives"]} '
              f'FN={g["false_negatives"]} maxerr={g["max_position_error_px"]:.4f}px/{g["max_angle_error_deg"]:.4f}deg/'
              f'{g["max_relative_scale_error"]:.5f} compared={r["comparisons"]["numbers_and_fields_compared"]} '
              f'proto_mm={len(r["comparisons"]["protocol_mismatches"])} '
              f'inferred_mm={len(r["comparisons"]["inferred_definition_mismatches"])} '
              f'host_gates={len(r["host_gates"]["derived_host_gates"])} counts_match={r["counts"]["match"]} '
              f'{r["seconds"]}s')
        for x in r['failures']:
            print('   FAIL', x)
        for x in r['notes']:
            print('   NOTE', x)
    for x in global_failures:
        print('GLOBAL FAIL', x)
    for x in worktree_failures:
        print('WORKTREE FAIL', x)
    print('peak RSS block definition hits', report['peak_rss_block_definition_hits'])
    if report['phases']['formal'].get('verdict_inputs_using_flagged_executions') is not None:
        print('formal verdict inputs using flagged executions',
              report['phases']['formal']['verdict_inputs_using_flagged_executions'])
    if report['phases']['formal']['verdicts_recomputed']:
        for k, v in report['phases']['formal']['verdicts_comparison'].items():
            print(f'formal {k}: recomputed={v["recomputed"]} published={v["published"]}')
    print('all_checks_pass', report['all_checks_pass'])


if __name__ == '__main__':
    main()
