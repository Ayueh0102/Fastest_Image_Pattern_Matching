"""Pack stage-48 evidence into cpp-core/docs/stage48-frame-overheads.

Run from the worktree root after every summary, validation and audit file exists.
Inputs stay where the stage-37 manifest put them (main checkout build/); their
bytes are already archived in stage40-ncc-closure/fixtures.tar.gz, so only their
hashes are listed and checked against that round's input-sha256.json. Raw results
are split so that each archive stays far below GitHub's 100 MB limit.
"""
from pathlib import Path, PurePosixPath
import gzip, hashlib, json, tarfile
root = Path.cwd()
work = root/'build/stage48-frame-overheads'
out = root/'cpp-core/docs/stage48-frame-overheads'
fixture_root = Path('/Users/Ayueh/Fastest_Image_Pattern_Matching')
PHASES = ('pilot', 'formal', 'dose', 'profile')
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False)+'\n')
def pack(path, items):
    def stable(info):
        info.uid = info.gid = 0; info.uname = info.gname = ''; info.mtime = 0; info.mode = 0o644
        return info
    with path.open('wb') as handle, gzip.GzipFile(filename='', fileobj=handle, mode='wb', compresslevel=9, mtime=0) as gz, \
            tarfile.open(fileobj=gz, mode='w') as tar:
        for source, name in items:
            tar.add(source, arcname=name, recursive=False, filter=stable)
frozen = json.loads((out/'source-sha256.json').read_text())
with tarfile.open(out/'source-snapshot.tar.gz') as tar:
    members = {member.name: tar.extractfile(member).read() for member in tar if member.isfile()}
assert set(members) == {*frozen['files'], 'source-sha256.json'}
assert all(hashlib.sha256(members[name]).hexdigest() == digest for name, digest in frozen['files'].items())
stage40 = json.loads((root/'cpp-core/docs/stage40-ncc-closure/input-sha256.json').read_text())
inputs = {}
for phase in PHASES:
    manifest = json.loads((work/phase/'manifest.json').read_text())
    assert manifest['complete'] and manifest['unchanged'], phase
    for path, digest in manifest['input_sha256'].items():
        assert sha(path) == digest, path
        relative = str(Path(path).relative_to(fixture_root))
        assert stage40.get(relative) == digest, relative
        assert inputs.get(relative, digest) == digest
        inputs[relative] = digest
save(out/'input-sha256.json', dict(sorted(inputs.items())))
def tree(phases, keep=lambda path: True):
    return [(path, str(path.relative_to(work))) for phase in phases for path in sorted((work/phase).rglob('*')) if path.is_file() and keep(path)]
# Formal is split by method (as in rounds 44-45); the manifest travels with the full-GPU part.
hybrid = lambda path: path.parent.name in ('jobs', 'results') and path.name.split('-', 1)[1].startswith('hybrid_best__')
CONTENTS = {'raw-results-formal-hybrid-best.tar.gz': 'formal jobs, stdout/stderr and results of every hybrid_best arm',
            'raw-results-formal-full-gpu.tar.gz': 'formal manifest.json and jobs, stdout/stderr and results of every full_gpu_simd and full_gpu_parallel arm',
            'raw-results-other.tar.gz': 'pilot, dose and profile phases: manifests, jobs, stdout/stderr and results'}
pack(out/'raw-results-formal-hybrid-best.tar.gz', tree(['formal'], hybrid))
pack(out/'raw-results-formal-full-gpu.tar.gz', tree(['formal'], lambda path: not hybrid(path)))
pack(out/'raw-results-other.tar.gz', tree(['pilot', 'dose', 'profile']))
assert len(tree(['formal'], hybrid))+len(tree(['formal'], lambda path: not hybrid(path))) == len(tree(['formal']))
logs = [(path, str(path.relative_to(work))) for path in sorted((work/'validation').rglob('*'))
        if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc']
pack(out/'validation-logs.tar.gz', logs)
artifacts = []
for path in sorted(out.iterdir()):
    if not path.is_file() or path.name == 'archive.json':
        continue
    row = dict(path=path.name, bytes=path.stat().st_size, sha256=sha(path))
    if path.name.endswith('.tar.gz'):
        count = size = 0
        with tarfile.open(path, 'r:gz') as tar:
            for member in tar:
                name = PurePosixPath(member.name)
                assert not name.is_absolute() and '..' not in name.parts and member.isfile(), (path, member.name)
                data = tar.extractfile(member).read()
                assert len(data) == member.size
                count += 1; size += member.size
        row.update(regular_files=count, uncompressed_bytes=size, all_members_read_and_safe_paths=True)
        if path.name in CONTENTS:
            row['contents'] = CONTENTS[path.name]
        assert row['bytes'] < 95*1024**2, path
    artifacts.append(row)
save(out/'archive.json', dict(stage=48, date='2026-10-26', path_base='cpp-core/docs/stage48-frame-overheads',
    all_archives_fully_read=True, source_files=len(frozen['files']), source_commit=frozen['commit'],
    unique_input_files=len(inputs), input_bytes_archived_in='cpp-core/docs/stage40-ncc-closure/fixtures.tar.gz', artifacts=artifacts))
print(json.dumps(dict(sources=len(frozen['files']), inputs=len(inputs), logs=len(logs), artifacts=len(artifacts))))
