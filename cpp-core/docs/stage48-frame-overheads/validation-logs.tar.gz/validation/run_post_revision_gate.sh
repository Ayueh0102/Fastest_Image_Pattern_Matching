#!/bin/zsh
# Post-revision Release gate for stage 48: fresh research build on a clean, committed tree.
# Run from the worktree root. Writes validation/post-revision-gate.log; refuses to reuse a build directory.
set -u
L=build/stage48-frame-overheads/validation/post-revision-gate.log
B=build/stage48-final
P=/Users/Ayueh/Fastest_Image_Pattern_Matching/python-port/venv/bin/python
if [ -e $B ]; then echo "refusing: $B exists"; exit 1; fi
exec > $L 2>&1
echo "HEAD_BEFORE=$(git rev-parse HEAD)"
echo "STATUS_BEFORE_BEGIN"; git status --porcelain; echo "STATUS_BEFORE_END"
step() {
    local name=$1; shift
    echo "=== $name start $(date -u +%Y-%m-%dT%H:%M:%SZ)"
    "$@"
    echo "=== $name exit=$? end $(date -u +%Y-%m-%dT%H:%M:%SZ)"
}
step configure cmake -S cpp-core -B $B -DCMAKE_BUILD_TYPE=Release -DFPM_BUILD_GUI=ON -DFPM_BUILD_EXPERIMENTS=ON -DFPM_WITH_OPENCV=ON
step build cmake --build $B -j
step ctest ctest --test-dir $B --output-on-failure
step harness env FPM_FINE_REUSE_BUILD=$B FPM_FINE_SEARCH_BUILD=$B FPM_FINE_FUSED_BUILD=$B $P -m unittest discover -s cpp-core/tests -p 'test_*.py'
step color $P cpp-core/tests/color_verify_runner_test.py --runner $B/experiments/fpm_color_verify_runner --metal
step other_py zsh -c 'for f in blender_challenge_test.py challenge_coverage_test.py real_rgb_benchmark_test.py; do "$0" -m unittest discover -s cpp-core/tests -p "$f" || exit 1; done' $P
echo "HEAD_AFTER=$(git rev-parse HEAD)"
echo "STATUS_AFTER_BEGIN"; git status --porcelain; echo "STATUS_AFTER_END"
