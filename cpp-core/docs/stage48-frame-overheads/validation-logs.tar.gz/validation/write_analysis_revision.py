"""Write cpp-core/docs/stage48-frame-overheads/analysis-revision.json.

Run from the worktree root after the revised profile summary, the regenerated decision file,
host-gate-sensitivity.json and analysis-revision-red-green.log exist.
"""
import hashlib, json
from pathlib import Path
docs = Path('cpp-core/docs/stage48-frame-overheads')
validation = Path('build/stage48-frame-overheads/validation')
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
frozen = json.loads((docs/'source-sha256.json').read_text())
old = json.loads((docs/'profile-summary-frozen-driver.json').read_text())
new = json.loads((docs/'profile-summary.json').read_text())
audit = json.loads((validation/'independent-audit.json').read_text())['phases']['profile']['recomputed']['profile_stages']
sensitivity = json.loads((validation/'host-gate-sensitivity.json').read_text())
embedded = json.loads((Path('build/stage48-frame-overheads/profile/manifest.json')).read_text())['summary']

stages, mismatches, largest = {}, 0, None
for case in new['cases']:
    before = {row['name']: row for row in old['cases']}[case['name']]
    for arm, row in case['arms'].items():
        for stage, values in row['profile_stages'].items():
            previous = before['arms'][arm]['profile_stages'][stage]
            mismatches += values['median'] != audit[case['name']][arm]['measured_only_median'][stage]
            mismatches += previous['median'] != audit[case['name']][arm]['all_rows_median'][stage]
            entry = dict(all_calls_median_ms=previous['median'], all_calls_count=len(previous['values']),
                         measured_median_ms=values['median'], measured_count=len(values['values']),
                         change_ms=values['median']-previous['median'])
            stages.setdefault(case['name'], {}).setdefault(arm, {})[stage] = entry
            if largest is None or abs(entry['change_ms']) > abs(largest['change_ms']):
                largest = dict(case=case['name'], arm=arm, stage=stage, **entry)
unchanged_keys = all(json.dumps({key: value for key, value in arm.items() if key != 'profile_stages'}, sort_keys=True) ==
                     json.dumps({key: value for key, value in {r['name']: r for r in old['cases']}[case['name']]['arms'][name].items()
                                 if key != 'profile_stages'}, sort_keys=True)
                     for case in new['cases'] for name, arm in case['arms'].items())
revision = dict(stage=48, date='2026-10-26', revision='post-measurement analysis revision 1',
    found_by='Independent audit after all four phases (build/stage48-frame-overheads/validation/independent-audit.json, profile notes)',
    reason='profile_stages pooled every call of each process (cold, 23 warm-up and 3 measured calls), while the protocol metric scope '
           'is measured calls only. The driver now builds stage distributions from measured calls. Native binaries, jobs, raw results, '
           'accuracy, verdicts and every other summary field are unchanged.',
    changed_files=[dict(path=path, measured_sha256=frozen['files'][path], final_sha256=sha(path))
                   for path in ('cpp-core/tests/test_frame_overheads_harness.py', 'cpp-core/tools/benchmark_frame_overheads.py')],
    test_first='The harness fixture now runs warm-up calls 2 ms slower; the revised test fails on the frozen driver (32.5 != 31.5) '
               'and passes on the revised one. Log: validation-logs.tar.gz:validation/analysis-revision-red-green.log',
    retained=dict(frozen_driver='source-snapshot.tar.gz (commit %s)' % frozen['commit'],
                  frozen_profile_summary='profile-summary-frozen-driver.json',
                  frozen_profile_summary_equals_manifest_embedded=json.dumps(embedded, indent=2, ensure_ascii=False, allow_nan=False)+'\n' ==
                      (docs/'profile-summary-frozen-driver.json').read_text(),
                  manifest_embedded_summary='raw-results-other.tar.gz:profile/manifest.json (summary key, frozen driver)'),
    recomputed_with_revised_driver=dict(
        pilot_formal_dose_byte_identical='checked by replay_check.py (replay-check.json, revised_driver section)',
        profile_fields_other_than_profile_stages_unchanged=unchanged_keys,
        profile_available_calls_scope='unchanged: every call that returned a profile (54 per arm), not only the measured calls',
        decision_file='decision-and-failures.json regenerated; only profile_stage_medians_ms changed'),
    audit_cross_check=dict(compared_values=2*sum(len(arm) for case in stages.values() for arm in case.values()), mismatches=mismatches,
        rule='revised medians equal the audit measured_only recomputation; frozen medians equal its all_rows recomputation'),
    largest_change=largest, profile_stage_medians=stages,
    disclosures=[
        dict(topic='host gates in formal', text='formal_decision_eligible marks the phase; the protocol records host_busy and host_load_high '
             'without a consequence. Formal keeps both flagged workers (128 full_gpu_simd static_sleep block 3, 8K hybrid static_decode block 4). '
             'Diagnostic sensitivity with those blocks removed from every arm of the same case and method: verdicts %s, %d effects recomputed, '
             '%d directions change (all 128 full_gpu_simd gap_on_update, none in a verdict or the report tables).' %
             ('unchanged' if sensitivity['verdicts_unchanged'] else 'CHANGED', sensitivity['recomputed_effects'], len(sensitivity['direction_changes'])),
             evidence='validation-logs.tar.gz:validation/host-gate-sensitivity.json'),
        dict(topic='gate definitions', text='The protocol names route_and_residency, requested_algorithm_not_executed and '
             'device_timestamp_unavailable without spelling out the checks; the driver compares row fields with the job request, and the '
             'independent audit re-derived them the same way.')])
(docs/'analysis-revision.json').write_text(json.dumps(revision, indent=2, ensure_ascii=False, allow_nan=False)+'\n')
print(json.dumps(dict(mismatches=mismatches, largest=largest, unchanged_keys=unchanged_keys,
                      embedded_equal=revision['retained']['frozen_profile_summary_equals_manifest_embedded']), indent=2))
