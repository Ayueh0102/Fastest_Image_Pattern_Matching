"""Hand-written mutants of benchmark_frame_overheads.py; each must make the harness tests fail.

Run from the worktree root. Each mutation must match exactly once; the file is restored afterwards.
"""
import json, subprocess, sys
from pathlib import Path
path = Path('cpp-core/tools/benchmark_frame_overheads.py')
original = path.read_text()
mutants = {
 'direction_pooled_only': ("if pooled and complete and signs == {pooled} else None", "if pooled else None"),
 'h1_sleep_decode_swapped': ("h1 = ('supported' if all(sleep.values()) else 'decode_only' if all(decode.values()) else",
                             "h1 = ('supported' if all(decode.values()) else 'decode_only' if all(sleep.values()) else"),
 'h2_ignores_gaps': ("'rejected' if not update else 'confounded' if gaps else 'supported'", "'rejected' if not update else 'supported'"),
 'static_update_unchecked': ("row['pose_invalidated'] == (reuse and refine and not gpu) and (reuse or row['source_update_ms'] == 0))",
                             "(reuse or row['source_update_ms'] == 0))"),
 'pose_rule_any': ("route &= row['pose_create_ms'] > 0 if creates else row['pose_create_ms'] == 0", "route &= True"),
 'generation_unchecked': ("route &= (row['source_generation'] == (call if reuse else 0) and", "route &= (True and"),
 'oversleep_allowed': ("sleep <= row['gap_ms'] <= sleep+SLEEP_TOLERANCE_MS", "sleep <= row['gap_ms']"),
 'no_gap_unbounded': ("row['gap_ms'] <= NO_GAP_MAXIMUM_MS", "row['gap_ms'] >= 0"),
 'decode_gap_unchecked': ("gap_ok &= row['source_decode_ms'] > 0 and row['gap_ms'] >= row['source_decode_ms']", "gap_ok &= True"),
 'no_cross_arm_parity': ("if any(value != values[0] for value in values):", "if False:"),
 'no_peak2_check': ("if G1 in outputs and G2 in outputs and any(value != outputs[G1][0] for value in outputs[G2]):", "if False:"),
 'no_warmup_gate': ("('warmup_shorter_than_1s', warmup_wall < WARMUP_MINIMUM_MS)", "('warmup_shorter_than_1s', False)"),
 'timed_includes_warmup': ("values = [metrics_of(row, item['method']) for row in rows[1+warmup:]]", "values = [metrics_of(row, item['method']) for row in rows[1:]]"),
 'job_keeps_reuse_for_static': ("    if item['mode'] != 'reuse':\n        result['sequence_mode'] = item['mode']\n", ""),
 'peak_mode_unchecked': ("route &= (metrics['peak_mode'] == METHODS[method]['full_gpu_peak_mode'] and", "route &= (True and"),
 'no_host_gate': ("if stage41.host_entry(entry.get('host')):", "if stage41.host_entry(entry.get('host')) and False:"),
 'no_load_gate': ("if finite(load[0], 'load_average') > HOST_LOAD_LIMIT:", "if finite(load[0], 'load_average') > HOST_LOAD_LIMIT+100:"),
 'gt_measured_only': ("**accuracy_summary(calls, case['truth']),", "**accuracy_summary(calls[1:2], case['truth']),"),
 'python_case_sensitive': ("if name.lower().startswith('python') else None", "if name.startswith('python') else None"),
 'no_cpu_rule': ("'cpu' if pcpu >= BUSY_CPU_PERCENT else None", "None"),
 'own_pid_counted': ("        if pid in own:\n            continue\n", ""),
 'sleep_rounding': ("return {name: round(cases[name]['arms']['hybrid_best_frames']['source_decode_ms']['median']) for name in SLEEP_MS}",
                    "return {name: math.ceil(cases[name]['arms']['hybrid_best_frames']['source_decode_ms']['median']) for name in SLEEP_MS}"),
}
results = {}
try:
    for name, (old, new) in mutants.items():
        assert original.count(old) == 1, name
        path.write_text(original.replace(old, new))
        run = subprocess.run([sys.executable, '-m', 'unittest', 'cpp-core/tests/test_frame_overheads_harness.py'], capture_output=True, text=True)
        results[name] = 'killed' if run.returncode else 'survived'
finally:
    path.write_text(original)
restored = path.read_text() == original
print(json.dumps(dict(mutants=results, killed=sum(value == 'killed' for value in results.values()), total=len(results), restored=restored), indent=2))
sys.exit(0 if restored and all(value == 'killed' for value in results.values()) else 1)
