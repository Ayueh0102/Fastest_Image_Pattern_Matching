"""Diagnostic: do the formal workers flagged by a host gate change any effect direction or verdict?

Run from the worktree root. The protocol records host_busy and host_load_high but gives them no
consequence, so the published formal summary keeps every worker. This check removes the flagged
block from every arm of the same case and method (pairing stays by block), recomputes the effects
with the driver's own effect() and hypotheses(), and compares them with the published ones.
Reads only cpp-core/docs/stage48-frame-overheads/formal-summary.json; writes host-gate-sensitivity.json.
"""
import copy, json, statistics, sys
from pathlib import Path
sys.path.insert(0, 'cpp-core/tools')
import benchmark_frame_overheads as bench

docs = Path('cpp-core/docs/stage48-frame-overheads')
formal = json.loads((docs/'formal-summary.json').read_text())
flagged = [gate for gate in formal['failed_gates'] if gate['gate'] in ('host_busy', 'host_load_high')]
cases = {case['name']: case for case in formal['cases']}
measured, remainder = divmod(formal['counts']['measured_calls'], formal['counts']['fresh_processes'])
assert not remainder

def method_of(arm):
    return arm.split('__')[0]

def check_order(arm):
    """Values are pooled block by block; confirm before slicing them."""
    for name, dist in arm['metrics'].items():
        if dist is None:
            continue
        for position, block in enumerate(arm['blocks']):
            chunk = dist['values'][measured*position:measured*(position+1)]
            if block['medians'][name] is not None and statistics.median(chunk) != block['medians'][name]:
                return False
    return True

def without(arm, block):
    row = copy.deepcopy(arm)
    position = [entry['block'] for entry in arm['blocks']].index(block)
    row['blocks'] = [entry for entry in arm['blocks'] if entry['block'] != block]
    for name, dist in arm['metrics'].items():
        if dist is not None:
            values = dist['values'][:measured*position]+dist['values'][measured*(position+1):]
            row['metrics'][name] = bench.distribution(values)
    return row

order_ok = all(check_order(arm) for case in formal['cases'] for arm in case['arms'].values())
removed = {}
for gate in flagged:
    removed.setdefault((gate['case'], method_of(gate['arm'])), set()).add(gate['block'])
rows, changes = [], []
for case in formal['cases']:
    effects = copy.deepcopy(case['effects'])
    for method, contrasts in case['effects'].items():
        blocks = removed.get((case['name'], method))
        if not blocks:
            continue
        arms = {name: row for name, row in case['arms'].items() if method_of(name) == method}
        for block in blocks:
            arms = {name: without(row, block) for name, row in arms.items()}
        names = bench.GPU_METRICS if method in bench.GPU_METHODS else bench.HYBRID_METRICS
        for contrast, (left, right) in bench.CONTRASTS.items():
            for metric in names:
                new = bench.effect(arms[f'{method}__{left}'], arms[f'{method}__{right}'], metric)
                old = contrasts[contrast][metric]
                effects[method][contrast][metric] = new
                if old['delta_ms'] is None and new['delta_ms'] is None:
                    continue
                changes.append(dict(case=case['name'], method=method, contrast=contrast, metric=metric, removed_blocks=sorted(blocks),
                                    published_delta_ms=old['delta_ms'], sensitivity_delta_ms=new['delta_ms'],
                                    published_direction=old['direction'], sensitivity_direction=new['direction']))
    rows.append(dict(name=case['name'], effects=effects))
verdicts = {name: row.get('verdict', row.get('reproduced')) for name, row in bench.hypotheses(rows).items()}
published = {name: row.get('verdict', row.get('reproduced')) for name, row in formal['hypotheses'].items()}
flips = [row for row in changes if row['published_direction'] != row['sensitivity_direction']]
largest = max(changes, key=lambda row: abs(row['sensitivity_delta_ms']-row['published_delta_ms']), default=None)
report = dict(flagged_workers=flagged, block_order_verified=order_ok, measured_calls_per_block=measured,
              recomputed_effects=len(changes), direction_changes=flips, largest_delta_change=largest,
              published_verdicts=published, sensitivity_verdicts=verdicts, verdicts_unchanged=verdicts == published,
              scope='Diagnostic only; the published formal summary keeps every worker. Removing a block from one case and method '
                    'drops it from every arm there, so contrasts stay paired by block.',
              effects=changes)
Path('build/stage48-frame-overheads/validation/host-gate-sensitivity.json').write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False)+'\n')
print(json.dumps({key: report[key] for key in ('block_order_verified', 'recomputed_effects', 'direction_changes', 'largest_delta_change',
                                               'verdicts_unchanged')}, indent=2, ensure_ascii=False))
sys.exit(0 if order_ok else 1)
