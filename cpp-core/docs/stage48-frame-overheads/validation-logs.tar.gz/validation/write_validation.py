"""Collect stage-48 validation evidence into cpp-core/docs/stage48-frame-overheads/validation.json.

Run from the worktree root after the final gate, mutants, independent audit and replay.
Every value is read from a log or JSON produced by those steps.
"""
import json, re
from pathlib import Path
work = Path('build/stage48-frame-overheads')
log = work/'validation'
out = Path('cpp-core/docs/stage48-frame-overheads')
PHASES = ('pilot', 'formal', 'dose', 'profile')
def text(name):
    return (log/name).read_text()
def ctest(name):
    match = re.search(r'(\d+)% tests passed, (\d+) tests failed out of (\d+)', text(name))
    return dict(passed=int(match[3])-int(match[2]), failed=int(match[2]), total=int(match[3]), log='validation/'+name)
def unittest_runs(name):
    body = text(name)
    return dict(ran=[int(value) for value in re.findall(r'Ran (\d+) tests', body)], ok_lines=body.count('\nOK'), log='validation/'+name)
manifests = {phase: json.loads((work/phase/'manifest.json').read_text()) for phase in PHASES}
summaries = {phase: json.loads((out/f'{phase}-summary.json').read_text()) for phase in PHASES}
audit = json.loads(text('independent-audit.json'))
replay = json.loads(text('replay-check.json'))
final = text('final-gate.log')
revision = json.loads((out/'analysis-revision.json').read_text())
sensitivity = json.loads(text('host-gate-sensitivity.json'))
red_green = text('analysis-revision-red-green.log').split('expected to pass')
frozen_profile = json.loads((out/'profile-summary-frozen-driver.json').read_text())
def gate_log(name):
    """Parse run_post_revision_gate.sh output: HEAD and clean state before and after, exit and time per step."""
    body = text(name)
    status = lambda when: body.split(f'STATUS_{when}_BEGIN\n')[1].split(f'STATUS_{when}_END')[0].strip().splitlines()
    steps = {name: dict(start=start, exit=int(code), end=end) for name, start, code, end in
             re.findall(r'=== (\w+) start (\S+)\n(?:.*\n)*?=== \1 exit=(\d+) end (\S+)', body)}
    return dict(log='validation/'+name, head_before=re.search(r'HEAD_BEFORE=(\w+)', body)[1], head_after=re.search(r'HEAD_AFTER=(\w+)', body)[1],
                dirty_before=status('BEFORE'), dirty_after=status('AFTER'), steps=steps, ctest=ctest(name),
                unittest_ran=[int(value) for value in re.findall(r'Ran (\d+) tests', body)],
                skipped=re.findall(r'OK \(skipped=(\d+)\)', body), build_directory='build/stage48-final (fresh)')
post_revision = gate_log('post-revision-gate.log') if (log/'post-revision-gate.log').exists() else None
hosts = {phase: dict(before=manifest['host']['before'], after=manifest['host']['after'], executions=len(manifest['executions']),
                     executions_with_competing_processes=sum(bool(entry['host']['competing_processes']) for entry in manifest['executions']),
                     load_average_1min_range=[min(entry['host']['load_average'][0] for entry in manifest['executions']),
                                              max(entry['host']['load_average'][0] for entry in manifest['executions'])],
                     started_utc=manifest['started_utc'], finished_utc=manifest['finished_utc'])
         for phase, manifest in manifests.items()}
refused = sorted(path.name for path in log.glob('*refused*.log'))
validation = dict(stage=48, date='2026-10-26',
    build=dict(directory='build/stage48-release', type='Release', options=['FPM_BUILD_GUI=ON', 'FPM_BUILD_EXPERIMENTS=ON', 'FPM_WITH_OPENCV=ON'],
               configure_log='validation/red-configure.log', build_logs=['validation/red-build.log', 'validation/green-build.log'],
               note='Built from the working tree that became 9fcc44b; later commits change Python only (harness and host check), so the runner binary is the frozen source.'),
    runner_tests=dict(red='native_runner_job_keys and native_runner_sequence_gaps failed before the runner change (feature missing)',
                      green='both passed after it', compiled_mutants=json.loads(text('runner-mutants.log')),
                      compiled_mutants_log='validation/runner-mutants.log', first_attempt='validation/runner-mutants-attempt1.txt'),
    pre_measurement=dict(ctest=ctest('pre-formal-ctest.log'), python_harness=unittest_runs('pre-formal-python-harness.log'),
                         color_verify_metal=unittest_runs('pre-formal-color-verify.log'),
                         note='Run before the host-check revision; that revision changed Python only and its tests ran again in the final gate.'),
    post_revision_gate=post_revision if post_revision else 'pending: run_post_revision_gate.sh after the round is committed',
    final_gate=dict(log='validation/final-gate.log', ctest=ctest('final-gate.log'), unittest=unittest_runs('final-gate.log'),
                    scope='After all four phases and before analysis revision 1, on the existing build/stage48-release; '
                          'the worktree then held only the untracked phase summaries',
                    exits={name: int(value) for name, value in re.findall(r'(\w+) exit=(\d+)', final)},
                    head=re.search(r'HEAD=(\w+)', final)[1]),
    harness=dict(tests=18, test_file='cpp-core/tests/test_frame_overheads_harness.py', mutants=json.loads(text('mutants.log')),
                 mutants_log='validation/mutants.log'),
    datasets={phase: summary['counts'] for phase, summary in summaries.items()},
    direct_gt_calls=sum(summary['counts']['gt_evaluated_calls'] for summary in summaries.values()),
    all_zero_fp_fn=all(summary['all_accuracy_pass'] for summary in summaries.values()),
    all_routes_pass=all(summary['all_routes_pass'] for summary in summaries.values()),
    all_repeat_exact=all(summary['all_repeat_exact'] for summary in summaries.values()),
    embedded_summary_reproduced={phase: json.dumps(manifests[phase]['summary'], sort_keys=True) ==
                                 json.dumps(frozen_profile if phase == 'profile' else summaries[phase], sort_keys=True) for phase in PHASES},
    embedded_summary_note='Manifest-embedded summaries come from the frozen driver. The published profile summary comes from the revised '
                          'driver (analysis revision 1); the frozen one is kept as profile-summary-frozen-driver.json.',
    analysis_revision=dict(file='analysis-revision.json', red_green_log='validation/analysis-revision-red-green.log',
                           revised_test_failed_on_frozen_driver='FAILED (failures=1)' in red_green[0],
                           revised_test_passed_on_revised_driver='\nOK' in red_green[1] and 'FAILED' not in red_green[1],
                           audit_cross_check=revision['audit_cross_check'], largest_change=revision['largest_change'],
                           changed_files=revision['changed_files']),
    host_gate_sensitivity=dict(file='validation/host-gate-sensitivity.json', flagged_workers=sensitivity['flagged_workers'],
                               recomputed_effects=sensitivity['recomputed_effects'], verdicts_unchanged=sensitivity['verdicts_unchanged'],
                               direction_changes=[{key: row[key] for key in ('case', 'method', 'contrast', 'metric', 'published_direction',
                                                                             'sensitivity_direction')} for row in sensitivity['direction_changes']],
                               scope=sensitivity['scope']),
    host=hosts, refused_starts=refused,
    independent_audit=dict(file='validation/independent-audit.json', independent=audit.get('independent'),
                           harness_imported=audit.get('harness_imported'), gpu_launched=audit.get('gpu_launched'),
                           native_runner_launched=audit.get('native_runner_launched'), stdlib_only=audit.get('stdlib_only'),
                           numbers_and_fields_compared=audit.get('numbers_and_fields_compared_total'),
                           protocol_mismatches=audit.get('protocol_mismatch_total'), inferred_definition_mismatches=audit.get('inferred_definition_mismatch_total'),
                           evidence_checks_pass=audit.get('evidence_checks_pass'), all_checks_pass=audit.get('all_checks_pass'),
                           all_failures=audit.get('all_failures'),
                           failure_note='The only failure is the then-uncommitted log-catalog mapping (build_log_catalog.py, edited after the last phase, '
                                        'not used by any measurement); it is committed with this round.',
                           observations=[dict(topic='profile stage scope', status='fixed by analysis revision 1'),
                                         dict(topic='host gates in formal have no stated consequence', status='disclosed; see host_gate_sensitivity')]),
    archive_replay=replay,
    limitations=['Single Apple M4 Pro on macOS 27.0.1; round 41 ran on macOS 26', 'Repeated identical frame',
                 'Timing inference only: no GPU frequency readout or hardware counters', 'Log catalog regenerated after packing',
                 'No ASan/UBSan run: the only C++ change is the native runner, which the sanitized configuration (no GUI) does not build',
                 'The 22 tool mutants ran on the frozen driver, before analysis revision 1'])
(out/'validation.json').write_text(json.dumps(validation, indent=2, ensure_ascii=False, allow_nan=False)+'\n')
print(json.dumps({key: validation[key] for key in ('direct_gt_calls', 'all_zero_fp_fn', 'embedded_summary_reproduced', 'refused_starts')}, ensure_ascii=False))
