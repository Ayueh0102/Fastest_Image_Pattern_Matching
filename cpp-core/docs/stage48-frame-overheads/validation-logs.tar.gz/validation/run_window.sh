#!/usr/bin/env bash
# Stage-48 timing window: pilot, formal, dose and profile phases back to back.
# Run from the worktree root. Each phase is a fresh driver run that refuses to
# start on a busy host; the window stops at the first failing phase.
set -u
python=/Users/Ayueh/Fastest_Image_Pattern_Matching/python-port/venv/bin/python
fixtures=/Users/Ayueh/Fastest_Image_Pattern_Matching/build/stage37-full-gpu/formal/manifest.json
work=build/stage48-frame-overheads
for phase in pilot formal dose profile; do
  echo "=== $phase start $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  "$python" cpp-core/tools/benchmark_frame_overheads.py --phase "$phase" --build build/stage48-release \
    --fixtures-manifest "$fixtures" --output "$work/$phase/manifest.json" > "$work/validation/$phase.log" 2>&1
  code=$?
  echo "=== $phase exit $code $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  [ "$code" -eq 0 ] || exit "$code"
done
