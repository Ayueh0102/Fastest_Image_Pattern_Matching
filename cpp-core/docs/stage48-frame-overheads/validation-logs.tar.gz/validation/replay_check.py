"""Replay the stage-48 summaries from the published archives with the frozen and the revised tool.

Run from the worktree root after archive_artifacts.py. Extracts the source snapshot and
the three raw archives into a fresh build/stage48-replay, checks every snapshot member hash,
reruns benchmark_frame_overheads.py --summarize per phase and compares bytes: the frozen
tool must reproduce what it published at measurement time (the profile summary of that
tool is kept as profile-summary-frozen-driver.json), and the revised tool (analysis
revision 1, profile stage scope) must reproduce the published summaries. No GPU run.
"""
import hashlib, json, shutil, subprocess, sys, tarfile
from pathlib import Path
docs = Path('cpp-core/docs/stage48-frame-overheads')
replay = Path('build/stage48-replay')
if replay.exists():
    shutil.rmtree(replay)
(replay/'source').mkdir(parents=True)
with tarfile.open(docs/'source-snapshot.tar.gz') as tar:
    tar.extractall(replay/'source', filter='data')
archives = sorted(path.name for path in docs.glob('raw-results-*.tar.gz'))
assert archives == ['raw-results-formal-full-gpu.tar.gz', 'raw-results-formal-hybrid-best.tar.gz', 'raw-results-other.tar.gz'], archives
# The summary reads manifests, jobs and results only. stdout/stderr members are read in full
# but not written, which halves the disk footprint (the host disk was full at this step).
streams = 0
for name in archives:
    with tarfile.open(docs/name) as tar:
        for member in tar:
            if member.name.endswith(('.stdout.txt', '.stderr.txt')):
                assert len(tar.extractfile(member).read()) == member.size, member.name
                streams += 1
            else:
                tar.extract(member, replay/'raw', filter='data')
frozen = json.loads((replay/'source/source-sha256.json').read_text())
mismatched = [name for name, digest in frozen['files'].items() if hashlib.sha256((replay/'source'/name).read_bytes()).hexdigest() != digest]
changes = subprocess.run(['git', 'diff', '--name-only', frozen['commit'], '--', 'cpp-core/src', 'cpp-core/include', 'cpp-core/experiments',
                          'cpp-core/tools', 'cpp-core/tests', 'cpp-core/CMakeLists.txt'], capture_output=True, text=True, check=True).stdout.split()
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
def run(tool, label, expected):
    results = {}
    for phase in ('pilot', 'formal', 'dose', 'profile'):
        output = replay/label/f'{phase}-summary.json'
        output.parent.mkdir(exist_ok=True)
        child = subprocess.run([sys.executable, str(tool), '--summarize', str(replay/'raw'/phase/'manifest.json'), '--output', str(output)],
                               capture_output=True, text=True)
        target = expected(phase)
        results[phase] = dict(returncode=child.returncode, stderr=child.stderr[-2000:], compared_with=target.name,
                              bytes_equal=child.returncode == 0 and output.read_bytes() == target.read_bytes())
    return dict(tool_sha256=sha(tool), summaries=results)
frozen_tool = run(replay/'source/cpp-core/tools/benchmark_frame_overheads.py', 'frozen',
                  lambda phase: docs/('profile-summary-frozen-driver.json' if phase == 'profile' else f'{phase}-summary.json'))
revised_tool = run(Path('cpp-core/tools/benchmark_frame_overheads.py'), 'revised', lambda phase: docs/f'{phase}-summary.json')
revision = json.loads((docs/'analysis-revision.json').read_text())
listed = {row['path']: row for row in revision['changed_files']}
report = dict(raw_archives=archives, stdout_stderr_members_read_not_written=streams, snapshot_files=len(frozen['files']), snapshot_hash_mismatches=mismatched, frozen_commit=frozen['commit'],
              source_changes_since_freeze_in_worktree=changes, frozen_tool=frozen_tool, revised_tool=revised_tool,
              revised_tool_listed_in_analysis_revision=listed['cpp-core/tools/benchmark_frame_overheads.py']['final_sha256'] == revised_tool['tool_sha256'],
              frozen_tool_listed_in_analysis_revision=listed['cpp-core/tools/benchmark_frame_overheads.py']['measured_sha256'] == frozen_tool['tool_sha256'],
              all_pass=not mismatched and all(row['bytes_equal'] for tool in (frozen_tool, revised_tool) for row in tool['summaries'].values()),
              scope='Summaries only, from the extracted archives. No GPU measurement rerun.')
report['all_pass'] = report['all_pass'] and report['revised_tool_listed_in_analysis_revision'] and report['frozen_tool_listed_in_analysis_revision']
Path('build/stage48-frame-overheads/validation/replay-check.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
sys.exit(0 if report['all_pass'] else 1)
