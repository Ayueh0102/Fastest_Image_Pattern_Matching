#!/usr/bin/env bash
# Stage-48 timing window with retries. Run from the worktree root. Waits until the
# host has been quiet for four checks 30 s apart, marks the shared timing lock
# ACTIVE and runs every phase whose manifest is not complete yet. A phase that the
# driver refused before any worker (busy host, no results directory) keeps its log
# as <phase>-refused-<attempt>.log, the lock returns to WAITING and the loop waits
# again; any other failure stops the loop.
set -u
python=/Users/Ayueh/Fastest_Image_Pattern_Matching/python-port/venv/bin/python
fixtures=/Users/Ayueh/Fastest_Image_Pattern_Matching/build/stage37-full-gpu/formal/manifest.json
work=build/stage48-frame-overheads
lock="/Users/Ayueh/Library/Application Support/Claude/side-session-notes/local_1b4c2052-63a8-4a9f-94f8-77e6ad04fbca/timing-lock-gallant-thompson.txt"
status() { /usr/bin/sed -i '' -e "s/^status: .*/status: $1/" "$lock"; }
complete() { [ -f "$work/$1/manifest.json" ] && "$python" -c "import json,sys; sys.exit(0 if json.load(open('$work/$1/manifest.json')).get('complete') else 1)"; }
for attempt in 2 3 4 5 6 7 8; do
  (cd cpp-core/tools && "$python" -c "
import time, benchmark_frame_overheads as b
quiet = 0
while quiet < 4:
    s = b.host_state()
    quiet = quiet+1 if not s['competing_processes'] and s['load_average'][0] <= b.HOST_LOAD_LIMIT else 0
    print(time.strftime('%H:%M:%S'), 'load', round(s['load_average'][0], 2), [p['command'] for p in s['competing_processes']], 'quiet', quiet, flush=True)
    if quiet < 4:
        time.sleep(30)
")
  status "ACTIVE - attempt $attempt started $(date -u +%Y-%m-%dT%H:%M:%SZ); expected end about 45 minutes later"
  refused=0
  for phase in pilot formal dose profile; do
    complete "$phase" && continue
    echo "=== attempt $attempt $phase start $(date -u +%Y-%m-%dT%H:%M:%SZ)"
    "$python" cpp-core/tools/benchmark_frame_overheads.py --phase "$phase" --build build/stage48-release \
      --fixtures-manifest "$fixtures" --output "$work/$phase/manifest.json" > "$work/validation/$phase.log" 2>&1
    code=$?
    echo "=== attempt $attempt $phase exit $code $(date -u +%Y-%m-%dT%H:%M:%SZ)"
    if [ "$code" -ne 0 ]; then
      if grep -q 'Host not quiet' "$work/validation/$phase.log" && [ ! -d "$work/$phase/results" ]; then
        mv "$work/validation/$phase.log" "$work/validation/$phase-refused-$attempt.log"
        status "WAITING - attempt $attempt refused at $phase (busy host); retrying when quiet for 90 s"
        refused=1
        break
      fi
      status "STOPPED - $phase failed; see the session"
      exit "$code"
    fi
  done
  [ "$refused" -eq 1 ] && continue
  exit 0
done
exit 3
