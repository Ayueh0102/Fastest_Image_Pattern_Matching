"""Compiled mutants of the runner's sequence-gap code in an isolated git-archive copy.

Usage: runner_mutants.py <copy root> <build dir>. Each mutation must match once; the
runner is rebuilt (the edit waits past one-second timestamp resolution and the build
log must show the runner compiled), both contract tests run, and the source is
restored; finally the original is rebuilt and both tests must pass again. GNU Make
3.81 compares whole seconds, so every source write waits more than a second first.
"""
import json, subprocess, sys, time
from pathlib import Path
root, build = Path(sys.argv[1]), Path(sys.argv[2])
source = root/'cpp-core/tools/native_pipeline_runner.cpp'
original = source.read_text()
mutants = {
 'static_updates_source': ('} else if(mode=="reuse") update=session->updateSource(frame.view());', '} else update=session->updateSource(frame.view());'),
 'sleep_skipped': ('else if(gap=="sleep") std::this_thread::sleep_for(std::chrono::duration<double,std::milli>(sleepMs));', ''),
 'none_still_decodes': ('if(gap=="decode") {src=fpm::io::readGrayImage(sourceFrames[index].toString(),loadMode);decode=ms(t);}',
                        'if(gap!="sleep") {src=fpm::io::readGrayImage(sourceFrames[index].toString(),loadMode);decode=ms(t);}'),
 'gap_ms_is_decode': ('row["gap_ms"]=gapMs;', 'row["gap_ms"]=decode;'),
 'static_many_frames': ('if(mode=="static" && sourceFrames.size()!=1) throw', 'if(false) throw'),
 'zero_sleep_allowed': ('sleepMs<=0 || sleepMs>10000', 'sleepMs<0 || sleepMs>10000'),
 'numeric_gap_accepted': ('if(j.contains("sequence_gap") && !j["sequence_gap"].isString()) throw', 'if(false) throw'),
 'gap_key_unlisted': ('"score","sequence_gap",', '"score",'),
}
def write(text):
    time.sleep(1.2)
    source.write_text(text)
def rebuild():
    log = subprocess.run(['cmake', '--build', str(build), '--target', 'fpm_native_pipeline_runner'], capture_output=True, text=True)
    return log.returncode, 'native_pipeline_runner.cpp' in log.stdout
def tests():
    runner = build/'experiments/fpm_native_pipeline_runner'
    contract = build/'experiments/fpm_native_runner_contract_test'
    return {mode: subprocess.run([str(contract), mode, str(runner)], capture_output=True, text=True).returncode for mode in ('--sequence-gaps', '--job-keys')}
results = {}
try:
    for name, (old, new) in mutants.items():
        assert original.count(old) == 1, name
        write(original.replace(old, new))
        code, compiled = rebuild()
        assert code == 0 and compiled, name+': mutant did not rebuild the runner'
        outcome = tests()
        results[name] = dict(tests=outcome, killed=any(outcome.values()))
finally:
    write(original)
code, compiled = rebuild()
final = tests()
report = dict(mutants=results, killed=sum(row['killed'] for row in results.values()), total=len(results),
              restored_rebuilt=code == 0 and compiled, restored_tests=final, restored_pass=not any(final.values()))
print(json.dumps(report, indent=2))
sys.exit(0 if report['killed'] == report['total'] and report['restored_pass'] and report['restored_rebuilt'] else 1)
