Metal submission merge study versus frozen de02299 Metal frontend.
All routes use compact maps, Metal frontend and CPU NCC refinement. Compare
frozen split, current split, and merged source preparation plus first scan. Raw ordered
proposals, work and final poses must match; independent GT is also checked. Negative scale and
unlabelled photo outcomes are preserved. CPU deterministic candidate selection remains; this is not all-GPU search.

Offline replay with NumPy/OpenCV, no GPU required:
python3 EXTRACT/formal/source-snapshot/cpp-core/tools/benchmark_sparse_metal_merge.py --summarize EXTRACT/formal/results.json --output /tmp/replayed.json

Absolute paths are historical provenance; source snapshots, input fixtures,
protocol, raw worker records and validation logs are archived. Binary hashes
are recorded; executables omitted. All member hashes are in sha256.json.
