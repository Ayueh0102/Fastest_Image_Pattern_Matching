import datetime,hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[2];raw=root/'build/fine-search-results';dest=root/'build/fine-search-default-recheck';dest.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
formal=json.loads((raw/'formal.json').read_text());reference=json.loads((raw/'jobs/many128_pose_fullres_subpixel-frozen-b0.result.json').read_text())['first']
protocol=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),reason='Recheck stage29 disabled-mode versus frozen stage28 128 fullres speed tolerance failure; all original evidence retained.',order=['frozen','current','current','frozen'],case='many128_pose_fullres_subpixel',repeats=3,warmup_seconds=1,binary_sha256=formal['binary_sha256'],source_sha256=formal['source_sha256'],original_summary_sha256=sha(raw/'summary.json'),time_tolerance='max(10%,2ms)',script_sha256=sha(Path(__file__)))
assert not (dest/'protocol.json').exists();save(dest/'protocol.json',protocol);results=[]
for i,m in enumerate(protocol['order']):
 job=json.loads((raw/f'jobs/many128_pose_fullres_subpixel-{m}-b0.json').read_text());p=dest/f'{i}-{m}.json';save(p,job)
 binary=root/f'build/{"fine-strip" if m=="frozen" else "fine-search"}/experiments/fpm_native_pipeline_runner'
 r=subprocess.run([str(binary),str(p)],capture_output=True,text=True);out=p.with_suffix('.result.json');out.write_text(r.stdout);p.with_suffix('.stderr.txt').write_text(r.stderr);assert r.returncode==0,r.stderr
 d=json.loads(r.stdout);assert d['exact_repeat'] and all(x[k]==reference[k] for x in [d['first'],*d['runs']] for k in ('matches','proposals'))
 import statistics
 result=dict(method=m,index=i,job=p.name,job_sha256=sha(p),result=out.name,result_sha256=sha(out),exact=True,median_ms=statistics.median(x['total_ms'] for x in d['runs']),peak_rss_bytes=d['final_memory']['peak_rss_bytes']);results.append(result);save(dest/'progress.json',results);print(m,result['median_ms'],flush=True)
checks=[dict(time_delta_percent=100*(b['median_ms']/a['median_ms']-1),time_tolerance_pass=b['median_ms']<=a['median_ms']+max(.1*a['median_ms'],2)) for a,b in ((results[0],results[1]),(results[3],results[2]))]
unchanged=all(sha(Path(p))==h for p,h in formal['binary_sha256'].items()) and all(sha(root/p)==h for p,h in formal['source_sha256'].items())
save(dest/'summary.json',dict(complete=True,unchanged=unchanged,workers=4,formal_calls=12,all_exact=True,results=results,comparisons=checks));assert unchanged
