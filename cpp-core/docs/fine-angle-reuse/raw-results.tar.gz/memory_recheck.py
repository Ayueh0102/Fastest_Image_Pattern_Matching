import datetime,hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[2];dest=root/'build/fine-search-memory-recheck';dest.mkdir(exist_ok=True)
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
raw=root/'build/fine-search-results';formal=json.loads((raw/'formal.json').read_text());binary=root/'build/fine-search/experiments/fpm_native_pipeline_runner'
reference=json.loads((raw/'jobs/many512_pose_fullres_subpixel-current-b0.result.json').read_text())['first']
protocol=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),reason='Recheck stage29 512 fullres RSS tolerance failures without changing measured code. First plus one repeated call per fresh process, no warmup; not a replacement warm speed benchmark.',order=['current','reuse','reuse','current'],case='many512_pose_fullres_subpixel',repeats=1,warmup_seconds=0,binary_sha256=formal['binary_sha256'],source_sha256=formal['source_sha256'],original_summary_sha256=sha(raw/'summary.json'),rss_tolerance='max(10%,16MiB)',script_sha256=sha(Path(__file__)))
assert not (dest/'protocol.json').exists();save(dest/'protocol.json',protocol)
results=[]
for index,method in enumerate(protocol['order']):
 job=json.loads((raw/f'jobs/many512_pose_fullres_subpixel-{method}-b0.json').read_text());job.update(repeats=1,warmup_seconds=0)
 label=f'{index}-{method}';path=dest/(label+'.json');save(path,job)
 before=subprocess.check_output(['/usr/bin/vm_stat'],text=True);(dest/(label+'.vm-before.txt')).write_text(before)
 r=subprocess.run([str(binary),str(path)],capture_output=True,text=True);out=path.with_suffix('.result.json');out.write_text(r.stdout);path.with_suffix('.stderr.txt').write_text(r.stderr)
 (dest/(label+'.vm-after.txt')).write_text(subprocess.check_output(['/usr/bin/vm_stat'],text=True))
 assert r.returncode==0,r.stderr
 d=json.loads(r.stdout);assert d['exact_repeat'];assert all(x[k]==reference[k] for x in [d['first'],*d['runs']] for k in ('matches','proposals'))
 result=dict(method=method,index=index,job=path.name,job_sha256=sha(path),result=out.name,result_sha256=sha(out),exact=True,peak_rss_bytes=d['final_memory']['peak_rss_bytes'],first_ms=d['first']['total_ms'],repeat_ms=d['runs'][0]['total_ms'],first_memory=d['first']['memory'],repeat_memory=d['runs'][0]['memory'])
 results.append(result);save(dest/'progress.json',results);print(label,'peakMiB',result['peak_rss_bytes']/2**20,flush=True)
comparisons=[]
for a,b in ((results[0],results[1]),(results[3],results[2])):
 comparisons.append(dict(rss_delta_bytes=b['peak_rss_bytes']-a['peak_rss_bytes'],rss_tolerance_pass=b['peak_rss_bytes']<=a['peak_rss_bytes']+max(.1*a['peak_rss_bytes'],16*1024**2)))
unchanged=all(sha(Path(p))==h for p,h in formal['binary_sha256'].items()) and all(sha(root/p)==h for p,h in formal['source_sha256'].items())
save(dest/'summary.json',dict(complete=True,unchanged=unchanged,workers=4,algorithm_calls=8,results=results,comparisons=comparisons,all_exact=True))
assert unchanged
