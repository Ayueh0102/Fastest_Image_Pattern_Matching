# Stage29 exact angle-map reuse evidence

Read docs/FINE_ANGLE_REUSE_zh-TW.md. The main experiment has 72 fresh worker processes and 312 formal calls over nine search configurations on six existing images. Three variants reuse the same image/GT with full-resolution subpixel enabled. All ordered outputs match, but one default-speed pair and three RSS pairs failed their predeclared tolerances. Rechecks are supplemental, never replacements for those failures.

## Contents

- source/: complete measured algorithm, C++/Metal sources, native GUI sources, bindings, tests and tools. source-extras.json records the unchanged C API test and historical instrumentation patch omitted by the measurement manifest suffix filter; the C test was verified identical to baseline.
- frozen-source/: Git extraction of b31c1439e1d33c6dafb725a7306d3b4d4b9b47e1. binaries/: SHA-verified stage28 and stage29 runners and libraries. System Qt/OpenCV/Apple frameworks are dependencies, not vendored runtime distributions.
- protocol.json, formal.json, summary.json, jobs/: predeclared protocol and every main raw sample, including failures. input-paths.json maps original image paths to inputs/. previous-cases.json is the original six-case descriptor, hashed by the main protocol. frozen-protocol.json verifies original binary hashes.
- fine-search-memory-recheck/: four fresh-process first/repeat memory checks, 8 calls with no warmup, including global vm_stat snapshots. These snapshots do not establish a process-specific compression cause.
- fine-search-default-recheck/: four fresh-process warm default-versus-frozen checks, 12 formal calls. memory_recheck.py and default_recheck.py preserve exact scripts; their original protocols hash them.
- pilot/, logs/, rebuild-checks/, additional-validation.json: exploratory runs, all validation logs, retained failed attempts, archive rebuild and negative controls.

## Offline replay

From the extracted directory, Python3 plus NumPy is sufficient; no GPU or original image paths are required:

```sh
python source/cpp-core/tools/benchmark_fine_search.py --summarize formal.json --output replay-summary.json
```

Replay checks the predeclared protocol, job settings/hashes and raw output hashes and reproduces summary.json byte-for-byte. content-sha256.json hashes every other archived file. Hashes are integrity checks, not cryptographic authorship signatures.

## Source rebuild

On the measured macOS Apple Silicon environment with Command Line Tools, CMake, Qt6 and OpenCV available:

```sh
DEVELOPER_DIR=/Library/Developer/CommandLineTools cmake -S source/cpp-core -B rebuilt -DCMAKE_BUILD_TYPE=Release -DFPM_BUILD_EXPERIMENTS=ON -DFPM_BUILD_TESTS=ON -DFPM_BUILD_GUI=ON -DFPM_WITH_OPENCV=ON
DEVELOPER_DIR=/Library/Developer/CommandLineTools cmake --build rebuilt -j 6
ctest --test-dir rebuilt --output-on-failure
```

The archive staging sources were rebuilt with tests ON for native runner, scheduler and profiler targets; two tests and a small complete search passed. This is not a repeat of the full performance experiment. Build paths may change binary hashes. Frozen sources are preserved but were not rebuilt as the performance reference.

To rerun a native job, copy a jobs/*.json file, replace source/template paths using input-paths.json, and run rebuilt/experiments/fpm_native_pipeline_runner on that copy. Keep historical jobs intact for integrity replay. For full orchestration, relocate source/template paths in a copy of previous-cases.json (six original cases; the tool adds the three variants), then use --previous and --baseline-protocol frozen-protocol.json with the matching frozen binaries. Do not use the nine-case formal manifest as the six-case input descriptor. Current profiling stays off for deployment. GUI defaults remain unchanged.
