import json,subprocess,sys
from pathlib import Path
root=Path('/Users/Ayueh/Fastest_Image_Pattern_Matching');stage=root/'build/resident-multiscale-archive';checks=stage/'archive-checks';checks.mkdir(exist_ok=True)
mapping=json.loads((stage/'input-paths.json').read_text());proof={}
for method in ['resident0','fused256','simd128']:
 name='new_texture12-'+method+'-b0';job=json.loads((stage/'formal/jobs'/(name+'.json')).read_text())
 for key in ('source','template'):job[key]=str(stage/mapping[job[key]])
 p=checks/(method+'.json');p.write_text(json.dumps(job,indent=2)+'\n')
 r=subprocess.run([str(root/'build/resident-multiscale-archive-build/experiments/fpm_native_pipeline_runner'),str(p)],capture_output=True,text=True)
 p.with_suffix('.result.json').write_text(r.stdout);p.with_suffix('.stderr.txt').write_text(r.stderr)
 assert r.returncode==0,r.stderr
 new=json.loads(r.stdout);old=json.loads((stage/'formal/jobs'/(name+'.result.json')).read_text())
 for a,b in zip([new['first'],*new['runs']],[old['first'],*old['runs']]):
  assert a['matches']==b['matches'] and a['proposals']==b['proposals']
 proof[method]=True
out=checks/'replay.json'
r=subprocess.run([sys.executable,str(stage/'source/cpp-core/tools/benchmark_resident_multiscale.py'),'--summarize',str(stage/'formal/formal.json'),'--output',str(out)],capture_output=True,text=True)
(checks/'replay.stderr.txt').write_text(r.stderr)
assert r.returncode==1, r.stderr
assert out.read_bytes()==(stage/'formal/summary.json').read_bytes()
(checks/'validation.json').write_text(json.dumps({'fresh_build_exact':proof,'relocated_replay_byte_identical':True,'replay_exit':r.returncode,'replay_accuracy_failures_preserved':True},indent=2)+'\n')
print('Fresh source outputs exact; relocated false-accuracy summary reproduced')
