import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
root=Path('/Users/Ayueh/Fastest_Image_Pattern_Matching')
d=json.loads((root/'build/stage33-scale-bias.json').read_text())
slices=[s for s in d['slices'] if s['anchor']=='truth_xy_angle']
failed=set(d['accuracy']['strict']['unmatched_truth_indices'])
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(figsize=(9,5.2),constrained_layout=True)
for s in slices:
 x=np.array([p['relative_to_truth'] for p in s['grid']]); y=np.array([p['ncc'] for p in s['grid']])-s['truth_scale_ncc']
 bad=s['truth_index'] in failed
 ax.plot(100*(x-1),y,color='#c45b24' if bad else '#67869d',alpha=.8,lw=1.6)
 b=s['grid_best_index'];ax.plot(100*(x[b]-1),y[b],'o',color='#c45b24' if bad else '#67869d',ms=4)
ax.axvline(0,color='#222222',ls='--',lw=1,label='True scale')
ax.axvline(-2,color='#999999',ls=':',lw=1,label='-2% accuracy boundary')
ax.axhline(0,color='#777777',lw=.7)
ax.set(xlabel='Scale relative to rendered ground truth (%)',ylabel='NCC minus NCC at true scale',title='Small template: all 12 local NCC peaks favor a smaller scale')
ax.text(.02,.04,'Fixed true position and angle • 41 scales per object\nOrange: 5 strict scale failures; blue: 7 within tolerance\nDots: sampled maxima, not a global optimum claim',transform=ax.transAxes,fontsize=10,bbox={'facecolor':'white','alpha':.85,'edgecolor':'none'})
ax.legend(loc='upper right',frameon=False)
fig.savefig(root/'cpp-core/docs/resident-multiscale/scale-bias.png',dpi=160)
fig.savefig(root/'cpp-core/docs/resident-multiscale/scale-bias.svg')

svg_path = root / 'cpp-core/docs/resident-multiscale/scale-bias.svg'
svg_path.write_text('\n'.join(line.rstrip() for line in svg_path.read_text().splitlines()) + '\n')
