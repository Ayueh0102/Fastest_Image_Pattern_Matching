import hashlib,json,shutil,subprocess
from pathlib import Path
root=Path('/Users/Ayueh/Fastest_Image_Pattern_Matching');stage=root/'build/resident-multiscale-archive';raw=root/'build/resident-multiscale-results'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def cp(src,dst,expected=None):
 src,dst=Path(src),Path(dst)
 if expected:assert sha(src)==expected,str(src)
 dst.parent.mkdir(exist_ok=True,parents=True);shutil.copy2(src,dst)
r=json.loads((raw/'formal.json').read_text());s=json.loads((raw/'summary.json').read_text())
assert r['complete'] and r['unchanged']
shutil.copytree(raw,stage/'formal',dirs_exist_ok=True)
for p,h in r['source_sha256'].items():cp(root/p,stage/'source'/p,h)
for name in subprocess.check_output(['git','ls-files','macos-cli','MatchTool'],cwd=root,text=True).splitlines():cp(root/name,stage/'source'/name)
for p in ['LICENSE','AGENTS.md','CMakeLists.txt','vcpkg.json','Test Images/Src7.bmp','Test Images/Dst7.bmp','Test Images/Dst3.bmp','Test Images/Dst4.bmp']:cp(root/p,stage/'source'/p)
mapping={}
for index,(p,h) in enumerate(r['input_sha256'].items()):
 dst=Path('inputs')/(str(index)+'-'+Path(p).name);cp(p,stage/dst,h);mapping[p]=str(dst)
(stage/'input-paths.json').write_text(json.dumps(mapping,indent=2)+'\n')
for p,h in r['binary_sha256'].items():cp(p,stage/'binaries'/Path(p).name,h)
for name in ['resident-multiscale-inputs','resident-multiscale-pilot']:
 shutil.copytree(root/'build'/name,stage/name,dirs_exist_ok=True)
for p in (root/'build').glob('stage33-*.json'):cp(p,stage/'reviews'/p.name)
for p in (root/'build').glob('resident-multiscale*.log'):cp(p,stage/'logs'/p.name)
cp(root/'build/run-diagnostics/CMakeCache.txt',stage/'logs/measured-CMakeCache.txt')
cp(__file__,stage/'pack_resident_multiscale.py')
print(stage)
