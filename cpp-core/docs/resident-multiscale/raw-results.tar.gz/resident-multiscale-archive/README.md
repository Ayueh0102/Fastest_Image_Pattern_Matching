# Stage33: integration validation and experiment gaps

The SAME frozen stage32 native runner and libraries serve all three methods; no
C++/Metal algorithm/kernel/default changed in stage33. Full measured source is in
`source`, binaries in `binaries`; their install names may point to original build
paths, so rebuild for independent execution rather than treating copies as an app.

`formal` contains predeclared protocol, 48 fresh workers / 96 first+repeat calls,
all jobs/results/stderr and the summary. Accuracy and performance failures are
retained. The expected summary `correctness_passed` is false when any GT case
fails; this does not mean a worker crashed or the experiment is incomplete.

Offline replay, from this extracted archive directory:

```
python source/cpp-core/tools/benchmark_resident_multiscale.py --summarize formal/formal.json --output replay.json
```

The tool deliberately returns exit 1 for retained accuracy failures AFTER saving
replay.json. Compare its bytes to formal/summary.json and inspect the separate
integrity/paired/accuracy/performance flags; do not suppress or relabel failures.
Dependencies include NumPy, OpenCV and Pillow from the existing research tools.

`input-paths.json` maps historical paths to archived files. To execute a worker,
copy a job and replace source/template with extracted paths; leave measured jobs
unchanged. Generation cases include GT and must NEVER be supplied as runner jobs.
`resident-multiscale-inputs` contains new PNGs and independent generation metadata.
The four older controls use unchanged archived input bytes.

There are 24 different new synthetic poses from two existing photographed
textures, not 24 newly photographed scenes. Degraded12 reuses 12 clean poses and
adds synthetic strip occlusion after gray8 rendering, then blur/noise. Empty noise
is only a simple negative control. Pilot results were inspected, but thresholds,
fixtures, classification and search settings were not tuned afterwards.

`reviews` includes source reviews, pilot failure diagnosis and the bounded CPU
scale-score probe with independent float64 oracle. These are separate from formal
speed data. The scale probe is a one-dimensional slice, not a global optimum or a
proof of the unique cause of all scale errors. Original failures remain present.

Peak RSS and explicit byte capacities differ. Shared host/GPU image pages count
once; child wall clocks and GPU wait/device overlap. Two processes per case/arm
support regression checks, not precise small-effect statistics or tail estimates.
The old 30-minute soak is not re-labelled as coverage of this new combination.

The content manifest covers every retained file except itself. Reproduction scripts
record original paths; use the mapping above when executing after relocation.
