"""Write cpp-core/docs/stage47-chroma-margin/decision-and-failures.json from the summary (run from the repo root)."""
import hashlib, json
from pathlib import Path
DOCS = Path('cpp-core/docs/stage47-chroma-margin')
s = json.loads((DOCS / 'summary.json').read_text())
pc = s['per_condition']
tau = {g: s['catch'][g]['tau'] for g in s['catch']}
def cell(rule, arm, group, key):
    c = pc[rule][arm][group][key]
    return dict(same_accepted=c['same']['accepted'], same_n=c['same']['n'], same_decided=c['same']['decided'],
                same_max_decided=c['same']['max_decided'], different_wrongly_accepted=c['different']['wrongly_accepted'],
                different_n=c['different']['n'], different_abstained=c['different']['abstained'],
                different_min_decided=c['different']['min_decided'], auc=c['auc'], auc_valid=c['auc_valid'])
def margin(arm, condition, groups):
    """Largest decided same-colour residual / tau over the groups (1 = at the threshold)."""
    values = [pc['catch'][arm][g][f'holdout/{condition}']['same']['max_decided'] / tau[g] for g in groups
              if pc['catch'][arm][g][f'holdout/{condition}']['same']['max_decided'] is not None]
    return max(values) if values else None
def failures(rule, arm, gated):
    return [dict(rule=rule, arm=arm, gated=gated, name=c['name'], condition=c.get('condition'), group=c.get('group'),
                 value=c['value'], target=c['target'], n=c['n']) for c in s['hypotheses'][rule][arm] if not c['passed']]
rows = [r for r in s['rows'] if r['found'] and not r['same_colour']]
def accepted(r, arm):
    v = r['values'].get(arm)
    return v is not None and v <= tau[r['group']]
def tally(arm, predicate):
    sub = [r for r in rows if predicate(r)]
    return dict(accepted=sum(accepted(r, arm) for r in sub), n=len(sub), abstained=sum(r['values'].get(arm) is None for r in sub))
delta2 = {f'{g} {d}': tally('vk_region', lambda r, g=g, d=d: r['group'] == g and r['direction'] == d and r['delta_e00_target'] == 2.)
          for g in ('syn_red', 'syn_teal') for d in ('hue+', 'hue-', 'chroma-', 'isogray0', 'isogray90')}
lightness = {f'{g} lightness+ {t:g}': tally('vk_region', lambda r, g=g, t=t: r['group'] == g and r['direction'] == 'lightness+'
             and r['delta_e00_target'] == t) for g in ('syn_red', 'syn_teal', 'bl_red') for t in (4., 8.)}
gated_wrong = [dict(scene=r['scene'], index=r['index'], arm=arm) for arm in ('vk_region', 'vk_linear_region') for r in rows
               if r['direction'] in ('hue+', 'hue-', 'chroma-', 'isogray0', 'isogray90') and r['delta_e00_target'] >= 4 and accepted(r, arm)]
synthetic = ('syn_red', 'syn_teal')
margins = {c: margin('vk_region', c, synthetic) for c in ('wb_warm', 'spot_warm', 'noise_jpeg')}
margins.update({c: margin('vk_region', c, ('bl_red',)) for c in ('warm3200', 'mixed')})
e2e = {f"{r['condition']}": dict(value=r['value'], abstained=r['abstained'], n=r['n']) for r in s['end_to_end']['vk_region']}
bright = [pc['catch']['vk_region'][g]['holdout/exposure_bright'] for g in synthetic]
comparison = s['gradient_comparison']
failed = failures('catch', 'vk_region', True) + failures('catch', 'vk_linear_region', True) + \
    [dict(f, gated=False) for rule in ('rayleigh', 'p95') for arm in ('vk_region', 'vk_linear_region') for f in failures(rule, arm, False)] + \
    [dict(rule='catch', arm=arm, gated=False, name=r['name'], condition=r['condition'], value=r['value'], target=r['target'], n=r['n'],
          abstained=r['abstained']) for arm, records in s['end_to_end'].items() for r in records if not r['passed']]
decision = dict(
    stage=47, protocol_sha256=s['protocol_sha256'], summary_sha256=hashlib.sha256((DOCS / 'summary.json').read_bytes()).hexdigest(),
    runner_sha256=s['runner_sha256'], base_runner_sha256=s['base_runner_sha256'],
    integrity=dict(passed=s['integrity_passed'], failures=s['integrity_failures'],
                   note='412 workers (220 candidate, 192 base) exit 0 with exact repeat; search matches identical across the 8 (synthetic) or '
                        '7 (Blender) methods of every scene; every method except vk_linear equals the base runner (ce057fe); no GT in any job; '
                        'holdout seeds equal the protocol and were never used; artwork byte-identical to v1; masks equal stage 46; catch '
                        'thresholds recomputed equal the protocol'),
    localization=dict(all_found_no_fp=s['localization_all_found'], per_scene={k: [v['tp'], v['fp'], v['fn']] for k, v in s['localization'].items()}),
    thresholds=dict(catch=tau, rule='half the smallest noise-free region chroma distance of a DeltaE00 4 must-catch change (artwork only)'),
    primary=dict(arm='vk_region', checks=s['hypotheses']['catch']['vk_region'], passed=s['primary_passed'],
                 margin_max_same_over_tau=margins, end_to_end=e2e),
    gradient=dict(arm='vk_linear_region', checks=s['hypotheses']['catch']['vk_linear_region'], checks_passed=s['gradient_checks_passed'],
                  comparison=comparison, better_on_gradients=s['gradient_better_on_gradients'], preferred=s['gradient_preferred']),
    recommended=s['recommended'], gradient_preferred=s['gradient_preferred'],
    decision='RECOMMENDED as the research threshold rule: the catch-anchored threshold (tau = d_catch/2, red 0.00816, teal 0.01470) on '
             'chroma_vk vk_region passed every pre-registered integrity, F, H1 and H2 check on the fresh holdout, with abstention as a review '
             'output (spot_warm end-to-end 9/20 because 11 same-colour objects abstain on a clipped panel; exposure_bright abstains on every object). '
             'The linear reference model is NOT preferred: it failed F1 for teal (calibration maximum 0.00911 against tau/2 0.00735) and gave larger '
             'same-colour residuals than the constant model in 9 of 13 gradient pairs (sign test p = 0.954). No default changes; '
             'chroma_vk and reference_model stay opt-in.',
    defaults='unchanged: gray_ncc, rgb_ncc, chroma and the constant chroma_vk are byte-identical to the base runner; GUI, core and research defaults untouched',
    failed_checks=failed,
    gated_different_colour_wrongly_accepted=gated_wrong,
    ungated=dict(delta_e2_primary=delta2, lightness_primary=lightness,
                 exposure_bright=[dict(group=g, same_abstained=c['same']['abstained'], same_n=c['same']['n'],
                                       different_abstained=c['different']['abstained'], different_n=c['different']['n'])
                                  for g, c in zip(synthetic, bright)]),
    predictions=[
        dict(id='P1', held=True, observed='F1 and F2 pass for every group; the largest calibration same-colour residual is 0.15 (red), 0.24 (teal) and '
             '0.23 (Blender) of tau', evidence={c['group']: c['value'] for c in s['hypotheses']['catch']['vk_region'] if c['name'].startswith('F1')}),
        dict(id='P2', held=True, observed='wb_warm 20/20 and noise_jpeg 20/20 decided same-colour objects accepted',
             evidence=dict(wb_warm=[cell('catch', 'vk_region', g, 'holdout/wb_warm') for g in synthetic],
                           noise_jpeg=[cell('catch', 'vk_region', g, 'holdout/noise_jpeg') for g in synthetic])),
        dict(id='P3', held=True, observed='spot_warm 9/9 decided accepted; its largest residual is the closest to tau of the gated synthetic cells '
             f"({margins['spot_warm']:.3f} of tau against noise_jpeg {margins['noise_jpeg']:.3f} and wb_warm {margins['wb_warm']:.3f}); "
             f"Blender mixed is tighter still ({margins['mixed']:.3f})",
             evidence=margins),
        dict(id='P4', held=True, observed=f"spot_warm end-to-end {e2e['spot_warm']['value']:.2f} ({e2e['spot_warm']['abstained']} of 20 same-colour "
             'abstained); exposure_bright abstained on all 64 objects', evidence=dict(spot_warm=e2e['spot_warm'], exposure_bright=bright)),
        dict(id='P5', held=True, observed='no gated different-colour object accepted by vk_region (H1b, H1c, H2b all 1.0)', evidence=gated_wrong),
        dict(id='P6', held='partly', observed='no lightness+ object was accepted (held); red hue+/- DeltaE 2 were accepted 3/12 and 4/12, about a third rather than '
             'the predicted half; the prediction missed teal, whose hue+ and isogray0 DeltaE 2 variants (noise-free 0.0139 and 0.0143, just below '
             'tau 0.0147) were accepted 8/12 and 7/12; every other DeltaE 2 direction 0/12',
             evidence=dict(delta_e2=delta2, lightness=lightness)),
        dict(id='P7', held=True, observed='Rayleigh: noise_jpeg 0.40, spot_warm 0.89, Blender mixed 0.75; p95: spot_warm 0.33, noise_jpeg 0.25, mixed 0.75',
             evidence=dict(rayleigh=failures('rayleigh', 'vk_region', False), p95=failures('p95', 'vk_region', False))),
        dict(id='P8', held=False, observed='the linear arm did NOT lower the gradient residuals (spot_warm 2 wins / 7 losses, mixed 2 wins / 2 losses, pooled p = 0.954); '
             'it did raise uniform-light residuals (noise_jpeg median ratio 2.10, 6/14) and abstained exactly as often in spot_warm (11)',
             evidence=comparison),
        dict(id='P9', held=True, observed='Blender warm3200 4/4 and mixed 4/4 decided same-colour accepted by both arms',
             evidence=dict(primary=[cell('catch', 'vk_region', 'bl_red', f'holdout/{c}') for c in ('warm3200', 'mixed')],
                           linear=[cell('catch', 'vk_linear_region', 'bl_red', f'holdout/{c}') for c in ('warm3200', 'mixed')])),
    ],
)
(DOCS / 'decision-and-failures.json').write_text(json.dumps(decision, indent=1) + '\n')
print('recommended', decision['recommended'], 'gradient preferred', decision['gradient_preferred'], 'failed checks', len(failed),
      'gated wrong', len(gated_wrong)); print(margins); print(delta2); print(lightness)
