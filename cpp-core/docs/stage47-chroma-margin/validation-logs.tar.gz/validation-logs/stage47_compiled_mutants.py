"""Stage-47 compiled mutants of the linear reference model (experiments/color_illuminant.cpp) and its runner key
(tools/color_verify_runner.cpp). Runs on a git-archive copy of COMMIT (the worktree is never modified): each mutant
is compiled into BUILD and must make the native test (fpm_color_illuminant_test) or the runner contract tests fail.
Usage, from the repository root: python stage47_compiled_mutants.py COMMIT SRC BUILD"""
import subprocess, sys
from pathlib import Path
PY = '/Users/Ayueh/Fastest_Image_Pattern_Matching/python-port/venv/bin/python'
commit, SRC, BUILD = sys.argv[1], Path(sys.argv[2]).resolve(), Path(sys.argv[3]).resolve()
CPP, RUNNER = 'cpp-core/experiments/color_illuminant.cpp', 'cpp-core/tools/color_verify_runner.cpp'
MUTANTS = [
 ('L1 slopes not applied', CPP, [('white[c] = reference.white[c]+slopeU[c]*(double(sample.u)-centreU)+slopeV[c]*(double(sample.v)-centreV);', 'white[c] = reference.white[c];')]),
 ('L2 u slope dropped', CPP, [('white[c] = reference.white[c]+slopeU[c]*(double(sample.u)-centreU)+slopeV[c]*(double(sample.v)-centreV);', 'white[c] = reference.white[c]+slopeV[c]*(double(sample.v)-centreV);')]),
 ('L3 v slope dropped', CPP, [('white[c] = reference.white[c]+slopeU[c]*(double(sample.u)-centreU)+slopeV[c]*(double(sample.v)-centreV);', 'white[c] = reference.white[c]+slopeU[c]*(double(sample.u)-centreU);')]),
 ('L4 extrapolation sign flipped', CPP, [('slopeU[c]*(double(sample.u)-centreU)', 'slopeU[c]*(centreU-double(sample.u))')]),
 ('L5 per-axis slopes instead of the joint solve', CPP, [('slopeU[c] = (dw1*dv2-dw2*dv1)/determinant;', 'slopeU[c] = dw1/du1;'), ('slopeV[c] = (du1*dw2-du2*dw1)/determinant;', 'slopeV[c] = dw2/dv2;')]),
 ('L6 end usability not required', CPP, [('reference.usable = reference.usable && end[e].usable;', 'reference.usable = reference.usable;')]),
 ('L7 non-positive illuminant accepted', CPP, [('positive = positive && white[c] > 0;', 'positive = true;')]),
 ('L8 linear region uses the centre gain', CPP, [('out.regionDistance = chromaDistance(correctedSum, templateSum);', 'std::array<double, 3> c0{}; for (int c = 0; c < 3; ++c) c0[c] = sourceSum[c]*out.gain[c]; out.regionDistance = chromaDistance(c0, templateSum);')]),
 ('L9 centre at the template origin', CPP, [('centreU = median(coordinates[0]);', 'centreU = 0;'), ('centreV = median(coordinates[1]);', 'centreV = 0;')]),
 ('L10 low and high ends swapped', CPP, [('ends_[order[k]] |= std::uint8_t(1u << (2*axis));', 'ends_[order[k]] |= std::uint8_t(2u << (2*axis));'), ('ends_[order[n-1-k]] |= std::uint8_t(2u << (2*axis));', 'ends_[order[n-1-k]] |= std::uint8_t(1u << (2*axis));')]),
 ('L11 halves instead of thirds', CPP, [('const std::size_t n = reference_.size(), third = n/3;', 'const std::size_t n = reference_.size(), third = n/2;')]),
 ('L12 ends at the centroid instead of the median coordinate', CPP, [('for (int e = 0; e < 4; ++e) for (int axis = 0; axis < 2; ++axis) at[e][axis] = median(endCoordinates[e][axis]);',
     'for (int e = 0; e < 4; ++e) for (int axis = 0; axis < 2; ++axis) { double s = 0; for (double v : endCoordinates[e][axis]) s += v; at[e][axis] = s/double(endCoordinates[e][axis].size()); }')]),
 ('L13 unusable linear result keeps its gain', CPP, [('    if (!positive) out.gain = {};\n', '')]),
 ('L14 slopes reported for the constant model', CPP, [('        } else {\n            std::array<double, 3> corrected{};\n            for (int c = 0; c < 3; ++c) corrected[c] = sourceSum[c]*out.gain[c];',
     '        } else {\n            out.referenceSlopeU = {1, 1, 1};\n            std::array<double, 3> corrected{};\n            for (int c = 0; c < 3; ++c) corrected[c] = sourceSum[c]*out.gain[c];')]),
 ('L15 linear with a source rectangle not rejected', CPP, [('    if (config.model == ReferenceModel::Linear && config.source != IlluminantSource::Object)\n        throw std::invalid_argument("Linear reference model requires an object reference");\n', '')]),
 ('L16 one-axis reference accepted', CPP, [('                if (reference_[order[third-1]][axis] == reference_[order[n-third]][axis])\n                    throw std::invalid_argument("Linear reference model needs a reference extended along both template axes");\n', '')]),
 ('R1 runner ignores reference_model', RUNNER, [('    else if(model=="linear") config.model=fpm::research::ReferenceModel::Linear;', '    else if(model=="linear") config.model=fpm::research::ReferenceModel::Constant;')]),
 ('R2 runner emits slopes for the constant model', RUNNER, [('out.append(illuminantJson(color,vkConfig.model==fpm::research::ReferenceModel::Linear));', 'out.append(illuminantJson(color,true));')]),
 ('R3 runner accepts unknown reference_model', RUNNER, [('    else throw std::invalid_argument("reference_model must be constant or linear");\n', '')]),
 ('R4 runner accepts reference_model for chroma', RUNNER, [('"max_reference_clip_fraction","min_reference_fraction","reference_model"};', '"max_reference_clip_fraction","min_reference_fraction"};')]),
]
def run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, **kw)
if not SRC.exists():
    SRC.mkdir(parents=True)
    archive = subprocess.run(['git', 'archive', commit], capture_output=True, check=True).stdout
    subprocess.run(['tar', '-x', '-C', str(SRC)], input=archive, check=True)
originals = {path: (SRC / path).read_text() for path in (CPP, RUNNER)}
if not (BUILD / 'CMakeCache.txt').exists():
    r = run(['cmake', '-S', str(SRC / 'cpp-core'), '-B', str(BUILD), '-DCMAKE_BUILD_TYPE=Release', '-DFPM_BUILD_GUI=ON',
             '-DFPM_BUILD_EXPERIMENTS=ON', '-DFPM_WITH_OPENCV=ON'])
    assert r.returncode == 0, r.stderr
survived = 0
def build_and_test():
    build = run(['cmake', '--build', str(BUILD), '-j', '--target', 'fpm_color_illuminant_test', 'fpm_color_verify_runner'])
    if build.returncode:
        return None, build
    native = run([str(BUILD / 'experiments/fpm_color_illuminant_test')])
    contract = run([PY, str(SRC / 'cpp-core/tests/color_verify_runner_test.py'), '--runner', str(BUILD / 'experiments/fpm_color_verify_runner'), '--metal'])
    return (native, contract), build
try:
    tested, build = build_and_test()
    assert tested and not tested[0].returncode and not tested[1].returncode, 'unmutated copy must pass'
    print('unmutated: native and runner contract pass', flush=True)
    for name, path, edits in MUTANTS:
        text = originals[path]
        for old, new in edits:
            assert text.count(old) == 1, (name, old)
            text = text.replace(old, new)
        (SRC / path).write_text(text)
        tested, build = build_and_test()
        (SRC / path).write_text(originals[path])
        if tested is None:
            print(name, 'BUILD FAILED', build.stderr[-800:].replace('\n', ' '), flush=True)
            survived += 1
            continue
        native, contract = tested
        killed_by = [k for k, r in (('native', native), ('runner_contract', contract)) if r.returncode]
        detail = native.stderr.strip().splitlines()[-1:] if native.returncode else []
        survived += not killed_by
        print(name, 'KILLED' if killed_by else 'SURVIVED', killed_by, detail, flush=True)
finally:
    for path, text in originals.items():
        (SRC / path).write_text(text)
tested, build = build_and_test()
print('restored:', tested is not None and not tested[0].returncode and not tested[1].returncode, 'survived:', survived)
sys.exit(1 if survived else 0)
