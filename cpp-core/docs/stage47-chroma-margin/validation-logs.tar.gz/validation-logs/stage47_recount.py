"""Independent stage-47 recount. Imports neither the harness (benchmark_chroma_margin, benchmark_illuminant_colour),
testbed_generate nor many_object_accuracy.

Re-derives, from the protocol, the run manifest, worker outputs, GT files and the v1 texture records only: the catch
thresholds (own sRGB/CIELAB/CIEDE2000 and bisection), strict assignment (own matcher), per-object dissimilarities,
the Rayleigh and p95 thresholds, every cell, the F/H1/H2 checks of both arms under all three rules, end-to-end
acceptance, the paired sign test, the verdicts and the holdout integrity, then compares every number with the summary.
Usage: python stage47_recount.py PROTOCOL MANIFEST SUMMARY OUTPUT.json [--negative]
"""
import hashlib
import json
import math
from pathlib import Path
import sys

protocol_path, manifest_path, summary_path, output_path = map(Path, sys.argv[1:5])
negative = '--negative' in sys.argv
root = manifest_path.resolve().parent
protocol = json.loads(protocol_path.read_text())
manifest = json.loads(manifest_path.read_text())
summary = json.loads(summary_path.read_text())
if negative:  # one wrongly accepted object more than the harness reported must be detected
    summary['per_condition']['catch']['vk_region']['syn_red']['holdout/wb_warm']['different']['wrongly_accepted'] += 1

GROUPS = ('syn_red', 'syn_teal', 'bl_red')
FAMILY = dict(syn_red='red', syn_teal='teal', bl_red='red')
ARM = {'gray_ncc': ('gray_ncc', 'ncc'), 'rgb_ncc': ('rgb_ncc', 'ncc'), 'chroma': ('chroma', 'mean_distance'),
       'chroma_masked': ('chroma_masked', 'mean_distance'), 'masked_region': ('vk_object_none', 'uncorrected_region_distance'),
       'vk_pixel': ('vk_object', 'mean_distance'), 'vk_region': ('vk_object', 'region_distance'),
       'vk_none_region': ('vk_object_none', 'region_distance'), 'card_gray_region': ('card_gray', 'region_distance'),
       'vk_linear_region': ('vk_linear', 'region_distance'), 'vk_linear_pixel': ('vk_linear', 'mean_distance')}
NCC = ('gray_ncc', 'rgb_ncc')
GATED = ('hue+', 'hue-', 'chroma-', 'isogray0', 'isogray90')
problems, checks = [], 0


def same(label, mine, theirs, tol=0.):
    global checks
    checks += 1
    if mine is None or theirs is None:
        ok = mine is None and theirs is None
    elif isinstance(mine, float) or isinstance(theirs, float):
        ok = abs(mine - theirs) <= tol
    else:
        ok = mine == theirs
    if not ok:
        problems.append(f'{label}: recount {mine!r} vs summary {theirs!r}')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


# ---------------------------------------------------------------- catch thresholds, independently
def to_linear(c):
    c = c / 255.
    return c / 12.92 if c <= .04045 else ((c + .055) / 1.055) ** 2.4


def from_linear(v):
    v = max(v, 0.)
    return 255. * (v * 12.92 if v <= .0031308 else 1.055 * v ** (1 / 2.4) - .055)


M = ((.4124564, .3575761, .1804375), (.2126729, .7151522, .0721750), (.0193339, .1191920, .9503041))
WHITE = (.95047, 1., 1.08883)


def invert3(m):
    (a, b, c), (d, e, f), (g, h, i) = m
    det = a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)
    return ((e * i - f * h) / det, (c * h - b * i) / det, (b * f - c * e) / det), \
           ((f * g - d * i) / det, (a * i - c * g) / det, (c * d - a * f) / det), \
           ((d * h - e * g) / det, (b * g - a * h) / det, (a * e - b * d) / det)


MINV = invert3(M)


def lab(rgb):
    lin = [to_linear(c) for c in rgb]
    xyz = [sum(M[r][k] * lin[k] for k in range(3)) / WHITE[r] for r in range(3)]
    f = [t ** (1 / 3) if t > (6 / 29) ** 3 else t / (3 * (6 / 29) ** 2) + 4 / 29 for t in xyz]
    return 116 * f[1] - 16, 500 * (f[0] - f[1]), 200 * (f[1] - f[2])


def rgb_from_lab(L, a, b):
    fy = (L + 16) / 116
    f = (fy + a / 500, fy, fy - b / 200)
    xyz = [(t ** 3 if t > 6 / 29 else 3 * (6 / 29) ** 2 * (t - 4 / 29)) * WHITE[k] for k, t in enumerate(f)]
    return [from_linear(sum(MINV[r][k] * xyz[k] for k in range(3))) for r in range(3)]


def de2000(p, q):
    (L1, a1, b1), (L2, a2, b2) = p, q
    cb = (math.hypot(a1, b1) + math.hypot(a2, b2)) / 2
    g = .5 * (1 - math.sqrt(cb ** 7 / (cb ** 7 + 25 ** 7)))
    A1, A2 = a1 * (1 + g), a2 * (1 + g)
    C1, C2 = math.hypot(A1, b1), math.hypot(A2, b2)
    h1 = math.degrees(math.atan2(b1, A1)) % 360 if C1 else 0.
    h2 = math.degrees(math.atan2(b2, A2)) % 360 if C2 else 0.
    dL, dC = L2 - L1, C2 - C1
    dh = 0. if C1 * C2 == 0 else (h2 - h1 - 360 if h2 - h1 > 180 else h2 - h1 + 360 if h2 - h1 < -180 else h2 - h1)
    dH = 2 * math.sqrt(C1 * C2) * math.sin(math.radians(dh / 2))
    Lb, Cb = (L1 + L2) / 2, (C1 + C2) / 2
    if C1 * C2 == 0:
        hb = h1 + h2
    elif abs(h1 - h2) <= 180:
        hb = (h1 + h2) / 2
    else:
        hb = (h1 + h2 + 360) / 2 if h1 + h2 < 360 else (h1 + h2 - 360) / 2
    T = 1 - .17 * math.cos(math.radians(hb - 30)) + .24 * math.cos(math.radians(2 * hb)) \
        + .32 * math.cos(math.radians(3 * hb + 6)) - .2 * math.cos(math.radians(4 * hb - 63))
    Rc = 2 * math.sqrt(Cb ** 7 / (Cb ** 7 + 25 ** 7))
    SL = 1 + .015 * (Lb - 50) ** 2 / math.sqrt(20 + (Lb - 50) ** 2)
    SC, SH = 1 + .045 * Cb, 1 + .015 * Cb * T
    RT = -math.sin(math.radians(60 * math.exp(-((hb - 275) / 25) ** 2))) * Rc
    return math.sqrt((dL / SL) ** 2 + (dC / SC) ** 2 + (dH / SH) ** 2 + RT * (dC / SC) * (dH / SH))


def chroma_distance(x, y):
    sx, sy = sum(x), sum(y)
    return math.sqrt(sum((p / sx - q / sy) ** 2 for p, q in zip(x, y)) * .5)


# Sharma, Wu, Dalal (2005) reference pairs 1, 7 and 17 guard the independent CIEDE2000.
for p, q, expected in (((50, 2.6772, -79.7751), (50, 0, -82.7485), 2.0425), ((50, 0, 0), (50, -1, 2), 2.3669),
                       ((50, 2.5, 0), (73, 25, -18), 27.1492)):
    same(f'ciede2000 reference {expected}', round(de2000(p, q), 4), expected)
textures = json.loads((Path(manifest['v1']) / 'textures' / 'textures.json').read_text())
families = textures['families']
catch = {}
for family, base in families.items():
    base_lab = lab(base)
    base_linear = [to_linear(c) for c in base]
    distances = []
    for degrees in range(360):
        angle = math.radians(degrees)
        point = lambda t: (base_lab[0], base_lab[1] + t * math.cos(angle), base_lab[2] + t * math.sin(angle))
        lo, hi = 0., 60.
        for _ in range(80):
            mid = (lo + hi) / 2
            lo, hi = (mid, hi) if de2000(base_lab, point(mid)) < 4 else (lo, mid)
        rgb = rgb_from_lab(*point((lo + hi) / 2))
        if all(0 <= c <= 255 for c in rgb):
            distances.append(chroma_distance(base_linear, [to_linear(c) for c in rgb]))
    same(f'{family} circle in gamut', len(distances), 360)
    variants = [chroma_distance(base_linear, [to_linear(c) for c in t['field_rgb']]) for t in textures['textures']
                if t['family'] == family and t['direction'] in GATED and t['delta_e00_target'] >= 4]
    same(f'{family} gated variants', len(variants), 15)
    catch[family] = min(min(distances), min(variants)) / 2
for g in GROUPS:
    same(f'catch tau {g} vs summary', catch[FAMILY[g]], summary['catch'][g]['tau'], 1e-9)
    same(f'catch tau {g} vs protocol', catch[FAMILY[g]], protocol['thresholds']['catch_tau'][g]['tau'], 1e-9)

# ---------------------------------------------------------------- raw outputs and holdout
executions = {}
for e in manifest['executions']:
    same(f"job hash {e['job']}", digest(root / e['job']), e['job_sha256'])
    same(f"returncode {e['job']}", e['returncode'], 0)
    if e['returncode'] == 0:
        same(f"result hash {e['result']}", digest(root / e['result']), e['result_sha256'])
    executions[(e['scene'], e['method'], e['runner_kind'])] = e
for path, h in manifest['input_sha256'].items():
    same(f'input {path}', digest(path), h)
same('run complete and unchanged', bool(manifest['complete'] and manifest['unchanged']), True)
holdout, v1 = Path(manifest['holdout']), Path(manifest['v1'])
seeds = protocol['data']['holdout_seeds']
same('holdout record', json.loads((holdout / 'holdout.json').read_text())['seeds'], seeds)
same('synthetic seeds', json.loads((holdout / 'synthetic' / 'synthetic.json').read_text())['seeds'],
     dict(texture=seeds['synthetic']['texture'], layout=seeds['synthetic']['layout'], noise=seeds['synthetic']['noise'],
          background=seeds['synthetic']['background']))
blender = json.loads((holdout / 'blender' / 'blender_generation.json').read_text())
same('blender seeds', [blender['seed'], blender['rgb_order_seed'], blender['rgb_layout_seed']],
     [seeds['blender']['cycles'], seeds['blender']['order'], seeds['blender']['layout']])
fresh = [seeds['synthetic']['noise'] + k for k in list(range(8)) + [99]] + [seeds['synthetic']['background'],
         *seeds['synthetic']['layout'].values(), *seeds['blender'].values()]
same('holdout seeds unused and distinct (derived noise seeds included)',
     not (set(fresh) & set(protocol['data']['used_seeds'])) and len(set(fresh)) == len(fresh), True)
v1_textures = sorted(p.name for p in (v1 / 'textures').iterdir())
same('texture file names', v1_textures, sorted(p.name for p in (holdout / 'textures').iterdir()))
for name in v1_textures:
    same(f'texture {name}', digest(holdout / 'textures' / name), digest(v1 / 'textures' / name))
for name, h in protocol['masks']['files'].items():
    same(f'mask {name}', digest(Path(manifest['masks']) / name), h)


def wrap(angle):
    return (angle + 180.) % 360. - 180.


def value(score, statistic):
    if statistic == 'ncc':
        return None if score < -1 else 1 - score
    v = score[statistic]
    return None if v < 0 else v


forbidden = ('"truth"', '"same_colour"', '"direction"', '.truth.json', 'delta_e', '"labels"', '"objects"')
rows = []
for scene in manifest['scenes']:
    key = scene['key']
    methods = [m for m in manifest['methods'] if scene['source'] == 'synthetic' or m != 'card_gray']
    results = {m: json.loads((root / executions[(key, m, 'candidate')]['result']).read_text()) for m in methods}
    for m in methods:
        same(f'{key} {m} exact_repeat', results[m]['exact_repeat'], True)
        text = (root / executions[(key, m, 'candidate')]['job']).read_text()
        same(f'{key} {m} job has no GT', any(k in text for k in forbidden) or ('/blender/' in text and '.json' in text), False)
        same(f'{key} {m} base run exists', (key, m, 'base') in executions, m != 'vk_linear')
        if (key, m, 'base') in executions:
            base = json.loads((root / executions[(key, m, 'base')]['result']).read_text())
            same(f'{key} {m} base scores', base['first']['scores'] == results[m]['first']['scores'], True)
            same(f'{key} {m} base matches', base['first']['search_matches'] == results[m]['first']['search_matches'], True)
    matches = results['gray_ncc']['first']['search_matches']
    for m in methods:
        same(f'{key} {m} localization identity', results[m]['first']['search_matches'] == matches, True)
    meta = json.loads(Path(scene['truth']).read_text())
    truth = meta['truth'] if scene['source'] == 'synthetic' else \
        [dict(o, pos_x=o['projected_center'][0], pos_y=o['projected_center'][1]) for o in meta['objects']]
    if scene['source'] == 'synthetic':
        same(f'{key} reference card', meta['reference_card']['xyxy'], [24, 16, 312, 112])
    candidates = {}
    for t_index, t in enumerate(truth):
        hits = [k for k, p in enumerate(matches) if math.hypot(p['pos_x'] - t['pos_x'], p['pos_y'] - t['pos_y']) <= 2
                and abs(wrap(p['angle'] - t['angle'])) <= 1 and abs(p['scale'] / t['scale'] - 1) <= .02]
        same(f'{key} truth {t_index} ambiguous', len(hits) <= 1, True)
        candidates[t_index] = hits[0] if hits else None
    used = [p for p in candidates.values() if p is not None]
    same(f'{key} prediction used twice', len(used) == len(set(used)), True)
    loc = summary['localization'][key]
    same(f'{key} tp', len(used), loc['tp'])
    same(f'{key} fp', len(matches) - len(used), loc['fp'])
    same(f'{key} fn', len(truth) - len(used), loc['fn'])
    for t_index, t in enumerate(truth):
        p = candidates[t_index]
        rows.append(dict(scene=key, group=scene['group'], condition=scene['condition'], split=scene['split'], source=scene['source'],
                         same=bool(t['same_colour']), direction=t['direction'], target=float(t['delta_e00_target']), found=p is not None,
                         values={arm: value(results[m]['first']['scores'][p], st) for arm, (m, st) in ARM.items() if m in results}
                         if p is not None else {}))
same('row count', len(rows), len(summary['rows']))
for mine, theirs in zip(rows, summary['rows']):
    same(f"row {mine['scene']} {theirs['index']} identity", (mine['scene'], mine['split'], mine['same'], mine['found']),
         (theirs['scene'], theirs['split'], theirs['same_colour'], theirs['found']))
    same(f"row {mine['scene']} {theirs['index']} values", mine['values'] == theirs['values'], True)


# ---------------------------------------------------------------- thresholds
def percentile95(values):
    xs = sorted(values)
    h = (len(xs) - 1) * .95
    lo = int(math.floor(h))
    return xs[lo] if lo + 1 >= len(xs) else xs[lo] + (h - lo) * (xs[lo + 1] - xs[lo])


def calibration(arm, g):
    return [r['values'][arm] for r in rows if r['split'] == 'calibration' and r['group'] == g and r['same'] and r['found']
            and r['values'].get(arm) is not None]


tables = {}
for rule in ('catch', 'rayleigh', 'p95'):
    table = {}
    for arm in ARM:
        for g in GROUPS:
            if not any(arm in r['values'] for r in rows if r['group'] == g and r['found']):
                continue
            vals = calibration(arm, g)
            if rule == 'catch':
                table[(arm, g)] = None if arm in NCC else catch[FAMILY[g]]
            elif rule == 'rayleigh':
                table[(arm, g)] = None if arm in NCC or not vals else \
                    math.sqrt(sum(v * v for v in vals) / len(vals) / 2) * math.sqrt(2 * math.log(1000))
            else:
                table[(arm, g)] = percentile95(vals) if vals else None
    reported = {(t['arm'], t['group']): t['value'] for t in summary['thresholds'][rule]}
    same(f'{rule} threshold keys', sorted(table), sorted(reported))
    for k, v in table.items():
        same(f'{rule} threshold {k}', v, reported.get(k), 1e-9 if rule == 'catch' else 1e-15)
    tables[rule] = table


def ok(r, arm, table):
    v, t = r['values'].get(arm), table.get((arm, r['group']))
    return v is not None and t is not None and v <= t


def auc(s, d):
    if not s or not d:
        return None
    s = [math.inf if v is None else v for v in s]
    d = [math.inf if v is None else v for v in d]
    return sum(1 if a > b else .5 if a == b else 0 for a in d for b in s) / len(s) / len(d)


for rule, table in tables.items():
    for arm in ARM:
        for g in GROUPS:
            for cell_key, cell in summary['per_condition'][rule][arm][g].items():
                split, condition = cell_key.split('/')
                sub = [r for r in rows if r['group'] == g and r['split'] == split and r['condition'] == condition and r['found']
                       and arm in r['values']]
                s, d = [r for r in sub if r['same']], [r for r in sub if not r['same']]
                tag = f'{rule} {arm} {g} {cell_key}'
                same(f'{tag} same n', len(s), cell['same']['n'])
                same(f'{tag} decided', sum(r['values'][arm] is not None for r in s), cell['same']['decided'])
                same(f'{tag} accepted', sum(ok(r, arm, table) for r in s), cell['same']['accepted'])
                same(f'{tag} wrongly accepted', sum(ok(r, arm, table) for r in d), cell['different']['wrongly_accepted'])
                same(f'{tag} different abstained', sum(r['values'][arm] is None for r in d), cell['different']['abstained'])
                same(f'{tag} auc', auc([r['values'][arm] for r in s], [r['values'][arm] for r in d]), cell['auc'], 1e-12)
                same(f'{tag} auc valid', auc([r['values'][arm] for r in s if r['values'][arm] is not None],
                                             [r['values'][arm] for r in d if r['values'][arm] is not None]), cell['auc_valid'], 1e-12)


# ---------------------------------------------------------------- checks, end-to-end, paired, verdicts
def gated(r):
    return not r['same'] and r['direction'] in GATED and r['target'] >= 4


def my_checks(arm, table):
    out = []
    found = [r for r in rows if r['found'] and arm in r['values']]
    for g in GROUPS:
        vals = calibration(arm, g)
        t = table.get((arm, g))
        out.append(bool(vals) and t is not None and max(vals) <= t / 2)
        d = [r for r in found if r['split'] == 'calibration' and r['group'] == g and gated(r)]
        out.append(bool(d) and sum(not ok(r, arm, table) for r in d) / len(d) >= .95)
    hold = [r for r in found if r['split'] == 'holdout']
    for conditions, source, st, dt, minimum in ((('wb_warm', 'spot_warm', 'noise_jpeg'), 'synthetic', .9, .95, 5),
                                                (('warm3200', 'mixed'), 'blender', 1., 1., 2)):
        for c in conditions:
            sub = [r for r in hold if r['condition'] == c and r['source'] == source]
            dec = [r for r in sub if r['same'] and r['values'][arm] is not None]
            d = [r for r in sub if gated(r)]
            out.append(len(dec) >= minimum and sum(ok(r, arm, table) for r in dec) / len(dec) >= st)
            out.append(bool(d) and sum(not ok(r, arm, table) for r in d) / len(d) >= dt)
    iso = [r for r in hold if r['source'] == 'synthetic' and r['condition'] in ('wb_warm', 'spot_warm', 'noise_jpeg') and gated(r)
           and r['direction'].startswith('isogray')]
    same(f'{arm} isogray n', len(iso), 36)
    out.append(sum(not ok(r, arm, table) for r in iso) / len(iso) >= .95)
    return out


for rule, table in tables.items():
    for arm in ('vk_region', 'vk_linear_region'):
        mine = my_checks(arm, table)
        theirs = summary['hypotheses'][rule][arm]
        same(f'{rule} {arm} check count', len(mine), len(theirs))
        for k, (a, b) in enumerate(zip(mine, theirs)):
            same(f"{rule} {arm} check {k} {b['name']} {b.get('condition') or b.get('group')}", a, b['passed'])
primary_passed = all(my_checks('vk_region', tables['catch']))
gradient_checks = all(my_checks('vk_linear_region', tables['catch']))
same('primary_passed', primary_passed, summary['primary_passed'])
same('gradient_checks_passed', gradient_checks, summary['gradient_checks_passed'])
for arm, records in summary['end_to_end'].items():
    for record in records:
        s = [r for r in rows if r['found'] and r['split'] == 'holdout' and r['condition'] == record['condition'] and r['same']]
        same(f"end to end {arm} {record['condition']}", sum(ok(r, arm, tables['catch']) for r in s) / len(s), record['value'], 1e-15)
        same(f"end to end {arm} {record['condition']} abstained", sum(r['values'][arm] is None for r in s), record['abstained'])
pairs = [(r['values']['vk_linear_region'], r['values']['vk_region']) for r in rows if r['found'] and r['same'] and r['split'] == 'holdout'
         and r['condition'] in ('spot_warm', 'mixed') and r['values'].get('vk_linear_region') is not None
         and r['values'].get('vk_region') is not None]
wins, losses = sum(a < b for a, b in pairs), sum(a > b for a, b in pairs)
p = sum(math.comb(wins + losses, k) for k in range(wins, wins + losses + 1)) / 2 ** (wins + losses)
gated_pair = summary['gradient_comparison']['gated']
same('paired n wins losses', [len(pairs), wins, losses], [gated_pair['n'], gated_pair['wins'], gated_pair['losses']])
same('paired p', p, gated_pair['p_one_sided'], 1e-15)
same('gradient_better', p < .05, summary['gradient_better_on_gradients'])
integrity = not problems and not summary['integrity_failures']
same('integrity_passed', integrity, summary['integrity_passed'])
same('recommended', integrity and primary_passed, summary['recommended'])
same('gradient_preferred', integrity and gradient_checks and p < .05, summary['gradient_preferred'])
result = dict(script='stage47_recount.py', imports_harness=False, negative_control=negative, checks=checks, problems=problems)
Path(output_path).write_text(json.dumps(result, indent=1) + '\n')
print(json.dumps(dict(checks=checks, problems=len(problems), first=problems[:5])))
sys.exit(0 if negative == bool(problems) else 1)
