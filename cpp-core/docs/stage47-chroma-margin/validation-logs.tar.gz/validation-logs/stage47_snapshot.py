"""Freeze the stage-47 source: git archive of COMMIT over round 46's path set, plus per-file SHA-256.
Usage, from the repository root: python stage47_snapshot.py COMMIT"""
import hashlib, io, json, subprocess, sys, tarfile
from pathlib import Path
commit = subprocess.run(['git', 'rev-parse', sys.argv[1]], capture_output=True, text=True, check=True).stdout.strip()
DOCS = Path('cpp-core/docs/stage47-chroma-margin')
PATHS = ['CMakeLists.txt', 'LICENSE', 'vcpkg.json', 'cpp-core/CMakeLists.txt', 'cpp-core/README_zh-TW.md', 'cpp-core/src',
         'cpp-core/include', 'cpp-core/experiments', 'cpp-core/tests', 'cpp-core/tools', 'cpp-core/examples',
         'macos-cli/CMakeLists.txt', 'macos-cli/main.cpp', 'macos-cli/mainwindow.cpp', 'macos-cli/mainwindow.h',
         'macos-cli/match_core.cpp', 'macos-cli/match_core.h']
tar_bytes = subprocess.run(['git', 'archive', '--format=tar', commit, *PATHS], capture_output=True, check=True).stdout
gz = subprocess.run(['gzip', '-n', '-9'], input=tar_bytes, capture_output=True, check=True).stdout
(DOCS / 'source-snapshot.tar.gz').write_bytes(gz)
files = {}
with tarfile.open(fileobj=io.BytesIO(tar_bytes)) as tar:
    for member in tar.getmembers():
        if member.isfile():
            files[member.name] = hashlib.sha256(tar.extractfile(member).read()).hexdigest()
(DOCS / 'source-sha256.json').write_text(json.dumps(dict(commit=commit, paths=PATHS, files=dict(sorted(files.items()))), indent=1) + '\n')
print(commit, len(files), 'files', len(gz), 'bytes')
