"""Write validation.json, validation-logs.tar.gz and archive.json for stage 47 (run from the repository root).
Usage: python stage47_validation.py LOGDIR  (LOGDIR holds validation-logs/ with every script, log and attest)"""
import hashlib, json, re, sys, tarfile
from pathlib import Path
DOCS = Path('cpp-core/docs/stage47-chroma-margin')
logs = Path(sys.argv[1]) / 'validation-logs'
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
def attest(name):
    fields = dict(line.split('=', 1) for line in (logs / f'{name}.attest').read_text().splitlines() if '=' in line)
    log = logs / f'{name}.log'
    if sha(log) != fields['LOG_SHA256']:
        raise ValueError(f'{name}: log hash differs from attest')
    text = log.read_text(errors='replace')
    results = re.findall(r'\d+% tests passed, \d+ tests failed out of \d+', text) + re.findall(r'Ran \d+ tests? in [\d.]+s', text)
    return dict(command=fields['COMMAND'], exit=int(fields['EXIT']), head_before=fields['HEAD_BEFORE'], head_after=fields['HEAD_AFTER'],
                clean_before=fields['CLEAN_BEFORE'] == 'true', clean_after=fields['CLEAN_AFTER'] == 'true', start=fields['START'], end=fields['END'],
                log=f'validation-logs/{name}.log', log_sha256=fields['LOG_SHA256'], results=results)
def mutants(log):
    rows = []
    for line in (logs / log).read_text().splitlines():
        m = re.match(r'^([LRT]\d+ .*?) (KILLED|SURVIVED|BUILD FAILED) ?(.*)$', line)
        if m:
            rows.append(dict(name=m.group(1), killed=m.group(2) == 'KILLED', by=m.group(3)))
    return dict(total=len(rows), killed=sum(r['killed'] for r in rows), survived=[r['name'] for r in rows if not r['killed']],
                log=f'validation-logs/{log}', mutants=rows)
load = lambda name: json.loads((logs / name).read_text())
gates = {name: attest(name) for name in ('build', 'ctest', 'harness', 'color', 'other-py', 'asan')}
tested = {g['head_before'] for g in gates.values()} | {g['head_after'] for g in gates.values()}
if len(tested) != 1:
    raise ValueError('gates ran at different heads')
recount, negative, replay = load('stage47-recount-result.json'), load('stage47-recount-negative.json'), load('stage47-replay-result.json')
validation = dict(
    stage=47, tested_commit=tested.pop(), platform='Apple M4 Pro, 48 GiB, macOS',
    gates=gates,
    gate_notes=dict(build='fresh Release research build (GUI+experiments+OpenCV) in build/research of the worktree',
                    ctest='full research ctest, includes experimental_color_illuminant with the linear-model controls',
                    harness='python unittest discover cpp-core/tests test_*.py with FPM_FINE_*_BUILD=build/research; includes the stage-47 harness tests',
                    color='color_verify_runner_test.py --runner build/research/... --metal (9 tests: 5 existing + 3 round-46 chroma_vk + 1 reference_model)',
                    other_py='blender_challenge, challenge_coverage, real_rgb_benchmark',
                    asan='Debug, FPM_SANITIZERS, FPM_DISABLE_SIMD, experiments on; includes the linear-model native test'),
    all_gates_passed=all(g['exit'] == 0 and g['clean_before'] and g['clean_after'] for g in gates.values()),
    frozen_runner=dict(path='build/stage47-release', sha256=replay['frozen_runner_sha256'], built_from='git archive 190973e'),
    base_runner=dict(path='build/stage47-base', sha256='e2be71b46bf807592ce389fd911da2e05440364b05094154553d5456a6142f85', built_from='git archive ce057fe'),
    compiled_mutants=dict(script='validation-logs/stage47_compiled_mutants.py',
                          note='each mutant of color_illuminant.cpp (L1-L16) or color_verify_runner.cpp (R1-R4) is compiled in a git-archive copy '
                               'and run against fpm_color_illuminant_test and the runner contract tests; the worktree is never modified',
                          first_run_172f86a=mutants('stage47-compiled-mutants-pre-protocol-first-run-172f86a.log'),
                          rerun_190973e=mutants('stage47-compiled-mutants-pre-protocol.log'),
                          after_measurement=mutants('stage47-compiled-mutants-after-measurement.log')),
    tool_mutants=dict(script='validation-logs/stage47_tool_mutants.py',
                      note='each mutant of benchmark_chroma_margin.py must make test_chroma_margin_harness.py fail, on a git-archive copy of '
                           'cpp-core/tools, tests and examples',
                      first_run_172f86a=mutants('stage47-tool-mutants-pre-protocol-first-run-172f86a.log'),
                      rerun_190973e=mutants('stage47-tool-mutants-pre-protocol.log'),
                      after_measurement=mutants('stage47-tool-mutants-after-measurement.log'),
                      first_run_note='R4, T13 and T20 survived the first run (before the protocol). R4: the contract case sent reference_model '
                                     'to chroma together with reference_mask, which is rejected on its own; T13/T20: gates and the paired comparison '
                                     'filtered by condition name only (equivalent under the real split definition). 190973e hardened the three tests; '
                                     'an earlier invocation of the tool-mutant script that could not import the test module (every mutant "killed" '
                                     'by an import error, restored copy failing) was discarded and the script now refuses to run unless the '
                                     'unmutated copy passes'),
    independent_recount=dict(script='validation-logs/stage47_recount.py', imports_harness=False, checks=recount['checks'],
                             problems=recount['problems'],
                             negative_control=dict(change='summary per_condition catch vk_region syn_red holdout/wb_warm wrongly_accepted + 1',
                                                   detected=negative['problems'])),
    summary_replay=dict(result='summarize on the extracted raw-results.tar.gz is byte-identical to summary.json', summary_sha256=sha(DOCS / 'summary.json')),
    job_replay=dict(script='validation-logs/stage47_replay.py', runner='rebuilt from source-snapshot.tar.gz into build/stage47-replay',
                    runner_sha256=replay['runner_sha256'], jobs=replay['jobs'], equal=replay['equal'], differences=replay['differences'],
                    note='first-call scores and search matches of every candidate job equal the archive; the binary hash differs from the '
                         'frozen runner because the build path differs'),
    round46_identity=dict(script='validation-logs/stage47_round46_identity.py', **{k: v for k, v in load('stage47-round46-identity.json').items()}),
    holdout_regeneration=dict(script='validation-logs/stage47_holdout_regen.py', **{k: v for k, v in load('stage47-holdout-regen.json').items()},
                              note='holdout regenerated from the protocol seeds into build/stage47-holdout-regen; synthetic, texture and GT files '
                                   'byte-identical, Blender PNGs pixel-identical (PNG metadata differs per render), scene JSON equal'),
    post_hoc=dict(script='validation-logs/stage47_posthoc.py', output='validation-logs/stage47-posthoc.json',
                  note='computed after the summary; diagnostic only, not adoption evidence'),
    smoke=dict(note='two pre-protocol plumbing smokes on smoke_seeds data (build/stage47-smoke, build/stage47-smoke2); disclosed in the '
               'protocol; their outputs are not evidence and were not archived'),
    interrupted_gate_run=dict(commit='28f09f7', logs='validation-logs/gates-28f09f7-interrupted/',
        note='first gate run, started 16:23:54Z inside round 48\'s active timing lock (not re-checked before starting); build, ctest, '
             'harness, color and other-py passed with a clean tree, the ASan gate was stopped at about 16:26:50Z and has no result. Kept, '
             'not used as the gate set; round 48 was told the interval. The gate script now refuses to start while a timing lock exists, '
             'and the recorded gates above ran after the lock was removed'),
    host=dict(notes='validation-logs/host-notes.md'),
)
(DOCS / 'validation.json').write_text(json.dumps(validation, indent=1) + '\n')
with tarfile.open(DOCS / 'validation-logs.tar.gz', 'w:gz', compresslevel=9) as tar:
    for path in sorted(p for p in logs.rglob('*') if p.is_file()):
        info = tar.gettarinfo(str(path), arcname=str(path.relative_to(logs.parent)))
        info.uid = info.gid = 0
        info.uname = info.gname = ''
        info.mtime = 0
        with open(path, 'rb') as handle:
            tar.addfile(info, handle)
roles = {'protocol.json': 'pre-registered protocol (frozen catch thresholds)', 'source-snapshot.tar.gz': 'frozen source of 190973e',
         'source-sha256.json': 'per-file SHA-256 of the frozen source', 'raw-results.tar.gz': 'masks, run manifest, jobs, stderr and results',
         'holdout-metadata.tar.gz': 'fresh holdout seed records, GT, Blender metadata and log, manifests (images pinned by SHA-256, not archived)',
         'raw-files-sha256.json': 'SHA-256 of every raw and holdout-metadata archive member', 'input-sha256.json': 'every input image and mask, every holdout PNG',
         'summary.json': 'harness summary (every arm, rule, cell, threshold and check)', 'decision-and-failures.json': 'decision, failed checks, predictions',
         'validation.json': 'gates, mutants, recount, replays, holdout regeneration', 'validation-logs.tar.gz': 'validation scripts, logs and attests'}
files = {}
for name, role in roles.items():
    path = DOCS / name
    files[name] = dict(bytes=path.stat().st_size, sha256=sha(path), role=role)
    if path.stat().st_size >= 100 * 1000 * 1000:
        raise ValueError(f'{name} at or above 100 MB')
extra = sorted(p.name for p in DOCS.iterdir() if p.name not in roles and p.name != 'archive.json')
if extra:
    raise ValueError(f'unlisted evidence files: {extra}')
(DOCS / 'archive.json').write_text(json.dumps(dict(stage=47, report='../CHROMA_MARGIN_zh-TW.md', files=files), indent=1) + '\n')
print('gates passed', validation['all_gates_passed'], 'tested', validation['tested_commit'],
      {k: (v['after_measurement']['killed'], v['after_measurement']['total']) for k, v in (('compiled', validation['compiled_mutants']), ('tool', validation['tool_mutants']))})
