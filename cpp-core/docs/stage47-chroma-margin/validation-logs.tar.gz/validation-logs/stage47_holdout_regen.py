"""Holdout regeneration: rebuild the fresh test-bed from the protocol seeds into a new directory and compare it with the one
the formal run read. Synthetic, texture and GT files must be byte-identical; Blender PNGs must decode to identical pixels
(Blender PNG files carry render metadata, so file bytes differ between renders) and Blender scene JSON must match except
the image and .blend hashes. Usage: python stage47_holdout_regen.py ORIGINAL REGENERATED OUTPUT.json  (REGENERATED exists)"""
import hashlib, json, sys
from pathlib import Path
import cv2
import numpy as np
original, regenerated, output = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
records, differences = [], []
for sub in ('textures', 'synthetic', 'blender'):
    names = sorted({p.name for p in (original / sub).iterdir()} | {p.name for p in (regenerated / sub).iterdir()})
    for name in names:
        a, b = original / sub / name, regenerated / sub / name
        if not a.exists() or not b.exists():
            kind, equal = 'missing', False
        elif sub == 'blender' and name.endswith('.png'):
            kind, equal = 'pixels', bool(np.array_equal(cv2.imread(str(a), cv2.IMREAD_UNCHANGED), cv2.imread(str(b), cv2.IMREAD_UNCHANGED)))
        elif sub == 'blender' and name.endswith('.blend'):
            continue   # binary scene files embed paths and timestamps; the JSON next to them records the scene
        elif sub == 'blender' and name.endswith('.json'):
            strip = lambda d: {k: v for k, v in d.items() if k not in ('image_sha256', 'blend_sha256', 'script_sha256')}
            kind, equal = 'json', strip(json.loads(a.read_text())) == strip(json.loads(b.read_text()))
        else:
            kind, equal = 'bytes', sha(a) == sha(b)
        records.append(dict(file=f'{sub}/{name}', kind=kind, equal=equal))
        if not equal:
            differences.append(records[-1])
result = dict(compared=len(records), equal=sum(r['equal'] for r in records), by_kind={k: sum(r['kind'] == k for r in records)
              for k in ('bytes', 'pixels', 'json', 'missing')}, differences=differences)
output.write_text(json.dumps(result, indent=1) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'differences'}), len(differences))
sys.exit(1 if differences else 0)
