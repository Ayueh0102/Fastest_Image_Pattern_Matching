"""Stage-47 job replay: rerun every archived candidate job with a runner rebuilt from source-snapshot.tar.gz.
First-call scores and search matches must equal the archived results exactly; timing and memory are not compared.
Usage: python stage47_replay.py ARCHIVE_ROOT RUNNER OUTPUT.json   (ARCHIVE_ROOT = the extracted stage47-margin directory)"""
import hashlib, json, subprocess, sys, tempfile
from pathlib import Path
root, runner, output = Path(sys.argv[1]) / 'run', Path(sys.argv[2]), Path(sys.argv[3])
manifest = json.loads((root / 'manifest.json').read_text())
records, differences = [], []
with tempfile.TemporaryDirectory(prefix='stage47-replay-') as scratch:
    for entry in manifest['executions']:
        if entry['runner_kind'] != 'candidate':
            continue
        job = json.loads((root / entry['job']).read_text())
        for key in ('mask', 'reference_mask'):  # masks travel inside the archive
            if key in job:
                job[key] = str((root.parent / 'masks' / Path(job[key]).name).resolve())
        path = Path(scratch) / 'job.json'
        path.write_text(json.dumps(job))
        child = subprocess.run([str(runner), str(path)], capture_output=True, text=True, timeout=900)
        archived = json.loads((root / entry['result']).read_text())
        equal = child.returncode == 0 and all(json.loads(child.stdout)['first'][k] == archived['first'][k] for k in ('scores', 'search_matches'))
        records.append(dict(scene=entry['scene'], method=entry['method'], returncode=child.returncode, equal=equal))
        if not equal:
            differences.append(records[-1])
result = dict(runner_sha256=hashlib.sha256(runner.read_bytes()).hexdigest(), frozen_runner_sha256=manifest['runner_sha256'],
              jobs=len(records), equal=sum(r['equal'] for r in records), differences=differences)
output.write_text(json.dumps(result, indent=1) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'differences'}), len(differences))
sys.exit(1 if differences else 0)
