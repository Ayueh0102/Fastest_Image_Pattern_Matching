"""Round-46 identity: on the 9 test-bed v1 calibration scenes, every stage-47 candidate output of a method that round 46 also ran
(same job settings) must equal round 46's archived result (first-call scores and search matches).
Usage: python stage47_round46_identity.py STAGE46_RAW_TGZ STAGE47_MARGIN_DIR OUTPUT.json"""
import json, sys, tarfile
from pathlib import Path
archive, margin, output = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
manifest = json.loads((margin / 'run' / 'manifest.json').read_text())
SHARED = ('gray_ncc', 'rgb_ncc', 'chroma', 'chroma_masked', 'vk_object', 'vk_object_none', 'card_gray')
with tarfile.open(archive) as tar:
    members = {m.name: m for m in tar.getmembers() if m.isfile()}
    records, differences = [], []
    for entry in manifest['executions']:
        if entry['runner_kind'] != 'candidate' or not entry['scene'].startswith('v1/') or entry['method'] not in SHARED:
            continue
        name = entry['scene'].split('/', 1)[1]
        theirs = json.loads(tar.extractfile(members[f"stage46-illuminant/run/results/{name}-{entry['method']}.json"]).read())
        mine = json.loads((margin / 'run' / entry['result']).read_text())
        mine_job = json.loads((margin / 'run' / entry['job']).read_text())
        their_job = json.loads(tar.extractfile(members[f"stage46-illuminant/run/jobs/{name}-{entry['method']}.json"]).read())
        strip = lambda job: {k: (Path(v).name if isinstance(v, str) and '/' in v else v) for k, v in job.items()}
        equal = all(mine['first'][k] == theirs['first'][k] for k in ('scores', 'search_matches'))
        records.append(dict(scene=name, method=entry['method'], jobs_equal_up_to_paths=strip(mine_job) == strip(their_job), equal=equal))
        if not equal or not records[-1]['jobs_equal_up_to_paths']:
            differences.append(records[-1])
result = dict(compared=len(records), equal=sum(r['equal'] for r in records),
              jobs_equal_up_to_paths=sum(r['jobs_equal_up_to_paths'] for r in records), differences=differences)
output.write_text(json.dumps(result, indent=1) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'differences'}), len(differences))
sys.exit(1 if differences else 0)
