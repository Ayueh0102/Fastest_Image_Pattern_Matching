"""Package stage-47 evidence into cpp-core/docs/stage47-chroma-margin (run from the repository root after summarize).
raw-results.tar.gz: masks, run manifest, jobs, stderr and results (build/stage47-margin minus the summary).
holdout-metadata.tar.gz: the fresh test-bed's records (holdout.json, synthetic.json, GT, Blender metadata and log, textures.json,
final/manifest.json); its images are pinned by SHA-256 in input-sha256.json and final/manifest.json, not archived."""
import hashlib, json, shutil, tarfile
from pathlib import Path
BUILD = Path('build')
RAW, HOLDOUT = BUILD / 'stage47-margin', BUILD / 'stage47-holdout'
DOCS = Path('cpp-core/docs/stage47-chroma-margin')
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def pack(name, members):
    with tarfile.open(DOCS / name, 'w:gz', compresslevel=9) as tar:
        for path in members:
            info = tar.gettarinfo(str(path), arcname=str(path.relative_to(BUILD)))
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            info.mtime = 0
            with open(path, 'rb') as handle:
                tar.addfile(info, handle)
    size = (DOCS / name).stat().st_size
    if size >= 100 * 1000 * 1000:
        raise ValueError(f'{name} at or above 100 MB')
    return size
raw = sorted(p for p in RAW.rglob('*') if p.is_file() and p.name != 'summary.json')
holdout = sorted(p for p in HOLDOUT.rglob('*') if p.is_file() and p.suffix in ('.json', '.log'))
sizes = dict(raw=pack('raw-results.tar.gz', raw), holdout=pack('holdout-metadata.tar.gz', holdout))
(DOCS / 'raw-files-sha256.json').write_text(json.dumps(dict(stage=47, note='every member of raw-results.tar.gz and '
    'holdout-metadata.tar.gz, path relative to build/', files={str(p.relative_to(BUILD)): sha(p) for p in raw + holdout}), indent=1) + '\n')
manifest = json.loads((RAW / 'run' / 'manifest.json').read_text())
images = {str(p.relative_to(BUILD)): sha(p) for p in sorted(HOLDOUT.rglob('*.png'))}
(DOCS / 'input-sha256.json').write_text(json.dumps(dict(stage=47, note='Every source, template and mask read by a stage-47 worker '
    '(v1 images are checked against build/testbed-v1/final/manifest.json, fresh images against build/stage47-holdout/final/manifest.json '
    'before the run), and every PNG of the fresh holdout (including the unused regenerated templates and textures).',
    inputs=manifest['input_sha256'], holdout_png=images), indent=1) + '\n')
shutil.copyfile(RAW / 'summary.json', DOCS / 'summary.json')
print(len(raw), 'raw files', len(holdout), 'holdout records', sizes)
