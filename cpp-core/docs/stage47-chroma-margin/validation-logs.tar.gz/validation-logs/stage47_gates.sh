#!/usr/bin/env bash
# Stage-47 final gates at the exact head. Run from the repository root: bash stage47_gates.sh LOGDIR
set -u
logs=$1; mkdir -p "$logs"
py=/Users/Ayueh/Fastest_Image_Pattern_Matching/python-port/venv/bin/python
status=0
notes="/Users/Ayueh/Library/Application Support/Claude/side-session-notes"
gate() {
  local name=$1; shift
  # Refuse to start while another session holds a timing lock (side-session-notes convention).
  if ls "$notes"/*/timing-lock-*.txt >/dev/null 2>&1; then echo "$name refused: timing lock present"; ls "$notes"/*/timing-lock-*.txt; exit 3; fi
  local log="$logs/$name.log" attest="$logs/$name.attest"
  local head_before clean_before start code head_after clean_after end
  head_before=$(git rev-parse HEAD); [ -z "$(git status --porcelain)" ] && clean_before=true || clean_before=false
  start=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  "$@" > "$log" 2>&1; code=$?
  end=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  head_after=$(git rev-parse HEAD); [ -z "$(git status --porcelain)" ] && clean_after=true || clean_after=false
  printf 'HEAD_BEFORE=%s\nCLEAN_BEFORE=%s\nSTART=%s\nCOMMAND=%s\nEXIT=%s\nEND=%s\nHEAD_AFTER=%s\nCLEAN_AFTER=%s\nLOG_SHA256=%s\n' \
    "$head_before" "$clean_before" "$start" "$*" "$code" "$end" "$head_after" "$clean_after" "$(shasum -a 256 "$log" | cut -d' ' -f1)" > "$attest"
  echo "$name exit $code"; [ "$code" -eq 0 ] || status=1
}
gate build bash -c 'cmake -S cpp-core -B build/research -DCMAKE_BUILD_TYPE=Release -DFPM_BUILD_GUI=ON -DFPM_BUILD_EXPERIMENTS=ON -DFPM_WITH_OPENCV=ON && cmake --build build/research -j'
gate ctest ctest --test-dir build/research --output-on-failure
gate harness env FPM_FINE_REUSE_BUILD=build/research FPM_FINE_SEARCH_BUILD=build/research FPM_FINE_FUSED_BUILD=build/research \
  "$py" -m unittest discover -s cpp-core/tests -p 'test_*.py'
gate color "$py" cpp-core/tests/color_verify_runner_test.py --runner build/research/experiments/fpm_color_verify_runner --metal
gate other-py bash -c 'for f in blender_challenge_test.py challenge_coverage_test.py real_rgb_benchmark_test.py; do "$0" -m unittest discover -s cpp-core/tests -p "$f" || exit 1; done' "$py"
gate asan bash -c 'cmake -S cpp-core -B build/sanitized -DCMAKE_BUILD_TYPE=Debug -DFPM_SANITIZERS=ON -DFPM_DISABLE_SIMD=ON -DFPM_BUILD_EXPERIMENTS=ON && cmake --build build/sanitized -j && ctest --test-dir build/sanitized --output-on-failure'
exit $status
