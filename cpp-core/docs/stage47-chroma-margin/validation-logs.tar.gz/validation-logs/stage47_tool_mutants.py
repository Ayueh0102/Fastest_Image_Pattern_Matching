"""Stage-47 tool mutants: each must make tests/test_chroma_margin_harness.py fail. Runs on a git-archive copy of
COMMIT's cpp-core/tools, cpp-core/tests and cpp-core/examples (the worktree is never modified).
Usage, from the repository root: python stage47_tool_mutants.py COMMIT SCRATCH"""
import shutil, subprocess, sys
from pathlib import Path
PY = '/Users/Ayueh/Fastest_Image_Pattern_Matching/python-port/venv/bin/python'
commit, scratch = sys.argv[1], Path(sys.argv[2]).resolve()
if scratch.exists():
    shutil.rmtree(scratch)
scratch.mkdir(parents=True)
archive = subprocess.run(['git', 'archive', commit, 'cpp-core/tools', 'cpp-core/tests', 'cpp-core/examples'], capture_output=True, check=True).stdout
subprocess.run(['tar', '-x', '-C', str(scratch)], input=archive, check=True)
p = scratch / 'cpp-core/tools/benchmark_chroma_margin.py'
TEST = ['-m', 'unittest', 'discover', '-s', str(scratch / 'cpp-core/tests'), '-p', 'test_chroma_margin_harness.py']
orig = p.read_text()
def tests():
    return subprocess.run([PY, *TEST], capture_output=True, text=True, cwd=scratch)
first = tests()
assert first.returncode == 0 and 'Ran 3' in first.stderr, first.stderr[-2000:]   # the unmutated copy must pass every test
print('unmutated:', first.stderr.strip().splitlines()[-3], flush=True)
mutants = [
 ('T1 catch fraction 1 (tau = d_catch)', "CATCH_DELTA_E, CATCH_FRACTION, CATCH_STEP_DEG = 4., .5, 1", "CATCH_DELTA_E, CATCH_FRACTION, CATCH_STEP_DEG = 4., 1., 1"),
 ('T2 catch ignores the artwork variants', "distance=min(closest_circle['distance'], closest_variant['distance']))", "distance=closest_circle['distance'])"),
 ('T3 catch requirement DeltaE 2', "CATCH_DELTA_E, CATCH_FRACTION, CATCH_STEP_DEG = 4., .5, 1", "CATCH_DELTA_E, CATCH_FRACTION, CATCH_STEP_DEG = 2., .5, 1"),
 ('T4 calibration values include fresh calibration lighting', "return [r['values'][arm] for r in rows if r['split'] == 'calibration' and r['group'] == group and r['same_colour']",
     "return [r['values'][arm] for r in rows if r['split'] != 'holdout' and r['group'] == group and r['same_colour']"),
 ('T5 exclusive threshold', "return value is not None and threshold is not None and value <= threshold", "return value is not None and threshold is not None and value < threshold"),
 ('T6 abstention accepted', "return value is not None and threshold is not None and value <= threshold", "return value is None or (threshold is not None and value <= threshold)"),
 ('T7 decided minimum ignored', "result['passed'] = result['passed'] and len(decided) >= MIN_DECIDED[source]", "result['passed'] = result['passed']"),
 ('T8 abstained objects in the H1a/H2a denominator', "decided = [r for r in subset if r['same_colour'] and r['values'][arm] is not None]", "decided = [r for r in subset if r['same_colour']]"),
 ('T9 feasibility at tau instead of tau/2', "FEASIBILITY_FRACTION = .5 ", "FEASIBILITY_FRACTION = 1. "),
 ('T10 lightness+ gated', "GATED_DIRECTIONS = ('hue+', 'hue-', 'chroma-', 'isogray0', 'isogray90')", "GATED_DIRECTIONS = ('hue+', 'hue-', 'chroma-', 'isogray0', 'isogray90', 'lightness+')"),
 ('T11 DeltaE 2 gated', "GATED_MIN_DELTA_E = 4.", "GATED_MIN_DELTA_E = 2."),
 ('T12 exposure_bright gated', "GATED_SYNTHETIC = ('wb_warm', 'spot_warm', 'noise_jpeg')", "GATED_SYNTHETIC = ('wb_warm', 'exposure_bright', 'spot_warm', 'noise_jpeg')"),
 ('T13 fresh calibration lighting gated as holdout', "    holdout = [r for r in found if r['split'] == 'holdout']", "    holdout = [r for r in found if r['split'] != 'calibration']"),
 ('T14 round-46 methods not compared with the base runner', "EXISTING = tuple(m for m in METHODS if m not in NEW_METHODS)", "EXISTING = ('gray_ncc', 'rgb_ncc', 'chroma', 'chroma_masked')"),
 ('T15 localization identity skipped', "        if any(m != matches[0] for m in matches[1:]):", "        if False:"),
 ('T16 GT in jobs ignored', "def gt_problems(job_dict):\n    return stage46.gt_problems(job_dict)", "def gt_problems(job_dict):\n    return []"),
 ('T17 seed reuse not checked', "    if used & set(fresh) or len(set(fresh)) != len(fresh):", "    if False:"),
 ('T18 artwork not compared', "    for name in artwork_differences(v1 / 'textures', holdout / 'textures'):", "    for name in []:"),
 ('T19 sign test off by one', "return sum(math.comb(n, k) for k in range(wins, n + 1)) / 2 ** n", "return sum(math.comb(n, k) for k in range(wins + 1, n + 1)) / 2 ** n"),
 ('T20 paired comparison includes fresh calibration lighting', "if r['found'] and r['same_colour'] and r['split'] == 'holdout'", "if r['found'] and r['same_colour'] and r['split'] != 'calibration'"),
 ('T21 gradient preference ignores its own checks', "gradient_preferred=integrity_passed and evaluation['gradient_checks_passed']\n", "gradient_preferred=integrity_passed\n"),
 ('T22 result hash not checked', "        elif sha(root / entry['result']) != entry['result_sha256']:", "        elif False:"),
 ('T23 input hash not checked', "        if not Path(path).exists() or sha(path) != digest:", "        if not Path(path).exists():"),
 ('T24 incomplete run accepted', "    if not manifest.get('complete') or not manifest.get('unchanged'):", "    if not manifest.get('complete'):"),
 ('T25 exact repeat not checked', "            if not result['exact_repeat']:", "            if False:"),
 ('T26 NCC arms get the catch threshold', "out[(arm, group)] = None if arm in NCC_ARMS else catch[group]", "out[(arm, group)] = catch[group]"),
 ('T27 catch protocol check loose', "any(abs(catch[g]['tau'] - frozen[g]) > 1e-12 for g in GROUPS)", "any(abs(catch[g]['tau'] - frozen[g]) > 1e-6 for g in GROUPS)"),
 ('T28 masks not compared', "if not (Path(masks) / name).exists() or sha(Path(masks) / name) != digest]", "if not (Path(masks) / name).exists()]"),
 ('T29 holdout record hash not checked', "    if sha(holdout / 'holdout.json') != manifest['holdout_json_sha256']:", "    if False:"),
 ('T30 isogray pooled over every direction', "           and r['direction'] in ISOGRAY]", "           ]"),
 ('T31 Rayleigh false-reject 1e-2', "RAYLEIGH_FALSE_REJECT = 1e-3", "RAYLEIGH_FALSE_REJECT = 1e-2"),
 ('T32 recommended ignores integrity', "    return dict(recommended=integrity_passed and evaluation['primary_passed'],", "    return dict(recommended=evaluation['primary_passed'],"),
]
survived = 0
for name, old, new in mutants:
    assert orig.count(old) == 1, name
    p.write_text(orig.replace(old, new))
    r = tests()
    failed = [l.split(' (')[0].split(': ')[1] for l in r.stderr.splitlines() if l.startswith(('FAIL:', 'ERROR:'))]
    survived += r.returncode == 0
    print(name, 'KILLED' if r.returncode else 'SURVIVED', failed, flush=True)
p.write_text(orig)
r = tests()
print('restored:', r.stderr.strip().splitlines()[-1], 'survived:', survived)
sys.exit(1 if survived or r.returncode else 0)
