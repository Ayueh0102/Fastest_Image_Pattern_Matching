"""Stage-47 post-hoc diagnostics, computed after the summary (not adoption evidence). Usage: python stage47_posthoc.py SUMMARY HOLDOUT OUTPUT.json"""
import json, math, statistics, sys
from pathlib import Path
summary, holdout, output = json.loads(Path(sys.argv[1]).read_text()), Path(sys.argv[2]), Path(sys.argv[3])
tau = {g: summary['catch'][g]['tau'] for g in summary['catch']}
rows = [r for r in summary['rows'] if r['found']]
out = {}
# 1. margins of the primary arm per holdout cell
margins = {}
for g in tau:
    for key, cell in summary['per_condition']['catch']['vk_region'][g].items():
        if key.startswith('holdout/') and cell['same']['decided']:
            gated = [r['values']['vk_region'] for r in rows if r['group'] == g and f"{r['split']}/{r['condition']}" == key and not r['same_colour']
                     and r['direction'] in ('hue+', 'hue-', 'chroma-', 'isogray0', 'isogray90') and r['delta_e00_target'] >= 4
                     and r['values']['vk_region'] is not None]
            margins[f'{g} {key}'] = dict(max_same_over_tau=cell['same']['max_decided'] / tau[g],
                                         min_gated_over_tau=min(gated) / tau[g] if gated else None)
out['primary_margins'] = margins
# 2. linear vs constant residual by condition, and the slope sizes behind them
by = {}
for r in rows:
    if r['same_colour'] and r['values'].get('vk_region') is not None and r['values'].get('vk_linear_region') is not None:
        d = r['diagnostics']['vk_linear']
        slope = max(abs(x) for x in d['reference_slope_u'] + d['reference_slope_v'])
        by.setdefault(f"{r['group']} {r['split']}/{r['condition']}", []).append((r['values']['vk_region'], r['values']['vk_linear_region'], slope))
out['linear_vs_constant_same_colour'] = {k: dict(n=len(v), median_constant=statistics.median(a for a, _, _ in v),
    median_linear=statistics.median(b for _, b, _ in v), linear_larger=sum(b > a for a, b, _ in v),
    median_max_abs_slope=statistics.median(s for _, _, s in v)) for k, v in sorted(by.items())}
# 3. spot_warm geometry: same-colour objects by distance from the spot centre (sigma = .22 x width)
geometry = []
for family in ('red', 'teal'):
    meta = json.loads((holdout / 'synthetic' / f'syn_{family}_spot_warm.truth.json').read_text())
    width, height = meta['source_shape'][1], meta['source_shape'][0]
    cx, cy, sigma = .3 * width, .55 * height, .22 * width
    status = {(r['index']): r['diagnostics']['vk_object']['status'] for r in rows if r['scene'] == f'r47/syn_{family}_spot_warm'}
    for t in meta['truth']:
        if t['same_colour']:
            geometry.append(dict(family=family, index=t['index'], sigma=math.hypot(t['pos_x'] - cx, t['pos_y'] - cy) / sigma,
                                 status=status.get(t['index'])))
abstained = [g['sigma'] for g in geometry if g['status'] == 3]
valid = [g['sigma'] for g in geometry if g['status'] == 0]
out['spot_geometry'] = dict(objects=sorted(geometry, key=lambda g: g['sigma']), abstained_max_sigma=max(abstained) if abstained else None,
                            valid_min_sigma=min(valid) if valid else None)
output.write_text(json.dumps(out, indent=1) + '\n')
print(json.dumps(dict(spot=dict(abstained_max_sigma=out['spot_geometry']['abstained_max_sigma'], valid_min_sigma=out['spot_geometry']['valid_min_sigma'])), indent=0))
for k, v in out['linear_vs_constant_same_colour'].items():
    print(f"{k:38s} n={v['n']:2d} const={v['median_constant']:.5f} linear={v['median_linear']:.5f} larger={v['linear_larger']} slope={v['median_max_abs_slope']:.2e}")
for k, v in margins.items(): print(k, {a: None if b is None else round(b, 3) for a, b in v.items()})
