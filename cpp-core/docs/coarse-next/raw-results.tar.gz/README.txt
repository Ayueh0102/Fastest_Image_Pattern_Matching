Coarse selection and GPU NCC experiment, 2026-10-13, organized 2026-10-14.

formal.json retains the original absolute provenance paths. Do not rewrite those
paths: job and worker content hashes verify the original bytes. Relocated replay
uses the explicit --worker-root to read only this archive, without falling back
to the original machine. From the repository root, run:

python3 cpp-core/tools/benchmark_coarse_next.py --summarize /path/to/archive/formal.json --worker-root /path/to/archive --output /tmp/replayed-summary.json

Compare that output byte-for-byte with cpp-core/docs/coarse-next/formal-summary.json.
The replay performs no image matching and no GPU calls. Worker-result hashes are
verified by the summary reader; job and all other file hashes are in sha256.json.

measured-sources contains the exact 39 files from formal.json source_hashes.
supplementary contains tests, plotting and documentation; these files are not
claimed to be covered by the pre-measurement source manifest. Baseline binaries
are not included; their hashes and source commit are in baseline-provenance.json.
Large image inputs are omitted. Deterministic generation and source input hashes
are in the measured benchmark sources and formal.json. Original BMP test inputs
remain in the repository. Logs include full Release/sanitized/harness validation.

Correctness passing does not mean all performance variants succeeded. Only the
CPU peak-tree optimization is recommended. The SIMD coarse NCC experiment is
slower on the main tested workloads. Existing defaults remain mode0/mode0.
