#!/usr/bin/env python3
"""Independent audit of the stage-43 (coarse-candidate dedup) GT and formal evidence.

Written from cpp-core/docs/stage43-candidate-dedup/protocol.json. It imports
nothing from cpp-core/tools: strict GT matching, deltas versus the same-path
off arm, aggregates, dedup counter contracts, timing statistics and gates are
recomputed from the raw worker JSON, then compared with the harness summaries
when they are given.

Output separates
  mismatches     contract violations or disagreements with manifests/summaries (should be empty)
  gate_failures  pre-registered protocol gate outcomes (results, not audit errors)
  missing        not-yet-run executions (only with --partial)
Exit status is 1 when any mismatch is found.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

import numpy as np

# Pre-registered arms, paths and gates (protocol.json).
ARMS = {
    'off': dict(top_k=0, radius=.5, angle_steps=3.),
    'k3': dict(top_k=3, radius=.5, angle_steps=3.),
    'k2': dict(top_k=2, radius=.5, angle_steps=3.),
    'k1': dict(top_k=1, radius=.5, angle_steps=3.),
    'k1_position_only': dict(top_k=1, radius=.5, angle_steps=1000.),
    'k1_wide_radius': dict(top_k=1, radius=2., angle_steps=3.),
}
PATHS = {'hybrid': 'hybrid_best', 'full_gpu': 'full_gpu_simd'}
PATH_JOB = {'hybrid': dict(full_gpu=False), 'full_gpu': dict(full_gpu=True, full_gpu_peak_mode=1, full_gpu_fine_mode=4)}
PATH_SWITCH = ('full_gpu', 'full_gpu_peak_mode', 'full_gpu_fine_mode')
DEDUP_JOB = ('candidate_dedup_top_k', 'candidate_dedup_radius', 'candidate_dedup_angle_steps')
CONTROLS = {'k1_position_only': 'sym_marker12', 'k1_wide_radius': 'adjacent_grid16'}
GT_CASES, GT_WORKERS = 112, 1146
FORMAL_CASES = ('many128_pose', 'many512_pose', 'controlled6', '8k_t256_angle180_3scales')
SPEED_CASES = FORMAL_CASES[:2]
FORMAL_ARMS = [('hybrid', 'off'), ('hybrid', 'k3'), ('full_gpu', 'off'), ('full_gpu', 'k3')]
BLOCKS, MEASURED = 6, 3
RESIDENCY = dict(command_buffers=1, cpu_waits=1, intermediate_readbacks=0, cpu_algorithm_steps=0)
POSE = ('pos_x', 'pos_y', 'angle', 'score', 'scale', 'corners')
SPEED_TARGET, TIME_GATE, RSS_GATE = -10., (2., .10), (8*1024*1024, .10)
FINGERPRINTS = ('source_sha256', 'binary_sha256', 'input_sha256')
FAIL_KEYS = ('gate', 'case', 'path', 'arm', 'block', 'process')
GT_GATES = {'worker', 'repeat', 'gt_regression'}
FORMAL_GATES = {'speed_target', 'time_budget', 'rss', 'gt', 'repeat', 'warmup', 'gt_phase_identity', 'host'}


class Audit:
    def __init__(self):
        self.checks, self.notes = Counter(), Counter()
        self.mismatches, self.missing, self.geometry = [], [], []
        self.gates = {'gt': [], 'formal': []}

    def check(self, kind, ok, **detail):
        self.checks[kind] += 1
        if not ok:
            self.mismatches.append(dict(check=kind, **detail))
        return bool(ok)

    def same(self, kind, mine, theirs, **where):
        return self.check(kind, close(mine, theirs), **where, mine=mine, theirs=theirs)

    def gate(self, phase, gate, **detail):
        self.gates[phase].append(dict(gate=gate, **detail))


def sha256(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b''):
            digest.update(chunk)
    return digest.hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def inside(root, relative):
    path = (root/relative).resolve()
    return path if path.is_relative_to(root) and path.is_file() else None


def num(value):
    try:
        return float(value)
    except (TypeError, ValueError, OverflowError):
        return float('nan')


def sign(x):
    return (x > 0)-(x < 0)


def median(values):
    ordered, n = sorted(values), len(values)
    return ordered[n//2] if n % 2 else (ordered[n//2-1]+ordered[n//2])/2


def close(x, y, rel=1e-12):
    """Exact for ints, bools, strings and None; relative tolerance for floats; recursive for containers."""
    if isinstance(x, bool) or isinstance(y, bool):
        return type(x) is type(y) and x == y
    if isinstance(x, (int, float)) and isinstance(y, (int, float)):
        if isinstance(x, int) and isinstance(y, int):
            return x == y
        return x == y or abs(x-y) <= rel*max(abs(x), abs(y))
    if isinstance(x, (list, tuple)) and isinstance(y, (list, tuple)):
        return len(x) == len(y) and all(close(u, v, rel) for u, v in zip(x, y))
    if isinstance(x, dict) and isinstance(y, dict):
        return x.keys() == y.keys() and all(close(x[k], y[k], rel) for k in x)
    return x == y


def poses(items):
    return [[item.get(key) for key in POSE] for item in items]


def max_matching(allowed):
    """Maximum-cardinality bipartite matching size (truth rows x prediction columns), BFS augmenting paths."""
    truths, predictions = allowed.shape
    neighbours = [[] for _ in range(truths)]
    for row, column in zip(*(index.tolist() for index in np.nonzero(allowed))):
        neighbours[row].append(column)
    owner, partner = [-1]*predictions, [-1]*truths
    for root in range(truths):
        via, frontier, seen, free = {}, [root], {root}, -1
        while frontier and free < 0:
            following = []
            for truth in frontier:
                for prediction in neighbours[truth]:
                    if prediction in via:
                        continue
                    via[prediction] = truth
                    if owner[prediction] < 0:
                        free = prediction
                        break
                    if owner[prediction] not in seen:
                        seen.add(owner[prediction])
                        following.append(owner[prediction])
                if free >= 0:
                    break
            frontier = following
        while free >= 0:  # flip the alternating path back to the root
            truth = via[free]
            previous = partner[truth]
            partner[truth], owner[free] = free, truth
            free = previous
    return sum(p >= 0 for p in partner)


def gt_counts(matches, truth):
    """Strict TP/FP/FN (<=2 px, wrapped angle <=1 deg, scale ratio in [0.98, 1.02]) and 20 px localization TP."""
    keys = ('pos_x', 'pos_y', 'angle', 'scale')
    pred = np.array([[num(m.get(k)) for k in keys] for m in matches], float).reshape(-1, 4)
    true = np.array([[num(t.get(k)) for k in keys] for t in truth], float).reshape(-1, 4)
    valid = np.isfinite(pred).all(axis=1) & (pred[:, 3] > 0)
    with np.errstate(all='ignore'):
        dist = np.hypot(pred[None, :, 0]-true[:, None, 0], pred[None, :, 1]-true[:, None, 1])
        dang = np.abs(np.mod(pred[None, :, 2]-true[:, None, 2]+180., 360.)-180.)
        ratio = pred[None, :, 3]/true[:, None, 3]
    strict = valid & (dist <= 2.) & (dang <= 1.) & (ratio >= .98) & (ratio <= 1.02)
    tp = max_matching(strict)
    return dict(tp=tp, fp=len(pred)-tp, fn=len(true)-tp), max_matching(valid & (dist <= 20.))


def record_values(a, rec, where):
    def finite_pose(p):
        corners = p.get('corners')
        return (all(isinstance(p.get(k), (int, float)) and np.isfinite(p[k]) for k in POSE[:5]) and p['scale'] > 0
                and isinstance(corners, list) and len(corners) == 4
                and all(isinstance(c, list) and len(c) == 2 and np.isfinite([num(v) for v in c]).all() for c in corners))
    total = rec.get('total_ms')
    ok = isinstance(total, (int, float)) and np.isfinite(total) and total > 0
    ok = ok and all(isinstance(rec.get(n), list) and all(finite_pose(p) for p in rec[n]) for n in ('matches', 'proposals'))
    a.check('record_values', ok, **where)


def record_contract(a, rec, path, arm, models, where):
    """Dedup counters and residency of one call; returns (input, kept, hybrid fine_maps)."""
    record_values(a, rec, where)
    cd, full, enabled = rec.get('candidate_dedup'), path == 'full_gpu', ARMS[arm]['top_k'] > 0
    if not a.check('dedup_present', isinstance(cd, dict) and cd.get('top_k') == ARMS[arm]['top_k'], **where):
        return None, None, None
    rows = cd.get('models')
    if full and not enabled:
        a.check('dedup_full_off_unavailable', cd.get('available') is False and rows == []
                and cd.get('input_candidates') is None and cd.get('kept_candidates') is None, **where)
    elif a.check('dedup_available', cd.get('available') is True and isinstance(rows, list) and len(rows) == models,
                 **where, models=len(rows or []), expected=models):
        for i, row in enumerate(rows):
            a.check('dedup_kept_le_input', 0 <= row['kept_candidates'] <= row['input_candidates'], model=i, **where)
            if not enabled:
                a.check('dedup_off_identity', row['kept_candidates'] == row['input_candidates'] and row['filter_ms'] == 0, model=i, **where)
            elif full:
                a.check('dedup_full_no_host_filter', row['filter_ms'] == 0, model=i, **where)
        a.check('dedup_totals', cd.get('input_candidates') == sum(r['input_candidates'] for r in rows)
                and cd.get('kept_candidates') == sum(r['kept_candidates'] for r in rows), **where)
    metrics = rec.get('full_gpu') or {}
    fine = None
    if full:
        a.check('residency', metrics.get('enabled') is True and all(metrics.get(k) == v for k, v in RESIDENCY.items()),
                **where, counters={k: metrics.get(k) for k in RESIDENCY})
    else:
        a.check('hybrid_not_full_gpu', not metrics.get('enabled', False), **where)
        fine = sum(int(w['fine_maps']) for w in rec.get('work', []))
        a.notes['hybrid_calls_work_rows_differ_from_models'] += len(rec.get('work', [])) != models
    return cd.get('input_candidates'), cd.get('kept_candidates'), fine


def load_worker(a, root, entry, where):
    """Verify listed SHA256s; a failed worker (no result) returns None and is a gate failure for the caller."""
    paths = {}
    for key in ('job', 'result'):
        if key in entry or key == 'job':
            paths[key] = inside(root, entry[key]) if key in entry else None
            a.check('sha256', paths[key] is not None and sha256(paths[key]) == entry.get(key+'_sha256'), file=entry.get(key), **where)
    a.check('result_iff_returncode_zero', ('result' in entry) == (entry.get('returncode') == 0), **where)
    host = entry.get('host')
    a.check('host_recorded', isinstance(host, dict) and isinstance(host.get('competing_processes'), list), **where)
    if paths.get('job') is None or paths.get('result') is None or entry.get('returncode') != 0:
        return None, None
    return load(paths['job']), load(paths['result'])


def job_contract(a, job, case, path, arm, where, repeats, min_warmup):
    want = dict(zip(DEDUP_JOB, (ARMS[arm]['top_k'], ARMS[arm]['radius'], ARMS[arm]['angle_steps'])), **PATH_JOB[path])
    a.check('job_keys', all(job.get(k) == v for k, v in want.items())
            and job.get('full_gpu_profiling', False) is False and job.get('repeats') == repeats
            and num(job.get('warmup_seconds')) >= min_warmup, **where)
    a.check('job_inputs', job.get('source') == case.get('source') and job.get('template') == case.get('template'), **where)
    scales = case.get('scales') or case.get('native_search', {}).get('scales')
    a.check('job_scales', job.get('scales') == scales, **where)
    return len(job.get('scales') or [])


def pairing(a, jobs):
    """One case's jobs differ across arms only in the dedup keys, across paths only in the path switches."""
    groups = {}
    for (name, path, arm), job in jobs.items():
        groups.setdefault(('arms', name, path), []).append({k: v for k, v in job.items() if k not in DEDUP_JOB})
        groups.setdefault(('paths', name, arm), []).append({k: v for k, v in job.items() if k not in PATH_SWITCH})
    for key, group in groups.items():
        a.check('job_pairing', all(job == group[0] for job in group), group=list(key))


def repeat_check(a, phase, worker, first, runs, where, same_counts=True):
    identical = all(poses(r.get('matches', [])) == poses(first.get('matches', []))
                    and poses(r.get('proposals', [])) == poses(first.get('proposals', [])) for r in runs)
    runner = worker.get('exact_repeat') is True
    a.check('repeat_flag_agrees', runner == identical, runner=runner, poses_identical=identical, **where)
    if not (runner and identical and same_counts):
        a.gate(phase, 'repeat', **where)
    return runner


def gt_cell(a, case, path, arm, worker, models, where):
    first, runs = worker.get('first'), worker.get('runs')
    if not a.check('worker_shape', isinstance(first, dict) and isinstance(runs, list) and len(runs) == 1
                   and isinstance(worker.get('final_memory'), dict), **where):
        return None
    calls = [first, *runs]
    counters = [record_contract(a, rec, path, arm, models, dict(where, call=i)) for i, rec in enumerate(calls)]
    counts = [gt_counts(rec.get('matches', []), case['truth']) for rec in calls]
    strict = [c[0] for c in counts]
    same_counts = all(s == strict[0] for s in strict)
    runner = repeat_check(a, 'gt', worker, first, runs, where, same_counts)
    inp, kept, fine = counters[0]
    return dict(strict=strict, localization_tp=[c[1] for c in counts], exact_repeat=runner, same_counts=same_counts,
                matches=len(first.get('matches', [])), proposals=len(first.get('proposals', [])),
                dedup_input=inp, dedup_kept=kept, fine_maps=fine, kept_fraction=kept/inp if inp else None,
                total_ms=[rec.get('total_ms') for rec in calls], peak_rss_bytes=worker['final_memory'].get('peak_rss_bytes'),
                _models=(first.get('candidate_dedup') or {}).get('models') or [],
                _matches=poses(first.get('matches', [])), _proposals=poses(first.get('proposals', [])))


def header(a, m, phase, partial, protocol_sha):
    a.check(phase+'_header', m.get('phase') == phase and m.get('stage') == 43 and m.get('arms') == ARMS and m.get('paths') == PATHS)
    if protocol_sha:
        a.check(phase+'_protocol_sha256', m.get('protocol_sha256') == protocol_sha)
    if m.get('complete') is True or not partial:
        a.check(phase+'_complete_unchanged', m.get('complete') is True and m.get('unchanged') is True
                and all(m.get(k) for k in FINGERPRINTS) and m.get('after_sha256') == {k: m.get(k) for k in FINGERPRINTS})
    else:
        a.notes[phase+'_manifest_incomplete'] = 1


def audit_gt(a, manifest_path, partial, protocol_sha):
    m, root = load(manifest_path), manifest_path.parent.resolve()
    header(a, m, 'gt', partial, protocol_sha)
    cases = {c['name']: c for c in m['cases']}
    expected = [(c['name'], p, arm) for c in m['cases'] for p in c['paths'] for arm in ARMS]
    a.check('gt_plan', len(cases) == len(m['cases']) == GT_CASES and len(expected) == len(set(expected)) == GT_WORKERS,
            cases=len(cases), workers=len(expected))
    hybrid_only = {n for n, c in cases.items() if list(c['paths']) == ['hybrid']}
    support = {n for n, c in cases.items() if (c.get('extra') or {}).get('scale_support_refine')}
    a.check('gt_hybrid_only_is_scale_support', hybrid_only == support
            and all(list(c['paths']) in (['hybrid'], ['hybrid', 'full_gpu']) for c in cases.values()))
    for c in cases.values():
        a.check('truth_valid', all(np.isfinite([num(t.get(k)) for k in ('pos_x', 'pos_y', 'angle', 'scale')]).all()
                                   and num(t.get('scale')) > 0 for t in c['truth']), case=c['name'])
    cells, jobs, seen, planned = {}, {}, Counter(), set(expected)
    for e in m['executions']:
        key = (e.get('case'), e.get('path'), e.get('arm'))
        seen[key] += 1
        where = dict(case=key[0], path=key[1], arm=key[2])
        if not a.check('gt_execution_planned_once', key in planned and seen[key] == 1 and e.get('block') == 0, **where):
            continue
        a.notes['gt_workers_with_competing_processes'] += bool((e.get('host') or {}).get('competing_processes'))
        job, worker = load_worker(a, root, e, where)
        if worker is None:
            a.gate('gt', 'worker', **where)
            continue
        jobs[key] = job
        models = job_contract(a, job, cases[key[0]], key[1], key[2], where, 1, 0.)
        cells[key] = gt_cell(a, cases[key[0]], key[1], key[2], worker, models, where)
    missing = [k for k in expected if k not in seen]
    a.check('gt_coverage', partial or not missing, missing=len(missing))
    a.missing += [dict(phase='gt', case=k[0], path=k[1], arm=k[2]) for k in missing] if partial else []
    pairing(a, jobs)
    cells = {k: v for k, v in cells.items() if v is not None}
    geometry(a, cells, jobs)
    return m, cases, cells


def geometry(a, cells, jobs):
    """Informational: radius_px/radius and angle_window/angle_steps agree per case model across enabled arms and paths."""
    units = {}
    for (name, path, arm), cell in cells.items():
        if ARMS[arm]['top_k'] == 0:
            continue
        overlap = jobs[(name, path, arm)].get('overlap')
        for i, row in enumerate(cell['_models']):
            units.setdefault((name, i), []).append(
                (path, arm, row['radius_px']/ARMS[arm]['radius'], row['angle_window_deg']/ARMS[arm]['angle_steps']))
            if isinstance(overlap, (int, float)) and overlap < 1:  # R/(radius*(1-maxOverlap)) = level-0 min side
                side = row['radius_px']/(ARMS[arm]['radius']*(1-overlap))
                a.notes['radius_min_side_not_integer'] += abs(side-round(side)) > 1e-6
    for (name, i), rows in units.items():
        a.notes['geometry_groups'] += 1
        bad = [r for r in rows if not (close(r[2], rows[0][2], 1e-6) and close(r[3], rows[0][3], 1e-6))]
        if bad:
            a.geometry.append(dict(case=name, model=i, reference=rows[0], differing=bad))


def compare_arms(a, cases, cells):
    versus = {}
    totals = {p: {arm: dict(cases=0, regressions=[], improvements=[], tp_delta=0, fp_delta=0, fn_delta=0, matches_identical=0,
                            proposals_identical=0, input=0, kept=0, fine_maps_off=0, fine_maps=0) for arm in ARMS if arm != 'off'} for p in PATHS}
    for (name, path, arm), cell in sorted(cells.items()):
        base = cells.get((name, path, 'off'))
        if arm == 'off' or base is None:
            continue
        d = {k: cell['strict'][0][k]-base['strict'][0][k] for k in ('tp', 'fp', 'fn')}
        regression = d['tp'] < 0 or d['fp'] > 0
        v = versus[(name, path, arm)] = dict(
            delta=d, regression=regression, improvement=(d['tp'] > 0 or d['fp'] < 0) and not regression,
            matches_identical=cell['_matches'] == base['_matches'], proposals_identical=cell['_proposals'] == base['_proposals'],
            match_count_delta=cell['matches']-base['matches'], proposal_count_delta=cell['proposals']-base['proposals'])
        t, role = totals[path][arm], cases[name]['role']
        t['cases'] += 1
        for k in ('tp', 'fp', 'fn'):
            t[k+'_delta'] += d[k]
        t['matches_identical'] += v['matches_identical']
        t['proposals_identical'] += v['proposals_identical']
        t['input'] += cell['dedup_input'] or 0
        t['kept'] += cell['dedup_kept'] or 0
        if path == 'hybrid':
            t['fine_maps_off'] += base['fine_maps'] or 0
            t['fine_maps'] += cell['fine_maps'] or 0
        if regression:
            t['regressions'].append(dict(case=name, role=role, **d))
            a.gate('gt', 'gt_regression', case=name, path=path, arm=arm, role=role, **d)
        if v['improvement']:
            t['improvements'].append(dict(case=name, role=role, **d))
    for path, arms in totals.items():
        for t in arms.values():
            t['kept_fraction'] = t['kept']/t['input'] if t['input'] else None
            if path == 'hybrid':
                t['fine_maps_fraction'] = t['fine_maps']/t['fine_maps_off'] if t['fine_maps_off'] else None
            else:
                del t['fine_maps_off'], t['fine_maps']
    decision = dict(
        gt_neutral={p: {arm: not totals[p][arm]['regressions'] for arm in totals[p]} for p in PATHS},
        negative_controls={arm: {p: dict(case=c, demonstrated=any(r['case'] == c for r in totals[p][arm]['regressions']))
                                 for p in PATHS} for arm, c in CONTROLS.items()})
    return versus, totals, decision


def failure_keys(items, gates):
    return sorted(json.dumps([item.get(k) for k in FAIL_KEYS]) for item in items if item.get('gate') in gates)


def rows_key(rows):
    return sorted((r.get('case'), r.get('role'), r.get('tp'), r.get('fp'), r.get('fn')) for r in rows)


CELL_FIELDS = ('strict', 'localization_tp', 'exact_repeat', 'same_counts', 'matches', 'proposals', 'dedup_input',
               'dedup_kept', 'fine_maps', 'kept_fraction', 'total_ms', 'peak_rss_bytes')
AGG_FIELDS = ('cases', 'tp_delta', 'fp_delta', 'fn_delta', 'matches_identical', 'proposals_identical', 'input', 'kept', 'kept_fraction')


def compare_gt_summary(a, summary_path, manifest_path, cases, cells, versus, totals, decision):
    s = load(summary_path)
    a.same('gt_summary_header', [sha256(manifest_path), 'gt', ARMS], [s.get('manifest_sha256'), s.get('phase'), s.get('arms')])
    rows = {r['case']: r for r in s.get('cases', [])}
    a.same('gt_summary_case_set', sorted(cases), sorted(rows))
    for name, case in cases.items():
        row = rows.get(name) or {}
        a.same('gt_summary_row', [case['family'], case['role'], len(case['truth'])], [row.get('family'), row.get('role'), row.get('truth')], case=name)
        for path in case['paths']:
            for arm in ARMS:
                where = dict(case=name, path=path, arm=arm)
                mine, theirs = cells.get((name, path, arm)), ((row.get('paths') or {}).get(path) or {}).get(arm)
                if not a.check('gt_summary_cell_present', (mine is None) == (theirs is None), **where) or mine is None:
                    continue
                for field in CELL_FIELDS:
                    a.same('gt_summary_cell', mine[field], theirs.get(field), field=field, **where)
                if arm != 'off':
                    a.same('gt_summary_versus_off', versus.get((name, path, arm)), theirs.get('versus_off'), **where)
    aggregates = s.get('aggregates') or {}
    for path in PATHS:
        for arm, t in totals[path].items():
            theirs = (aggregates.get(path) or {}).get(arm) or {}
            for field in AGG_FIELDS+(('fine_maps_off', 'fine_maps', 'fine_maps_fraction') if path == 'hybrid' else ()):
                a.same('gt_summary_aggregate', t[field], theirs.get(field), path=path, arm=arm, field=field)
            for field in ('regressions', 'improvements'):
                a.same('gt_summary_aggregate', rows_key(t[field]), rows_key(theirs.get(field, [])), path=path, arm=arm, field=field)
    theirs = s.get('decision') or {}
    a.same('gt_summary_gt_neutral', {p: decision['gt_neutral'][p]['k3'] for p in PATHS}, theirs.get('gt_neutral'))
    a.same('gt_summary_negative_controls', decision['negative_controls'], theirs.get('negative_controls'))
    a.same('gt_summary_failures', failure_keys(a.gates['gt'], GT_GATES), failure_keys(s.get('failures', []), GT_GATES))


def audit_formal(a, manifest_path, partial, protocol_sha, gt_cases, gt_cells):
    m, root = load(manifest_path), manifest_path.parent.resolve()
    header(a, m, 'formal', partial, protocol_sha)
    a.check('formal_blocks_measured', m.get('blocks') == BLOCKS and m.get('measured_calls') == MEASURED)
    before = ((m.get('host') or {}).get('before') or {}).get('competing_processes')
    a.check('formal_host_before_recorded', isinstance(before, list))
    if before:
        a.gate('formal', 'host_start', processes=before)
    cases = {c['name']: c for c in m['cases']}
    a.same('formal_cases', sorted(FORMAL_CASES), sorted(cases))
    keys = ('pos_x', 'pos_y', 'angle', 'scale')
    for name, c in cases.items():
        a.check('formal_truth_equals_gt', name in gt_cases and [[t.get(k) for k in keys] for t in c['truth']]
                == [[t.get(k) for k in keys] for t in gt_cases[name]['truth']], case=name)
    expected = [(n, p, arm, b) for n in FORMAL_CASES for b in range(BLOCKS) for p, arm in (FORMAL_ARMS if b % 2 == 0 else FORMAL_ARMS[::-1])]
    actual = [(e.get('case'), e.get('path'), e.get('arm'), e.get('block')) for e in m['executions']]
    a.check('formal_order', actual == expected or (partial and actual == expected[:len(actual)]), executions=len(actual))
    if partial and len(actual) < len(expected):
        a.missing.append(dict(phase='formal', not_yet_run=len(expected)-len(actual)))
    workers = {}
    for e, key in zip(m['executions'], actual):
        where = dict(case=key[0], path=key[1], arm=key[2], block=key[3])
        if not a.check('formal_execution_once', key in expected and key not in workers and key[0] in cases, **where):
            continue
        for process in (e.get('host') or {}).get('competing_processes', []):
            a.gate('formal', 'host', process=process.get('command'), **where)
        job, worker = load_worker(a, root, e, where)
        if worker is None:
            a.gate('formal', 'worker', **where)
            continue
        models = job_contract(a, job, cases[key[0]], key[1], key[2], where, MEASURED, 1.)
        workers[key] = formal_worker(a, cases[key[0]], key[1], key[2], worker, models, where, gt_cells.get(key[:3]))
    return formal_stats(a, workers)


def formal_worker(a, case, path, arm, worker, models, where, reference):
    first, runs = worker.get('first'), worker.get('runs')
    if not a.check('worker_shape', isinstance(first, dict) and isinstance(runs, list) and len(runs) == MEASURED
                   and isinstance(worker.get('final_memory'), dict), **where):
        return None
    calls = [first, *runs]
    counters = [record_contract(a, rec, path, arm, models, dict(where, call=i)) for i, rec in enumerate(calls)]
    if any(s['fp'] or s['fn'] for s in (gt_counts(rec.get('matches', []), case['truth'])[0] for rec in calls)):
        a.gate('formal', 'gt', **where)
    repeat_check(a, 'formal', worker, first, runs, where)
    warmups = worker.get('warmups_ms') or []
    if len(warmups) < 1:
        a.gate('formal', 'warmup', **where)
    a.notes['formal_workers_warmup_total_below_1000ms'] += sum(warmups) < 1000
    if reference is None:
        a.notes['formal_gt_identity_unchecked'] += 1
    elif [poses(first.get('matches', [])), poses(first.get('proposals', []))] != [reference['_matches'], reference['_proposals']]:
        a.gate('formal', 'gt_phase_identity', **where)
    return dict(total_ms=[r.get('total_ms') for r in runs], first_ms=first.get('total_ms'),
                rss=worker['final_memory'].get('peak_rss_bytes'), input=counters[0][0], kept=counters[0][1])


def formal_stats(a, workers):
    rows = {}
    for name in FORMAL_CASES:
        for path in PATHS:
            groups = {arm: [workers.get((name, path, arm, b)) for b in range(BLOCKS)] for arm in ('off', 'k3')}
            if any(w is None for group in groups.values() for w in group):
                continue  # not yet run (partial) or a failed worker, reported above
            stats = {}
            for arm, group in groups.items():
                values = [v for w in group for v in w['total_ms']]
                stats[arm] = dict(median=median(values), values=values, block_medians=[median(w['total_ms']) for w in group],
                                  rss=[w['rss'] for w in group], first_ms=[w['first_ms'] for w in group],
                                  kept=sorted({w['kept'] for w in group}, key=str), input=sorted({w['input'] for w in group}, key=str))
            off, on = stats['off'], stats['k3']
            pooled = 100*(on['median']/off['median']-1)
            paired = [100*(k/o-1) for o, k in zip(off['block_medians'], on['block_medians'])]
            consistent = sign(pooled) != 0 and all(sign(p) == sign(pooled) for p in paired)
            row = rows[(name, path)] = dict(off=off, k3=on, delta_percent=pooled, paired=paired, consistent_direction=consistent,
                                            k3_faster_blocks=sum(p < 0 for p in paired))
            if name in SPEED_CASES:
                row['speed_target_met'] = consistent and pooled <= SPEED_TARGET
                if not row['speed_target_met']:
                    a.gate('formal', 'speed_target', case=name, path=path, delta_percent=pooled, consistent=consistent)
            else:
                row['time_budget_ok'] = [k <= o+max(TIME_GATE[0], TIME_GATE[1]*o) for o, k in zip(off['block_medians'], on['block_medians'])]
                for block, ok in enumerate(row['time_budget_ok']):
                    if not ok:
                        a.gate('formal', 'time_budget', case=name, path=path, block=block, delta_percent=paired[block])
            row['rss_ok'] = [k <= o+max(RSS_GATE[0], RSS_GATE[1]*o) for o, k in zip(off['rss'], on['rss'])]
            for block, ok in enumerate(row['rss_ok']):
                if not ok:
                    a.gate('formal', 'rss', case=name, path=path, block=block, off=off['rss'][block], k3=on['rss'][block])
    return rows


def compare_formal_summary(a, summary_path, manifest_path, rows):
    s = load(summary_path)
    a.same('formal_summary_header', [sha256(manifest_path), 'formal'], [s.get('manifest_sha256'), s.get('phase')])
    theirs_rows = {r['case']: r for r in s.get('cases', [])}
    for (name, path), mine in rows.items():
        theirs, where = ((theirs_rows.get(name) or {}).get('paths') or {}).get(path) or {}, dict(case=name, path=path)
        for arm in ('off', 'k3'):
            m, t = mine[arm], (theirs.get('arms') or {}).get(arm) or {}
            dist = t.get('total_ms') or {}
            a.same('formal_summary_total_ms', [m['median'], min(m['values']), max(m['values']), m['values']],
                   [dist.get(k) for k in ('median', 'min', 'max', 'values')], arm=arm, **where)
            a.same('formal_summary_block_medians', m['block_medians'], t.get('block_medians'), arm=arm, **where)
            a.same('formal_summary_rss', m['rss'], t.get('peak_rss_bytes'), arm=arm, **where)
            a.same('formal_summary_first_ms', m['first_ms'], (t.get('first_ms') or {}).get('values'), arm=arm, **where)
            a.same('formal_summary_dedup', [m['kept'], m['input']], [t.get('dedup_kept'), t.get('dedup_input')], arm=arm, **where)
        v = theirs.get('k3_versus_off') or {}
        a.same('formal_summary_versus', [mine['delta_percent'], mine['paired'], mine['consistent_direction'], mine['k3_faster_blocks']],
               [v.get('delta_percent'), [p.get('delta_percent') for p in v.get('paired', [])], v.get('consistent_direction'),
                v.get('k3_faster_blocks')], **where)
    a.same('formal_summary_failures', failure_keys(a.gates['formal'], FORMAL_GATES), failure_keys(s.get('failures', []), FORMAL_GATES))


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--gt-manifest', type=Path, required=True)
    parser.add_argument('--gt-summary', type=Path)
    parser.add_argument('--formal-manifest', type=Path)
    parser.add_argument('--formal-summary', type=Path)
    parser.add_argument('--protocol', type=Path, help='protocol.json: verify the manifests protocol_sha256 and the hard-coded arms')
    parser.add_argument('--partial', action='store_true', help='treat missing executions as not yet run instead of mismatches')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    a, protocol_sha = Audit(), None
    if args.protocol:
        protocol_sha = sha256(args.protocol)
        arms = {k: {f: v[f] for f in ('top_k', 'radius', 'angle_steps')} for k, v in load(args.protocol)['arms'].items()}
        a.same('protocol_arms', ARMS, arms)
    gt_path = args.gt_manifest.resolve()
    manifest, cases, cells = audit_gt(a, gt_path, args.partial, protocol_sha)
    versus, totals, decision = compare_arms(a, cases, cells)
    if args.gt_summary:
        compare_gt_summary(a, args.gt_summary, gt_path, cases, cells, versus, totals, decision)
    formal = {}
    if args.formal_manifest:
        formal = audit_formal(a, args.formal_manifest.resolve(), args.partial, protocol_sha, cases, cells)
        if args.formal_summary:
            compare_formal_summary(a, args.formal_summary, args.formal_manifest.resolve(), formal)
    speed = {p: [formal[(n, p)].get('speed_target_met') for n in SPEED_CASES if (n, p) in formal] for p in PATHS}
    table = [dict(case=k[0], path=k[1], arm=k[2], strict=c['strict'][0], repeat_strict=c['strict'][1:], localization_tp=c['localization_tp'][0],
                  kept=c['dedup_kept'], input=c['dedup_input'], **({'versus_off': versus[k]} if k in versus else {}))
             for k, c in sorted(cells.items())]
    out = dict(
        audit='stage43 candidate-dedup independent audit (no cpp-core/tools imports)', partial=args.partial,
        inputs={k: str(v) for k, v in vars(args).items() if isinstance(v, Path)},
        checks_total=sum(a.checks.values()), checks=dict(sorted(a.checks.items())), mismatch_count=len(a.mismatches),
        mismatches=a.mismatches, missing=a.missing, notes=dict(sorted(a.notes.items())), geometry_inconsistencies=a.geometry,
        gate_failures=a.gates,
        gt=dict(manifest_complete=manifest.get('complete'), workers_audited=len(cells), calls_evaluated=sum(len(c['strict']) for c in cells.values()),
                baseline_strict={p: {k: sum(c['strict'][0][k] for (n, q, arm), c in cells.items() if q == p and arm == 'off')
                                     for k in ('tp', 'fp', 'fn')} for p in PATHS},
                aggregates=totals, decision=decision, cells=table),
        formal=dict(rows=[dict(case=n, path=p, off_median_ms=r['off']['median'], k3_median_ms=r['k3']['median'],
                               delta_percent=r['delta_percent'], paired_delta_percent=r['paired'], consistent_direction=r['consistent_direction'],
                               k3_faster_blocks=r['k3_faster_blocks'], **{k: r[k] for k in ('speed_target_met', 'time_budget_ok', 'rss_ok') if k in r},
                               off_rss=r['off']['rss'], k3_rss=r['k3']['rss'], kept=r['k3']['kept'], input=r['k3']['input'])
                          for (n, p), r in formal.items()],
                    suitable={p: decision['gt_neutral'][p]['k3'] and len(speed[p]) == len(SPEED_CASES) and all(speed[p]) for p in PATHS})
        if args.formal_manifest else None)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(out, indent=1)+'\n')
    print(f"checks {out['checks_total']}, mismatches {len(a.mismatches)}, gt workers {len(cells)}, "
          f"gt gate failures {len(a.gates['gt'])}, formal gate failures {len(a.gates['formal'])}, missing {len(a.missing)}")
    return 1 if a.mismatches else 0


if __name__ == '__main__':
    raise SystemExit(main())
