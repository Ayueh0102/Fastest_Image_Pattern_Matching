"""Implementation smoke for the round-43 dedup option (not evidence)."""
import json, subprocess, sys, time
from pathlib import Path
WT = Path('/Users/Ayueh/Fastest_Image_Pattern_Matching/.claude/worktrees/ecstatic-fermi-009cdc')
sys.path.insert(0, str(WT/'cpp-core/tools'))
import benchmark_gpu_ncc_closure as s40
from many_object_accuracy import evaluate
manifest = json.load(open('/Users/Ayueh/Fastest_Image_Pattern_Matching/build/stage37-full-gpu/formal/manifest.json'))
runner = WT/'build/stage43-dev/experiments/fpm_native_pipeline_runner'
out = Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)
cases = sys.argv[2].split(','); arms = sys.argv[3].split(';')
for case in [c for c in manifest['cases'] if c['name'] in cases]:
    for method in ('hybrid_best', 'full_gpu_simd'):
        for arm in arms:
            k, radius, steps = (float(v) for v in arm.split(','))
            job = s40.job(case, method, 1, 0)
            job.update(candidate_dedup_top_k=int(k), candidate_dedup_radius=radius, candidate_dedup_angle_steps=steps)
            path = out/f"{case['name']}-{method}-{arm.replace(',', '_')}.json"; path.write_text(json.dumps(job))
            t = time.time(); p = subprocess.run([str(runner), str(path)], capture_output=True, text=True)
            if p.returncode: print(case['name'], method, arm, 'FAILED', p.stderr[-500:]); continue
            r = json.loads(p.stdout); first = r['first']; run = r['runs'][0]
            a = evaluate(run['matches'], case['truth'])['strict']
            d = run['candidate_dedup']
            print(f"{case['name']:14s} {method:13s} k={arm:10s} total={run['total_ms']:8.1f} gt tp={a['tp']} fp={a['fp']} fn={a['fn']} "
                  f"in={d['input_candidates']} kept={d['kept_candidates']} props={len(run['proposals'])} matches={len(run['matches'])} wall={time.time()-t:.1f}s", flush=True)
