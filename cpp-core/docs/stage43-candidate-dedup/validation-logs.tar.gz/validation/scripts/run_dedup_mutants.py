"""Compiled mutants for the round-43 candidate-dedup tests.

Each mutant edits one file of a disposable tree (its anchor must occur exactly
once), waits >1 s (whole-second make timestamps), rebuilds the dedup test
targets, requires the mutated translation unit in the build log, runs every
dedup test binary and restores the file. A final run rebuilds and reruns all
tests on the restored tree. A mutant is killed when it builds and at least one test fails; a build
failure aborts the run instead of counting as a kill.

Usage: run_dedup_mutants.py <tree root> <build dir> <log dir>
"""
import json
import subprocess
import sys
import time
from pathlib import Path

ROOT, BUILD, LOGS = (Path(arg) for arg in sys.argv[1:4])
LOGS.mkdir(parents=True, exist_ok=True)
TARGETS = ['fpm_candidate_dedup_test', 'fpm_full_gpu_dedup_test', 'fpm_candidate_dedup_pipeline_test']
TESTS = {'unit': [str(BUILD/'fpm_candidate_dedup_test')],
         'gpu_kernels': [str(BUILD/'experiments/fpm_full_gpu_dedup_test')],
         'pipeline_cpu': [str(BUILD/'experiments/fpm_candidate_dedup_pipeline_test'), '--cpu'],
         'pipeline_metal': [str(BUILD/'experiments/fpm_candidate_dedup_pipeline_test'), '--metal'],
         'pipeline_full_gpu': [str(BUILD/'experiments/fpm_candidate_dedup_pipeline_test'), '--full-gpu']}
DEDUP, MATCHER = 'cpp-core/src/candidate_dedup.cpp', 'cpp-core/src/matcher.cpp'
SHADER, HOST = 'cpp-core/experiments/full_gpu_dedup.metal', 'cpp-core/experiments/full_gpu_metal.mm'
SESSION = 'cpp-core/experiments/research_pipeline.cpp'
UNIT = {DEDUP: 'candidate_dedup.cpp.o', MATCHER: 'matcher.cpp.o', SHADER: 'full_gpu_metal.mm.o',
        HOST: 'full_gpu_metal.mm.o', SESSION: 'research_pipeline.cpp.o'}
MUTANTS = {
    'M1_count_only_kept_neighbors': (DEDUP, '\t\tgrid[{cx, cy}].push_back(i);', '\t\tif (keep[i]) grid[{cx, cy}].push_back(i);'),
    'M2_ignore_angle_window': (DEDUP, 'std::abs(normalizeAngle(p.angle - q.angle)) <= angleWindow + 1e-9 &&', 'true &&'),
    'M3_corner_instead_of_center': (MATCHER,
        '{{(candidate.point.x + 0.5 * (topW * c - topH * s)) * toSource,\n\t\t\t\t(candidate.point.y + 0.5 * (topW * s + topH * c)) * toSource}',
        '{{candidate.point.x * toSource + 0 * c,\n\t\t\t\tcandidate.point.y * toSource + 0 * s}'),
    'M4_gpu_break_on_equal_score': (SHADER, 'other.score<own.score) break;', 'other.score<=own.score) break;'),
    'M5_gpu_level0_size_for_center': (HOST, 'top.tw,top.th,uint32_t(m),0,float(radius)', 'base.tw,base.th,uint32_t(m),0,float(radius)'),
    'M6_gpu_drop_not_applied': (SHADER, 'if(i<k.maps*k.limit && drop[k.first+i]) candidates', 'if(i<k.maps*k.limit && drop[k.first+i] && false) candidates'),
    'M7_filter_result_ignored': (MATCHER, '\t\t\tif (keep[i]) candidates[kept++] = candidates[i];\n\t\tcandidates.resize(kept);',
        '\t\t\tif (keep[i]) ++kept;'),
    'M8_session_drops_top_k': (SESSION, 'FpmCandidateDedupConfigV1 dedup{1,sizeof(dedup),o.candidateDedupTopK,0,',
        'FpmCandidateDedupConfigV1 dedup{1,sizeof(dedup),0,0,'),
    'M9_gpu_counts_dropped_as_kept': (SHADER, '    if(!dropped) atomic_fetch_add_explicit(&counts[2*k.model+1]', '    atomic_fetch_add_explicit(&counts[2*k.model+1]'),
}


def build(label, unit=None):
    log = LOGS/(label+'-build.log')
    result = subprocess.run(['cmake', '--build', str(BUILD), '-j', '6', '--target', *TARGETS], capture_output=True, text=True)
    log.write_text(result.stdout+result.stderr)
    if result.returncode:
        return 'build_failed'
    if unit and unit not in result.stdout:
        raise RuntimeError(label+': mutated unit '+unit+' was not rebuilt')
    return 'built'


def run_tests(label):
    outcome = {}
    for name, command in TESTS.items():
        result = subprocess.run(command, capture_output=True, text=True, timeout=600)
        (LOGS/f'{label}-{name}.log').write_text(result.stdout+result.stderr)
        outcome[name] = 'pass' if result.returncode == 0 else 'fail'
    return outcome


summary = {}
for label, (relative, old, new) in MUTANTS.items():
    path = ROOT/relative
    text = path.read_text()
    if text.count(old) != 1:
        raise RuntimeError(label+': anchor must occur exactly once')
    time.sleep(1.1)
    path.write_text(text.replace(old, new))
    try:
        state = build(label, UNIT[relative])
        outcome = run_tests(label) if state == 'built' else {}
    finally:
        time.sleep(1.1)
        path.write_text(text)
    if state != 'built':
        raise RuntimeError(label+': mutant did not build; every mutant must compile to count')
    killed = any(value == 'fail' for value in outcome.values())
    summary[label] = dict(file=relative, build=state, tests=outcome, killed=killed)
    print(label, 'KILLED' if killed else 'SURVIVED', outcome, flush=True)
state = build('restored', None)
summary['restored'] = dict(build=state, tests=run_tests('restored'))
summary['all_killed'] = all(row['killed'] for key, row in summary.items() if key.startswith('M'))
summary['restored_all_pass'] = state == 'built' and all(v == 'pass' for v in summary['restored']['tests'].values())
(LOGS/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps({k: summary[k] for k in ('all_killed', 'restored_all_pass')}))
