#!/bin/bash
# Round 43 post-measurement validation at a clean committed HEAD. Waits while
# another session's timing lock exists. Every step logs to $LOG; failures stop.
set -uo pipefail
WT=/Users/Ayueh/Fastest_Image_Pattern_Matching/.claude/worktrees/ecstatic-fermi-009cdc
NOTES="/Users/Ayueh/Library/Application Support/Claude/side-session-notes/local_1b4c2052-63a8-4a9f-94f8-77e6ad04fbca"
PY=/Users/Ayueh/Fastest_Image_Pattern_Matching/python-port/venv/bin/python
S=/private/tmp/claude-502/-Users-Ayueh-Fastest-Image-Pattern-Matching--claude-worktrees-ecstatic-fermi-009cdc/8e8a7ba6-1b4a-4c10-aac8-2dfd240c7abc/scratchpad
LOG=$WT/build/stage43-logs/final
mkdir -p $LOG
cd $WT
while ls "$NOTES"/timing-lock-*.txt >/dev/null 2>&1; do sleep 15; done
step() { local name=$1; shift; echo "START $name $(date -u +%FT%TZ)"; "$@" > $LOG/$name.log 2>&1; local rc=$?; echo "END $name rc=$rc $(date -u +%FT%TZ)"; return $rc; }
{
echo "HEAD=$(git rev-parse HEAD) CLEAN=$([ -z "$(git status --porcelain -- cpp-core/src cpp-core/include cpp-core/experiments cpp-core/tools cpp-core/tests cpp-core/CMakeLists.txt CMakeLists.txt macos-cli)" ] && echo true || echo false)"
step release-configure cmake -S cpp-core -B build/stage43-final -DCMAKE_BUILD_TYPE=Release -DFPM_BUILD_GUI=ON -DFPM_BUILD_EXPERIMENTS=ON -DFPM_WITH_OPENCV=ON || exit 1
step release-build cmake --build build/stage43-final -j 10 || exit 1
step release-ctest ctest --test-dir build/stage43-final --output-on-failure -j 4 || exit 1
step python env FPM_FINE_REUSE_BUILD=build/stage43-final FPM_FINE_SEARCH_BUILD=build/stage43-final FPM_FINE_FUSED_BUILD=build/stage43-final $PY -m unittest discover -s cpp-core/tests -p 'test_*.py' || exit 1
step color $PY cpp-core/tests/color_verify_runner_test.py --runner build/stage43-final/experiments/fpm_color_verify_runner --metal || exit 1
step metal-validation env MTL_SHADER_VALIDATION=1 MTL_DEBUG_LAYER=1 ctest --test-dir build/stage43-final --output-on-failure -R 'dedup|experimental_full_gpu|native_runner' || exit 1
step sanitized-configure cmake -S cpp-core -B build/stage43-sanitized -DCMAKE_BUILD_TYPE=Debug -DFPM_SANITIZERS=ON -DFPM_DISABLE_SIMD=ON -DFPM_BUILD_EXPERIMENTS=ON || exit 1
step sanitized-build cmake --build build/stage43-sanitized -j 10 --target fpm_candidate_dedup_test fpm_candidate_dedup_pipeline_test fpm_full_gpu_dedup_test fpm_core_test fpm_research_pipeline_test || exit 1
step sanitized-ctest ctest --test-dir build/stage43-sanitized --output-on-failure -R 'dedup|portable_core|native_research' || exit 1
echo "HEAD_AFTER=$(git rev-parse HEAD) CLEAN_AFTER=$([ -z "$(git status --porcelain -- cpp-core/src cpp-core/include cpp-core/experiments cpp-core/tools cpp-core/tests cpp-core/CMakeLists.txt CMakeLists.txt macos-cli)" ] && echo true || echo false)"
} 2>&1 | tee $LOG/steps.log
