#!/bin/bash
# Round 43 timing phases in pre-registered order: pilot, formal, profile.
set -euo pipefail
WT=/Users/Ayueh/Fastest_Image_Pattern_Matching/.claude/worktrees/ecstatic-fermi-009cdc
PY=/Users/Ayueh/Fastest_Image_Pattern_Matching/python-port/venv/bin/python
OUT=$WT/build/stage43-candidate-dedup
cd $WT/cpp-core/tools
for phase in pilot formal profile; do
  mkdir -p $OUT/$phase
  echo "START $phase $(date -u +%FT%TZ)"
  $PY benchmark_candidate_dedup.py --phase $phase --build $WT/build/stage43-release --output $OUT/$phase/manifest.json > $WT/build/stage43-logs/$phase-run.log 2>&1
  echo "END $phase $(date -u +%FT%TZ)"
done
