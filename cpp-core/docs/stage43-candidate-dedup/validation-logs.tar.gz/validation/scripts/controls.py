"""Control-scene development check (not evidence)."""
import json, subprocess, sys
from pathlib import Path
WT = Path('/Users/Ayueh/Fastest_Image_Pattern_Matching/.claude/worktrees/ecstatic-fermi-009cdc')
sys.path.insert(0, str(WT/'cpp-core/tools'))
import benchmark_gpu_ncc_closure as s40
from many_object_accuracy import evaluate
import candidate_dedup_scenes as scenes
out = Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)
runner = WT/'build/stage43-dev/experiments/fpm_native_pipeline_runner'
ARMS = {'off': (0, .5, 3), 'k3': (3, .5, 3), 'k1': (1, .5, 3), 'k1_position_only': (1, .5, 1000), 'k1_wide_radius': (1, 2., 3)}
for case in scenes.make_cases(out/'inputs'):
    for method in ('hybrid_best', 'full_gpu_simd'):
        for arm, (k, r, a) in ARMS.items():
            job = s40.job(case, method, 1, 0); job.update(candidate_dedup_top_k=k, candidate_dedup_radius=r, candidate_dedup_angle_steps=a)
            path = out/f"{case['name']}-{method}-{arm}.json"; path.write_text(json.dumps(job))
            p = subprocess.run([str(runner), str(path)], capture_output=True, text=True)
            if p.returncode: print(case['name'], method, arm, 'FAILED', p.stderr[-300:]); continue
            run = json.loads(p.stdout)['runs'][0]; e = evaluate(run['matches'], case['truth'])
            s = e['strict']; d = run['candidate_dedup']
            print(f"{case['name']:16s} {method:13s} {arm:17s} tp={s['tp']:2d} fp={s['fp']} fn={s['fn']} loc_tp={e['localization']['tp']} kept={d['kept_candidates']}/{d['input_candidates']} total={run['total_ms']:.0f}", flush=True)
