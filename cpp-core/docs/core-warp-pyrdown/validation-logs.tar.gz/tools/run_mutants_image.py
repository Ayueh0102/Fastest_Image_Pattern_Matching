"""Compiled mutants for the exact warp/pyrDown changes (scratch).

Usage: run_mutants.py <worktree> <scratch dir>
Each mutant replaces one anchor (asserted to occur exactly once) in a copy of
cpp-core/src/image.cpp, rebuilds fpm_core_test in Release, and must make it fail.
The unmutated copy is built and must pass first.
"""
import json
import shutil
import subprocess
import sys
from pathlib import Path

MUTANTS = {
    "W1_interior_one_column_too_far": ("innerW = vdupq_n_f64(src.width - 1)", "innerW = vdupq_n_f64(src.width)"),
    "W2_top_not_fused": ("vfmaq_f64(vmulq_f64(p10, dx), p00, rx)", "vaddq_f64(vmulq_f64(p10, dx), vmulq_f64(p00, rx))"),
    "W3_lower_pair_swapped": ("vcombine_u64(vcreate_u64(bytePair(p + src.stride)), vcreate_u64(bytePair(q + src.stride)))",
                              "vcombine_u64(vcreate_u64(bytePair(q + src.stride)), vcreate_u64(bytePair(p + src.stride)))"),
    "W4_pyr_interior_too_far": ("std::min(width, (image.width - 1) / 2)", "std::min(width, (image.width + 1) / 2)"),
    "W5_pyr_rows_shifted": ("reflect101(y * 2 + k - 2, image.height)", "reflect101(y * 2 + k - 1, image.height)"),
    "W6_offset_axes_swapped": ("vfmaq_f64(fx, fy, stride)", "vfmaq_f64(fy, fx, stride)"),
    "W7_no_row_bound": ("vandq_u64(vcgeq_f64(sy, zero), vcltq_f64(sy, innerH))", "vcgeq_f64(sy, zero)"),
}


def build_and_test(src: Path, build: Path, log: Path) -> int:
    with log.open("w") as out:
        subprocess.run(["cmake", "-S", str(src / "cpp-core"), "-B", str(build), "-DCMAKE_BUILD_TYPE=Release"],
                       stdout=out, stderr=subprocess.STDOUT, check=True)
        subprocess.run(["cmake", "--build", str(build), "--target", "fpm_core_test", "-j", "8"],
                       stdout=out, stderr=subprocess.STDOUT, check=True)
        return subprocess.run([str(build / "fpm_core_test")], stdout=out, stderr=subprocess.STDOUT).returncode


def main():
    worktree, scratch = Path(sys.argv[1]), Path(sys.argv[2])
    scratch.mkdir(parents=True, exist_ok=True)
    original = (worktree / "cpp-core/src/image.cpp").read_text()
    results = {}
    for name in ["M0_unmutated", *MUTANTS]:
        src = scratch / name / "src"
        if src.exists():
            shutil.rmtree(src)
        for part in ("cpp-core/src", "cpp-core/include", "cpp-core/tests", "cpp-core/tools", "cpp-core/examples"):
            shutil.copytree(worktree / part, src / part)
        shutil.copy(worktree / "cpp-core/CMakeLists.txt", src / "cpp-core/CMakeLists.txt")
        shutil.copytree(worktree / "macos-cli", src / "macos-cli")
        shutil.copy(worktree / "LICENSE", src / "LICENSE")
        text = original
        if name in MUTANTS:
            old, new = MUTANTS[name]
            assert original.count(old) == 1, (name, original.count(old))
            text = original.replace(old, new)
        (src / "cpp-core/src/image.cpp").write_text(text)
        status = build_and_test(src, scratch / name / "build", scratch / name / "log.txt")
        tail = (scratch / name / "log.txt").read_text().strip().splitlines()[-1]
        expected_fail = name != "M0_unmutated"
        results[name] = {"exit": status, "killed_or_passed": (status != 0) == expected_fail, "last_line": tail}
        print(name, results[name], flush=True)
    (scratch / "summary.json").write_text(json.dumps(results, indent=2) + "\n")
    return int(not all(r["killed_or_passed"] for r in results.values()))


if __name__ == "__main__":
    sys.exit(main())
