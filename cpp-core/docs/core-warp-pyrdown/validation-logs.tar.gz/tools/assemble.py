"""Assemble cpp-core/docs/core-warp-pyrdown evidence from the scratch runs (scratch helper)."""
import hashlib
import io
import json
import shutil
import sys
import tarfile
from pathlib import Path

S, W = Path(sys.argv[1]), Path(sys.argv[2])
X = S / "warp"
D = W / "cpp-core/docs/core-warp-pyrdown"
if D.exists():
    shutil.rmtree(D)
for sub in ("formal", "pilot"):
    (D / sub).mkdir(parents=True)
shutil.copy(X / "bench/protocol.json", D / "protocol.json")
for p in sorted((X / "bench").iterdir()):
    if p.name not in ("protocol.json", "summarize.py"):
        shutil.copy(p, D / "formal" / p.name)
shutil.copy(X / "warp_micro.cpp", D / "pilot/warp_micro.cpp")
shutil.copy(X / "micro-output-rerun.txt", D / "pilot/micro-output-rerun.txt")


def load(path):
    return json.loads(Path(path).read_text())


identity = load(X / "final/identity.json")
mutants = load(X / "mutants/summary.json")
cv = {b: load(X / f"final/compare-versions-{b}.json") for b in ("base", "new")}
gate = (X / "final/gate.log").read_text()
validation = {
    "date": "2026-10-25",
    "head_before_change": "51d95b17d0737a4a5b5cfa2955edbffe717c56a0",
    "gate_log_sha256": hashlib.sha256(gate.encode()).hexdigest(),
    "image_cpp_sha256": gate.split("image_sha256=")[1].split()[0],
    "core_test_sha256": gate.split("test_sha256=")[1].split()[0],
    "release_ctest": "3/3 (portable_core incl. rotation/pyramid/exact-reference, c_abi, opencv_stage_comparison)",
    "no_dotprod_ctest_march_armv8_a": "3/3 (NEON rotation still on, UDOT off)",
    "scalar_release_ctest_disable_simd": "3/3 (scalar warp loop, no NEON intrinsics)",
    "asan_ubsan_scalar_ctest": "2/2 (Debug, FPM_SANITIZERS=ON, FPM_DISABLE_SIMD=ON)",
    "asan_ubsan_simd_ctest": "2/2 (Debug -O0, FPM_SANITIZERS=ON; NEON rotation and exact-reference test)",
    "research_ctest": "73/73 (Release, GUI + experiments + OpenCV)",
    "python_harness": "570 tests OK",
    "identity": {"runs": identity["runs"], "different_runs": identity["different_runs"],
                 "libraries": list(identity["libraries"]), "reference": identity["reference"],
                 "cases": len(identity["cases"]), "matches_compared": sum(c["count"] for c in identity["cases"])},
    "compare_versions": {b: {"outside_tolerance": [c["source"] for c in d["cases"]
                                                   if not c["portable_vs_legacy"]["within_tolerance"]],
                             "cases": len(d["cases"])} for b, d in cv.items()},
    "compare_versions_portable_matches_identical_base_vs_new":
        sum(a["portable_cpp"]["matches"] == b["portable_cpp"]["matches"] for a, b in zip(cv["base"]["cases"], cv["new"]["cases"])),
    "compiled_mutants": {k: {"exit": v["exit"], "expected_outcome": v["killed_or_passed"]} for k, v in mutants.items()},
}
(D / "validation.json").write_text(json.dumps(validation, indent=2) + "\n")

formal = load(X / "bench/summary.json")
decision = {
    "adopted": [
        "warp: NEON float64x2 pairs (clang + aarch64 + NEON, not FPM_DISABLE_SIMD) mirroring the fused scalar expressions; pairs with any pixel outside 0<=sx<w-1, 0<=sy<h-1 and the odd tail use the unchanged scalar warpPixel",
        "pyrDown: direct taps for interior columns, reflect101 only at the edges, reflected row pointers once per output row; integer arithmetic unchanged",
    ],
    "rejected_in_pilot": [
        {"variant": "A: scalar loop with an interior fast path", "reason": "about 8-20% faster warp only; dropped so the scalar reference loop stays literal"},
        {"variant": "B: NEON pairs with per-pixel double gathers through the stack", "reason": "slower than C (integer byte-pair gathers)"},
        {"variant": "D: C unrolled to four pixels", "reason": "about 3-12% faster warp than C in the pilot, not worth a second unrolled copy"},
    ],
    "failures_and_caveats": [
        "the NEON path reproduces clang's default -ffp-contract=on fusion; other compilers (GCC) keep the scalar loop and a different contraction flag would be caught by rotation/pyramid/exact-reference",
        "the uint8 output is not proof of identical intermediates in general, but mutant W2 (one multiply-add left unfused) was caught by the exact-reference test",
        "rotation SIMD is compile-time only: Backend::Scalar still selects only the scalar dot product, so portable_scalar mode also got faster (-9.9%)",
        "pilot micro outputs were rerun once after selection to archive them; the selection used the earlier, unarchived runs with the same ordering",
        "other Claude/Codex processes were active; load averages recorded per session (1-minute 3.0-3.9)",
        "only one Apple M4 Pro; Linux/Jetson/Windows-on-ARM and x86 not run; the pyrDown change is platform-independent integer code that was not run on x86",
    ],
    "formal_benchmark_modes": formal["benchmark_modes"],
    "formal_fixtures_ab_geomean_ratio": formal["fixtures_ab"]["geomean_ratio"],
}
(D / "decision-and-failures.json").write_text(json.dumps(decision, indent=2) + "\n")

members = {
    "final/gate.sh": X / "final/gate.sh", "final/gate.log": X / "final/gate.log",
    "final/identity.json": X / "final/identity.json",
    "final/compare-versions-base.json": X / "final/compare-versions-base.json",
    "final/compare-versions-new.json": X / "final/compare-versions-new.json",
    "final/mutants/summary.json": X / "mutants/summary.json",
    "tools/run_mutants_image.py": X / "run_mutants_image.py",
    "tools/summarize.py": X / "bench/summarize.py",
    "tools/assemble.py": X / "assemble.py",
    "tools/profile_loop.py": S / "final/profile/loop.py",
}
for p in sorted((X / "final/logs").iterdir()):
    members[f"final/logs/{p.name}"] = p
for m in sorted((X / "mutants").glob("[MW]*")):
    members[f"final/mutants/{m.name}.log"] = m / "log.txt"
for folder in ("profile-before", "profile-after"):
    for p in sorted((X / folder).glob("sample-*.txt")):
        members[f"{folder}/{p.name}"] = p
with tarfile.open(D / "validation-logs.tar.gz", "w:gz") as tar:
    for name, path in sorted(members.items()):
        data = Path(path).read_bytes()
        info = tarfile.TarInfo(name)
        info.size, info.mtime, info.mode = len(data), 0, 0o644
        tar.addfile(info, io.BytesIO(data))
files = sorted(p for p in D.rglob("*") if p.is_file() and p.name != "archive.json")
(D / "archive.json").write_text(json.dumps({str(p.relative_to(D)): hashlib.sha256(p.read_bytes()).hexdigest()
                                            for p in files}, indent=2) + "\n")
print("files", len(files), "bytes", sum(p.stat().st_size for p in files))
