import hashlib
import json
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parents[4]
out = Path(__file__).resolve().parent
binary = root/'build/stage37-review/release/experiments/fpm_native_pipeline_runner'
formal = root/'build/stage37-full-gpu/formal'
manifest = json.loads((formal/'manifest.json').read_text())
checks = {'initial_attempt': {'method': 'hybrid_best', 'timeout_seconds': 180,
    'outcome': 'timeout before main; dyld fcntl stack retained'},
    'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(), 'retry': {}}
for method in ('hybrid_best', 'full_gpu'):
    started = time.monotonic()
    try:
        p = subprocess.run([str(binary), str(out/(method+'-job.json'))],
                           capture_output=True, text=True, timeout=60)
        (out/(method+'-retry-stdout.json')).write_text(p.stdout)
        (out/(method+'-retry-stderr.log')).write_text(p.stderr)
        check = {'exit_code': p.returncode, 'wall_seconds': time.monotonic()-started}
        if p.returncode == 0:
            result = json.loads(p.stdout)
            entry = next(e for e in manifest['executions'] if e['case']=='controlled6' and e['method']==method)
            reference = json.loads((formal/entry['result']).read_text())
            check['calls'] = len(result['runs'])+1
            check['matches_and_proposals_exact'] = all(
                call[field] == reference['first'][field]
                for call in [result['first'], *result['runs']]
                for field in ('matches', 'proposals'))
    except subprocess.TimeoutExpired as exc:
        (out/(method+'-retry-timeout.log')).write_text(str(exc)+'\n')
        check = {'timeout_seconds': 60, 'wall_seconds': time.monotonic()-started,
                 'outcome': 'timeout; no runtime parity verdict'}
    checks['retry'][method] = check
    (out/'parity.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(method, check, flush=True)
