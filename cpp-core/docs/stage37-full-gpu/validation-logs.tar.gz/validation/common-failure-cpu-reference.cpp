#include "fpm/matcher.hpp"
#include <random>
#include <iostream>
#include <algorithm>
using namespace fpm;
int main(){Image t(32,24);std::mt19937 rng(370019);for(int y=0;y<24;++y)for(int x=0;x<32;++x)t.row(y)[x]=uint8_t(rng()); Image s(192,128);for(int y=0;y<128;++y)std::fill_n(s.row(y),192,uint8_t(23));for(int y=0;y<24;++y)std::copy_n(t.row(y),32,s.row(y+40)+50);MatchConfig c;c.minScore=.9;c.maxTargets=4;c.maxOverlap=.2;c.toleranceAngle=0;c.stopLayer=0;for(int area:{64,256,100000}){auto m=match(s.view(),Pattern(t.view(),area),c);std::cout<<"upright area="<<area<<" n="<<m.size()<<'\n';for(auto v:m)std::cout<<v.center.x<<' '<<v.center.y<<' '<<v.angle<<' '<<v.score<<'\n';}Image qt(23,17);for(int y=0;y<17;++y)for(int x=0;x<23;++x)qt.row(y)[x]=uint8_t(rng());Image qs(128,96);for(int y=0;y<96;++y)std::fill_n(qs.row(y),128,uint8_t(23));for(int y=0;y<17;++y)for(int x=0;x<23;++x)qs.row(30+22-x)[40+y]=qt.row(y)[x];c.angleRanges={{90.,90.}};for(int area:{64,256,100000}){auto m=match(qs.view(),Pattern(qt.view(),area),c);std::cout<<"quarter area="<<area<<" n="<<m.size()<<'\n';for(auto v:m)std::cout<<v.center.x<<' '<<v.center.y<<' '<<v.angle<<' '<<v.score<<'\n';}}
