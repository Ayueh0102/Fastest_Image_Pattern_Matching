import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
p=Path('cpp-core/docs/stage37-full-gpu');s=json.loads((p/'formal-summary.json').read_text())['cases'][:6]
labels=['6 rotated objects','12 rotated objects','Small / full resolution','8K / 6 objects / 3 scales','128 objects','512 objects']
fig,axes=plt.subplots(1,2,figsize=(12,5),layout='constrained');y=np.arange(6);colors=['#27628c','#ce6538']
for j,(method,label) in enumerate([('hybrid_best','Hybrid baseline'),('full_gpu','Full Metal data path')]):
 times=[c['methods'][method]['stages']['total_ms'] for c in s];values=np.array([t['median'] for t in times]);lo=values-np.array([t['min'] for t in times]);hi=np.array([t['max'] for t in times])-values
 axes[0].errorbar(values,y+(j-.5)*.25,xerr=[lo,hi],fmt='o',color=colors[j],capsize=3,label=label)
 axes[1].barh(y+(j-.5)*.34,[c['methods'][method]['peak_rss_bytes']/2**20 for c in s],height=.30,color=colors[j])
axes[0].set_xscale('log');axes[0].set_xlabel('Algorithm time, ms (log scale)');axes[0].set_title('Median and full measured range')
axes[1].set_xlabel('Process peak RSS, MiB');axes[1].set_title('Not total physical GPU + CPU memory')
for a in axes:a.set_yticks(y,labels);a.invert_yaxis();a.grid(axis='x',alpha=.2);a.spines[['top','right']].set_visible(False)
axes[1].tick_params(labelleft=False)
fig.legend(*axes[0].get_legend_handles_labels(),loc='outside lower center',ncol=2,frameon=False)
fig.suptitle('Stage 37 | M4 Pro | 4 paired blocks × 3 timed calls | all ground-truth checks passed',fontsize=12)
fig.savefig(p/'comparison.png',dpi=170)
