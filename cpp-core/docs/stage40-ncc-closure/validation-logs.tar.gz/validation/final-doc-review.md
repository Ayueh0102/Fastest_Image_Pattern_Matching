# Stage 40 independent final document review

Reviewer: `stage40_research` agent. Date: 2026-10-19.

Result: **PASS — no unresolved numerical, scope, or recommendation contradiction found in the reviewed documents.** This review read existing evidence; it launched no GPU jobs or builds and changed no frozen source.

Reviewed the current on-disk versions of:

- `cpp-core/docs/GPU_NCC_CLOSURE_zh-TW.md`
- `cpp-core/docs/CURRENT_BEST_zh-TW.md`
- `cpp-core/docs/PROJECT_STATUS_zh-TW.md`
- Stage 40 and adjacent historical entries in `cpp-core/docs/EXPERIMENT_REVIEW_zh-TW.md`
- The rendered `comparison.png`, published summaries, validation records, and corresponding raw test logs.

## Numerical checks

The formal, stop0, and seven-case holdout time tables and formal RSS table agree with their JSON summaries at the displayed precision. Primary fine4 medians are 806.4577915 ms and 2805.1776035 ms, reductions of 16.2644% and 15.3598% against the same-build GPU baseline. Against hybrid, the corresponding differences are -2.1992% and +17.2760%; the stated close result at 128 and hybrid advantage at 512 are supported. The 8K fine4 median is 66.7951455 ms and is now correctly displayed as 66.80 ms. Stop0 is explicitly separated from the original stop1 workload.

Fine4 maximum errors over formal, stop0-formal, and holdout are 0.1283358605470548 px, 0.09951369303348656 degrees, and 0.0027805511549205963 relative scale. Their displayed 0.12834 px / 0.09951 degrees / 0.27806% values are correct. The 52 retained failures are speed or primary-improvement gates, not GT or RSS failures; they are not silently reclassified as successful acceptance.

The independent audits support 507 direct GT evaluations in six datasets, plus 54 in cross-version controls and one initial soak result, totaling 562. All have zero FP/FN, and the required complete ordered GPU matches and proposals are identical. The 92,660 warmup calls and 107 streamed soak repeats are correctly excluded from direct GT counts. Inspection of the runner warmup loop confirms native exact-result comparisons are performed there. The streamed soak repeats retain native equality attestations, not independently archived full vectors.

Five-minute soak evidence supports 108 total algorithm calls, one recreation after 100 streamed calls, constant 247,774,208-byte named GPU allocation, and RSS first/last-ten median growth of 1,212,416 bytes = 1.15625 MiB = 0.7107866679%. This is not a new 30-minute, real-video, or leak qualification.

Profile values agree with the independent auxiliary audit: fine4 fine-search medians 416.14 / 1326.81 ms and peak selection 229.30 / 938.09 ms. GPU-time fractions are approximately 51.5% / 47.6% and 28.4% / 33.7%. All 54 profile calls have timestamps; 11 negative signed residuals are retained, with overall range -0.9773743241 to +5.3215130007 ms. The report correctly explains that upload/readback are host-side measured scopes and wait overlaps GPU work. It does not equate these with DMA/PCIe transfer time or extrapolate M4 measurements to CUDA.

## Verification and source checks

The underlying logs confirm Release 70/70, harness 73/73, Metal validation 7/7, clean frozen-source tests 7/7, and ASan/UBSan 7/7. The normal fine test contains 52 fixtures at each of two cache capacities, totaling 104, across five production modes; the instrumented 4 KiB run has 52. The rebuilt-output record contains five case/method combinations with two calls each, totaling ten. Seven invalid runner inputs are rejected. The soak harness has one positive and six negative controls. LeakSanitizer is explicitly excluded.

All 278 files in `source-sha256.json` matched the working-tree hashes at review time. The available archive replay record verifies 294 source/input fingerprints and byte-identical reconstruction of all eight summaries. Final re-packaging and re-execution of the portable replay script remain the parent workflow's archive-release step; any `FINAL_REPLAY` progress marker is not treated as missing experimental evidence. The planned later catalog mapping edit is explicitly disclosed and must not be represented as part of the original measurement source freeze.

## Consistency and scope

All four documents consistently recommend `full_gpu=true`, `full_gpu_peak_mode=1`, and `full_gpu_fine_mode=4` only as the measured full-GPU research configuration. They retain GUI/general defaults, mode0–3 source and unsuccessful evidence, and the hybrid option for workload-dependent advantages. The report describes complete gray8 GPU algorithm execution with CPU I/O/static planning; it does not mistake the older coarse-only experiment for the full pipeline.

The bounded closure claim concerns stages 37–40 and the tested exact NCC variants. It does not claim a theoretical performance limit, complete RGB resident matching, CUDA validation, multiple-template-library scaling, perspective/occlusion robustness, or annotated real-camera sequence accuracy. Previously used holdout scenes and the two new synthetic seeds are distinguished. Research citations are separated from locally reproduced performance claims; FFT/approximation methods are explicitly not implemented in this round.

## Small review corrections completed

The parent corrected and this reviewer rechecked: 8K fine4 rounding to 66.80 ms; explicit hybrid subject in the Stage 40 experiment-index comparison; seven soak checks described as including six negative controls; and the new 25 harness items described as tests and negative controls rather than all being negative controls. These edits do not alter measurements, gates, or adoption decisions.

Supporting independent records are `independent-evidence-audit.json` and `independent-auxiliary-audit.json` in this validation directory. No further actionable document issue was found.
