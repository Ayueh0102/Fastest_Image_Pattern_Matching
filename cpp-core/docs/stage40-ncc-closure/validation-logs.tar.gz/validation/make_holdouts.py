"""Build Stage-40 frozen holdouts; run only between GPU timing sessions.

The five old cases were withheld from the Stage-38/39 optimization suite but
were exercised in Stage 37. Two new random seeds change pose/noise only; they
remain synthetic, same-template, separated-grid scenes. GT never enters jobs.
"""
import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT/'cpp-core/tools'))
import benchmark_gpu_ncc_closure as bench
import many_object_scenes as scenes
import cv2
import numpy as np

EXISTING = ['heldout12', 'small_fullres', 'boundary_one', 'empty_scene', 'constant_source']
ORIGINAL_MANY = ['many128_pose', 'many512_pose']
PLACEMENT_SEED = 20261019
NOISE_SEED = 20261020


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fixtures-manifest', type=Path, default=ROOT/'build/stage37-full-gpu/formal/manifest.json')
    parser.add_argument('--output', type=Path, default=ROOT/'build/stage40-ncc-closure/holdout-fixtures.json')
    parser.add_argument('--inputs', type=Path, default=ROOT/'build/stage40-ncc-closure/holdout-inputs')
    args = parser.parse_args()
    output, inputs = args.output.resolve(), args.inputs.resolve()
    targets = [output] + [inputs/(f'many{count}_holdout'+suffix) for count in (128, 512) for suffix in ('.png', '.json')]
    if any(path.exists() for path in targets):
        raise ValueError('Refusing to overwrite an existing holdout artifact')
    originals = bench.fixture_cases(args.fixtures_manifest, EXISTING+ORIGINAL_MANY)
    original_by_name = {case['name']: case for case in originals}
    cases = [copy.deepcopy(original_by_name[name]) for name in EXISTING]
    input_before = {case[key]: bench.sha(case[key]) for case in originals for key in ('source', 'template')}
    generator_path = Path(scenes.__file__).resolve()
    source_before = {str(path): bench.sha(path) for path in (Path(__file__).resolve(), generator_path)}
    inputs.mkdir(parents=True, exist_ok=True)
    metadata_hashes = {}
    for count in (128, 512):
        original = original_by_name[f'many{count}_pose']
        name = f'many{count}_holdout'
        template = cv2.imread(original['template'], cv2.IMREAD_GRAYSCALE)
        photographed = cv2.imread(str(scenes.TEMPLATE_SOURCE), cv2.IMREAD_GRAYSCALE)
        if template is None or photographed is None or not np.array_equal(template, photographed):
            raise ValueError('Archived template differs from original photographed pixels')
        columns = 32 if count == 512 else 16
        shape = (4096, columns*256)
        # Python default argument seeds are fixed at function definition time:
        # override both explicitly rather than assigning module constants.
        truth = scenes.make_placements(template.shape, rows=16, columns=columns,
            cell_size=256, seed=PLACEMENT_SEED, jitter=8., upright=False)[:count]
        geometry_validation = scenes.validate_placements(truth, shape, template.shape)
        image = scenes.render_scene(template, truth, shape,
            noise_seed=NOISE_SEED, noise_std=2., background=150.)
        source_path, metadata_path = inputs/(name+'.png'), inputs/(name+'.json')
        if not cv2.imwrite(str(source_path), image):
            raise RuntimeError('Failed to write '+str(source_path))
        case = copy.deepcopy(original)
        case.update(name=name, source=str(source_path), truth=truth,
            metadata=str(metadata_path), object_count=count, scene_shape=list(shape))
        changed_settings = {key for key in original.keys() | case.keys()
            if key not in {'name', 'source', 'truth', 'metadata', 'object_count', 'scene_shape'}
            and original.get(key) != case.get(key)}
        if changed_settings:
            raise ValueError('Holdout search settings changed: '+','.join(sorted(changed_settings)))
        metadata = dict(version=1, name=name, original_case=original['name'],
            generator=str(generator_path), generator_sha256=bench.sha(generator_path),
            invocation_generator=str(Path(__file__).resolve()),
            invocation_generator_sha256=bench.sha(Path(__file__).resolve()),
            renderer='OpenCV warpAffine INTER_LINEAR, constant zero border; original local-ROI renderer',
            numpy_version=np.__version__, opencv_version=cv2.__version__,
            seed=PLACEMENT_SEED, noise_seed=NOISE_SEED, noise_std=2., background=150.,
            rows=16, columns=columns, cell_size=256, center_jitter=8.,
            angle_range=[-180., 180.], scale_range=[.72, 1.28], scale_distribution='log-uniform',
            gain_range=[.85, 1.1], bias_range=[-12., 12.], object_count=count,
            shape=list(shape), template_shape=list(template.shape),
            template_source=str(scenes.TEMPLATE_SOURCE), template_source_sha256=bench.sha(scenes.TEMPLATE_SOURCE),
            template_file=case['template'], template_png_sha256=bench.sha(case['template']),
            source_file=str(source_path), source_png_sha256=bench.sha(source_path),
            source_pixels_sha256=hashlib.sha256(image.tobytes()).hexdigest(),
            validation=geometry_validation, truth=truth,
            limitations=['Same photographed template as development; unseen pose and noise realization only.',
                        'Separated grid placements; no occlusion or touching objects.',
                        'Gray8 synthetic scenes, not RGB or independent real-video data.',
                        'Truth is for evaluation after search and never a worker input.'])
        bench.save(metadata_path, metadata)
        metadata_hashes[str(metadata_path)] = bench.sha(metadata_path)
        cases.append(case)
        del image
    input_after = {path: bench.sha(path) for path in input_before}
    source_after = {path: bench.sha(path) for path in source_before}
    if input_after != input_before or source_after != source_before:
        raise ValueError('Generator or original input changed while creating holdouts')
    manifest = dict(version=1, complete=True, unchanged=True,
        created_utc=datetime.now(timezone.utc).isoformat(), cases=cases,
        input_sha256={case[key]: bench.sha(case[key]) for case in cases for key in ('source', 'template')},
        source_sha256=source_before, metadata_sha256=metadata_hashes,
        original_fixtures_manifest=str(args.fixtures_manifest.resolve()),
        original_fixtures_manifest_sha256=bench.sha(args.fixtures_manifest),
        seeds=dict(placements=PLACEMENT_SEED, noise=NOISE_SEED),
        scope='Five previously tested Stage-37 cases held out from Stage-38/39 optimization, plus two previously unevaluated pose/noise-seed realizations of the same many-object scene family.',
        settings='Original matching settings retained; new scenes use original count, geometry, template pixels and rendering distributions.',
        no_seed_retry=True)
    bench.save(output, manifest)
    # Verify the public fixture reader accepts all seven paths and hashes.
    bench.fixture_cases(output, [case['name'] for case in cases])
    print(json.dumps(dict(output=str(output), cases=[case['name'] for case in cases],
        truth_counts=[len(case['truth']) for case in cases], seeds=manifest['seeds']), indent=2))


if __name__ == '__main__':
    main()
