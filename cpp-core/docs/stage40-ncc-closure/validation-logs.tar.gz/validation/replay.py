from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys,tarfile
root=Path.cwd();out=root/'cpp-core/docs/stage40-ncc-closure';review=root/'build/stage40-review';source=review/'source';raw=review/'raw';val=root/'build/stage40-ncc-closure/validation'
val.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for archive,destination in [('source-snapshot.tar.gz',source),('fixtures.tar.gz',source),('raw-results.tar.gz',raw),('validation-logs.tar.gz',review)]:
 destination.mkdir(parents=True,exist_ok=True)
 with tarfile.open(out/archive) as t:t.extractall(destination,filter='data')
count=0
for name in ('source-sha256.json','input-sha256.json'):
 for path,digest in json.loads((out/name).read_text()).items():
  assert sha(source/path)==digest,path;count+=1
checks=[]
for name,formal in [('pilot',None),('formal',None),('stop0-formal',None),('holdout',None),('profile','formal'),('stop0-profile','stop0-formal')]:
 destination=review/(name+'-replay.json')
 if destination.exists():
  assert destination.read_bytes()==(out/(name+'-summary.json')).read_bytes(), 'Existing replay output was modified: '+name
  destination.unlink()
 command=[sys.executable,str(source/'cpp-core/tools/benchmark_gpu_ncc_closure.py'),'--summarize',str(raw/name/'manifest.json'),'--output',str(destination)]
 if formal:command+=['--unprofiled-manifest',str(raw/formal/'manifest.json')]
 subprocess.run(command,check=True,capture_output=True,text=True)
 assert destination.read_bytes()==(out/(name+'-summary.json')).read_bytes(),name
 checks.append({'dataset':name,'byte_identical':True,'sha256':sha(destination)})
# Cross-version comparison uses the separately preserved Stage39 source helpers.
old=review/'stage39-source';old.mkdir(exist_ok=True)
with tarfile.open(root/'cpp-core/docs/stage39-fine-tiles/source-snapshot.tar.gz') as t:t.extractall(old,filter='data')
destination=review/'cross-version-replay.json'
if destination.exists():destination.unlink()
subprocess.run([sys.executable,str(review/'validation/check_previous_binary.py'),'--frozen-source',str(old),'--summarize',str(review/'validation/cross-version/manifest.json'),'--output',str(destination)],check=True,capture_output=True,text=True)
expected=json.loads((review/'validation/cross-version/manifest.json').read_text())['summary']
assert json.loads(destination.read_text())==expected
assert destination.read_bytes()==(out/'cross-version-summary.json').read_bytes()
checks.append({'dataset':'cross-version','byte_identical':True,'sha256':sha(destination)})
# Import the frozen current harness before the archived soak auditor.
sys.path.insert(0,str(source/'cpp-core/tools'))
import benchmark_gpu_ncc_closure as bench
spec=importlib.util.spec_from_file_location('soak_replay',review/'validation/run_soak.py');soak=importlib.util.module_from_spec(spec);spec.loader.exec_module(soak)
m=json.loads((raw/'soak/manifest.json').read_text());assert m['complete'] and m['unchanged']
for item in m['artifacts'].values():assert sha(raw/'soak'/item['path'])==item['sha256']
assert sha(review/'validation/run_soak.py')==m['validation_script_sha256']
worker=json.loads((raw/'soak/stdout.json').read_text());rows=[json.loads(line) for line in (raw/'soak/rows.jsonl').read_text().splitlines()]
formal=json.loads((raw/'formal/manifest.json').read_text());case=next(c for c in formal['cases'] if c['name']=='many512_pose')
e=next(e for e in formal['executions'] if e['case']=='many512_pose' and e['method']=='full_gpu_tiled' and e['block']==0)
baseline=json.loads((raw/'formal'/e['result']).read_text())['first']
s=soak.audit_result(worker,rows,case,baseline,m['repeats']);before={k:m[k] for k in ('source_sha256','binary_sha256','input_sha256')}
s['unchanged_fingerprints']=before==m['after_sha256'];s['all_gates_pass']=s['all_gates_pass'] and s['unchanged_fingerprints']
if not s['unchanged_fingerprints']:s['failed_gates'].append('unchanged_fingerprints')
destination=review/'soak-replay.json';bench.save(destination,s)
assert destination.read_bytes()==(out/'soak-summary.json').read_bytes()
checks.append({'dataset':'soak','byte_identical':True,'sha256':sha(destination)})
audit={'source_and_input_files_verified':count,'all_hashes_match':True,'replay':checks,'scope':'Extracted archives and frozen tools; six benchmark, cross-version and soak summaries replayed. No GPU measurements rerun by this script.'}
(val/'archive-replay.json').write_text(json.dumps(audit,indent=2)+'\n');print(json.dumps(audit))
