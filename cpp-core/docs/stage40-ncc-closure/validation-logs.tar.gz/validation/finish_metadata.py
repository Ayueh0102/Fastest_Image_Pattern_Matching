from pathlib import Path
import json, shutil

root = Path.cwd()
out = root / 'cpp-core/docs/stage40-ncc-closure'
work = root / 'build/stage40-ncc-closure'
val = work / 'validation'

def read(p):
    return json.loads(p.read_text())

def save(p, value):
    p.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')

names = ['pilot', 'formal', 'stop0-formal', 'holdout', 'profile', 'stop0-profile']
summaries = {name: read(out / (name + '-summary.json')) for name in names}
save(out / 'cross-version-summary.json', read(val / 'cross-version/manifest.json')['summary'])
shutil.copy2(work / 'soak/summary.json', out / 'soak-summary.json')
failures = [{**row, 'dataset': name} for name, summary in summaries.items()
            for row in summary['failed_gates']]
assert len(failures) == 52
assert all(s['all_accuracy_pass'] and s['all_candidates_exact_baseline'] for s in summaries.values())
assert summaries['formal']['candidates']['full_gpu_simd']['formal_primary_target_pass'] is True
save(out / 'decision-and-failures.json', {
    'stage': 40, 'date': '2026-10-19', 'phase_complete': True,
    'scope': 'Bounded exact gray8 Metal resident NCC phase; not all future research',
    'recommended_explicit_gpu_settings': {'full_gpu': True, 'full_gpu_peak_mode': 1, 'full_gpu_fine_mode': 4},
    'universal_default_changed': False,
    'adoption': 'SIMD32 mode4 passes main >=10% reduction and all GPU-baseline block time/RSS/parity gates; keep hybrid for case-dependent latency.',
    'mode_decisions': {
        '0': 'Retain original complete ROI/direct uint64 reference',
        '1': 'Retain oversized row cache, not sufficient for main stop1 cases',
        '2': 'Retain safe bounded uint32 and fallback; fails 10% primary target alone',
        '3': 'Retain complete source and negative pilot/profile; screened out for slower primary cases',
        '4': 'Preferred explicit GPU research option on measured SIMD32 device; includes mode2',
    },
    'no_additional_combination': 'No complementary winner: mode4 already contains bounded accumulation and row-cache fallback; mode3 lost.',
    'comparison_scope': '128 approximately matches hybrid; 512 still17.3% slower than hybrid. No universal all-GPU win.',
    'accuracy': {'direct_gt_calls': 562, 'all_zero_fp_fn': True,
                 'six_dataset_direct_gt': 507, 'cross_version_direct_gt': 54, 'soak_initial_direct_gt': 1,
                 'separate_native_soak_exact_attestations': 107},
    'named_gpu_allocation_change_bytes': 0, 'static_threadgroup_bytes': 28560,
    'all_failed_gates': failures,
    'failure_counts': {name: len(summary['failed_gates']) for name, summary in summaries.items()},
    'failure_interpretation': 'Speed tolerance or primary10% target failures; no accuracy or RSS failures. All retained, including hybrid comparisons.',
    'limits': ['One Apple M4 Pro', 'Gray8 full resident path; not RGB or CUDA',
               'Synthetic pose GT, not annotated real image sequence', 'No claim of algorithmic limit',
               'No physical DMA, occupancy or cache-hit counters', 'Five-minute new-variant regression, not new30-minute qualification'],
})
assert 'All validation builds and tests passed' in (val / 'build-validation.log').read_text()
assert read(val / 'rebuilt/parity.json')['total_calls'] == 10
save(out / 'validation.json', {
    'stage': 40, 'date': '2026-10-19',
    'build_and_tests': {
        'release': {'passed': 70, 'failed': 0, 'log': 'validation/release-tests-details.log'},
        'python_harness': {'passed': 73, 'failed': 0, 'new_stage40_tests': 25, 'log': 'validation/harness-tests.log'},
        'invalid_runner_json': {'passed': 7, 'log': 'validation/runner-inputs/results.json'},
        'soak_harness_checks': read(val / 'soak-harness-check.json'),
        'metal_api_shader': {'passed': 7, 'failed': 0, 'cache_bytes': 4096, 'fine_fixtures': 52, 'production_modes': 5,
                             'log': 'validation/metal-validation-details.log'},
        'fine_differential_normal': {'fixtures': 104, 'production_modes': 5, 'cache_capacities': [16384, 4096],
                                     'all_49_scores_exact': True, 'reference': 'frozen legacy and independent scalar'},
        'clean_frozen_release': {'passed': 7, 'failed': 0, 'log': 'validation/clean-release-tests-details.log'},
        'clean_rebuild_output_parity': read(val / 'rebuilt/parity.json'),
        'asan_ubsan': {'passed': 7, 'failed': 0, 'leak_sanitizer_enabled': False, 'log': 'validation/asan-tests-details.log'},
    },
    'datasets': {name: summary['counts'] for name, summary in summaries.items()},
    'independent_evidence_audit': read(val / 'independent-evidence-audit.json'),
    'independent_auxiliary_audit': read(val / 'independent-auxiliary-audit.json'),
    'soak': read(out / 'soak-summary.json'),
    'archive_replay': None,
    'source_freeze': {'source_files': 278, 'source_manifest': 'source-sha256.json',
                      'post_freeze_edit': 'After archive/source verification only build_log_catalog.py stage40 directory mapping and documentation/catalog outputs are updated. Benchmark, algorithm, tests and binary sources remain frozen.',
                      'reproduce_from': 'source-snapshot.tar.gz, not a claim that all later HEAD files are byte-identical'},
    'limitations': ['No new manual GUI session', 'No Windows/CUDA/other Metal device run',
                    'Not a LeakSanitizer result', 'Not a new30-minute or real-video qualification'],
})

def change(path, old, new):
    p = root / path
    text = p.read_text()
    assert old in text, (path, old)
    p.write_text(text.replace(old, new, 1))

for path in ['cpp-core/docs/CURRENT_BEST_zh-TW.md', 'cpp-core/docs/PROJECT_STATUS_zh-TW.md', 'cpp-core/docs/EXPERIMENT_REVIEW_zh-TW.md']:
    change(path, '更新：2026-10-18', '更新：2026-10-19')

change('cpp-core/docs/CURRENT_BEST_zh-TW.md',
       '| 完整灰階搜尋留在GPU | 研究設定選`full_gpu=true, full_gpu_peak_mode=1`；追求大量物件低延遲仍用混合 | [第38輪分塊選峰](GPU_TILED_PEAKS_zh-TW.md)：128／512較原GPU耗時少79.8%／87.3%，仍較混合慢15.5%／38.7%；不含RGB與稀疏路徑 |',
       '| 完整灰階搜尋留在GPU | 研究設定選`full_gpu=true, full_gpu_peak_mode=1, full_gpu_fine_mode=4` | [第40輪](GPU_NCC_CLOSURE_zh-TW.md)：128／512對本輪GPU基線再少16.3%／15.4%；128接近混合，512仍比混合多17.3%時間，8K少物件GPU有明顯優勢；不含RGB與稀疏路徑 |')
change('cpp-core/docs/CURRENT_BEST_zh-TW.md', '## 本輪的採用判斷\n',
       '## 本輪的採用判斷\n\n第40輪[精確NCC與大階段結案](GPU_NCC_CLOSURE_zh-TW.md)完成有界uint32、來源統計滑動重用與SIMD32比較。GPU研究推薦peak1／fine4，完整時間128為806.46ms、512為2805.18ms；命名GPU配置不增加。統計重用mode3較慢，保留源碼與失敗。562次直接GT零FP／FN、GPU有序結果一致，Release70／70、五分鐘108次呼叫及來源重建／重播均通過。這一有界大階段結束，不代表算法已達極限。\n')
change('cpp-core/docs/CURRENT_BEST_zh-TW.md', '維持第38輪建議；`full_gpu_fine_mode=1`', '該輪維持第38輪建議，現已由第40輪更新；`full_gpu_fine_mode=1`')
change('cpp-core/docs/CURRENT_BEST_zh-TW.md',
       '- 整條Metal灰階常駐 `full_gpu=true`：保留完整源碼與研究選項，依第37輪場景評估；大量候選仍不適合直接替換混合預設。',
       '- 整條Metal灰階常駐不作通用預設：第40輪peak1／fine4已可與混合競爭，但512與部分小圖仍較慢；依相同工作量比較選用。\n- 完整GPU來源統計滑動重用fine3：本輪初測與診斷較慢；保留源碼，不採用為推薦組合。')
change('cpp-core/docs/PROJECT_STATUS_zh-TW.md', '第37輪補齊',
       '第40輪完成[精確NCC優化與本大階段結案](GPU_NCC_CLOSURE_zh-TW.md)：有界累加、統計重用、SIMD32、正式／stop0／七組保留場景、跨版本控制與完整封存已結束。peak1／fine4使原128／512完整GPU時間再少16.3%／15.4%，命名GPU配置不增、結果精確一致；128接近混合，512仍以混合較快。562次直接GT、70項Release、Metal／ASan／UBSan、乾淨重建、五分鐘連續檢查與八份摘要重播通過。失敗變體與全部速度失敗均保留。\n\n第37輪補齊')
change('cpp-core/docs/PROJECT_STATUS_zh-TW.md', '下一輪改看實際熱路徑的有界uint32 NCC累加及重疊統計重用。', '後續有界uint32、重疊統計及SIMD工作分配已由第40輪完成。')
change('cpp-core/docs/PROJECT_STATUS_zh-TW.md', '## 仍未解決，下一輪應按問題選題', '## 本階段以外的研究缺口')
change('cpp-core/docs/PROJECT_STATUS_zh-TW.md',
       '| 更多GPU並行 | 第38輪選峰已改善；第39輪分列快取只幫助實際過大ROI，原128／512完全使用既有快取 | 測試有界uint32局部累加與uint64合併，再測重疊來源統計；不能將工作量占比當成每層時間或硬體利用率 |',
       '| 更多GPU並行 | 第40輪三個精確NCC變體已完成；512新方案細搜尋約占GPU47.6%、粗選峰33.7% | 後續可另研究選峰／細搜尋分工或允許近似的架構；沒有證據已達極限，不能將階段時間當硬體利用率 |')
change('cpp-core/docs/PROJECT_STATUS_zh-TW.md', '最新512設定30分鐘745次通過', '第34輪512混合設定30分鐘745次通過；第40輪新GPU變體五分鐘108次通過')
change('cpp-core/docs/EXPERIMENT_REVIEW_zh-TW.md', '第1–36輪列出', '第1–40輪列出')
change('cpp-core/docs/EXPERIMENT_REVIEW_zh-TW.md', '第5–14、19–25、28–34、36輪', '第5–14、19–25、28–34、36–40輪')
change('cpp-core/docs/EXPERIMENT_REVIEW_zh-TW.md',
       '灰階尺度流程已原生化，仍不是全 C++ Fourier 或全 GPU 流程',
       '灰階尺度流程已原生化，第37–40輪另有完整Metal灰階選項；Fourier仍非全C++，RGB驗色不在完整GPU範圍內')
p = root / 'cpp-core/docs/EXPERIMENT_REVIEW_zh-TW.md'
p.write_text(p.read_text() + '''
### 40. 精確NCC內迴圈、SIMD工作分配與大階段結案（2026-10-19）

- 問題／實作：第39輪已確認主要ROI都在快取，本輪直接比較有界uint32累加mode2、來源S/Q滑動重用mode3、保留原四條帶順序的SIMD32 mode4。三agent協作，借鑑2025 GPU cross-correlation論文與作者程式，自行實作完整Metal原碼。
- 正式結果：128GPU基線963.10→806.46ms（−16.3%），5123314.24→2805.18ms（−15.4%）；RSS93.41→93.47／165.22→164.98MiB，命名GPU配置與28,560B threadgroup容量完全不變。混合824.59／2391.95ms；128接近，512仍以混合較快。
- 邊界／失敗：stop0比GPU基線少28.1%／27.4%；七組保留場景全GT與GPU有序結果一致，新種子128／512仍相同趨勢。mode3初測較慢而不採用，mode2單獨未達10%主要目標；52筆速度／改善目標失敗原樣保留，沒有精度／RSS失敗。
- 診斷：新512細搜尋1326.81ms、粗選峰938.09ms；主機shared memcpy約0.52ms、最後結果取回約0.022ms，這不是硬體傳輸計時。仍一次提交／最後一次等待，中途零讀回、零CPU算法步驟。
- 驗證：六組177程序／507次直接GT＋跨版本54＋soak首次1＝562次直接GT；另107次原生一致性確認。Release70／70、工具73／73、Metal及ASan／UBSan各7／7、凍結來源重建10次結果一致、八份摘要換目錄重播。五分鐘108次、一次Session重建，RSS首末中位數增加1.16MiB。LeakSanitizer未啟用。
- 決定：本有界精確Metal大階段完成，GPU研究推薦peak1／fine4，不改通用／GUI預設。不是RGB完整常駐、CUDA或實拍序列驗收，也不宣稱理論極限。
- 證據：[完整報告與文獻](GPU_NCC_CLOSURE_zh-TW.md)、[正式摘要](stage40-ncc-closure/formal-summary.json)、[採用與失敗](stage40-ncc-closure/decision-and-failures.json)、[驗證](stage40-ncc-closure/validation.json)、[完整源碼與Log封存](stage40-ncc-closure/archive.json)。
''')
change('docs/PROJECT_GUIDE_zh-TW.md', '通用建議仍維持第38輪。', '該輪建議維持第38輪，現行建議已由第40輪更新。\n\n第40輪[精確NCC與大階段結案](../cpp-core/docs/GPU_NCC_CLOSURE_zh-TW.md)完成有界整數累加、滑動統計重用與SIMD32工作分配實驗。完整GPU研究選`full_gpu_peak_mode=1, full_gpu_fine_mode=4`，原128／512耗時再少16.3%／15.4%，完整輸出一致且GPU配置不增。128接近混合方案，512仍以混合較快；來源統計重用反而變慢也完整保留。正式、保留場景、跨版本、短期連續檢查、來源重建與摘要重播皆已完成。本大階段可供外部審查，未宣稱所有實拍或GPU硬體適用。')
change('cpp-core/docs/LOG_CATALOG_zh-TW.md',
       '| 39 | 細搜尋分列快取、實際路徑計數、主假說失敗與stop0補充 | [stage39-fine-tiles](stage39-fine-tiles/)、[報告](GPU_FINE_TILES_zh-TW.md) |',
       '| 39 | 細搜尋分列快取、實際路徑計數、主假說失敗與stop0補充 | [stage39-fine-tiles](stage39-fine-tiles/)、[報告](GPU_FINE_TILES_zh-TW.md) |\n| 40 | 精確u32／SIMD NCC、負面統計重用、七組保留場景、跨版本與大階段結案 | [stage40-ncc-closure](stage40-ncc-closure/)、[報告](GPU_NCC_CLOSURE_zh-TW.md) |')
print('Closure metadata and overview documents written; archive replay still pending.')
