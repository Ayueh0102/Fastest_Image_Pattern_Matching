import json,subprocess
from pathlib import Path
root=Path.cwd();output=root/'build/stage40-ncc-closure/validation/runner-inputs';output.mkdir(exist_ok=True)
job=json.loads((root/'build/stage40-ncc-closure/formal/jobs/controlled6-full_gpu_simd-b0.json').read_text())
job.update(repeats=1,warmup_seconds=0)
results=[]
for label,value in [('bool',True),('fraction',.5),('string','1'),('negative',-1),('range',5),('null',None)]:
    work={**job,'full_gpu_fine_mode':value};p=output/(label+'.json');p.write_text(json.dumps(work,indent=2)+'\n')
    r=subprocess.run([str(root/'build/fourier-gpu/experiments/fpm_native_pipeline_runner'),str(p)],capture_output=True,text=True,timeout=60)
    (output/(label+'.stdout.txt')).write_text(r.stdout);(output/(label+'.stderr.txt')).write_text(r.stderr)
    assert r.returncode!=0 and 'full_gpu_fine_mode must be integer 0..4' in r.stderr,(label,r.returncode,r.stderr)
    results.append({'case':label,'rejected':True,'stderr':r.stderr})
work={**job,'full_gpu':False,'full_gpu_peak_mode':0,'full_gpu_fine_mode':1};p=output/'hybrid.json';p.write_text(json.dumps(work,indent=2)+'\n')
r=subprocess.run([str(root/'build/fourier-gpu/experiments/fpm_native_pipeline_runner'),str(p)],capture_output=True,text=True,timeout=60)
(output/'hybrid.stdout.txt').write_text(r.stdout);(output/'hybrid.stderr.txt').write_text(r.stderr)
assert r.returncode!=0 and 'requires full_gpu=true' in r.stderr,r.stderr
results.append({'case':'hybrid','rejected':True,'stderr':r.stderr})
(output/'results.json').write_text(json.dumps(results,indent=2)+'\n');print('Rejected',len(results),'invalid fine-mode jobs')
