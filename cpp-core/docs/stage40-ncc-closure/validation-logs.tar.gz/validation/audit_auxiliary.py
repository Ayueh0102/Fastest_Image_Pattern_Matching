#!/usr/bin/env python3
"""Read-only independent cross-version/soak audit and raw profile interpretation."""
from collections import defaultdict
import json
from pathlib import Path
import statistics
from audit_evidence import accuracy, canonical, digest, gpu_call, load, require

REPO = Path(__file__).resolve().parents[3]
ROOT = REPO/'build/stage40-ncc-closure'


def verify_files(mapping, root=REPO):
    for name, sha in mapping.items():
        path = Path(name) if Path(name).is_absolute() else root/name
        require(digest(path) == sha, 'Changed fingerprint: '+str(path))


def cross_version():
    root=ROOT/'validation/cross-version'; manifest=load(root/'manifest.json')
    require(manifest['complete'] is True and manifest['unchanged'] is True, 'Cross-version incomplete')
    require(manifest['before_sha256'] == manifest['after_sha256'], 'Cross-version fingerprint drift')
    f=manifest['before_sha256']
    verify_files(f['current_source_sha256'])
    verify_files(f['frozen_source_sha256'],Path(manifest['frozen_source']))
    verify_files(f['binary_sha256']); verify_files(f['input_sha256'])
    require(digest(ROOT/'validation/check_previous_binary.py') == f['script_sha256'], 'Cross-version script changed')
    require(digest(manifest['fixtures_manifest']) == f['fixture_manifest_sha256'], 'Cross-version fixture manifest changed')
    methods=manifest['methods']; cases={c['name']:c for c in manifest['cases']}
    expected={(c,m,b) for c in cases for m in methods for b in range(manifest['blocks'])}
    workers={}
    for e in manifest['executions']:
        key=e['case'],e['method'],e['block'];require(key in expected and key not in workers,'Cross-version worker matrix mismatch')
        require(e['returncode']==0,'Cross-version worker failed')
        for kind in ('job','result','stdout','stderr'):
            require(digest(root/e[kind])==e[kind+'_sha256'],'Cross-version raw artifact changed')
        job=load(root/e['job']); require('truth' not in job,'Truth sent to worker')
        require(job['full_gpu_fine_mode']==(4 if e['method']=='current_fine4' else 0),'Cross-version fine mode differs')
        worker=load(root/e['result']);require(len(worker['runs'])==manifest['repeats'],'Cross-version repeat count differs')
        require(load(root/e['stdout'])==worker,'Captured stdout/result differs')
        workers[key]=worker
    require(set(workers)==expected,'Cross-version missing jobs')
    result=[]; gt_calls=0; measured_calls=0; warmups=0
    for name,case in cases.items():
        baseline=workers[(name,'stage39_fine0',0)]['first']; row={}
        for method in methods:
            ws=[workers[(name,method,b)] for b in range(manifest['blocks'])]
            calls=[c for w in ws for c in [w['first'],*w['runs']]]; measured=[c for w in ws for c in w['runs']]
            gt_calls+=len(calls);measured_calls+=len(measured);warmups+=sum(len(w['warmups_ms']) for w in ws)
            gt=[]
            for call in calls:
                require(call['matches']==baseline['matches'] and call['proposals']==baseline['proposals'],'Cross-version exact ordered mismatch')
                gt.append(accuracy(call['matches'],case['truth']))
                require(gt[-1]['fp']==0 and gt[-1]['fn']==0,'Cross-version GT failed')
                g=call['full_gpu'];require(g['enabled'] and g['command_buffers']==g['cpu_waits']==1 and g['cpu_algorithm_steps']==g['intermediate_readbacks']==0,'Cross-version residency failed')
                require(g['gpu_bytes']==baseline['full_gpu']['gpu_bytes'] and g['fine_threadgroup_bytes']==baseline['full_gpu']['fine_threadgroup_bytes'],'Cross-version memory contract differs')
            row[method]=dict(median_ms=statistics.median(c['total_ms'] for c in measured),
                gt_calls=len(calls),all_gt_pass=True,ordered_matches_and_proposals_exact=True,
                peak_rss_bytes=max(w['final_memory']['peak_rss_bytes'] for w in ws),
                named_metal_bytes=baseline['full_gpu']['gpu_bytes'],threadgroup_bytes=baseline['full_gpu']['fine_threadgroup_bytes'],
                block_medians=[statistics.median(c['total_ms'] for c in w['runs']) for w in ws])
        for method in ('current_fine0','current_fine4'):
            row[method]['delta_percent_vs_frozen39']=100*(row[method]['median_ms']/row['stage39_fine0']['median_ms']-1)
            row[method]['paired_deltas_percent_vs_frozen39']=[100*(new/old-1) for old,new in zip(row['stage39_fine0']['block_medians'],row[method]['block_medians'])]
        result.append(dict(name=name,methods=row))
    require(manifest['summary']['evaluated_calls']==gt_calls and manifest['summary']['measured_calls']==measured_calls,'Cross-version summary counts differ')
    return dict(complete=True,manifest_sha256=digest(root/'manifest.json'),fresh_processes=len(workers),
                first_calls=len(workers),measured_calls=measured_calls,direct_gt_calls=gt_calls,warmup_timings=warmups,cases=result)


def soak():
    root=ROOT/'soak'; manifest=load(root/'manifest.json');summary=load(root/'summary.json');worker=load(root/'stdout.json')
    require(manifest['complete'] is True and manifest['unchanged'] is True,'Soak incomplete')
    before={k:manifest[k] for k in ('source_sha256','binary_sha256','input_sha256')}
    require(before==manifest['after_sha256'],'Soak fingerprints drifted')
    for files in before.values():verify_files(files)
    for name,a in manifest['artifacts'].items():
        require(digest(root/a['path'])==a['sha256'] and (root/a['path']).stat().st_size==a['bytes'],'Soak artifact differs: '+name)
    require(summary==manifest['summary'],'Soak summary files differ')
    for field in ('job','formal_manifest','formal_baseline_result','validation_script'):
        path=Path(manifest[field]);path=path if path.is_absolute() else root/path
        require(digest(path)==manifest[field+'_sha256'],'Soak referenced artifact differs: '+field)
    baseline=load(manifest['formal_baseline_result'])['first'];first=worker['first']
    require(first['matches']==baseline['matches'] and first['proposals']==baseline['proposals'],'Soak initial ordered output differs from formal GPU baseline')
    truth=accuracy(first['matches'],manifest['case']['truth']);require(truth['fp']==truth['fn']==0,'Soak initial independent GT failed')
    rows=[json.loads(s) for s in (root/'rows.jsonl').read_text().splitlines()]
    require(worker['calls']==len(rows)==summary['calls'] and len(rows)>=101,'Soak call counts differ')
    require(worker['duration_ms']==summary['elapsed_ms'] and worker['duration_ms']>=300000,'Soak duration insufficient')
    require(worker['exact'] is True and worker['drained'] is True,'Soak not exact/drained')
    require(worker['contexts_recreated']==summary['contexts_recreated']==(len(rows)-1)//100,'Soak context counts differ')
    reference_allocation=gpu_call(first,'full_gpu_simd',False)['allocation'];last_elapsed=-1
    rss=[];peaks=[]
    for i,row in enumerate(rows):
        require(row['call']==i and row['context_index']==i//100,'Soak stream call/context sequence differs')
        require(row['exact'] is True,'Soak native ordered-output attestation false')
        require(row['elapsed_ms']>last_elapsed,'Soak time not increasing');last_elapsed=row['elapsed_ms']
        require(bool(row['recreate_ms'])==bool(i and i%100==0),'Soak recreate timing schedule differs')
        g=gpu_call(row,'full_gpu_simd',False)
        require(not g['fallback'] and g['allocation']==reference_allocation,'Soak mode/memory contract differs')
        rss.append(row['memory']['current_rss_bytes']);peaks.append(row['memory']['peak_rss_bytes'])
        require(0<rss[-1]<=peaks[-1],'Soak RSS invalid')
    early,late=statistics.median(rss[:10]),statistics.median(rss[-10:])
    require(early==summary['rss']['first10_median_bytes'] and late==summary['rss']['last10_median_bytes'],'Soak RSS medians differ')
    peak=max(peaks+[worker['before']['peak_rss_bytes'],worker['after']['peak_rss_bytes'],first['memory']['peak_rss_bytes']])
    require(peak==summary['rss']['peak_bytes'],'Soak peak RSS differs')
    require(late<=early+max(8*1024**2,.1*early),'Soak RSS drift exceeds bound')
    return dict(complete=True,manifest_sha256=digest(root/'manifest.json'),elapsed_ms=worker['duration_ms'],
        direct_gt_calls=1,native_attested_repeat_calls=len(rows),total_algorithm_calls=len(rows)+1,
        recreated_contexts=worker['contexts_recreated'],total_contexts=worker['contexts_recreated']+1,
        first_ground_truth=truth,rss_first10_median_bytes=early,rss_last10_median_bytes=late,
        rss_drift_bytes=late-early,rss_drift_percent=100*(late/early-1),peak_process_rss_bytes=peak,
        named_metal_bytes=reference_allocation[0],static_threadgroup_bytes=reference_allocation[2],
        unchanged_allocation=True,exact_attestation=True,drained=True,
        limitation='Only the first full vector has independent GT/parity replay; 107 later calls preserve native exact attestations, not independently archived full vectors. Five minutes, fixed scene, one device: no long-term or real-video claim.')


def profiles():
    result=[]
    for dataset in ('profile','stop0-profile'):
        root=ROOT/dataset;manifest=load(root/'manifest.json');records=defaultdict(list)
        for e in manifest['executions']:
            records[(e['case'],e['method'])].extend(load(root/e['result'])['runs'])
        for (case,method),calls in records.items():
            timing={key:statistics.median(c['full_gpu'][key] for c in calls)
                    for key in ('device_ms','wait_ms','encode_ms','upload_ms','readback_ms','upload_bytes','readback_bytes')}
            stages={s['name']:statistics.median(next(x['gpu_ms'] for x in c['full_gpu']['stages'] if x['name']==s['name']) for c in calls)
                    for s in calls[0]['full_gpu']['stages']}
            result.append(dict(dataset=dataset,case=case,method=method,measured_calls=len(calls),
                median_host_metrics=timing,median_stages_ms=stages,
                fine_share_percent=100*stages['fine_search']/timing['device_ms'],
                peaks_share_percent=100*stages['coarse_peaks']/timing['device_ms']))
    return dict(measured_rows=result,interpretation=[
        'Mode4 leaves fine_search the largest stage for large scenes; coarse_peaks is next, not eliminated.',
        'Mode3 source-statistics reuse is slower on primary scenes: reduced arithmetic alone does not guarantee faster GPU scheduling/access.',
        'upload_ms measures host memcpy into shared buffers; readback_ms measures post-wait status/result collection. Neither is a direct PCIe/DMA measurement.',
        'wait_ms overlaps the same device execution interval; it is not an additional transfer cost to add to device_ms.',
        'GPU private/shared copies and output work are already within command/stage intervals. These measurements do not establish CUDA transfer cost.',
        'Profile runs are diagnostic; formal unprofiled runs decide speed gates.' ])


if __name__=='__main__':
    result=dict(independent=True,gpu_launched=False,harness_imported=False,
                cross_version=cross_version(),soak=soak(),profiles=profiles())
    result['complete']=True
    output=ROOT/'validation/independent-auxiliary-audit.json'
    output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(canonical(dict(complete=True,cross_version_calls=result['cross_version']['direct_gt_calls'],
        soak_direct_gt=result['soak']['direct_gt_calls'],soak_native_attested=result['soak']['native_attested_repeat_calls'],output=str(output))))
