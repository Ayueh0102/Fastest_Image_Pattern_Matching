from pathlib import Path,PurePosixPath
import hashlib,json,tarfile,shutil,gzip
root=Path.cwd();work=root/'build/stage40-ncc-closure';out=root/'cpp-core/docs/stage40-ncc-closure'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def pack(path,items):
 def stable(info):
  info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;info.mode=0o644
  return info
 with path.open('wb') as f, gzip.GzipFile(filename='',fileobj=f,mode='wb',compresslevel=9,mtime=0) as gz, tarfile.open(fileobj=gz,mode='w') as t:
  for src,name in items:t.add(src,arcname=name,recursive=False,filter=stable)
# Source archive is already frozen before pilot. Verify every archived source.
hashes=json.loads((out/'source-sha256.json').read_text())
for p,h in hashes.items():assert sha(root/p)==h,p
names=['pilot','formal','stop0-formal','holdout','profile','stop0-profile']
inputs={}
for name in names:
 m=json.loads((work/name/'manifest.json').read_text());assert m['complete'] and m['unchanged']
 for p,h in m['input_sha256'].items():
  assert sha(p)==h,p
  rel=str(Path(p).relative_to(root));assert rel not in inputs or inputs[rel]==h;inputs[rel]=h
save(out/'input-sha256.json',dict(sorted(inputs.items())))
pack(out/'fixtures.tar.gz',[(root/p,p) for p in sorted(inputs)])
for src,name in [(work/'holdout-fixtures.json','holdout-fixtures.json'),(root/'build/stage39-fine-tiles/stop0-fixtures.json','stop0-fixtures.json')]:shutil.copy2(src,out/name)
raw=[]
for name in [*names,'soak']:
 raw += [(p,str(p.relative_to(work))) for p in sorted((work/name).rglob('*')) if p.is_file()]
raw += [(work/'holdout-fixtures.json','holdout-fixtures.json'),(root/'build/stage39-fine-tiles/stop0-fixtures.json','stop0-fixtures.json')]
raw += [(p,str(p.relative_to(work))) for p in sorted((work/'holdout-inputs').glob('*.json'))]
pack(out/'raw-results.tar.gz',raw)
validation=[(p,str(p.relative_to(work))) for p in sorted((work/'validation').rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc' and p.name not in {'archive-build.log'}]
pack(out/'validation-logs.tar.gz',validation)
artifacts=[]
for p in sorted(out.iterdir()):
 if not p.is_file() or p.name=='archive.json':continue
 row={'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)}
 if p.name.endswith('.tar.gz'):
  count=0;size=0
  with tarfile.open(p,'r:gz') as t:
   for m in t:
    name=PurePosixPath(m.name);assert not name.is_absolute() and '..' not in name.parts and m.isfile(),(p,m.name)
    f=t.extractfile(m);data=f.read();assert len(data)==m.size
    count+=1;size+=m.size
  row.update(regular_files=count,uncompressed_bytes=size,all_members_read_and_safe_paths=True)
 artifacts.append(row)
save(out/'archive.json',{'stage':40,'date':'2026-10-19','path_base':'cpp-core/docs/stage40-ncc-closure','all_archives_fully_read':True,'source_files':len(hashes),'unique_input_files':len(inputs),'artifacts':artifacts})
print(json.dumps({'sources':len(hashes),'inputs':len(inputs),'raw_files':len(raw),'validation_files':len(validation),'artifacts':len(artifacts)}))
