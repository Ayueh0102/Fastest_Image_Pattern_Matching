from pathlib import Path
import subprocess,sys,json
root=Path.cwd();work=root/'build/stage40-ncc-closure';py=root/'python-port/venv/bin/python';tool=root/'cpp-core/tools/benchmark_gpu_ncc_closure.py'
steps=[
 ('stop0-formal',['--fixtures-manifest','build/stage39-fine-tiles/stop0-fixtures.json','--cases','many128_pose_stop0,many512_pose_stop0','--methods','hybrid_best,full_gpu_tiled,full_gpu_fine_tiled,full_gpu_simd']),
 ('holdout',['--fixtures-manifest',str(work/'holdout-fixtures.json'),'--cases','heldout12,small_fullres,boundary_one,empty_scene,constant_source,many128_holdout,many512_holdout','--methods','hybrid_best,full_gpu_tiled,full_gpu_simd']),
 ('profile',['--profile','--blocks','1','--repeats','2','--warmup','0','--cases','many128_pose,many512_pose,8k_t256_angle180_3scales','--methods','full_gpu_tiled,full_gpu_u32,full_gpu_moments,full_gpu_simd']),
 ('stop0-profile',['--profile','--blocks','1','--repeats','2','--warmup','0','--fixtures-manifest','build/stage39-fine-tiles/stop0-fixtures.json','--cases','many128_pose_stop0,many512_pose_stop0','--methods','full_gpu_tiled,full_gpu_fine_tiled,full_gpu_simd'])]
for name,args in steps:
 print('START '+name,flush=True)
 with (work/'validation'/(name+'.log')).open('w') as log:
  subprocess.run([str(py),str(tool),'--output',str(work/name/'manifest.json'),*args],stdout=log,stderr=subprocess.STDOUT,check=True)
 print('DONE '+name,flush=True)
for name,script in [('cross-version','check_previous_binary.py'),('soak','run_soak.py')]:
 print('START '+name,flush=True)
 with (work/'validation'/(name+'.log')).open('w') as log:
  subprocess.run([str(py),str(work/'validation'/script)],stdout=log,stderr=subprocess.STDOUT,check=True)
 print('DONE '+name,flush=True)
