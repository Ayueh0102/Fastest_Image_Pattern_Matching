#!/usr/bin/env python3
"""Independent Stage-40 evidence audit; never imports a benchmark harness.

Reads completed artifacts only. It does not launch the runner, compile code,
change frozen source, or rerun GPU work. Performance and ground-truth gate
failures remain observations; exact GPU parity/integrity failures fail the audit.
"""
import argparse
from collections import Counter, defaultdict, deque
import hashlib
import json
import math
from pathlib import Path
import statistics

DATASETS = ('pilot', 'formal', 'stop0-formal', 'holdout', 'profile', 'stop0-profile')
MODES = {'full_gpu_tiled': 0, 'full_gpu_fine_tiled': 1,
         'full_gpu_u32': 2, 'full_gpu_moments': 3, 'full_gpu_simd': 4}
BASELINE = 'full_gpu_tiled'
PRIMARY = {'many128_pose', 'many512_pose'}
COUNTS = ('reached_candidates', 'angles', 'cached_angles', 'direct_angles',
          'tiled_angles', 'source_samples', 'tile_loads')
GEOMETRY = ('template_width', 'template_height', 'roi_cache_bytes')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    hasher = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            hasher.update(chunk)
    return hasher.hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def number(value, name):
    require(type(value) in (int, float) and math.isfinite(value) and value >= 0, name)
    return value


def natural(value, name):
    require(type(value) is int and value >= 0, name)
    return value


def child(root, name):
    path = (root / name).resolve()
    require(path.is_relative_to(root.resolve()), 'Worker path escapes artifact directory')
    return path


def accuracy(predictions, truths):
    """Spatial buckets plus independent maximum-cardinality augmenting paths."""
    buckets = defaultdict(list)
    for pi, prediction in enumerate(predictions):
        values = [prediction[k] for k in ('pos_x', 'pos_y', 'angle', 'scale', 'score')]
        require(all(type(v) in (int, float) and math.isfinite(v) for v in values), 'Nonfinite prediction')
        require(prediction['scale'] > 0, 'Nonpositive prediction scale')
        buckets[(math.floor(prediction['pos_x']/2), math.floor(prediction['pos_y']/2))].append(pi)
    edges, errors = [], {}
    for ti, truth in enumerate(truths):
        require(all(math.isfinite(truth[k]) for k in ('pos_x', 'pos_y', 'angle', 'scale')) and truth['scale'] > 0,
                'Invalid independent truth')
        bx, by = math.floor(truth['pos_x']/2), math.floor(truth['pos_y']/2)
        neighbors = []
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for pi in buckets.get((bx+dx, by+dy), ()):
                    prediction = predictions[pi]
                    pos = math.hypot(prediction['pos_x']-truth['pos_x'], prediction['pos_y']-truth['pos_y'])
                    angle = abs((prediction['angle']-truth['angle']+180) % 360-180)
                    ratio = prediction['scale']/truth['scale']
                    if pos <= 2 and angle <= 1 and .98 <= ratio <= 1.02:
                        neighbors.append(pi)
                        errors[(ti, pi)] = (pos, angle, abs(ratio-1))
        edges.append(sorted(neighbors))
    assigned_t, assigned_p = [-1]*len(truths), [-1]*len(predictions)
    for start in range(len(truths)):
        queue, seen_t, parent_p, terminal = deque([start]), {start}, {}, None
        while queue and terminal is None:
            ti = queue.popleft()
            for pi in edges[ti]:
                if pi in parent_p:
                    continue
                parent_p[pi] = ti
                if assigned_p[pi] < 0:
                    terminal = pi
                    break
                if assigned_p[pi] not in seen_t:
                    seen_t.add(assigned_p[pi]); queue.append(assigned_p[pi])
        while terminal is not None and terminal >= 0:
            ti = parent_p[terminal]
            old = assigned_t[ti]
            assigned_t[ti] = terminal; assigned_p[terminal] = ti
            terminal = old
    pairs = [errors[(ti, pi)] for ti, pi in enumerate(assigned_t) if pi >= 0]
    tp = len(pairs)
    return dict(tp=tp, fp=len(predictions)-tp, fn=len(truths)-tp,
                max_errors={name: max((p[k] for p in pairs), default=None)
                            for k, name in enumerate(('position_px', 'angle_deg', 'relative_scale'))})


def fine_work(gpu, profiling):
    require(gpu['fine_work_available'] is profiling, 'Fine-work availability differs from profiling request')
    rows = gpu['fine_work']
    require(type(rows) is list, 'Fine-work rows missing')
    if not profiling:
        require(not rows and gpu['fine_diagnostic_readback_bytes'] == 0, 'Unprofiled call contains fine diagnostics')
        return None
    require(gpu['fine_diagnostic_readback_bytes'] == 16*len(rows), 'Fine diagnostic payload/level mismatch')
    workload, totals, seen = [], Counter(), set()
    for row in rows:
        for name in ('model', 'layer', *GEOMETRY, *COUNTS):
            natural(row[name], 'fine_work.'+name)
        key = (row['model'], row['layer'])
        require(key not in seen, 'Repeated fine-work level'); seen.add(key)
        w, h, capacity = (row[name] for name in GEOMETRY)
        require(w > 0 and h > 0 and capacity > 0, 'Empty fine-work geometry')
        roi = (w+6)*(h+6)
        body = min(16, capacity//(w+6)-6)
        cached = roi <= capacity
        tiled = not cached and gpu['fine_effective_mode'] >= 1 and body >= 1
        expected_kind = 'cached_angles' if cached else 'tiled_angles' if tiled else 'direct_angles'
        require(row['angles'] == sum(row[k] for k in ('cached_angles', 'direct_angles', 'tiled_angles')), 'Angle categories do not sum')
        require(row[expected_kind] == row['angles'], 'Unexpected fine cache path')
        require(row['angles'] <= row['reached_candidates']*1260, 'Fine angle bound exceeded')
        loads = row['tiled_angles']*((h+body-1)//body) if tiled else 0
        require(row['tile_loads'] == loads, 'Tile count formula mismatch')
        samples = row['cached_angles']*roi + row['direct_angles']*49*w*h + (w+6)*(row['tiled_angles']*h+6*loads)
        require(row['source_samples'] == samples, 'Sampler count formula mismatch')
        for name in COUNTS:
            totals[name] += row[name]
        workload.append((*key, w, h, capacity, row['reached_candidates'], row['angles']))
    return dict(workload=sorted(workload), totals=dict(totals))


def gpu_call(record, method, profiling):
    g = record['full_gpu']
    require(g['enabled'] is True, 'GPU method disabled')
    for field, expected in {'command_buffers': 1, 'cpu_waits': 1,
                            'intermediate_readbacks': 0, 'cpu_algorithm_steps': 0}.items():
        require(type(g[field]) is int and g[field] == expected, 'Residency mismatch: '+field)
    require(g['fine_mode'] == MODES[method] and g['peak_mode'] == 1, 'Algorithm mode mismatch')
    require(g['fine_simd_width'] > 0, 'Missing SIMD width')
    effective = 2 if MODES[method] == 4 and g['fine_simd_width'] != 32 else MODES[method]
    require(g['fine_effective_mode'] == effective, 'SIMD fallback mismatch')
    for field in ('gpu_bytes', 'peak_scratch_bytes', 'fine_threadgroup_bytes', 'fine_diagnostic_bytes',
                  'fine_diagnostic_readback_bytes', 'profile_samples', 'profile_counter_bytes', 'profile_resolve_bytes'):
        natural(g[field], field)
    require(g['gpu_bytes'] > 0 and g['peak_scratch_bytes'] <= g['gpu_bytes'], 'GPU allocation scope invalid')
    require(g['fine_diagnostic_readback_bytes'] <= g['fine_diagnostic_bytes'] <= g['gpu_bytes'], 'Fine diagnostic allocation invalid')
    require(g['profile_requested'] is profiling and type(g['profile_available']) is bool, 'Profile availability invalid')
    if g['device_timestamp_available']:
        number(g['device_ms'], 'device duration')
    else:
        require(g['device_ms'] is None, 'Unavailable device timestamp not null')
    stages, residual = {}, None
    if g['profile_available']:
        require(profiling and g['stages'], 'Unexpected/missing stages')
        encoders = 0
        for stage in g['stages']:
            require(stage['name'] not in stages, 'Duplicate GPU stage')
            number(stage['gpu_ms'], 'stage duration'); natural(stage['encoders'], 'stage encoders')
            require(stage['encoders'] > 0, 'Empty encoder group')
            stages[stage['name']] = stage['gpu_ms']; encoders += stage['encoders']
        require(g['profile_samples'] == 2*encoders, 'Timestamp sample/encoder mismatch')
        require(math.isclose(sum(stages.values()), g['profile_gpu_ms'], rel_tol=1e-6, abs_tol=1e-5), 'Stage sum mismatch')
        if g['device_timestamp_available']:
            residual = g['device_ms']-sum(stages.values())
    else:
        require(not g['stages'] and g['profile_gpu_ms'] in (None, 0), 'Unavailable profile has stage data')
    return dict(fine=fine_work(g, profiling), stages=stages, residual_ms=residual,
                profile_available=g['profile_available'], fallback=effective != MODES[method],
                allocation=tuple(g[k] for k in ('gpu_bytes', 'peak_scratch_bytes', 'fine_threadgroup_bytes',
                                               'fine_diagnostic_bytes', 'fine_diagnostic_readback_bytes')))


def audit_dataset(path, fingerprints, verify_files, file_cache):
    manifest = load(path); root = path.parent
    require(manifest.get('complete') is True and manifest.get('unchanged') is True, 'Experiment not complete/unchanged')
    require(manifest.get('failure') is None, 'Experiment manifest records failure')
    before = {key: manifest[key] for key in ('source_sha256', 'binary_sha256', 'input_sha256')}
    require(all(before.values()) and manifest['after_sha256'] == before, 'Before/after fingerprints differ')
    for category, files in before.items():
        for name, checksum in files.items():
            fingerprints[(category, name)].add(checksum)
            if verify_files:
                resolved = Path(name) if Path(name).is_absolute() else verify_files/str(name)
                cache_key = str(resolved)
                if cache_key not in file_cache:
                    file_cache[cache_key] = digest(resolved)
                require(file_cache[cache_key] == checksum, 'Current artifact hash differs: '+name)
    profiling = manifest['profiling']; methods = manifest['methods']
    require(type(profiling) is bool and len(methods) == len(set(methods)), 'Invalid methods/profiling')
    require(set(methods) <= {*MODES, 'hybrid_best'}, 'Unknown method')
    require(BASELINE in methods, 'Independent audit requires baseline GPU')
    cases = {c['name']: c for c in manifest['cases']}
    require(len(cases) == len(manifest['cases']), 'Duplicate cases')
    blocks, repeats = manifest['blocks'], manifest['repeats']
    require(blocks > 0 and repeats > 0, 'Empty experiment')
    if manifest['phase'] == 'formal':
        require(blocks >= 3 and repeats >= 2 and manifest['warmup_seconds'] >= 1, 'Formal protocol too small')
    expected = {(c, m, b) for c in cases for m in methods for b in range(blocks)}
    entries, jobs = {}, {}
    for e in manifest['executions']:
        key = (e['case'], e['method'], e['block'])
        require(key in expected and key not in entries, 'Duplicate/unexpected execution')
        for kind in ('job', 'result'):
            require(digest(child(root, e[kind])) == e[kind+'_sha256'], 'Changed worker '+kind)
        jobs[key] = load(child(root, e['job'])); entries[key] = load(child(root, e['result']))
        require('truth' not in jobs[key] and 'truths' not in jobs[key], 'Ground truth supplied to worker')
        require(jobs[key]['full_gpu_profiling'] is profiling, 'Worker profiling mismatch')
        require(jobs[key]['repeats'] == repeats and jobs[key]['warmup_seconds'] == manifest['warmup_seconds'], 'Worker measurement protocol mismatch')
        require(jobs[key]['full_gpu'] is (e['method'] in MODES), 'Worker route mismatch')
        if e['method'] in MODES:
            require(jobs[key]['full_gpu_fine_mode'] == MODES[e['method']], 'Worker mode mismatch')
        require(len(entries[key]['runs']) == repeats, 'Missing repeats')
    require(set(entries) == expected, 'Incomplete worker matrix')
    counts = dict(fresh_processes=len(entries), first_calls=len(entries), measured_calls=len(entries)*repeats,
                  gt_evaluated_calls=len(entries)*(repeats+1), warmups=sum(len(w['warmups_ms']) for w in entries.values()))
    for field in ('fresh_processes', 'first_calls', 'measured_calls', 'gt_evaluated_calls'):
        require(manifest['summary']['counts'][field] == counts[field], 'Summary call count mismatch')
    result_cases, observed_gates, semantic_gates = [], [], []
    profile_call_count, profile_residuals = 0, []
    for case_name, case in cases.items():
        reference = entries[(case_name, BASELINE, 0)]['first']
        expected_job = {k:v for k,v in jobs[(case_name, BASELINE, 0)].items()
                        if k not in ('full_gpu', 'full_gpu_fine_mode', 'full_gpu_peak_mode')}
        for method in methods:
            for b in range(blocks):
                comparison_job = {k:v for k,v in jobs[(case_name,method,b)].items()
                                  if k not in ('full_gpu', 'full_gpu_fine_mode', 'full_gpu_peak_mode')}
                require(canonical(comparison_job) == canonical(expected_job), 'Search/measurement settings differ across methods')
        baseline_alloc = gpu_call(reference, BASELINE, profiling)['allocation']
        baseline_workload = gpu_call(reference, BASELINE, profiling)['fine']
        rows = {}
        for method in methods:
            workers = [entries[(case_name, method, b)] for b in range(blocks)]
            calls = [r for w in workers for r in [w['first'], *w['runs']]]
            measured = [r for w in workers for r in w['runs']]
            checks, gpus = [], []
            for ci, call in enumerate(calls):
                number(call['total_ms'], 'total duration'); require(call['total_ms'] > 0, 'Nonpositive total duration')
                check = accuracy(call['matches'], case['truth']); checks.append(check)
                require(call['matches'] == calls[0]['matches'] and call['proposals'] == calls[0]['proposals'], 'Repeat output differs')
                if method in MODES:
                    require(call['matches'] == reference['matches'] and call['proposals'] == reference['proposals'], 'Complete ordered GPU result differs')
                    audit = gpu_call(call, method, profiling); gpus.append(audit)
                    require(audit['allocation'] == baseline_alloc, 'GPU buffers/static threadgroup bytes changed across modes')
                    if profiling:
                        require(audit['fine']['workload'] == baseline_workload['workload'], 'Fine candidate/angle workload changed')
                        profile_call_count += audit['profile_available']
                        if audit['residual_ms'] is not None:
                            profile_residuals.append(audit['residual_ms'])
                else:
                    require(call['full_gpu']['enabled'] is False, 'Hybrid routed through full GPU')
            require(all(w['exact_repeat'] is True for w in workers), 'Worker exact_repeat flag false')
            gt_pass = all(c['fp'] == 0 and c['fn'] == 0 for c in checks)
            if not gt_pass:
                semantic_gates.append(dict(case=case_name, method=method, gate='independent_ground_truth'))
            if any(g['fallback'] for g in gpus):
                semantic_gates.append(dict(case=case_name, method=method, gate='requested_algorithm_not_executed'))
            rows[method] = dict(median_ms=statistics.median(r['total_ms'] for r in measured),
                block_medians=[statistics.median(r['total_ms'] for r in w['runs']) for w in workers],
                peak_rss_bytes=max(w['final_memory']['peak_rss_bytes'] for w in workers),
                gt_calls=len(calls), all_gt_pass=gt_pass, gpu_ordered_parity=method in MODES,
                accuracy_counts=sorted({(c['tp'],c['fp'],c['fn']) for c in checks}),
                max_errors={k:max((c['max_errors'][k] for c in checks if c['max_errors'][k] is not None), default=None)
                            for k in ('position_px', 'angle_deg', 'relative_scale')},
                gpu_allocation=list(baseline_alloc) if gpus else None,
                profile_available_calls=sum(g['profile_available'] for g in gpus),
                fine_work_totals=gpus[0]['fine']['totals'] if gpus and profiling else None,
                measured_stage_medians={s:statistics.median(gpu_call(r,method,profiling)['stages'][s] for r in measured)
                                        for s in gpus[0]['stages']} if gpus and all(g['profile_available'] for g in gpus) else {})
        if not profiling:
            for candidate in (m for m in methods if m in MODES and m != BASELINE):
                for baseline in (BASELINE, 'hybrid_best', 'full_gpu_fine_tiled'):
                    if baseline not in rows or candidate == baseline:
                        continue
                    left, right = rows[baseline], rows[candidate]
                    for b, (old, new) in enumerate(zip(left['block_medians'], right['block_medians'])):
                        if new > old+max(2, .1*old):
                            observed_gates.append(dict(case=case_name, method=candidate, baseline=baseline, gate='time_budget', block=b))
                    if right['peak_rss_bytes'] > left['peak_rss_bytes']+max(8*1024**2, .1*left['peak_rss_bytes']):
                        observed_gates.append(dict(case=case_name, method=candidate, baseline=baseline, gate='rss_budget'))
                    if baseline == BASELINE and case_name in PRIMARY and 100*(right['median_ms']/left['median_ms']-1) > -10:
                        observed_gates.append(dict(case=case_name, method=candidate, baseline=baseline, gate='primary_10_percent_improvement'))
        result_cases.append(dict(name=case_name, truth_count=len(case['truth']), methods=rows))
    require(sorted(map(canonical, observed_gates+semantic_gates)) == sorted(map(canonical, manifest['summary']['failed_gates'])),
            'Independent failed-gate list differs from summary')
    return dict(manifest_sha256=digest(path), phase=manifest['phase'], profiling=profiling,
                counts=counts, cases=result_cases, independently_reproduced_failed_gates=observed_gates+semantic_gates,
                available_profile_calls=profile_call_count,
                signed_profile_residual_ms=dict(values=profile_residuals,
                    min=min(profile_residuals,default=None), max=max(profile_residuals,default=None),
                    negative_count=sum(x<0 for x in profile_residuals)))


def self_test():
    pose=lambda x:dict(pos_x=x,pos_y=0,angle=0,scale=1,score=1)
    require(accuracy([pose(0),pose(0)],[pose(0),pose(10)])['fn'] == 1, 'Duplicate detection negative control')
    require(accuracy([pose(1),pose(-1.5)],[pose(0),pose(2.5)])['tp'] == 2, 'Augmenting-path reassignment')
    require(accuracy([],[])['tp'] == 0, 'Empty-set negative control')
    wrong=pose(0); wrong['angle']=2
    require(accuracy([wrong],[pose(0)])['fp'] == 1, 'Angle negative control')
    wrong=pose(0); wrong['scale']=1.03
    require(accuracy([wrong],[pose(0)])['fp'] == 1, 'Scale negative control')
    print('Independent audit self-test: 5 controls passed')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    parser.add_argument('--repo',type=Path,default=Path(__file__).resolve().parents[3])
    parser.add_argument('--output',type=Path)
    parser.add_argument('--datasets',nargs='+',default=DATASETS)
    parser.add_argument('--skip-current-files',action='store_true',help='Only archived before/after/cross-dataset hashes; for offline archives')
    parser.add_argument('--self-test',action='store_true')
    args=parser.parse_args()
    if args.self_test:
        self_test(); return
    results, failures, fingerprints, file_cache = {}, [], defaultdict(set), {}
    for dataset in args.datasets:
        path=args.root/dataset/'manifest.json'
        try:
            results[dataset]=audit_dataset(path,fingerprints,None if args.skip_current_files else args.repo,file_cache)
        except Exception as error:
            failures.append(dict(dataset=dataset,error=type(error).__name__,message=str(error)))
    conflicts=[dict(category=k[0],path=k[1],hashes=sorted(v)) for k,v in fingerprints.items() if len(v)>1]
    if conflicts:
        failures.append(dict(dataset='cross_dataset',error='FingerprintConflict',conflicts=conflicts))
    counts=Counter()
    for row in results.values(): counts.update(row['counts'])
    result=dict(schema=1,independent=True,harness_imported=False,gpu_launched=False,
                complete=not failures,datasets=results,failures=failures,counts=dict(counts),
                unique_fingerprinted_files=len(fingerprints),current_files_verified=len(file_cache),
                scope_notes=['Warmup timings are counted but do not contain GT-evaluated result records.',
                             'Exact ordered parity is against the original full GPU path, not CPU double arithmetic.',
                             'GPU allocation compares named buffer lengths and compiled static threadgroup bytes; not physical VRAM.',
                             'Fine source_samples are derived sampler calls, not measured hardware traffic.',
                             'Signed timestamp residuals are retained; negative residuals are not silently clamped.',
                             'Failed speed or independent-GT gates are evidence, not audit-integrity failures.'])
    output=args.output or args.root/'validation'/'independent-evidence-audit.json'
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(canonical(dict(complete=result['complete'],counts=result['counts'],failures=failures,output=str(output))))
    raise SystemExit(0 if result['complete'] else 1)


if __name__ == '__main__':
    main()
