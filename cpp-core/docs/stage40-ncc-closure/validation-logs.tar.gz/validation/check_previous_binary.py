#!/usr/bin/env python3
"""Independent, serial Stage-39 binary control for the Stage-40 NCC study.

Defaults: original 128/512 cases, 3 alternating blocks, 2 measured repeats,
1 second warmup. Compare frozen Stage-39 peak1/fine0 against current fine0
and fine4, with every other setting shared. Run only when the GPU is idle.
All first/measured ordered outputs, GT evaluations, warmups, RSS and hashes
are retained. A mismatch or changed fingerprint fails the run. Timing gates
are reported independently; they do not suppress raw results.

The imported validators/job builder come only from the frozen source tree.
No frozen source is modified (Python bytecode writing is disabled).
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib
import json
import math
from pathlib import Path
import platform
import statistics
import subprocess
import sys

sys.dont_write_bytecode = True
REPO = Path(__file__).resolve().parents[3]
METHODS = ('stage39_fine0', 'current_fine0', 'current_fine4')
MODES = {'stage39_fine0': 0, 'current_fine0': 0, 'current_fine4': 4}
CASES = ('many128_pose', 'many512_pose')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def helpers(frozen):
    tools = (frozen / 'cpp-core/tools').resolve()
    sys.path.insert(0, str(tools))
    module = importlib.import_module('benchmark_gpu_fine_tiles')
    if not Path(module.__file__).resolve().is_relative_to(tools):
        raise RuntimeError('Expected frozen Stage-39 helpers, not current modules')
    return module


def sources(root):
    result = {}
    for folder in ('src', 'include', 'experiments', 'tools', 'tests'):
        for path in (root / 'cpp-core' / folder).rglob('*'):
            if path.is_file() and (path.suffix in ('.cpp', '.hpp', '.h', '.mm', '.metal', '.py', '.in') or path.name == 'CMakeLists.txt'):
                result[str(path.relative_to(root))] = sha(path)
    result['cpp-core/CMakeLists.txt'] = sha(root / 'cpp-core/CMakeLists.txt')
    return dict(sorted(result.items()))


def fingerprints(repo, frozen, binaries, cases, fixture_manifest):
    files = {binary for binary in binaries.values()}
    for binary in binaries.values():
        files.update(binary.parent.glob('*.dylib'))
    return dict(script_sha256=sha(__file__), current_source_sha256=sources(repo),
                frozen_source_sha256=sources(frozen),
                binary_sha256={str(p): sha(p) for p in sorted(files)},
                input_sha256={case[key]: sha(case[key]) for case in cases for key in ('source', 'template')},
                fixture_manifest_sha256=sha(fixture_manifest))


def job(h, case, method, repeats, warmup):
    result = h.job(case, 'full_gpu_tiled', repeats, warmup, False)
    result['full_gpu_fine_mode'] = MODES[method]
    assert result['full_gpu_peak_mode'] == 1 and result['full_gpu'] is True
    assert 'truth' not in result
    return result


def read_worker(h, manifest, root, entry, case):
    expected = job(h, case, entry['method'], manifest['repeats'], manifest['warmup_seconds'])
    for label in ('job', 'result', 'stdout', 'stderr'):
        path = h.previous.worker_path(root, entry[label])
        if sha(path) != entry[label + '_sha256']:
            raise ValueError('Changed worker artifact: ' + entry[label])
    actual = json.loads((root / entry['job']).read_text())
    if json.dumps(actual, sort_keys=True) != json.dumps(expected, sort_keys=True):
        raise ValueError('Job differs from declared shared settings')
    worker = json.loads((root / entry['result']).read_text())
    if json.loads((root / entry['stdout']).read_text()) != worker or entry['returncode'] != 0:
        raise ValueError('Parsed result differs from successful raw worker output')
    if len(worker['runs']) != manifest['repeats'] or type(worker.get('exact_repeat')) is not bool:
        raise ValueError('Missing measured repeats or exact-repeat contract')
    h.previous.finite_nonnegative(worker['construct_ms'], 'construct_ms')
    for field in ('current_rss_bytes', 'peak_rss_bytes'):
        h.peaks.integer(worker['final_memory'][field], 'final_memory.' + field)
    if not isinstance(worker.get('warmups_ms'), list) or not worker['warmups_ms']:
        raise ValueError('Warmup calls missing')
    for value in worker['warmups_ms']:
        h.previous.finite_nonnegative(value, 'warmups_ms')
    # Native worker stops by elapsed wall time; sum(warmups_ms) excludes
    # surrounding overhead and is not an independent wall-duration measure.
    for record in [worker['first'], *worker['runs']]:
        if not h.previous.validate_record(record, True):
            raise ValueError('GPU residency contract failed')
        metrics = record['full_gpu']
        if type(metrics.get('peak_mode')) is not int or metrics['peak_mode'] != 1:
            raise ValueError('Wrong peak mode')
        if type(metrics.get('fine_mode')) is not int or metrics['fine_mode'] != MODES[entry['method']]:
            raise ValueError('Wrong fine mode')
        if h.profile_record(record, False) is not None:
            raise ValueError('Unexpected profiling measurements')
        if metrics.get('fine_work_available') is not False or metrics.get('fine_work') != []:
            raise ValueError('Unexpected diagnostic fine workload')
        if metrics['fine_diagnostic_readback_bytes'] != 0:
            raise ValueError('Unexpected diagnostic readback')
        if entry['method'] != 'stage39_fine0':
            width = h.peaks.integer(metrics['fine_simd_width'], 'fine_simd_width')
            effective = 2 if MODES[entry['method']] == 4 and width != 32 else MODES[entry['method']]
            if width < 1 or metrics['fine_effective_mode'] != effective:
                raise ValueError('Current SIMD-width fallback contract failed')
    return worker


def summarize(h, manifest, root):
    if manifest.get('complete') is not True or manifest.get('unchanged') is not True:
        raise ValueError('Incomplete experiment or changed fingerprints')
    if manifest['before_sha256'] != manifest['after_sha256']:
        raise ValueError('Inconsistent before/after fingerprint claims')
    if tuple(manifest['methods']) != METHODS or tuple(c['name'] for c in manifest['cases']) != CASES:
        raise ValueError('Unexpected comparison methods/cases')
    if manifest['blocks'] < 3 or manifest['repeats'] < 2 or manifest['warmup_seconds'] < 1:
        raise ValueError('Incomplete cross-version protocol')
    case_by_name = {case['name']: case for case in manifest['cases']}
    expected = {(name, method, block) for name in CASES for block in range(manifest['blocks']) for method in METHODS}
    workers = {}
    for entry in manifest['executions']:
        key = (entry['case'], entry['method'], entry['block'])
        if key not in expected or key in workers:
            raise ValueError('Unexpected/duplicate execution')
        workers[key] = read_worker(h, manifest, root, entry, case_by_name[entry['case']])
    if set(workers) != expected:
        raise ValueError('Missing executions')
    results, failures = [], []
    for name, case in case_by_name.items():
        reference = workers[(name, 'stage39_fine0', 0)]['first']
        rows = {}
        for method in METHODS:
            blocks = [(b, workers[(name, method, b)]) for b in range(manifest['blocks'])]
            calls = [(b, 'first' if i == 0 else 'measured', i - 1, record)
                     for b, worker in blocks for i, record in enumerate([worker['first'], *worker['runs']])]
            evaluated = []
            for block, kind, index, record in calls:
                metrics = h.evaluate(record['matches'], case['truth'])
                parity = {key: record[key] == reference[key] for key in ('matches', 'proposals')}
                passed = all(parity.values()) and metrics['strict']['fp'] == metrics['strict']['fn'] == 0
                evaluated.append(dict(block=block, kind=kind, measured_index=index if kind == 'measured' else None,
                                      ordered_matches_exact=parity['matches'], ordered_proposals_exact=parity['proposals'],
                                      accuracy=metrics, passed=passed))
                if not passed:
                    failures.append(dict(case=name, method=method, block=block, call=kind, measured_index=index))
            if not all(worker['exact_repeat'] for _, worker in blocks):
                failures.append(dict(case=name, method=method, reason='worker exact_repeat false'))
            measured = [r for _, worker in blocks for r in worker['runs']]
            rows[method] = dict(
                total_ms=h.distribution([r['total_ms'] for r in measured]),
                first_ms=h.distribution([w['first']['total_ms'] for _, w in blocks]),
                construct_ms=h.distribution([w['construct_ms'] for _, w in blocks]),
                peak_rss_bytes=h.distribution([w['final_memory']['peak_rss_bytes'] for _, w in blocks]),
                named_metal_bytes=h.distribution([r['full_gpu']['gpu_bytes'] for r in measured]),
                threadgroup_bytes=sorted({r['full_gpu']['fine_threadgroup_bytes'] for r in measured}),
                warmups_ms=[dict(block=b, values=w['warmups_ms']) for b, w in blocks],
                blocks=[dict(block=b, total_ms=statistics.median(r['total_ms'] for r in w['runs']),
                             peak_rss_bytes=w['final_memory']['peak_rss_bytes']) for b, w in blocks],
                evaluated_calls=evaluated,
                all_ordered_outputs_exact=all(r['ordered_matches_exact'] and r['ordered_proposals_exact'] for r in evaluated),
                all_strict_gt=all(r['accuracy']['strict']['fp'] == r['accuracy']['strict']['fn'] == 0 for r in evaluated))
        comparisons = {}
        old = rows['stage39_fine0']
        for method in ('current_fine0', 'current_fine4'):
            current = rows[method]
            pairs = []
            for baseline, candidate in zip(old['blocks'], current['blocks']):
                left, right = baseline['total_ms'], candidate['total_ms']
                pairs.append(dict(block=baseline['block'], old_ms=left, current_ms=right,
                                  time_delta_percent=100 * (right / left - 1),
                                  rss_delta_bytes=candidate['peak_rss_bytes'] - baseline['peak_rss_bytes'],
                                  time_within_10_percent_or_2ms=right <= left + max(2, left * .1)))
            comparisons[method] = dict(
                time_delta_percent_vs_frozen39=100 * (current['total_ms']['median'] / old['total_ms']['median'] - 1),
                peak_rss_delta_bytes=current['peak_rss_bytes']['max'] - old['peak_rss_bytes']['max'],
                all_blocks_within_10_percent_or_2ms=all(p['time_within_10_percent_or_2ms'] for p in pairs),
                paired_blocks=pairs)
        results.append(dict(name=name, truth_count=len(case['truth']), methods=rows, comparisons_vs_frozen39=comparisons,
                            current_mode4_delta_percent_vs_current_mode0=100 * (rows['current_fine4']['total_ms']['median'] / rows['current_fine0']['total_ms']['median'] - 1)))
    return dict(correctness_passed=not failures, failures=failures, cases=results,
                worker_processes=len(workers), evaluated_calls=len(workers) * (1 + manifest['repeats']),
                measured_calls=len(workers) * manifest['repeats'],
                note='First and measured calls have full ordered output and independent GT checks. Warmups retain timings only. RSS is process peak; named Metal allocations are a separate scope. Timing deltas are paired controls, not proof of causation.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=REPO)
    parser.add_argument('--frozen-source', type=Path, default=REPO/'build/stage39-review/source')
    parser.add_argument('--old-binary', type=Path, default=REPO/'build/stage39-review/release/experiments/fpm_native_pipeline_runner')
    parser.add_argument('--current-binary', type=Path, default=REPO/'build/fourier-gpu/experiments/fpm_native_pipeline_runner')
    parser.add_argument('--fixtures-manifest', type=Path, default=REPO/'build/stage37-full-gpu/formal/manifest.json')
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parent/'cross-version/manifest.json')
    parser.add_argument('--blocks', type=int, default=3)
    parser.add_argument('--repeats', type=int, default=2)
    parser.add_argument('--warmup', type=float, default=1.)
    parser.add_argument('--timeout', type=float, default=600.)
    parser.add_argument('--summarize', type=Path, help='Replay an existing manifest without running workers')
    args = parser.parse_args()
    if args.output.exists():
        parser.error('Refusing to overwrite output')
    h = helpers(args.frozen_source)
    if args.summarize:
        result = summarize(h, json.loads(args.summarize.read_text()), args.summarize.resolve().parent)
        save(args.output, result)
        if not result['correctness_passed']:
            raise RuntimeError('Cross-version correctness mismatches; see retained summary')
        return
    if args.blocks < 3 or args.repeats < 2 or not 1 <= args.warmup <= 60 or not math.isfinite(args.timeout) or args.timeout <= 0:
        parser.error('Require >=3 blocks, >=2 repeats, warmup 1..60 seconds and finite positive timeout')
    root = args.output.resolve().parent
    if any((root / name).exists() for name in ('jobs', 'results')):
        raise ValueError('Refusing to reuse an existing worker directory')
    cases = h.fixture_cases(args.fixtures_manifest, list(CASES))
    binaries = dict(stage39_fine0=args.old_binary.resolve(), current_fine0=args.current_binary.resolve(), current_fine4=args.current_binary.resolve())
    before = fingerprints(args.repo.resolve(), args.frozen_source.resolve(), binaries, cases, args.fixtures_manifest)
    manifest = dict(version=1, purpose='Frozen Stage39 control for shared-kernel baseline regression',
                    platform=platform.platform(), started_utc=datetime.now(timezone.utc).isoformat(),
                    methods=list(METHODS), cases=cases, blocks=args.blocks, repeats=args.repeats,
                    warmup_seconds=args.warmup, timeout_seconds=args.timeout,
                    binaries={k: str(v) for k, v in binaries.items()},
                    frozen_source=str(args.frozen_source.resolve()), fixtures_manifest=str(args.fixtures_manifest.resolve()),
                    before_sha256=before, executions=[], complete=False)
    save(args.output, manifest)
    try:
        for case in cases:
            for block in range(args.blocks):
                for method in METHODS[::1 if block % 2 == 0 else -1]:
                    label = f"{case['name']}-{method}-b{block}"
                    jp, rp = root/'jobs'/(label+'.json'), root/'results'/(label+'.json')
                    stdout, stderr = jp.with_suffix('.stdout.txt'), jp.with_suffix('.stderr.txt')
                    save(jp, job(h, case, method, args.repeats, args.warmup))
                    print('Running '+label, flush=True)
                    try:
                        child = subprocess.run([str(binaries[method]), str(jp)], capture_output=True, text=True, timeout=args.timeout)
                    except subprocess.TimeoutExpired as error:
                        stdout.write_text(error.stdout.decode() if isinstance(error.stdout, bytes) else error.stdout or '')
                        stderr.write_text(error.stderr.decode() if isinstance(error.stderr, bytes) else error.stderr or '')
                        raise
                    stdout.write_text(child.stdout)
                    stderr.write_text(child.stderr)
                    if child.returncode:
                        raise RuntimeError(label+': worker exit '+str(child.returncode)+': '+child.stderr[-4000:])
                    save(rp, json.loads(child.stdout))
                    entry = dict(case=case['name'], method=method, block=block, returncode=child.returncode)
                    for key, path in dict(job=jp, result=rp, stdout=stdout, stderr=stderr).items():
                        entry[key], entry[key+'_sha256'] = str(path.relative_to(root)), sha(path)
                    manifest['executions'].append(entry)
                    save(args.output, manifest)
        after = fingerprints(args.repo.resolve(), args.frozen_source.resolve(), binaries, cases, args.fixtures_manifest)
        manifest.update(complete=True, finished_utc=datetime.now(timezone.utc).isoformat(), after_sha256=after, unchanged=before==after)
        save(args.output, manifest)
        manifest['summary'] = summarize(h, manifest, root)
        save(args.output, manifest)
        if not manifest['summary']['correctness_passed']:
            raise RuntimeError('Cross-version correctness mismatches; see retained summary')
    except Exception as error:
        manifest['failure'] = dict(type=type(error).__name__, message=str(error))
        save(args.output, manifest)
        raise


if __name__ == '__main__':
    main()
