from pathlib import Path
import json,os,subprocess,tarfile,shutil
root=Path.cwd();work=root/'build/stage40-ncc-closure';val=work/'validation';review=root/'build/stage40-review';source=review/'source'
def run(name,cmd,env=None):
 print('START '+name,flush=True)
 with (val/(name+'.log')).open('w') as log:subprocess.run([str(x) for x in cmd],stdout=log,stderr=subprocess.STDOUT,check=True,env=env)
 if str(cmd[0])=='ctest':
  detail=Path(cmd[cmd.index('--test-dir')+1])/'Testing/Temporary/LastTest.log'
  if detail.exists():shutil.copy2(detail,val/(name+'-details.log'))
 print('DONE '+name,flush=True)
run('release-tests',['ctest','--test-dir','build/fourier-gpu','--output-on-failure'])
run('harness-tests',[root/'python-port/venv/bin/python','-m','unittest','discover','-s','cpp-core/tests','-p','test_gpu_*harness.py','-v'])
run('runner-invalid-inputs',[root/'python-port/venv/bin/python',val/'check_inputs.py'])
env=os.environ.copy();env.update(MTL_DEBUG_LAYER='1',MTL_SHADER_VALIDATION='1')
run('metal-validation',['ctest','--test-dir','build/fourier-gpu','-R','^experimental_full_gpu(_fine$|_ncc_)','--output-on-failure'],env)
source.mkdir(parents=True,exist_ok=True)
with tarfile.open(root/'cpp-core/docs/stage40-ncc-closure/source-snapshot.tar.gz') as t:t.extractall(source,filter='data')
common=['-DCMAKE_BUILD_TYPE=Release','-DFPM_BUILD_EXPERIMENTS=ON','-DFPM_BUILD_GUI=ON','-DFPM_WITH_OPENCV=ON']
run('clean-release-configure',['cmake','-S',source/'cpp-core','-B',review/'release',*common])
run('clean-release-build',['cmake','--build',review/'release','--parallel','8','--target','fpm_native_pipeline_runner','fpm_full_gpu_test','fpm_full_gpu_fine_test'])
run('clean-release-tests',['ctest','--test-dir',review/'release','-R','^experimental_full_gpu(_fine$|_ncc_)','--output-on-failure'])
flags='-fsanitize=address,undefined -fno-omit-frame-pointer'
run('asan-configure',['cmake','-S',source/'cpp-core','-B',review/'asan',*common,'-DCMAKE_CXX_FLAGS='+flags,'-DCMAKE_OBJCXX_FLAGS='+flags,'-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined'])
run('asan-build',['cmake','--build',review/'asan','--parallel','8','--target','fpm_full_gpu_test','fpm_full_gpu_fine_test'])
env=os.environ.copy();env.update(ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
run('asan-tests',['ctest','--test-dir',review/'asan','-R','^experimental_full_gpu(_fine$|_ncc_)','--output-on-failure'],env)
print('All validation builds and tests passed',flush=True)
