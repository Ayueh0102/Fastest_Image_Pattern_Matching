# Stage 40 independent host review and holdout plan

Reviewer: stage40_benchmark agent. Scope: read-only code review; no build, GPU dispatch, or benchmark was launched. No production/source files were edited by this review.

## Reviewed changes

- `cpp-core/experiments/research_pipeline.hpp`: requested/effective mode and SIMD-width metrics.
- `cpp-core/experiments/research_pipeline.cpp`: option range 0 through 4; non-full-GPU route rejects nonzero fine modes.
- `cpp-core/tools/native_pipeline_runner.cpp`: strict numeric integral 0 through 4 parsing, Boolean rejection by QJson type, serialized fine mode/effective mode/SIMD width.
- `cpp-core/experiments/full_gpu_metal.mm`: reads the exact fine pipeline's execution width, uses mode 2 for requested mode 4 when width differs from 32, passes the effective mode to FGFineOptions, reports requested and effective modes separately. Fine-work diagnostics remain final-readback-only and derive sampler counts from the executed counters.
- `cpp-core/tests/full_gpu_pipeline_test.cpp`: mode argument propagation, effective-mode assertion, same-session baseline/mode switching, profile disabling/re-enabling, oversized rows, quarter-turn, boundary, threshold, repeated calls, multiscale and unsupported-mode checks.

## Findings

No actionable defect identified in the reviewed changed host paths at review time. This is source review evidence, not device execution evidence. A non-32-wide GPU is not available here; fallback accounting is covered by the Stage-40 harness negative control, while the actual device fallback branch still requires future hardware validation.

The sampler formula remains valid for modes 2–4: full-cache sampling is `(tw+6)*(th+6)` per angle; direct sampling is `49*tw*th`; strip sampling is `(tw+6)*(th+6*ceil(th/tileRows))`, where `tileRows=min(16,floor(cacheBytes/(tw+6))-6)` when positive. Reusing moments changes NCC arithmetic, not these source-sampler calls. Logical GPU buffer lengths, static threadgroup bytes and peak process RSS remain different scopes.

## Bounded holdout recommendations

Freeze the selected candidate and search settings before running the holdout. Compare `hybrid_best`, `full_gpu_tiled`, and the selected candidate; avoid all losing candidates because this is validation, not another tuning round.

Use the five existing Stage-37 cases excluded from the Stage-38/39 primary suite:

1. `heldout12`: independent 12-pose scene, existing full-rescue settings.
2. `small_fullres`: original-resolution search, 2 objects, core-only route.
3. `boundary_one`: object touches the image origin.
4. `empty_scene`: random negative scene.
5. `constant_source`: zero-variance negative scene.

These are holdouts from the current optimization suite, not historically unseen project data: their previous Stage-37 use must be stated.

Generate exactly two new pose/noise-seed scenes using the existing photographed texture and original renderer, without changing its source:

- `many128_holdout`: 16 rows by 16 columns, first 128 entries, 4096 by 4096 pixels.
- `many512_holdout`: 16 rows by 32 columns, first 512 entries, 4096 by 8192 pixels.
- Root-agent preregistration: placement seed 20261019 and noise seed 20261020 for both counts; different grid shapes produce different placement banks. Select these once, before evaluating output, and keep even a failure.
- Call `make_placements(template.shape, columns=columns, seed=chosen_seed)` and `render_scene(template, truth, shape, noise_seed=chosen_noise_seed)` explicitly. Assigning the module's SEED or NOISE_SEED variables alone will not override Python's already-captured default argument values.
- Preserve original cell size 256, position jitter 8, rotation range ±180 degrees, scale distribution log-uniform [0.72, 1.28], gain [0.85, 1.1], bias [-12, 12], background 150 and noise standard deviation 2.
- Preserve the original 128/512 search settings, including scale bank, target limit, score/proposal cutoff, stop layer and refinement workflow. Ground truth must stay out of worker JSON.
- Archive generator invocation/wrapper, exact seeds, full placement/photometric metadata, renderer/NumPy/OpenCV versions, validation results, template/input hashes and source pixel hashes. Re-run `validate_placements` before saving both scenes.

Use formal 3 alternating blocks, 2 measured repeats, 1 second warmup for all seven cases. With three methods this gives 63 processes, 63 first calls plus 126 measured calls, or 189 GT-evaluated calls. Run serially; record first/warmup costs separately. Do not pool these timings with primary-suite timings.

Require independent one-to-one GT and exact complete ordered GPU match/proposal parity against `full_gpu_tiled`, one submit/final wait, and no intermediate readback. Keep per-case paired time and process-RSS regression gates. The Stage-40 primary 10% target remains attached to the preregistered `many128_pose` and `many512_pose` cases, so new-seed holdout names should not be relabelled to obtain that gate. Report holdout timing separately.

If all GPU methods fail a new-seed GT case in the same way, retain it as a shared algorithm limitation; do not loosen thresholds or rerender favorable seeds. Exact parity alone then proves optimization consistency, not detection correctness. A mode-4 fallback must remain explicitly ineligible for a SIMD adoption claim.

Limits: two additional seeds vary placements, pose and noise for the same photographed template and separated grid scene distribution. They cannot establish real-video, RGB, occlusion, touching-instance or unseen-template generalization.

## Prepared generator

`build/stage40-ncc-closure/validation/make_holdouts.py` implements the plan with the root-agent seed pair above. Syntax compilation passed. It has not been executed for image generation. The default output is `build/stage40-ncc-closure/holdout-fixtures.json`, with generated images/metadata under `holdout-inputs/`. It refuses overwrite, verifies original input hashes, preserves search settings, and validates compatibility with the benchmark fixture reader. Run only between GPU timing sessions.
