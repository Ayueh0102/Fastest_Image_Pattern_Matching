from pathlib import Path
import sys,json
root=Path.cwd();sys.path.insert(0,str(root/'cpp-core/tools'))
import benchmark_gpu_ncc_closure as bench
out=root/'cpp-core/docs/stage40-ncc-closure';work=root/'build/stage40-ncc-closure'
summaries={}
for name,formal in [('pilot',None),('formal',None),('stop0-formal',None),('holdout',None),('profile','formal'),('stop0-profile','stop0-formal')]:
 manifest=json.loads((work/name/'manifest.json').read_text());summary=bench.summarize(manifest,work/name)
 if formal:
  baseline=json.loads((work/formal/'manifest.json').read_text())
  summary['profile_overhead']=bench.profile_overhead(manifest,summary,baseline,bench.summarize(baseline,work/formal))
  summary['unprofiled_manifest_sha256']=bench.sha(work/formal/'manifest.json')
 bench.save(out/(name+'-summary.json'),summary);summaries[name]=summary
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,axes=plt.subplots(2,2,figsize=(12,8),gridspec_kw={'width_ratios':[1.6,1]})
methods=['hybrid_best','full_gpu_tiled','full_gpu_simd'];labels=['Hybrid','GPU baseline','GPU SIMD32'];colors=['#9098a5','#276892','#d67a2e']
for col,name in enumerate(['formal','stop0-formal']):
 cases=summaries[name]['cases'];x=np.arange(len(cases));w=.24
 for j,(method,label,color) in enumerate(zip(methods,labels,colors)):
  rows=[c['methods'][method] for c in cases]
  med=np.array([r['total_ms']['median'] for r in rows]);lo=np.array([r['total_ms']['min'] for r in rows]);hi=np.array([r['total_ms']['max'] for r in rows])
  axes[0,col].bar(x+(j-1)*w,med,w,color=color,label=label,yerr=[med-lo,hi-med],capsize=2)
  axes[1,col].bar(x+(j-1)*w,[r['peak_rss_bytes']/2**20 for r in rows],w,color=color)
 for row in (0,1):
  axes[row,col].set_xticks(x,['128','512','6','8K / 6'] if col==0 else ['128','512']);axes[row,col].set_xlabel('Objects / scene');axes[row,col].grid(axis='y',alpha=.2);axes[row,col].set_axisbelow(True)
 axes[0,col].set_yscale('log');axes[0,col].set_ylabel('Algorithm time (ms, log scale)');axes[1,col].set_ylabel('Peak process RSS (MiB)')
 axes[0,col].set_title('Original settings' if col==0 else 'Supplement: full-resolution fine search')
axes[0,0].legend(loc='upper left',fontsize=9)
fig.suptitle('Stage 40 — exact NCC work distribution on Metal',fontweight='bold',y=.99)
fig.text(.5,.015,'Median of 6 measured calls; whiskers: observed min–max. RSS: maximum of 3 fresh processes.\nOriginal 128/512 stop at pyramid layer 1; supplement changes only stop layer to 0. Profiling excluded.',ha='center',fontsize=9)
fig.tight_layout(rect=[0,.07,1,.97]);fig.savefig(out/'comparison.png',dpi=160);plt.close(fig)
# All screening variants remain visible, including slower reused moments.
fig,ax=plt.subplots(figsize=(10,4.4));names=['full_gpu_fine_tiled','full_gpu_u32','full_gpu_moments','full_gpu_simd'];x=np.arange(len(names));w=.32
for j,case in enumerate(summaries['pilot']['cases'][:2]):
 b=case['methods']['full_gpu_tiled']['total_ms']['median']
 ax.bar(x+(j-.5)*w,[case['methods'][n]['total_ms']['median']/b for n in names],w,label=case['name'],color=['#276892','#d67a2e'][j])
ax.axhline(1,color='#555555',lw=1);ax.set_xticks(x,['Row cache','Bounded u32','Reused moments','SIMD32']);ax.set_ylabel('Time / GPU baseline');ax.set_title('Screening only: one measured call per method');ax.legend();ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
fig.tight_layout();fig.savefig(out/'screening.png',dpi=160);plt.close(fig)
print('Six replayable summaries and two figures written')
