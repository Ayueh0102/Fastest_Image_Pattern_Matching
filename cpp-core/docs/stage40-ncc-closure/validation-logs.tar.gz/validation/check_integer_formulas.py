#!/usr/bin/env python3
"""Independent integer formula audit; no GPU, Metal, or production imports."""
import json
import random
from pathlib import Path


def audit():
    rng = random.Random(4017)
    sliding_windows = 0
    for width in range(1, 20):
        for height in range(1, 14):
            image = [[rng.randrange(256) for _ in range(width + 6)] for _ in range(height + 6)]
            for wx in range(7):
                parts = []
                for stripe in range(4):
                    values = [image[p // width][wx + p % width] for p in range(stripe, width * height, 4)]
                    total, square = sum(values), sum(v * v for v in values)
                    offsets = [(total, square)]
                    for wy in range(1, 7):
                        outgoing, incoming = wy - 1, wy + height - 1
                        for x in range((stripe - (outgoing * width & 3)) & 3, width, 4):
                            v = image[outgoing][wx + x]
                            total -= v
                            square -= v * v
                            assert total >= 0 and square >= 0
                        for x in range((stripe - (incoming * width & 3)) & 3, width, 4):
                            v = image[incoming][wx + x]
                            total += v
                            square += v * v
                        offsets.append((total, square))
                    parts.append(offsets)
                for wy in range(7):
                    values = [image[wy + y][wx + x] for y in range(height) for x in range(width)]
                    assert sum(p[wy][0] for p in parts) == sum(values)
                    assert sum(p[wy][1] for p in parts) == sum(v * v for v in values)
                    sliding_windows += 1

    # The production SIMD shuffle reduction observes only lanes 0..3. Values
    # returned for an out-of-range source lane are unspecified; simulate two
    # deliberately different choices and require identical observed lanes.
    simd_trials = 0
    max_u32 = (1 << 32) - 1
    areas = [1, 2, 3, 4, 5, 31, 32, 33, 63, 64, 65, 16384, 264204]
    for area in areas:
        for white in (False, True):
            pixels = [255 if white else rng.randrange(256) for _ in range(area)]
            template = [255 if white else rng.randrange(256) for _ in range(area)]
            contributions = (pixels, [v * v for v in pixels], [v * t for v, t in zip(pixels, template)])
            for values in contributions:
                reference = [sum(values[k::4]) for k in range(4)]
                assert max(reference) <= max_u32
                for undefined_value in (0, max_u32):
                    lanes = [sum(values[k::32]) for k in range(32)]
                    for offset in (16, 8, 4):
                        lanes = [(v + (lanes[k + offset] if k + offset < 32 else undefined_value)) & max_u32
                                 for k, v in enumerate(lanes)]
                    assert lanes[:4] == reference
                    simd_trials += 1
    assert max_u32 // (255 * 255) == 66051
    assert ((264204 + 3) // 4) * 65025 <= max_u32
    assert ((264205 + 3) // 4) * 65025 > max_u32
    return {
        "pass": True,
        "seed": 4017,
        "sliding_dimensions": 247,
        "sliding_windows": sliding_windows,
        "simd_reduction_trials": simd_trials,
        "max_safe_stripe_pixels": 66051,
        "max_safe_stripe_square": 66051 * 65025,
        "first_unsafe_stripe_square": 66052 * 65025,
        "guard_last_safe_area": 264204,
        "guard_first_unsafe_area": 264205,
        "scope": "Integer formulas only; GPU execution, sampling, performance and host fallback are separate checks.",
    }


if __name__ == "__main__":
    result = audit()
    Path(__file__).with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
