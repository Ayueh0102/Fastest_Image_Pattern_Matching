"""Five-minute Stage-40 SIMD integrity soak; not a formal speed benchmark.

Run serially after formal GPU jobs. Full output vectors are archived for the
first call only. The unchanged native runner compares every streamed call's
complete ordered matches AND proposals to that first call and emits `exact`.
This parent independently evaluates first-call GT, checks it against formal
baseline output, and validates every streamed telemetry/residency record.
"""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import statistics
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT/'cpp-core/tools'))
import benchmark_gpu_ncc_closure as bench

CASE = 'many512_pose'
METHOD = 'full_gpu_simd'
DURATION_SECONDS = 300.


def nonnegative(value, label):
    return bench.previous.finite_nonnegative(value, label)


def integer(value, label):
    return bench.integer(value, label)


def audit_telemetry(row):
    # The telemetry-only JSONL intentionally omits pose vectors. Empty arrays
    # are used solely to invoke the unchanged timing/route field validator;
    # no per-row independent GT or raw-vector parity is inferred from them.
    route = bench.previous.validate_record(dict(row, matches=[], proposals=[]), True)
    bench.fine_work_record(row, False)
    bench.profile_record(row, False)
    gpu = row['full_gpu']
    return bool(route and gpu['peak_mode'] == 1 and gpu['fine_mode'] == 4 and
                gpu['fine_effective_mode'] == 4 and gpu['fine_simd_width'] == 32)


def audit_result(worker, rows, case, baseline, repeats):
    if not rows:
        raise ValueError('No soak telemetry rows')
    first = worker['first']
    bench.previous.validate_record(first, True)
    first_route = audit_telemetry(first)
    truth = bench.evaluate(first['matches'], case['truth'])['strict']
    gt_pass = truth['fp'] == truth['fn'] == 0
    matches_equal = first['matches'] == baseline['matches']
    proposals_equal = first['proposals'] == baseline['proposals']
    count = integer(worker.get('calls'), 'calls')
    contexts = integer(worker.get('contexts_recreated'), 'contexts_recreated')
    nonnegative(worker.get('duration_ms'), 'duration_ms')
    if count != len(rows) or count < repeats or count < 101:
        raise ValueError('Call count differs from streamed rows or minimum repetitions')
    if contexts != (count-1)//100 or contexts < 1:
        raise ValueError('Context recreation count differs from the 100-call schedule')
    if worker['duration_ms'] < DURATION_SECONDS*1000:
        raise ValueError('Soak ended before the preregistered five minutes')
    for field in ('exact', 'drained'):
        if type(worker.get(field)) is not bool:
            raise ValueError('Missing '+field+' Boolean')
    all_exact = worker['exact']
    all_routes = first_route
    rss, peak, gpu_bytes, durations = [], [], [], []
    named_fields = ('gpu_bytes', 'peak_scratch_bytes', 'fine_diagnostic_bytes',
                    'profile_counter_bytes', 'profile_resolve_bytes', 'fine_threadgroup_bytes')
    named = {field: [] for field in named_fields}
    elapsed = -1.
    for index, row in enumerate(rows):
        if integer(row.get('call'), 'call') != index:
            raise ValueError('JSONL call order is not contiguous')
        context = integer(row.get('context_index'), 'context_index')
        if context != index//100:
            raise ValueError('Unexpected per-row context index')
        if type(row.get('exact')) is not bool:
            raise ValueError('Missing per-row exact Boolean')
        all_exact = all_exact and row['exact']
        all_routes = audit_telemetry(row) and all_routes
        row_elapsed = nonnegative(row.get('elapsed_ms'), 'elapsed_ms')
        if row_elapsed <= elapsed:
            raise ValueError('Nonincreasing elapsed clock')
        elapsed = row_elapsed
        recreation = nonnegative(row.get('recreate_ms'), 'recreate_ms')
        if bool(recreation) != bool(index and index % 100 == 0):
            raise ValueError('Context recreation duration differs from recreation schedule')
        current = integer(row['memory'].get('current_rss_bytes'), 'current_rss_bytes')
        high = integer(row['memory'].get('peak_rss_bytes'), 'peak_rss_bytes')
        if current <= 0 or high < current:
            raise ValueError('Current RSS unavailable or exceeds peak RSS')
        rss.append(current)
        peak.append(high)
        durations.append(row['total_ms'])
        for field in named_fields:
            named[field].append(integer(row['full_gpu'].get(field), field))
        gpu_bytes.append(row['full_gpu']['gpu_bytes'])
    if worker['duration_ms'] < elapsed:
        raise ValueError('Summary duration is shorter than its last streamed record')
    for memory in (worker['before'], worker['after'], first['memory']):
        integer(memory['peak_rss_bytes'], 'peak_rss_bytes')
        integer(memory['current_rss_bytes'], 'current_rss_bytes')
    initial, last = statistics.median(rss[:10]), statistics.median(rss[-10:])
    tolerance = max(8*1024**2, .1*initial)
    memory_pass = last <= initial+tolerance
    named_stable = len(set(gpu_bytes)) == 1 and gpu_bytes[0] == first['full_gpu']['gpu_bytes']
    gates = dict(independent_first_ground_truth=gt_pass,
        first_ordered_matches_equal_formal_baseline=matches_equal,
        first_ordered_proposals_equal_formal_baseline=proposals_equal,
        all_streamed_exact_attestations=all_exact,
        all_rows_resident_and_requested_simd_executed=all_routes,
        drained=worker['drained'], memory_drift_within_budget=memory_pass,
        named_gpu_allocation_constant=named_stable)
    return dict(case=CASE, method=METHOD, phase='five_minute_integrity_soak',
        formal_speed_evidence=False, elapsed_ms=worker['duration_ms'], calls=count,
        initial_calls=1, total_algorithm_calls_including_first=count+1,
        contexts_recreated=contexts, total_contexts=contexts+1, first_accuracy=truth,
        gates=gates, all_gates_pass=all(gates.values()),
        failed_gates=[name for name, passed in gates.items() if not passed],
        rss=dict(first10_median_bytes=initial, last10_median_bytes=last,
            last_minus_first_bytes=last-initial, last_minus_first_percent=100*(last/initial-1),
            permitted_growth_bytes=tolerance, first10_values=rss[:10], last10_values=rss[-10:],
            peak_bytes=max([*peak, worker['before']['peak_rss_bytes'], worker['after']['peak_rss_bytes'], first['memory']['peak_rss_bytes']]),
            min_current_bytes=min(rss), max_current_bytes=max(rss)),
        named_allocations={field: dict(values=sorted(set(values)), min=min(values), max=max(values),
                                      first=values[0], last=values[-1]) for field, values in named.items()},
        observed_total_ms=dict(median=statistics.median(durations), min=min(durations), max=max(durations)),
        parity_scope='First full ordered matches AND proposals compared independently to formal mode-0 GPU result. Every JSONL row carries the native runner exact-equality attestation against that first result; repeated full vectors are not archived.',
        accuracy_scope='Independent GT applies directly to the archived first output. Subsequent outputs are covered by native exact comparison; no independent GT reconstruction from telemetry is claimed.',
        memory_scope='RSS is whole-process memory. gpu_bytes is retained named Metal buffer lengths; scratch/diagnostic allocations are subsets. Static threadgroup storage, counter capacity and transient CPU resolve payload are separate scopes, not additive.',
        limitation='Five minutes on one fixed 512-object scene, including at least one teardown/recreation, is bounded integrity evidence and not long-term stability, real-video or cross-device proof.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--formal', type=Path, default=ROOT/'build/stage40-ncc-closure/formal/manifest.json')
    parser.add_argument('--build', type=Path, default=ROOT/'build/fourier-gpu')
    parser.add_argument('--output', type=Path, default=ROOT/'build/stage40-ncc-closure/soak/manifest.json')
    parser.add_argument('--repeats', type=int, default=101)
    parser.add_argument('--timeout', type=float, default=900.)
    args = parser.parse_args()
    if args.repeats < 101 or args.repeats > 10000 or not 300 < args.timeout <= 3600:
        parser.error('repeats must be 101..10000 and timeout must be >300 and <=3600 seconds')
    output = args.output.resolve()
    root = output.parent
    files = {name: root/filename for name, filename in {
        'job':'job.json', 'stream':'rows.jsonl', 'stdout':'stdout.json', 'stderr':'stderr.txt',
        'summary':'summary.json'}.items()}
    if output.exists() or any(path.exists() for path in files.values()):
        raise ValueError('Refusing to overwrite soak artifacts')
    formal = json.loads(args.formal.read_text())
    if formal.get('phase') != 'formal':
        raise ValueError('Reference must be a completed formal run')
    # Verify every archived job/result, declared mode, shared setting, and hash.
    formal_summary = bench.summarize(formal, args.formal.resolve().parent)
    case = next(case for case in formal['cases'] if case['name'] == CASE)
    entry = next(entry for entry in formal['executions']
                 if entry['case'] == CASE and entry['method'] == bench.BASELINE and entry['block'] == 0)
    baseline_path = bench.previous.worker_path(args.formal.resolve().parent, entry['result'])
    baseline = json.loads(baseline_path.read_text())['first']
    binary = (args.build/'experiments/fpm_native_pipeline_runner').resolve()
    before = bench.previous.fingerprints(binary, [case])
    if before['source_sha256'] != formal['source_sha256'] or before['binary_sha256'] != formal['binary_sha256']:
        raise ValueError('Source or binary differs from formal reference')
    if any(formal['input_sha256'].get(path) != digest for path, digest in before['input_sha256'].items()):
        raise ValueError('Soak input differs from formal reference')
    script_hash = bench.sha(Path(__file__).resolve())
    work = bench.job(case, METHOD, args.repeats, 0., False)
    work.update(soak_seconds=DURATION_SECONDS, stream_path=str(files['stream']))
    bench.save(files['job'], work)
    manifest = dict(version=1, phase='five_minute_integrity_soak', complete=False,
        started_utc=datetime.now(timezone.utc).isoformat(), case=case, method=METHOD,
        requested_seconds=DURATION_SECONDS, repeats=args.repeats, warmup_seconds=0., timeout_seconds=args.timeout,
        job=str(files['job'].relative_to(root)), job_sha256=bench.sha(files['job']),
        formal_manifest=str(args.formal.resolve()), formal_manifest_sha256=bench.sha(args.formal),
        formal_baseline_result=str(baseline_path), formal_baseline_result_sha256=bench.sha(baseline_path),
        validation_script=str(Path(__file__).resolve()), validation_script_sha256=script_hash, **before)
    bench.save(output, manifest)
    try:
        # Stream the worker to disk; its JSONL is flushed on every call. No
        # unbounded capture buffer obscures the worker memory measurement.
        with files['stdout'].open('w') as stdout, files['stderr'].open('w') as stderr:
            child = subprocess.run([str(binary), str(files['job'])], stdout=stdout, stderr=stderr, timeout=args.timeout)
        if child.returncode:
            raise RuntimeError('Soak worker failed with exit status '+str(child.returncode))
        worker = json.loads(files['stdout'].read_text())
        rows = [json.loads(line) for line in files['stream'].read_text().splitlines() if line.strip()]
        summary = audit_result(worker, rows, case, baseline, args.repeats)
        after = bench.previous.fingerprints(binary, [case])
        unchanged = before == after and bench.sha(Path(__file__).resolve()) == script_hash
        summary['unchanged_fingerprints'] = unchanged
        summary['all_gates_pass'] = summary['all_gates_pass'] and unchanged
        if not unchanged:
            summary['failed_gates'].append('unchanged_fingerprints')
        bench.save(files['summary'], summary)
        manifest.update(complete=True, unchanged=unchanged, after_sha256=after,
            finished_utc=datetime.now(timezone.utc).isoformat(), summary=summary,
            artifacts={name: dict(path=str(path.relative_to(root)), sha256=bench.sha(path), bytes=path.stat().st_size)
                       for name, path in files.items()})
        bench.save(output, manifest)
        print(json.dumps(dict(output=str(output), passed=summary['all_gates_pass'], calls=summary['calls'],
            contexts_recreated=summary['contexts_recreated'], rss=summary['rss']), indent=2))
        if not summary['all_gates_pass']:
            raise RuntimeError('Soak completed with failed gates: '+','.join(summary['failed_gates']))
    except Exception as error:
        manifest['failure'] = dict(type=type(error).__name__, message=str(error))
        manifest['artifacts'] = {name: dict(path=str(path.relative_to(root)), sha256=bench.sha(path), bytes=path.stat().st_size)
                                for name, path in files.items() if path.exists()}
        bench.save(output, manifest)
        raise


if __name__ == '__main__':
    main()
