from pathlib import Path
import hashlib,json,subprocess,shutil
root=Path.cwd();review=root/'build/stage40-review';original=root/'build/stage40-ncc-closure/formal'
binary=review/'release/experiments/fpm_native_pipeline_runner';out=root/'build/stage40-ncc-closure/validation/rebuilt';out.mkdir(exist_ok=True)
checks=[]
for case,method in [('controlled6',m) for m in ('hybrid_best','full_gpu_tiled','full_gpu_u32','full_gpu_simd')]+[('many512_pose','full_gpu_simd')]:
 label=case+'-'+method+'-b0';job=json.loads((original/'jobs'/(label+'.json')).read_text())
 for key in ('source','template'):
  src=Path(job[key]);dst=review/'source'/src.relative_to(root);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
  assert hashlib.sha256(src.read_bytes()).digest()==hashlib.sha256(dst.read_bytes()).digest()
  job[key]=str(dst)
 job.update(repeats=1,warmup_seconds=0)
 jp=out/(label+'-job.json');jp.write_text(json.dumps(job,indent=2)+'\n')
 child=subprocess.run([str(binary),str(jp)],capture_output=True,text=True,timeout=120)
 (out/(label+'.stderr.txt')).write_text(child.stderr);(out/(label+'.stdout.txt')).write_text(child.stdout)
 assert child.returncode==0,(label,child.stderr)
 result=json.loads(child.stdout);(out/(label+'.json')).write_text(json.dumps(result,indent=2)+'\n')
 expected=json.loads((original/'results'/(label+'.json')).read_text())['first']
 for run in [result['first'],*result['runs']]:
  for key in ('matches','proposals'):assert run[key]==expected[key],(label,key)
 checks.append({'case':case,'method':method,'calls':2,'ordered_matches_and_proposals_exact':True})
summary={'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'checks':checks,'total_calls':10,'scope':'Clean frozen source rebuild; full6object4methods and512objectSIMD4 outputs compared with formal first output. Inputs copied and SHA256 checked.'}
(out/'parity.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
