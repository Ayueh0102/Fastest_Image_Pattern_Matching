"""Archive native GUI study with immutable measured sources and raw results."""
import gzip,hashlib,json,shutil,tarfile,subprocess,sys
from pathlib import Path
root=Path.cwd().resolve();data=root/'build/gui-integration-results';dest=root/'cpp-core/docs/gui-integration';folder=root/'build/gui-integration-archive'
folder.mkdir(exist_ok=True);dest.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def copy(src,dst):dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
r=json.loads((data/'formal.json').read_text());assert r['complete'] and r['unchanged'] and r['summary']['correctness_passed']
assert all(sha(p)==h for group in ('source_sha256','binary_sha256','input_sha256') for p,h in r[group].items())
old_path=root/'build/coarse-tiling-results/formal.json'
old=json.loads(old_path.read_text())
frozen={p:h for p,h in r['binary_sha256'].items() if '/build/coarse-tiling/' in p}
assert len(frozen)==3 and all(old['library_hashes'][p]==h for p,h in frozen.items())
copy(old_path,folder/'baseline-provenance.json')
for e in r['execution_order']:
 assert sha(data/e['job'])==e['job_sha256'] and sha(data/e['result'])==e['sha256']
 job=json.loads((data/e['job']).read_text());assert 'truth' not in job and 'truth' not in job.get('case',{})
 worker=json.loads((data/e['result']).read_text())
 if e['method'].startswith('python_'):
  assert all(w['output_sha256']==worker['first']['output_sha256'] and not w['profile_errors'] for w in worker['warmups'])
 for call in [worker['first'],*worker['runs']]:
  for output in ('matches','proposals'):
   assert all(len(m['corners'])==4 and all(len(p)==2 for p in m['corners']) for m in call[output])
for name in ('formal','pilot','pilot-fixed'):
 copy(data/(name+'.json'),folder/(name+'.json'))
 shutil.copytree(data/(name+'-jobs'),folder/(name+'-jobs'),dirs_exist_ok=True)
for p in data.glob('soak*'):
 if p.is_file():copy(p,folder/p.name)
for p in sorted((root/'build').glob('gui-integration*.log')):copy(p,folder/'logs'/p.name)
for name in ('gui-integration','gui-integration-sanitized','gui-integration-cpu-gui'):
 copy(root/'build'/name/'CMakeCache.txt',folder/'build-provenance'/name/'CMakeCache.txt')
 for p in (root/'build'/name/'CMakeFiles').glob('*/CMakeCXXCompiler.cmake'):copy(p,folder/'build-provenance'/name/'CMakeCXXCompiler.cmake')
source_map={}
for p,h in r['source_sha256'].items():
 dst=folder/'measured-sources'/Path(p).relative_to(root);copy(p,dst);assert sha(dst)==h;source_map[str(dst.relative_to(folder))]=h
save(folder/'measured-source-sha256.json',source_map)
for c in r['cases']:
 if c.get('metadata'):copy(Path(c['metadata']),folder/'input-metadata'/Path(c['metadata']).name)
for p in (root/'cpp-core/tests').glob('*'):
 if p.is_file():copy(p,folder/'supplementary/tests'/p.name)
for p in (root/'macos-cli').glob('*'):
 if p.is_file() and p.suffix in ('.cpp','.h'):copy(p,folder/'supplementary/gui'/p.name)
copy(root/'cpp-core/CMakeLists.txt',folder/'supplementary/CMakeLists.txt')
copy(Path(__file__),folder/'supplementary/archive_gui_integration.py')
copy(root/'build/plot_gui_integration.py',folder/'supplementary/plot_gui_integration.py')
copy(root/'build/derive_gui_diagnostics.py',folder/'supplementary/derive_gui_diagnostics.py')
copy(dest/'diagnostics.json',folder/'diagnostics.json')
copy(dest/'validation.json',folder/'validation.json')
copy(root/'build/gui-integration-ui.png',dest/'gui.png')
for name in ('soak128','soak6'):
 soak=json.loads((data/(name+'.json')).read_text());assert soak['passed']
 assert all(sha(p)==h for p,h in soak['sha256'].items())
 copy(data/(name+'.json'),dest/(name+'.json'))
# Replay reads exclusively relative archived jobs and results, not live paths.
cmd=[sys.executable,str(folder/'measured-sources/cpp-core/tools/benchmark_native_pipeline.py'),'--summarize',str(folder/'formal.json'),'--worker-root',str(folder),'--output',str(folder/'replayed-summary.json')]
subprocess.run(cmd,check=True,cwd="/tmp");assert json.loads((folder/'replayed-summary.json').read_text())==r['summary']
copy(folder/'replayed-summary.json',dest/'results.json')
(folder/'README.txt').write_text('''Native C++ GUI / NCC tiling + overlap study, 2026-10-14.
formal.json holds the immutable source/library/input SHA-256, cases and execution
order. Sources are archived verbatim; build flags, all worker outputs, pilot
results, soak streams, failed diagnostics and successful reruns are retained.
Large deterministic input PNGs and local binaries are omitted. Original Test
Images remain in Git; generators and input hashes are archived. Build paths in
old records are historical, not instructions for relocated replay.

Replay from any directory with the repository Python environment:
python cpp-core/tools/benchmark_native_pipeline.py --summarize EXTRACT/formal.json
  --worker-root EXTRACT --output /tmp/replay.json
Output must byte-match replayed-summary.json. sha256.json covers every member
except itself. The external artifact-sha256.json covers the gzip and manifest.

Timing excludes decode and one-time model setup; first/warmup are separate,
frame.prepare is in every algorithm interval. proposal_ms INCLUDES prepare_ms.
All GT stays in the parent. Python/native port tolerance is 1e-5; native routes
are exact. RSS is process memory, not GPU-exclusive memory. Do not add unified
memory buffers to RSS. Bounded soak is not proof of leak freedom or 24h uptime.
The GUI screenshot is a synthetic two-scale integration fixture.
''')
manifest={str(p.relative_to(folder)):sha(p) for p in sorted(folder.rglob('*')) if p.is_file() and p!=folder/'sha256.json'};save(folder/'sha256.json',manifest)
archive=dest/'raw-results.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for p in sorted(folder.rglob('*')):
    if p.is_file():
     info=tar.gettarinfo(str(p),arcname=str(p.relative_to(folder)));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
     with p.open('rb') as src:tar.addfile(info,src)
with tarfile.open(archive,'r:gz') as tar:
 assert set(tar.getnames())==set(manifest)|{'sha256.json'}
 for name,h in manifest.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==h
validation=dict(complete=True,formal_workers=len(r['execution_order']),measured_calls=r['repeats']*len(r['execution_order']),first_calls=len(r['execution_order']),all_source_binary_input_job_result_hashes_valid=True,frozen_libraries_match_previous_study=True,all_workers_exclude_ground_truth=True,python_warmup_digests_match_first=True,all_output_geometry_shapes_valid=True,relocated_summary_identical=True,archive_files=len(manifest),archive_bytes=archive.stat().st_size,archive_sha256=sha(archive),manifest_sha256=sha(folder/'sha256.json'),replayed_summary_sha256=sha(folder/'replayed-summary.json'))
save(dest/'artifact-sha256.json',validation);print(json.dumps(validation,indent=2))
