import json,statistics,hashlib
from pathlib import Path
root=Path('build/gui-integration-results');report=json.loads((root/'formal.json').read_text());out={}
keys=('device_ms','wait_ms','copy_ms','normalization_ms','async_device_ms','async_wait_ms','async_maps','async_fallback_maps')
for c in report['summary']['cases']:
 out[c['name']]={}
 for m in ('native_original','native_tile','native_combined'):
  runs=[]
  for e in report['execution_order']:
   if e['case']==c['name'] and e['method']==m:
    p=root/e['result'];assert hashlib.sha256(p.read_bytes()).hexdigest()==e['sha256'];runs+=json.loads(p.read_text())['runs']
  out[c['name']][m]={k:statistics.median(sum(w[k] for w in r['work']) for r in runs) for k in keys}
Path('cpp-core/docs/gui-integration/diagnostics.json').write_text(json.dumps(out,indent=2)+'\n')
