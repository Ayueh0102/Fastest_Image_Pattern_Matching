import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
r=json.loads(Path('build/gui-integration-results/formal.json').read_text())
assert r['complete']
cases=r['summary']['cases'];dest=Path('cpp-core/docs/gui-integration')
methods=['python_frozen','python_reference','native_original','native_tile','native_overlap','native_combined']
labels=['Py frozen','Py current','C++ base','C++ tile','C++ overlap','C++ both']
colors=['#a5aab3','#77818f','#3d5f8b','#439a95','#b29447','#815d9d']
names=['6 objects','12 objects','8K / three scales','Small / full resolution','128 objects','512 objects']
for field,name,ylabel in [('total_ms','timing','Algorithm time (ms)'),('rss_bytes','memory','Fresh-process peak RSS (MiB)')]:
 fig,axes=plt.subplots(2,3,figsize=(13,7.3));fig.suptitle('Native GUI pipeline: same candidates and detection results',fontsize=15,y=.99)
 for ax,c,title in zip(axes.flat,cases,names):
  import statistics
  values=[c['methods'][m]['total_ms']['median'] if field=='total_ms' else statistics.median(c['methods'][m]['rss_bytes'])/2**20 for m in methods]
  ax.bar(range(6),values,color=colors,width=.74)
  # Dots show the two independent block medians / peak-RSS samples.
  for i,m in enumerate(methods):
   dots=[b['total_ms'] for b in c['methods'][m]['blocks']] if field=='total_ms' else [x/2**20 for x in c['methods'][m]['rss_bytes']]
   ax.scatter([i-.07,i+.07],dots,c='#202a33',s=12,zorder=3)
  ax.set_title(title,fontsize=12,loc='left');ax.set_ylim(0,max(max(values),max(line.get_offsets()[:,1].max() for line in ax.collections))*1.17)
  ax.set_xticks(range(6),labels,rotation=28,ha='right',fontsize=8);ax.set_ylabel(ylabel,fontsize=9)
  ax.grid(axis='y',alpha=.18);ax.set_axisbelow(True);ax.spines[['right','top']].set_visible(False)
  for i,v in enumerate(values):ax.text(i,v+ax.get_ylim()[1]*.017,f'{v:.1f}',ha='center',fontsize=8)
 fig.text(.015,.018,'Bars: pooled median; dots: two serial blocks. Decode/setup excluded from time. RSS includes process dependencies.\nSmall-case combined mode failed one per-block latency gate; bounded soak results are separate.',fontsize=9,color='#424b54')
 fig.tight_layout(rect=[0,.07,1,.96]);fig.savefig(dest/(name+'.png'),dpi=180);plt.close(fig)
paths=[Path('build/gui-integration-results')/(n+'.jsonl') for n in ('soak128','soak6')]
if all(p.exists() for p in paths):
 fig,axes=plt.subplots(1,2,figsize=(12,4.3))
 for ax,p,title in zip(axes,paths,['128 objects / 10-minute session','6 objects / 2-minute session']):
  rows=[json.loads(line) for line in p.read_text().splitlines()];x=[r['elapsed_ms']/60000 for r in rows];y=[r['memory']['current_rss_bytes']/2**20 for r in rows]
  ax.plot(x,y,color='#3d5f8b',lw=1.4)
  for r in rows:
   if r['recreate_ms']>0:ax.axvline(r['elapsed_ms']/60000,color='#b29447',alpha=.4,lw=.8)
  ax.set(title=title,xlabel='Elapsed minutes',ylabel='Current process RSS (MiB)');ax.grid(alpha=.16);ax.spines[['top','right']].set_visible(False)
 fig.text(.015,.02,'Thin vertical lines: context recreation every 100 calls. Includes setup, driver and allocator effects; not a leak-freedom proof.',fontsize=9)
 fig.tight_layout(rect=[0,.06,1,1]);fig.savefig(dest/'soak-rss.png',dpi=180);plt.close(fig)
