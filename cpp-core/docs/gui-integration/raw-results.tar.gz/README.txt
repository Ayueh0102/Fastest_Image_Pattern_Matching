Native C++ GUI / NCC tiling + overlap study, 2026-10-14.
formal.json holds the immutable source/library/input SHA-256, cases and execution
order. Sources are archived verbatim; build flags, all worker outputs, pilot
results, soak streams, failed diagnostics and successful reruns are retained.
Large deterministic input PNGs and local binaries are omitted. Original Test
Images remain in Git; generators and input hashes are archived. Build paths in
old records are historical, not instructions for relocated replay.

Replay from any directory with the repository Python environment:
python cpp-core/tools/benchmark_native_pipeline.py --summarize EXTRACT/formal.json
  --worker-root EXTRACT --output /tmp/replay.json
Output must byte-match replayed-summary.json. sha256.json covers every member
except itself. The external artifact-sha256.json covers the gzip and manifest.

Timing excludes decode and one-time model setup; first/warmup are separate,
frame.prepare is in every algorithm interval. proposal_ms INCLUDES prepare_ms.
All GT stays in the parent. Python/native port tolerance is 1e-5; native routes
are exact. RSS is process memory, not GPU-exclusive memory. Do not add unified
memory buffers to RSS. Bounded soak is not proof of leak freedom or 24h uptime.
The GUI screenshot is a synthetic two-scale integration fixture.
