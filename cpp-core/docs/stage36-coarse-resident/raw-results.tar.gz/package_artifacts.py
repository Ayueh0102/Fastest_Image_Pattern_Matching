import hashlib,json,platform,subprocess,tarfile
from pathlib import Path
root=Path.cwd();run=root/'build/stage36-coarse-resident';pub=root/'cpp-core/docs/stage36-coarse-resident'
def save(p,value): p.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
env={'platform':platform.platform()}
for label,command in [('hardware',['sysctl','-n','machdep.cpu.brand_string','hw.memsize','hw.ncpu']),('compiler',['clang++','--version']),('cmake',['cmake','--version'])]:
 child=subprocess.run(command,capture_output=True,text=True,check=True);env[label]=child.stdout.strip()
cache=(root/'build/fourier-gpu/CMakeCache.txt').read_text().splitlines()
env['build_settings']=[line for line in cache if line.startswith(('CMAKE_BUILD_TYPE:','CMAKE_CXX_COMPILER:','CMAKE_OSX_ARCHITECTURES:','FPM_','OpenCV_DIR:','Qt6_DIR:'))]
save(run/'validation/environment.json',env)
raw=[]
for name in ['formal','pilot']:
 raw += [p for p in (run/name).rglob('*') if p.is_file() and 'inputs' not in p.relative_to(run/name).parts]
raw += [run/name for name in ['protocol.json','pilot.log','formal.log','measured-build.diff','source-and-fixtures-sha256.json','replayed-summary.json','package_artifacts.py']]
with tarfile.open(pub/'raw-results.tar.gz','w:gz',compresslevel=9) as tf:
 for p in sorted(raw): tf.add(p,arcname=str(p.relative_to(run)),recursive=False)
# Validation archive is built after offline replay below, so all logs can be kept.
print('Raw files:',len(raw),'MiB:',(pub/'raw-results.tar.gz').stat().st_size/1024**2)
