NCC single-map probe. Formal:54 workers,540 measured calls; setup, first and warmup separate. Pilot is not performance evidence. Every map bitwise checked outside timing. CPU reference evaluated after RSS sampling. FNV is only a convenience digest; archive/worker/source integrity uses SHA256. Binaries omitted; their hashes are in formal.json. Exact source snapshot retained.

Replay: python cpp-core/tools/benchmark_tile_probe.py --summarize /archive/formal.json --worker-root /archive --output /tmp/replay.json
Compare with replayed-summary.json. sha256.json authenticates every other archive member; artifact-sha256.json authenticates compressed archive.
