import gzip,hashlib,json,shutil,tarfile
from pathlib import Path
root=Path.cwd().resolve();data=root/'build/coarse-tiling-probe';folder=root/'build/coarse-tiling-probe-archive';dest=root/'cpp-core/docs/coarse-tiling/probe'
folder.mkdir(exist_ok=True);dest.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def copy(src,dst):dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
p=json.loads((data/'formal.json').read_text());assert p['complete'] and p['sources_unchanged'] and p['summary']['exact']
assert all(sha(f)==h for f,h in {**p['source_hashes'],**p['binary_hashes']}.items())
workers=[]
for e in p['execution_order']:
 assert sha(e['result'])==e['sha256'];workers.append(json.loads(Path(e['result']).read_text()))
for name in ['formal','pilot']:
 copy(data/(name+'.json'),folder/(name+'.json'))
 shutil.copytree(data/(name+'-workers'),folder/(name+'-workers'),dirs_exist_ok=True)
source_map={}
for name,h in p['source_hashes'].items():
 target=folder/'measured-sources'/Path(name).relative_to(root);copy(name,target);assert sha(target)==h;source_map[str(target.relative_to(folder))]=h
save(folder/'measured-source-sha256.json',source_map)
copy(root/'build/coarse-tiling-probe-summary.json',folder/'replayed-summary.json')
copy(Path(__file__),folder/'supplementary/archive_tile_probe.py')
for log in (root/'build').glob('coarse-tiling-probe*.log'):copy(log,folder/'logs'/log.name)
(folder/'README.txt').write_text('NCC single-map probe. Formal:54 workers,540 measured calls; setup, first and warmup separate. Pilot is not performance evidence. Every map bitwise checked outside timing. CPU reference evaluated after RSS sampling. FNV is only a convenience digest; archive/worker/source integrity uses SHA256. Binaries omitted; their hashes are in formal.json. Exact source snapshot retained.\n\nReplay: python cpp-core/tools/benchmark_tile_probe.py --summarize /archive/formal.json --worker-root /archive --output /tmp/replay.json\nCompare with replayed-summary.json. sha256.json authenticates every other archive member; artifact-sha256.json authenticates compressed archive.\n')
manifest={str(f.relative_to(folder)):sha(f) for f in sorted(folder.rglob('*')) if f.is_file() and f.name!='sha256.json'};save(folder/'sha256.json',manifest)
archive=dest/'raw-results.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for f in sorted(folder.rglob('*')):
    if f.is_file():
     info=tar.gettarinfo(str(f),arcname=str(f.relative_to(folder)));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
     with f.open('rb') as source:tar.addfile(info,source)
with tarfile.open(archive,'r:gz') as tar:
 assert set(tar.getnames())==set(manifest)|{'sha256.json'}
 for name,h in manifest.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==h
save(dest/'results.json',p['summary'])
validation=dict(complete=True,exact=True,sources_and_binaries_unchanged=True,worker_count=len(workers),measured_calls=sum(len(w['runs']) for w in workers),first_calls=len(workers),warmup_calls=sum(len(w['warmups']) for w in workers),archive_files=len(manifest),archive_bytes=archive.stat().st_size,archive_sha256=sha(archive),manifest_sha256=sha(folder/'sha256.json'),replayed_summary_sha256=sha(folder/'replayed-summary.json'))
save(dest/'artifact-sha256.json',validation);print(json.dumps(validation,indent=2))
