CPU exact lookup fairness study versus frozen 8e0bd61 CPU.
All routes use compact maps and CPU NCC refinement. Compare atan2 CPU, exact
lookup CPU, and Metal frontend with the same lookup transform. Raw ordered
proposals, work and final poses must match; independent GT is also checked. Negative scale and
unlabelled photo outcomes are preserved. CPU deterministic candidate selection remains; this is not all-GPU search.

Offline replay with NumPy/OpenCV, no GPU required:
python3 EXTRACT/formal/source-snapshot/cpp-core/tools/benchmark_sparse_cpu_lut.py --summarize EXTRACT/formal/results.json --output /tmp/replayed.json

Absolute paths are historical provenance; source snapshots, input fixtures,
protocol, raw worker records and validation logs are archived. Binary hashes
are recorded; executables omitted. All member hashes are in sha256.json.
