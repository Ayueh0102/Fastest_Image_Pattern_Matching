"""Assemble cpp-core/docs/core-exhaustive-ncc evidence from the scratch runs (scratch helper)."""
import hashlib
import io
import json
import shutil
import sys
import tarfile
from pathlib import Path

S, W = Path(sys.argv[1]), Path(sys.argv[2])
X = S / "ncc"
D = W / "cpp-core/docs/core-exhaustive-ncc"
if D.exists():
    shutil.rmtree(D)
for sub in ("formal", "pilot"):
    (D / sub).mkdir(parents=True)
shutil.copy(X / "bench/protocol.json", D / "protocol.json")
for p in sorted((X / "bench").iterdir()):
    if p.name not in ("protocol.json", "summarize.py"):
        shutil.copy(p, D / "formal" / p.name)
shutil.copy(X / "window_micro_g8.cpp", D / "pilot/window_micro.cpp")
shutil.copy(X / "window-micro-g8-rerun.txt", D / "pilot/window-micro-output-rerun.txt")
shutil.copy(X / "pilot-console-transcript.txt", D / "pilot/pilot-console-transcript.txt")
shutil.copy(X / "ncc-pilot1-win4-integer-integral.cpp", D / "pilot/pilot1-ncc.cpp")


def load(path):
    return json.loads(Path(path).read_text())


identity = load(X / "final/identity.json")
mutants = load(X / "mutants/summary.json")
cv = {b: load(X / f"final/compare-versions-{b}.json") for b in ("base", "new")}
gate = (X / "final/gate.log").read_text()
validation = {
    "date": "2026-10-25",
    "head_before_change": "65b7dad11e5aaa9d9c9cca3594568a882280152f",
    "gate_log_sha256": hashlib.sha256(gate.encode()).hexdigest(),
    "ncc_cpp_sha256": gate.split("ncc_sha256=")[1].split()[0],
    "core_test_sha256": gate.split("test_sha256=")[1].split()[0],
    "release_ctest": "3/3 (portable_core incl. NCC/exhaustive/exact-reference, c_abi, opencv_stage_comparison)",
    "no_dotprod_ctest_march_armv8_a": "3/3 (sliding sums with the row-by-row NEON dot product)",
    "scalar_release_ctest_disable_simd": "3/3 (sliding sums with the scalar dot product)",
    "asan_ubsan_scalar_ctest": "2/2 (Debug, FPM_SANITIZERS=ON, FPM_DISABLE_SIMD=ON)",
    "asan_ubsan_simd_ctest": "2/2 (Debug -O0, FPM_SANITIZERS=ON; grouped UDOT windows over the padded copy)",
    "research_ctest": "73/73 (Release, GUI + experiments + OpenCV)",
    "python_harness": "570 tests OK",
    "identity": {"runs": identity["runs"], "different_runs": identity["different_runs"],
                 "libraries": list(identity["libraries"]), "reference": identity["reference"],
                 "cases": len(identity["cases"]), "matches_compared": sum(c["count"] for c in identity["cases"])},
    "compare_versions": {b: {"outside_tolerance": [c["source"] for c in d["cases"]
                                                   if not c["portable_vs_legacy"]["within_tolerance"]],
                             "cases": len(d["cases"])} for b, d in cv.items()},
    "compare_versions_portable_matches_identical_base_vs_new":
        sum(a["portable_cpp"]["matches"] == b["portable_cpp"]["matches"] for a, b in zip(cv["base"]["cases"], cv["new"]["cases"])),
    "compiled_mutants": {k: {"exit": v["exit"], "expected_outcome": v["killed_or_passed"]} for k, v in mutants.items()},
}
(D / "validation.json").write_text(json.dumps(validation, indent=2) + "\n")

formal = load(X / "bench/summary.json")
decision = {
    "adopted": [
        "default exhaustive maps (finite source in binary64 integer range, no bounds, no screen, template height <= 65536) use exhaustiveNcc: uint32 column sums slid vertically and uint64 window sums slid horizontally replace the binary64 integral images",
        "UDOT builds (Backend::Auto, template width <= 4096) compute products of eight adjacent windows per kernel call over a zero-padded template and a tight zero-tailed source copy; groups whose eight denominators are all zero are skipped like the original per-window skip",
        "bounded and screened maps keep the original code path unchanged",
    ],
    "rejected_in_pilot": [
        {"variant": "pilot 1: four-row interleaved whole-window UDOT + uint64 integral images", "reason": "Src7/Src6 only -11%: level-0 templates exceed L1, so every window re-streamed the template; the integral images still wrote 16 bytes per ROI pixel"},
        {"variant": "single-accumulator whole-window UDOT (win1)", "reason": "about 2x slower than row-by-row on wide templates (one long dependency chain)"},
        {"variant": "eight-row interleave (win8)", "reason": "no better than four rows"},
    ],
    "failures_and_caveats": [
        "two early profiling attempts were invalid (duplicated dot calls merged by the compiler; a patch that did not apply); both are disclosed in pilot/pilot-console-transcript.txt and superseded",
        "pilot timings were printed to the console only; they are transcribed verbatim in pilot/pilot-console-transcript.txt; the window microbenchmark was rerun once to archive its output",
        "the grouped kernel reads up to 22 bytes past a window inside a private zero-tailed copy; mutant N6 (no tail) is caught only by ASan",
        "Backend::Scalar also changes how window sums are formed (exact integer sliding sums), so portable_scalar mode is faster (-11.6%); its dot product is unchanged",
        "the integer code is platform independent; x86 was not run",
        "other Claude/Codex processes were active; load averages recorded per session (1-minute 3.7-4.4)",
        "only one Apple M4 Pro",
    ],
    "formal_benchmark_modes": formal["benchmark_modes"],
    "formal_fixtures_ab_geomean_ratio": formal["fixtures_ab"]["geomean_ratio"],
}
(D / "decision-and-failures.json").write_text(json.dumps(decision, indent=2) + "\n")

members = {
    "instrumented/ncc-65b7dad-instrumented.cpp": X / "instr/cpp-core/src/ncc.cpp",
    "instrumented/ncc-pilot1-instrumented.cpp": X / "instr2/cpp-core/src/ncc.cpp",
    "final/gate.sh": X / "final/gate.sh", "final/gate.log": X / "final/gate.log",
    "final/identity.json": X / "final/identity.json",
    "final/compare-versions-base.json": X / "final/compare-versions-base.json",
    "final/compare-versions-new.json": X / "final/compare-versions-new.json",
    "final/mutants/summary.json": X / "mutants/summary.json",
    "tools/run_mutants_ncc.py": X / "run_mutants_ncc.py",
    "tools/summarize.py": X / "bench/summarize.py",
    "tools/assemble.py": X / "assemble.py",
    "tools/profile_loop.py": S / "final/profile/loop.py",
}
for p in sorted((X / "final/logs").iterdir()):
    members[f"final/logs/{p.name}"] = p
for m in sorted((X / "mutants").glob("[MN]*")):
    members[f"final/mutants/{m.name}.log"] = m / "log.txt"
for folder in ("profile-before", "profile-after"):
    for p in sorted((X / folder).glob("sample-*.txt")):
        members[f"{folder}/{p.name}"] = p
with tarfile.open(D / "validation-logs.tar.gz", "w:gz") as tar:
    for name, path in sorted(members.items()):
        data = Path(path).read_bytes()
        info = tarfile.TarInfo(name)
        info.size, info.mtime, info.mode = len(data), 0, 0o644
        tar.addfile(info, io.BytesIO(data))
files = sorted(p for p in D.rglob("*") if p.is_file() and p.name != "archive.json")
(D / "archive.json").write_text(json.dumps({str(p.relative_to(D)): hashlib.sha256(p.read_bytes()).hexdigest()
                                            for p in files}, indent=2) + "\n")
print("files", len(files), "bytes", sum(p.stat().st_size for p in files))
