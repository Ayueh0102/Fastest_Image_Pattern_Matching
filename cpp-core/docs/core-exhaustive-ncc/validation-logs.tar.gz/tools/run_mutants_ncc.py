"""Compiled mutants for the exhaustive NCC changes (scratch).

Usage: run_mutants.py <worktree> <scratch dir>
Each mutant replaces one anchor (asserted to occur exactly once) in a copy of
cpp-core/src/ncc.cpp, rebuilds fpm_core_test (Release, or Debug+ASan/UBSan), and must make it fail.
The unmutated copy is built and must pass first.
"""
import json
import shutil
import subprocess
import sys
from pathlib import Path

MUTANTS = {
    "N1_lane_offset": ("a7 = vdotq_u32(a7, tb, vld1q_u8(p + b + 7));", "a7 = vdotq_u32(a7, tb, vld1q_u8(p + b + 6));", "release"),
    "N2_no_flush": ("if ((pending += blocks) >= 256) {\n\t\t\ttotal[0]", "if ((pending += blocks) >= (1 << 30)) {\n\t\t\ttotal[0]", "release"),
    "N3_skip_wrong_groups": ("needed |= denominators[k] != 0;", "needed |= denominators[k] == 0;", "release"),
    "N4_column_not_removed": ("columns[x] = columns[x] + added[x] - removed[x];", "columns[x] = columns[x] + added[x];", "release"),
    "N5_slide_wrong_column": ("sum = sum + columns[x + tw - 1] - columns[x - 1];", "sum = sum + columns[x + tw - 1] - columns[x];", "release"),
    "N6_no_zero_tail": ("source.assign(std::size_t(src.width) * src.height + row + 8, 0);", "source.assign(std::size_t(src.width) * src.height, 0);", "asan"),
    "N7_bounds_take_exhaustive": ("if (integerRange && !useBounds && !screened && t.height() <= 65536) {", "if (integerRange && !screened && t.height() <= 65536) {", "release"),
}


def build_and_test(src: Path, build: Path, log: Path, mode: str = "release") -> int:
    with log.open("w") as out:
        subprocess.run(["cmake", "-S", str(src / "cpp-core"), "-B", str(build)] + (["-DCMAKE_BUILD_TYPE=Release"] if mode == "release" else ["-DCMAKE_BUILD_TYPE=Debug", "-DFPM_SANITIZERS=ON"]),
                       stdout=out, stderr=subprocess.STDOUT, check=True)
        subprocess.run(["cmake", "--build", str(build), "--target", "fpm_core_test", "-j", "8"],
                       stdout=out, stderr=subprocess.STDOUT, check=True)
        return subprocess.run([str(build / "fpm_core_test")], stdout=out, stderr=subprocess.STDOUT).returncode


def main():
    worktree, scratch = Path(sys.argv[1]), Path(sys.argv[2])
    scratch.mkdir(parents=True, exist_ok=True)
    original = (worktree / "cpp-core/src/ncc.cpp").read_text()
    results = {}
    for name in ["M0_unmutated", *MUTANTS]:
        src = scratch / name / "src"
        if src.exists():
            shutil.rmtree(src)
        for part in ("cpp-core/src", "cpp-core/include", "cpp-core/tests", "cpp-core/tools", "cpp-core/examples"):
            shutil.copytree(worktree / part, src / part)
        shutil.copy(worktree / "cpp-core/CMakeLists.txt", src / "cpp-core/CMakeLists.txt")
        shutil.copytree(worktree / "macos-cli", src / "macos-cli")
        shutil.copy(worktree / "LICENSE", src / "LICENSE")
        text = original
        if name in MUTANTS:
            old, new, mode = MUTANTS[name]
            assert original.count(old) == 1, (name, original.count(old))
            text = original.replace(old, new)
        (src / "cpp-core/src/ncc.cpp").write_text(text)
        status = build_and_test(src, scratch / name / "build", scratch / name / "log.txt", MUTANTS[name][2] if name in MUTANTS else "release")
        tail = (scratch / name / "log.txt").read_text().strip().splitlines()[-1]
        expected_fail = name != "M0_unmutated"
        results[name] = {"exit": status, "killed_or_passed": (status != 0) == expected_fail, "last_line": tail}
        print(name, results[name], flush=True)
    (scratch / "summary.json").write_text(json.dumps(results, indent=2) + "\n")
    return int(not all(r["killed_or_passed"] for r in results.values()))


if __name__ == "__main__":
    sys.exit(main())
