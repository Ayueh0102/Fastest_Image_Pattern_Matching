from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();src=root/'build/stage39-review/source';raw=root/'build/stage39-review/raw';out=root/'cpp-core/docs/stage39-fine-tiles';result={}
count=0
for name in ('source-sha256.json','input-sha256.json'):
 for path,digest in json.loads((out/name).read_text()).items():
  assert hashlib.sha256((src/path).read_bytes()).hexdigest()==digest,path
  count+=1
for name,formal in [('formal',None),('profile','formal'),('stop0-formal',None),('stop0-profile','stop0-formal'),('8k-profile','formal')]:
 destination=root/'build/stage39-review'/(name+'-replay.json')
 command=[str(root/'python-port/venv/bin/python'),str(src/'cpp-core/tools/benchmark_gpu_fine_tiles.py'),'--summarize',str(raw/name/'manifest.json'),'--output',str(destination)]
 if formal:command+=['--unprofiled-manifest',str(raw/formal/'manifest.json')]
 child=subprocess.run(command,capture_output=True,text=True,timeout=120)
 assert child.returncode==0,(name,child.stderr)
 assert destination.read_bytes()==(out/(name+'-summary.json')).read_bytes(),name
 result[name]={'byte_identical':True,'sha256':hashlib.sha256(destination.read_bytes()).hexdigest()}
audit={'source_and_input_files_verified':count,'all_hashes_match':True,'replay':result,'scope':'Extractedsourceandrawarchive, frozenharness, eachfileSHA256; fiveJSONsummariesbyteidentical'}
(root/'build/stage39-fine-tiles/validation/archive-replay.json').write_text(json.dumps(audit,indent=2)+'\n');print(json.dumps(audit))
