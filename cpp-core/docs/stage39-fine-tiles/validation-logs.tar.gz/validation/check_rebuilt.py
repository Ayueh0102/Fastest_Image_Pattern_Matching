import hashlib,json,subprocess
from pathlib import Path
root=Path.cwd(); review=root/'build/stage39-review'; original=root/'build/stage39-fine-tiles/formal'
binary=review/'release/experiments/fpm_native_pipeline_runner'; output=root/'build/stage39-fine-tiles/validation/rebuilt';output.mkdir(exist_ok=True)
checks={}
for method in ('hybrid_best','full_gpu_tiled','full_gpu_fine_tiled'):
    label='controlled6-'+method+'-b0'
    work=json.loads((original/'jobs'/f'{label}.json').read_text())
    for name in ('source','template'):work[name]=str(review/'source'/Path(work[name]).relative_to(root))
    work.update(repeats=1,warmup_seconds=0)
    path=output/f'{method}-job.json';path.write_text(json.dumps(work,indent=2)+'\n')
    child=subprocess.run([str(binary),str(path)],capture_output=True,text=True,timeout=120)
    (output/f'{method}.stderr.txt').write_text(child.stderr)
    (output/f'{method}.stdout.txt').write_text(child.stdout)
    assert child.returncode==0,(method,child.stderr)
    result=json.loads(child.stdout);(output/f'{method}.json').write_text(json.dumps(result,indent=2)+'\n')
    baseline=json.loads((original/'results'/f'{label}.json').read_text())
    for run in [result['first'],*result['runs']]:
        for key in ('matches','proposals'):assert run[key]==baseline['first'][key],(method,key)
    checks[method]={'calls':2,'ordered_matches_and_proposals_exact':True}
summary={'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'checks':checks}
(output/'parity.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
