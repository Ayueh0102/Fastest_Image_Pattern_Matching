from pathlib import Path
import sys,json
root=Path.cwd(); sys.path.insert(0,str(root/'cpp-core/tools'))
import benchmark_gpu_fine_tiles as bench
out=root/'cpp-core/docs/stage39-fine-tiles'; work=root/'build/stage39-fine-tiles'
summaries={}
for name,formal in [('formal',None),('profile','formal'),('stop0-formal',None),('stop0-profile','stop0-formal'),('8k-profile','formal')]:
    manifest=json.loads((work/name/'manifest.json').read_text())
    summary=bench.summarize(manifest,work/name)
    if formal:
        baseline=json.loads((work/formal/'manifest.json').read_text())
        summary['profile_overhead']=bench.profile_overhead(manifest,summary,baseline,bench.summarize(baseline,work/formal))
        summary['unprofiled_manifest_sha256']=bench.sha(work/formal/'manifest.json')
    bench.save(out/(name+'-summary.json'),summary);summaries[name]=summary
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,axes=plt.subplots(2,2,figsize=(12,8),gridspec_kw={'width_ratios':[1.6,1]})
colors=['#9098a5','#276892','#d67a2e'];methods=list(bench.METHODS)
labels=['Hybrid','GPU baseline','GPU row cache']
for col,name in enumerate(['formal','stop0-formal']):
    cases=summaries[name]['cases'];x=np.arange(len(cases));w=.24
    for j,(method,label,color)in enumerate(zip(methods,labels,colors)):
        rows=[c['methods'][method] for c in cases]
        med=np.array([r['total_ms']['median']for r in rows]);lo=np.array([r['total_ms']['min']for r in rows]);hi=np.array([r['total_ms']['max']for r in rows])
        axes[0,col].bar(x+(j-1)*w,med,w,color=color,label=label,yerr=[med-lo,hi-med],capsize=2)
        axes[1,col].bar(x+(j-1)*w,[r['peak_rss_bytes']/2**20 for r in rows],w,color=color)
    ticks=['128','512','6','8K / 6'] if col==0 else ['128','512']
    for row in (0,1):
        axes[row,col].set_xticks(x,ticks);axes[row,col].set_xlabel('Objects / scene');axes[row,col].grid(axis='y',alpha=.2);axes[row,col].set_axisbelow(True)
    axes[0,col].set_yscale('log');axes[0,col].set_ylabel('Algorithm time (ms, log scale)')
    axes[1,col].set_ylabel('Peak process RSS (MiB)')
    axes[0,col].set_title('Original settings' if col==0 else 'Supplement: full-resolution fine search')
axes[0,0].legend(loc='upper left',fontsize=9)
fig.suptitle('Stage 39 — rotated ROI row caching on Metal',fontweight='bold',y=.99)
fig.text(.5,.015,'Time: median of 6 measured calls; whiskers: observed min–max. RSS: maximum of 3 fresh processes.\nOriginal 128/512 stop at pyramid layer 1; supplement changes only stop layer to 0. Profiling excluded.',ha='center',fontsize=9)
fig.tight_layout(rect=[0,.07,1,.97]);fig.savefig(out/'comparison.png',dpi=160);plt.close(fig)
print('Five summaries and comparison.png written')
