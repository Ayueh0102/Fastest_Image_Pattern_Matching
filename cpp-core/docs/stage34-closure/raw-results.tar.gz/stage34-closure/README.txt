Stage34 complete evidence snapshot.
source/ contains the measured C++/Metal/GUI code and test/tools sources.
evidence/ retains formal results, pilots, failed cases, Blender scenes and the 30-minute stream.
input-paths.json maps historical absolute image paths to portable input copies.
binaries/ are the measured arm64 executables/libraries; system Qt/OpenCV remain prerequisites.
Run tools with --summarize on a relocated formal.json to replay saved statistics without GPU calls.
Backend/challenge summaries intentionally report accuracy/performance failures.
Scale support is experimental and disabled by default. Synthetic data is not camera validation.
trace-target/ contains only the benchmark process records. The complete system trace stays local;
its content hashes are preserved, because it also contains unrelated system-process records.
reviews/ preserves supplementary scripts, source freeze, validation and test logs.
See repository cpp-core/docs/STAGE34_CLOSURE_zh-TW.md for decisions and limits.
