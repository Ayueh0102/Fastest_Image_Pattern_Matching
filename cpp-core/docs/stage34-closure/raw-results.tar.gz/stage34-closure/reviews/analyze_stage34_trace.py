from pathlib import Path
import xml.etree.ElementTree as E
import json,collections,hashlib
base=Path(__file__).resolve().parent/'stage34-trace'
def load(name):
 r=E.parse(base/(name+'.xml')).getroot();ids={e.get('id'):e for e in r.iter() if e.get('id')}
 def resolve(e):return ids[e.get('ref')] if e.get('ref') else e
 keys=[c.findtext('mnemonic') for c in r.find('.//schema').findall('col')]
 return [{k:resolve(e) for k,e in zip(keys,row)} for row in r.findall('.//row')],resolve
def text(e):return e.get('fmt') or e.text or ''
def numeric(e):return float(e.text or 0)
def union(spans):
 acc=0;end=None
 for a,b in sorted(spans):
  if end is None or a>end:acc+=b-a;end=b
  elif b>end:acc+=b-end;end=b
 return acc
app,_=load('metal-application-intervals');gpu,_=load('metal-gpu-intervals');cpu,resolve=load('time-profile')
app=[r for r in app if 'fpm_native_pipeline_runner' in text(r['process'])]
gpu=[r for r in gpu if 'fpm_native_pipeline_runner' in text(r['process'])]
active=[r for r in gpu if text(r['state'])=='Active']
spans=[(numeric(r['start']),numeric(r['start'])+numeric(r['duration'])) for r in active]
first=min(a for a,b in spans);last=max(b for a,b in spans);busy=union(spans)
leaf=collections.Counter();project=collections.Counter();weights=0
for row in cpu:
 if 'fpm_native_pipeline_runner' not in text(row['process']):continue
 weight=numeric(row['weight']);weights+=weight
 frames=[resolve(f) for f in row['stack'].findall('frame')]
 if frames:leaf[frames[0].get('name','?')]+=weight
 for f in frames:
  b=f.find('binary')
  if b is not None:
   b=resolve(b)
   if b.get('name','').startswith(('libfpm','fpm_native')):
    project[f.get('name','?')]+=weight;break
raw=json.loads((base/'worker-output.json').read_text())
runs=[raw['first'],*raw['runs']]
clocks=[]
for r in runs:
 d={k:r[k] for k in ['total_ms','proposal_ms','refine_ms','prepare_ms','nms_ms','refinement_wait_ms','refinement_device_ms']}
 for k in ['copy_ms','wait_ms','device_ms','fine_wait_ms','fine_rotation_ms','fine_normalization_ms','fine_repair_ms']:
  d[k]=sum(w[k] for w in r['work'])
 clocks.append(d)
summary=dict(scope='Separate instrumented launch, first+3repeat, not formal benchmark timing',
 application_rows=len(app),gpu_rows=len(gpu),gpu_states=dict(collections.Counter(text(r['state']) for r in gpu)),
 gpu_channels=dict(collections.Counter(text(r['channel-name']) for r in gpu)),
 target_command_buffers=len({text(r['cmdbuffer-id']) for r in app}),
 gpu_active_union_ms=busy/1e6,gpu_first_to_last_span_ms=(last-first)/1e6,
 gpu_active_fraction_of_first_to_last_span=busy/(last-first),
 encoding_union_ms=union([(numeric(r['start']),numeric(r['start'])+numeric(r['duration'])) for r in app])/1e6,
 gpu_start_latency_sum_ms=sum(numeric(r['start-latency']) for r in active)/1e6,
 sampled_cpu_running_weight_ms=weights/1e6,
 cpu_leaf_ms=[{'symbol':k,'weight_ms':v/1e6} for k,v in leaf.most_common(15)],
 first_project_frame_ms=[{'symbol':k,'weight_ms':v/1e6} for k,v in project.most_common(15)],
 instrumented_clocks=clocks,
 notes=['GPU occupancy here is time activity fraction, not compute unit utilization.',
 'Encoding and GPU spans can overlap; do not add or infer all gaps are transport.',
 'No blit channel does not prove no CPU memcpy/unified-memory traffic.',
 'CPU running samples exclude waiting threads; first project frame aggregates descendants, not exclusive CPU time.',
 'Trace does not establish the historical +48% outlier cause.'],
 hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in base.glob('*.xml')})
(base/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(base/'gpu-active-intervals.json').write_text(json.dumps([[a/1e9,b/1e9] for a,b in spans])+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['instrumented_clocks','hashes']},indent=2))
