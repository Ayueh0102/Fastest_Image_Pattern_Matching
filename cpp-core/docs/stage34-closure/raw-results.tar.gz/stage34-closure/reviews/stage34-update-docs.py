"""Finalize repository review documents from saved stage34 results."""
from pathlib import Path
import json

root=Path(__file__).resolve().parents[1]
docs=root/'cpp-core/docs'
follow=json.loads((root/'build/stage34-scale-timing/summary.json').read_text())
report=docs/'STAGE34_CLOSURE_zh-TW.md'
s=report.read_text()
old='另安排固定12block的針對性速度追查，與首輪數據分開保存。'
new='另完成12block的針對性速度追查，與首輪數據分開保存。這三個案例是看過首輪結果後挑選的追查，不稱新盲測；在量測前固定三種組合，108程序／216次呼叫，來源、圖片、預算與門檻不變。'
s=s.replace(old,new)
rows=['\n| 針對性追查 | 原Metal repeat ms | Metal＋修正 ms | CPU精修＋修正 ms | 原／修正 strict TP | 原／Metal修正／CPU修正 RSS MiB |',
      '|---|---:|---:|---:|---|---|']
for c in follow['cases']:
    m=c['methods']
    rows.append('| '+c['case']+' | '+' | '.join(f"{m[k]['repeat_ms']['median']:.2f}" for k in ['baseline','support','cpu_support'])+
        f" | {m['baseline']['tp']}／{m['support']['tp']} | "+'／'.join(f"{m[k]['rss_bytes']['median']/2**20:.2f}" for k in ['baseline','support','cpu_support'])+' |')
rows.append('''
小模板12物件的Metal＋修正，repeat配對變化中位+8.99%，95% bootstrap區間[+3.19%,+12.55%]，12對中5對超過時間容忍；修正本身中位5.17ms，是可量到的額外成本。CPU精修＋修正相對原Metal，repeat配對變化+3.49%，區間[−0.91%,+4.94%]，首次及repeat各12對全部通過時間容忍；它同時改精修後端與加入修正，不能把全部差額歸於尺度數學式。較小單物件Dst4的CPU組合更快，但較大Dst3控制仍有慢配對，故不作全域分流。

較大Dst3模板不符合修正面積條件，支撐評分耗時約0.000125ms、沒有新增NCC評分，repeat配對區間仍很寬。這支持短工作量有毫秒級比例波動；沒有證明所有慢樣本都是波動，也不能據此撤銷原時間失敗。

三組的前段／候選與自身repeat都相同，RSS門檻全通過。但CPU與Metal「加修正後」的小模板結果有一個物件的分數差0.000102784，超過原1e-4門檻；同一差異在12個block的first／repeat重現，24個比較旗標為false，不是24個獨立失敗物件。最大位置差0.00154px、角度0.00404°、相對尺度0.00982%，各自GT仍12/12且零FP／FN。**保留這個數值一致性限制，不放寬門檻；CPU＋修正僅列有界研究選項，未自動採用或改GUI預設。**
''')
s=s.replace('\n## 2．遮擋、干擾與Blender','\n'+'\n'.join(rows)+'\n## 2．遮擋、干擾與Blender')
# Add process RSS to every challenge row without rewriting failed accuracy.
names=['development遮擋','development相似非目標','development接觸','heldout遮擋','heldout相似非目標','heldout接觸',
       'Blender中性光','Blender變光','Blender遮擋','Blender相似非目標']
cases=[]
for folder in ['stage34-challenge','stage34-blender/results']:
    cases.extend(json.loads((root/'build'/folder/'summary.json').read_text())['cases'])
s=s.replace('| 現行→擴搜repeat ms |','| 現行→擴搜repeat ms | 現行／擴搜 RSS MiB |').replace('|---|---|---|---:|','|---|---|---|---:|---:|',1)
for label,c in zip(names,cases):
    prefix='| '+label+' |'
    line=next(line for line in s.splitlines() if line.startswith(prefix))
    values='／'.join(f"{c['methods'][m]['median']['rss_bytes']/2**20:.2f}" for m in ['baseline','expanded'])
    s=s.replace(line,line+' '+values+' |')
s=s.replace('最終數字、逐項採用決定與封存索引在正式量測和持續測試完成後填入；本檔在此之前屬工作中記錄。','''六組正式／有界比較共384個程序、944次算法呼叫，另有上述745次持續串流記錄；這些呼叫數不是獨立影像數。六份核心summary已由原始worker重新計算，完全相同；針對性比較另核對每筆設定、路徑、候選、GT與hash，保留後端分數差失敗。首次獨立稽核誤將first的generation=1與repeat=2比較，修正為同phase比對，原錯誤log留存；沒有修改受測程式或原始資料。

## 階段採用決定與尚未解決的問題

這五項已完成本輪規劃的有界實驗，結果有正有負。大型多尺度保留Metal前段＋resident0精修，使用u8/shared與fine strip／融合；128／512物件的同版公平對照有穩定收益。CPU＋尺度支撐修正對已測小模板是值得選用的研究組合，但保留數值差異與其他控制的慢樣本，因此不自動分流。`Session::updateSource`可用於新來源更新，但pose影像仍重建；擴大提案預算則不採用。

下一個算法缺口是遮擋下的候選召回及相似負例的身份區分，可分別研究分區一致性／部分支撐評分與多峰歧義判斷；不能再只靠提高迭代或放寬分數。CPU前段準備、精確修補與選峰仍有GPU化空間；本輪時間線沒有證明達到GPU算力或頻寬極限。實拍GT、完整RGB全圖流程、透視／離平面、不同模板的大型庫與其他硬體仍未驗收。

## 可審查與重現的保存內容

- [完整來源、原始資料與Blender場景封存](stage34-closure/raw-results.tar.gz)：C++／Metal／Qt／MFC來源、量測工具與測試、受測arm64執行檔、原始worker、圖片／GT、先導及失敗紀錄、packed `.blend`與生成腳本。系統OpenCV／Qt／Blender依賴不打包為專案原始碼。
- [封存內容雜湊](stage34-closure/archive.json)與[解壓／統計重播／重建驗證](stage34-closure/validation.json)。來源凍結清單包含257個檔案；封存另含GUI資源與測試素材。
- `evidence/`各protocol／formal／summary保持原名及失敗旗標，`input-paths.json`將歷史絕對路徑對應到封存輸入；`reviews/stage34-replay-archive.py`可離線重算六組統計，無須啟動GPU。
- `trace-target/`保存本次matcher程序的原始事件值、統計與計算程式；完整系統trace留在本機`build/stage34-trace/metal.trace`，內容hash一併保存。含其他系統程序的原始trace不推送到遠端。

原生建置使用`cmake -S cpp-core -B build/stage34-closure -DCMAKE_BUILD_TYPE=Release -DFPM_BUILD_EXPERIMENTS=ON -DFPM_BUILD_GUI=ON -DFPM_WITH_OPENCV=ON`，接續建置與CTest。新增選項在研究C++ API／runner：`refinement_backend`、`scale_support_refine`、`source_frames`／`sequence_mode`；尚未新增GUI控制項。原預設保持不變。
''')
report.write_text(s)

latest='''**第34輪：五項缺口已完成階段驗證，改善與失敗均保留。** [完整結果與Blender素材](STAGE34_CLOSURE_zh-TW.md)：同一Metal前段下，128／512物件用Metal精修完整時間比CPU約快12%／15%；小模板尺度支撐修正使既有7/12→12/12、新小模板16/24→24/24。針對性CPU精修＋修正為92.42ms、原Metal89.94ms，RSS34.56／36.23MiB；但有一個分數差略超原後端門檻，保持研究選項、預設關閉。新影格192次fresh／reuse完全一致；最新512設定30分鐘745次、7次重建通過，RSS中位僅增加3.02MiB。Blender中性／變光通過，遮擋與相似負例仍失敗，擴搜方案不採用；無實拍GT及完整RGB驗收。完整源碼、原始數據及失敗均封存。

'''
for name in ['CURRENT_BEST_zh-TW.md','PROJECT_STATUS_zh-TW.md','ORIGINAL_ALGORITHM_NEXT_zh-TW.md']:
    p=docs/name;t=p.read_text();head,rest=t.split('\n\n',1);t=head+'\n\n'+latest+rest.replace('**第33輪：','**第33輪歷史：',1)
    if name=='PROJECT_STATUS_zh-TW.md':
        t=t.replace('後者尚未被本輪固定圖持續測試覆蓋。','第34輪已補新來源合成序列192次；真實相機串流、長期GUI持有與多模板庫仍未驗收。')
        t=t.replace('[33階段研究總索引]','[34階段研究總索引]')
        t=t.replace('此表是後續優先順序，沒有把未實作的改善當成已交付功能。先前30分鐘測試對應歷史第14輪，不能視為第32／33輪最新組合的持續運行覆蓋。','此表保留第33輪的優先順序；第34輪已完成其中尺度、新來源API、公平後端比較、性能分布與最新30分鐘驗證，未解決事項以本頁開頭及第34輪報告為準。舊第14輪30分鐘紀錄仍作歷史保留。')
    p.write_text(t)
p=docs/'EXPERIMENT_REVIEW_zh-TW.md';t=p.read_text().replace('## 目前推薦方案\n\n','## 目前推薦方案\n\n'+latest,1).replace('**第33輪：','**第33輪歷史：',1)
t+='\n### 34. 五項缺口、Blender與最新30分鐘驗證（2026-10-16）\n\n'+latest+'Release 54/54、相關ASan／UBSan 2/2及Python工具75項通過。正式／有界比較384程序944次，另745次soak；所有原始失敗保留，數量不代表獨立場景。\n'
p.write_text(t)
p=docs/'EXPERIMENT_GAPS_zh-TW.md';t=p.read_text();head,rest=t.split('\n\n',1)
p.write_text(head+'\n\n'+latest+'''本頁以下是第33輪缺口清單的歷史快照。第34輪已完成：尺度目標函數與C++修正、遮擋／負例＋Blender、新來源更新與fresh／reuse、公平CPU／Metal精修、性能分布＋新30分鐘測試。沒有已標註實拍序列，因此實拍泛化仍保持未驗證；實驗結果為負不等於未執行。未通過的遮擋、方向錯峰與後端分數一致性，下一輪應另立準確度假設，不把它們標記為已解決。\n\n'''+rest)
print('Final stage34 report and five review indices updated.')
