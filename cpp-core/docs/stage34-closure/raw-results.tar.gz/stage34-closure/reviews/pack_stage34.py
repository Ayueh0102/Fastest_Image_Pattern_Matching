"""Run only after all measured workers finish. Preserve failed evidence too."""
import hashlib
import json
import shutil
import subprocess
import tarfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
dest = root/'build/stage34-archive'
published = root/'cpp-core/docs/stage34-closure'
assert not dest.exists(), 'Refusing to overwrite an archive staging tree'
assert json.loads((root/'build/stage34-soak/summary.json').read_text())['passed']
assert json.loads((root/'build/stage34-scale-timing/summary.json').read_text())['complete']
dest.mkdir()
published.mkdir(exist_ok=True)

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''):
            h.update(b)
    return h.hexdigest()

def cp(src, rel, expected=None):
    src = Path(src)
    if expected:
        assert sha(src) == expected, str(src)
    target = dest/rel
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert sha(src) == sha(target), str(target)
    else:
        shutil.copy2(src, target)

def tree(src, rel):
    for p in sorted(src.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts and p.name != '.DS_Store':
            cp(p, Path(rel)/p.relative_to(src))

frozen = json.loads((root/'build/stage34-frozen-sources.json').read_text())
for name, digest in frozen.items():
    p = Path(name)
    cp(p, Path('source')/p.relative_to(root), digest)
# Include GUI resources, fixtures and build metadata beyond hashed code files.
for name in subprocess.check_output(['git','ls-files','cpp-core','macos-cli','MatchTool','Test Images'], cwd=root, text=True).splitlines():
    p = Path(name)
    if 'docs' not in p.parts and (root/p).is_file():
        cp(root/p, Path('source')/p)
for name in ('LICENSE','AGENTS.md','CMakeLists.txt','vcpkg.json','README.md'):
    cp(root/name, Path('source')/name)

directories = ['stage34-backend-pilot','stage34-backends-results','stage34-scale',
    'stage34-scale-support-results','stage34-scale-timing','stage34-challenge',
    'stage34-challenge-inputs','stage34-blender','stage34-sequence-pilot',
    'stage34-soak','stage34-regression','stage34-figures']
for name in directories:
    tree(root/'build'/name, Path('evidence')/name)

# Resolve every source/template/frame input independently of the original machine.
inputs = {}
def walk(x):
    if isinstance(x, dict):
        for k, v in x.items():
            if k in ('source','template','path') and isinstance(v,str) and Path(v).is_file():
                p = Path(v).resolve()
                digest = sha(p)
                rel = Path('inputs')/(digest[:16]+'-'+p.name)
                cp(p, rel, digest)
                inputs[str(p)] = str(rel)
            walk(v)
    elif isinstance(x, list):
        for v in x:
            walk(v)
for name in directories:
    for p in (root/'build'/name).rglob('protocol.json'):
        walk(json.loads(p.read_text()))
(dest/'input-paths.json').write_text(json.dumps(inputs,indent=2)+'\n')
for name in ('fpm_native_pipeline_runner','libfpm_pose_experiment.dylib','libfpm_coarse_experiment.dylib'):
    cp(root/'build/stage34-closure/experiments'/name, Path('binaries')/name)
for pattern in ('stage34*.log','stage34*.json','stage34*.py'):
    for p in sorted((root/'build').glob(pattern)):
        cp(p, Path('reviews')/p.name)
for name in ('analyze_stage34_trace.py','plot_stage34.py','pack_stage34.py'):
    cp(root/'build'/name, Path('reviews')/name)
for name in ('CMakeCache.txt','Testing/Temporary/LastTest.log'):
    cp(root/'build/stage34-closure'/name, Path('logs')/Path(name).name)
for name in ('summary.json','gpu-active-intervals.json','target-records.json','job.json','worker-output.json','record.log','local-trace-manifest.json'):
    cp(root/'build/stage34-trace'/name, Path('trace-target')/name)

(dest/'README.txt').write_text('Stage34 complete evidence snapshot.\n'
    'source/ contains the measured C++/Metal/GUI code and test/tools sources.\n'
    'evidence/ retains formal results, pilots, failed cases, Blender scenes and the 30-minute stream.\n'
    'input-paths.json maps historical absolute image paths to portable input copies.\n'
    'binaries/ are the measured arm64 executables/libraries; system Qt/OpenCV remain prerequisites.\n'
    'Run tools with --summarize on a relocated formal.json to replay saved statistics without GPU calls.\n'
    'Backend/challenge summaries intentionally report accuracy/performance failures.\n'
    'Scale support is experimental and disabled by default. Synthetic data is not camera validation.\n'
    'trace-target/ contains only the benchmark process records. The complete system trace stays local;\n'
    'its content hashes are preserved, because it also contains unrelated system-process records.\n'
    'reviews/ preserves supplementary scripts, source freeze, validation and test logs.\n'
    'See repository cpp-core/docs/STAGE34_CLOSURE_zh-TW.md for decisions and limits.\n')
manifest = {str(p.relative_to(dest)):sha(p) for p in sorted(dest.rglob('*')) if p.is_file()}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archives=[]
for filename,children in [('raw-results.tar.gz',[p for p in dest.iterdir() if p.name!='source']),
                           ('source-and-fixtures.tar.gz',[dest/'source'])]:
    archive=published/filename
    assert not archive.exists()
    with tarfile.open(archive,'w:gz',compresslevel=6) as t:
        for child in sorted(children):
            t.add(child,arcname='stage34-closure/'+child.name)
    assert archive.stat().st_size<95*2**20
    archives.append(dict(file=filename,sha256=sha(archive),bytes=archive.stat().st_size))
(published/'archive.json').write_text(json.dumps(dict(archives=archives,content_files=len(manifest),
    source_files=len(frozen),instruction='Extract both archives into the same directory.'),indent=2)+'\n')
for p in (root/'build/stage34-figures').glob('*.png'):
    shutil.copy2(p,published/p.name)
print(json.dumps(dict(archives=archives,content_files=len(manifest))))
