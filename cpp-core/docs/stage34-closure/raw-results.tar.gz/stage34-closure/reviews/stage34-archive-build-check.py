"""Rebuild the extracted native source and replay two saved jobs with new paths."""
import json
import os
from pathlib import Path
import subprocess
import sys

archive=Path(sys.argv[1]).resolve()
build=Path(sys.argv[2]).resolve()
build.mkdir(exist_ok=False)
sys.path.insert(0,str(archive/'source/cpp-core/tools'))
from benchmark_native_pipeline import sha,save
from benchmark_resident_multiscale import strip_clocks
env=dict(os.environ,DEVELOPER_DIR='/Library/Developer/CommandLineTools')
def run(cmd,name):
    with (build/name).open('w') as f:
        subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
run(['cmake','-S',str(archive/'source/cpp-core'),'-B',str(build/'cmake'),
    '-DCMAKE_BUILD_TYPE=Release','-DFPM_BUILD_EXPERIMENTS=ON','-DFPM_BUILD_GUI=ON',
    '-DFPM_WITH_OPENCV=ON','-DFPM_BUILD_TESTS=ON'],'configure.log')
run(['cmake','--build',str(build/'cmake'),'--parallel','4','--target',
    'fpm_native_pipeline_runner','fpm_research_source_update_test','fpm_scale_support_refine_test'],'build.log')
run(['ctest','--test-dir',str(build/'cmake'),'--output-on-failure','-R',
    '^(native_source_update_cpu|experimental_scale_support_refine)$'],'tests.log')
mapping=json.loads((archive/'input-paths.json').read_text())
def relocate(value):
    if isinstance(value,dict):return {k:relocate(v) for k,v in value.items()}
    if isinstance(value,list):return [relocate(v) for v in value]
    if isinstance(value,str) and value in mapping:return str(archive/mapping[value])
    return value
cases=[('controlled6',archive/'evidence/stage34-backends-results', 'controlled6-metal-0'),
       ('small_cpu_support',archive/'evidence/stage34-scale-timing','new_small12-cpu_support-0')]
result=[]
for label,base,name in cases:
    # The main harness uses jobs/*.job.json; the targeted follow-up uses *.json.
    candidates=[base/'jobs'/(name+'.job.json'),base/'jobs'/(name+'.json'),base/(name+'.json')]
    path=next(p for p in candidates if p.exists())
    refpath=path.with_name(name+'.raw.json')
    job=relocate(json.loads(path.read_text()))
    jp=build/(label+'.job.json');save(jp,job)
    raw=build/(label+'.raw.json')
    with raw.open('w') as out,(build/(label+'.stderr.txt')).open('w') as err:
        subprocess.run([str(build/'cmake/experiments/fpm_native_pipeline_runner'),str(jp)],
            env=env,stdout=out,stderr=err,check=True)
    actual=json.loads(raw.read_text());expected=json.loads(refpath.read_text())
    assert actual['exact_repeat']
    for r in [actual['first'],*actual['runs']]:
        assert r['matches']==expected['first']['matches'] and r['proposals']==expected['first']['proposals']
        assert strip_clocks(r['work'])==strip_clocks(expected['first']['work'])
        assert r['configured_refinement_backend']==expected['first']['configured_refinement_backend']
        for k in ('scale_support_changed','scale_support_evaluations','scale_support_samples'):
            assert r[k]==expected['first'][k]
    result.append(dict(case=label,ordered_outputs_exact=True,logical_work_exact=True,
        job_sha256=sha(jp),raw_sha256=sha(raw)))
save(build/'summary.json',dict(rebuilt_from_extracted_source=True,cpu_ctest_passed=2,
    native_replays=result,passed=True,
    note='Rebuild/replay is a portability and evidence check, not another performance measurement.'))
print('Extracted C++ source rebuilt; 2 native tests and both relocated jobs passed exactly.')
