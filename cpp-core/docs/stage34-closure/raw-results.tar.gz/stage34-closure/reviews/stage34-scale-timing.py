import sys,json,subprocess
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'cpp-core/tools'))
from benchmark_native_pipeline import sha,save
from benchmark_scale_support import make_job
from benchmark_closure_backends import distribution,paired_change
from many_object_accuracy import evaluate
root=Path(__file__).resolve().parents[1];dest=root/'build/stage34-scale-timing';protocol=dest/'protocol.json'
if len(sys.argv)>1 and sys.argv[1]=='prepare':
 dest.mkdir(exist_ok=False)
 p=json.loads((root/'build/stage34-scale-support-results/protocol.json').read_text())
 names=['new_small12','Dst4-2026101702-5-area4','Dst3-2026101701-1-area4']
 save(protocol,dict(cases=[c for c in p['cases'] if c['name'] in names],blocks=12,reason='Targeted follow-up after stage34 two-block timing failures; observed cases, not independent holdout.',hashes=json.loads((root/'build/stage34-frozen-sources.json').read_text()),binary_sha256={str(root/'build/stage34-closure/experiments'/n):sha(root/'build/stage34-closure/experiments'/n) for n in ('fpm_native_pipeline_runner','libfpm_pose_experiment.dylib','libfpm_coarse_experiment.dylib')}));sys.exit()
p=json.loads(protocol.read_text());report=dict(protocol_sha256=sha(protocol),entries=[],complete=False)
assert not (dest/'formal.json').exists()
for block in range(p['blocks']):
 for c in (p['cases'] if block%2==0 else p['cases'][::-1]):
  for m in (['baseline','support','cpu_support'] if block%2==0 else ['cpu_support','support','baseline']):
   label=f'{c["name"]}-{m}-{block}';jp=dest/(label+'.json');rp=dest/(label+'.raw.json');ep=dest/(label+'.stderr.txt')
   j=make_job(c,'support' if m=='cpu_support' else m)
   if m=='cpu_support':j.update(refinement_backend=0,pose_storage_mode=0)
   save(jp,j);r=subprocess.run([str(root/'build/stage34-closure/experiments/fpm_native_pipeline_runner'),str(jp)],capture_output=True,text=True)
   rp.write_text(r.stdout);ep.write_text(r.stderr);assert r.returncode==0,r.stderr
   report['entries'].append(dict(case=c['name'],method=m,block=block,job=jp.name,raw=rp.name,stderr=ep.name,hashes={f.name:sha(f) for f in [jp,rp,ep]}));save(dest/'formal.json',report)
report.update(complete=True,unchanged=all(sha(k)==v for group in ['hashes','binary_sha256','input_sha256'] for k,v in p[group].items()));save(dest/'formal.json',report)
summary=[]
for c in p['cases']:
 methods={}
 for m in ['baseline','support','cpu_support']:
  es=[e for e in report['entries'] if e['case']==c['name'] and e['method']==m];ws=[json.loads((dest/e['raw']).read_text()) for e in es]
  acc=[evaluate(w['first']['matches'],c['truth'])['strict'] for w in ws]
  methods[m]=dict(first_ms=distribution([w['first']['total_ms'] for w in ws]),repeat_ms=distribution([w['runs'][0]['total_ms'] for w in ws]),polish_ms=distribution([w['runs'][0]['scale_support_refine_ms'] for w in ws]),rss_bytes=distribution([w['final_memory']['peak_rss_bytes'] for w in ws]),tp=min(a['tp'] for a in acc),fp=max(a['fp'] for a in acc),fn=max(a['fn'] for a in acc),ordered_exact=all(w['first']['matches']==ws[0]['first']['matches'] and w['runs'][0]['matches']==ws[0]['first']['matches'] and w['first']['proposals']==ws[0]['first']['proposals'] for w in ws))
 comparisons={m:{phase:paired_change(methods['baseline'][phase]['values'],methods[m][phase]['values']) for phase in ['first_ms','repeat_ms']} for m in ['support','cpu_support']}
 gates={m:{phase:[b<=a+max(2.,.1*a) for a,b in zip(methods['baseline'][phase]['values'],methods[m][phase]['values'])] for phase in ['first_ms','repeat_ms']} for m in ['support','cpu_support']}
 summary.append(dict(case=c['name'],methods=methods,comparisons=comparisons,gates=gates))
save(dest/'summary.json',dict(complete=True,unchanged=report['unchanged'],workers=len(report['entries']),calls=2*len(report['entries']),cases=summary))
print('Targeted timing follow-up complete')
