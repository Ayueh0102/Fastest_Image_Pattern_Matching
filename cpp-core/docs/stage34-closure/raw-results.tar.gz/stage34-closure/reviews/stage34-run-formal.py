import json,subprocess,time,sys
from pathlib import Path
root=Path('/Users/Ayueh/Fastest_Image_Pattern_Matching');py=str(root/'python-port/venv/bin/python');state=root/'build/stage34-run-status.json'
tasks=[
 ('backends',['benchmark_closure_backends.py','--blocks','12','--output','build/stage34-backends-results'],'build/stage34-backends-results'),
 ('scale_support',['benchmark_scale_support.py','--output','build/stage34-scale-support-results'],'build/stage34-scale-support-results'),
 ('challenge',['challenge_coverage_benchmark.py','--protocol','build/stage34-challenge/protocol.json','--build','build/stage34-closure','--output','build/stage34-challenge'],'build/stage34-challenge'),
 ('blender',['challenge_coverage_benchmark.py','--protocol','build/stage34-blender/results/protocol.json','--build','build/stage34-closure','--output','build/stage34-blender/results'],'build/stage34-blender/results')]
results=[]
for name,args,dest in tasks:
 state.write_text(json.dumps({'active':name,'completed':results,'started_unix':time.time()},indent=2)+'\n')
 with (root/f'build/stage34-formal-{name}.log').open('w') as f:
  p=subprocess.run([py,str(root/'cpp-core/tools'/args[0]),*args[1:]],cwd=root,stdout=f,stderr=subprocess.STDOUT)
 summary=root/dest/'summary.json'
 assert summary.exists(),f'{name} failed before summary exit{p.returncode}'
 s=json.loads(summary.read_text())
 assert s.get('complete') and s.get('unchanged',True),f'{name} incomplete/sourcechanged'
 assert s.get('integrity_passed',s.get('evidence_integrity_passed',False)),f'{name} integrity failed'
 results.append({'name':name,'exit':p.returncode,'summary':str(summary),'workers':s['workers'],'calls':s['algorithm_calls']})
 print(name,'complete',p.returncode,flush=True)
state.write_text(json.dumps({'active':None,'completed':results,'complete':True},indent=2)+'\n')
