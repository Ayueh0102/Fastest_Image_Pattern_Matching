"""Split the complete staging payload into two Git-sized, jointly verified parts."""
import hashlib,json,shutil,tarfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
dest=root/'build/stage34-archive';published=root/'cpp-core/docs/stage34-closure'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
for name in ['pack_stage34.py','stage34-finalize-archive.py']:
    shutil.copy2(root/'build'/name,dest/'reviews'/name)
manifest={str(p.relative_to(dest)):sha(p) for p in sorted(dest.rglob('*')) if p.is_file() and p!=dest/'manifest.json'}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archives=[]
for filename,children in [('raw-results.tar.gz',[p for p in dest.iterdir() if p.name!='source']),
                         ('source-and-fixtures.tar.gz',[dest/'source'])]:
    archive=published/filename
    assert not archive.exists()
    with tarfile.open(archive,'w:gz',compresslevel=6) as t:
        for child in sorted(children):t.add(child,arcname='stage34-closure/'+child.name)
    assert archive.stat().st_size<95*2**20
    archives.append(dict(file=filename,sha256=sha(archive),bytes=archive.stat().st_size))
(published/'archive.json').write_text(json.dumps(dict(archives=archives,content_files=len(manifest),
    source_files=257,instruction='Extract both archives into the same directory.'),indent=2)+'\n')
for p in (root/'build/stage34-figures').glob('*.png'):shutil.copy2(p,published/p.name)
print(json.dumps(dict(archives=archives,content_files=len(manifest))))
