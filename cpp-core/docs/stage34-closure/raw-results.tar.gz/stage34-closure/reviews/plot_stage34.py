import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path('/Users/Ayueh/Fastest_Image_Pattern_Matching');dest=root/'build/stage34-figures';dest.mkdir(exist_ok=True)
s=json.loads((root/'build/stage34-blender/results/summary.json').read_text());p=json.loads((root/'build/stage34-blender/results/protocol.json').read_text())
fig,axes=plt.subplots(2,2,figsize=(9,9),constrained_layout=True)
labels=['Neutral light','Changed light','Partial occlusion','Similar non-targets']
for ax,c,label in zip(axes.ravel(),s['cases'],labels):
 case=next(x for x in p['cases'] if x['name']==c['name']);ax.imshow(plt.imread(case['source']),cmap='gray',vmin=0,vmax=1)
 a=c['methods']['baseline']['blocks'][0]['diagnostics'][0]['accuracy']['strict']
 ax.set_title(f"{label} | TP {a['tp']} / FP {a['fp']} / FN {a['fn']}",fontsize=12);ax.axis('off')
fig.suptitle('Blender planar scenes: baseline strict pose results',fontsize=16)
fig.savefig(dest/'blender-results.png',dpi=150);plt.close(fig)
s=json.loads((root/'build/stage34-backends-results/summary.json').read_text())
fig,axes=plt.subplots(1,4,figsize=(12,3.5),constrained_layout=True)
labels=['6 objects','128 objects','512 objects','12 small objects']
for ax,c,label in zip(axes,s['cases'],labels):
 for i,m in enumerate(['cpu','metal']):
  d=c['methods'][m]['phases']['repeat']['total_ms'];ax.scatter([i]*len(d['values']),d['values'],s=16,alpha=.45,color=['#6b7c8e','#b66338'][i]);ax.scatter(i,d['median'],marker='_',s=500,color='#111111',zorder=5)
 ax.set_xticks([0,1],['CPU refine','Metal refine']);ax.set_title(label);ax.set_ylabel('Total algorithm time (ms)');ax.spines[['top','right']].set_visible(False)
fig.suptitle('Same Metal frontend | 12 paired fresh processes | one repeat per process',fontsize=13)
fig.savefig(dest/'backend-distribution.png',dpi=150);plt.close(fig)
