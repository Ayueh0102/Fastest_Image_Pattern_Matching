"""Export only this benchmark's process records; keep the system trace local."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as E

base = Path(__file__).resolve().parent / 'stage34-trace'
out = {}
for name in ('metal-application-intervals', 'metal-gpu-intervals', 'time-profile'):
    p = base / (name + '.xml')
    root = E.parse(p).getroot()
    ids = {e.get('id'): e for e in root.iter() if e.get('id')}
    def resolve(e):
        return ids[e.get('ref')] if e.get('ref') else e
    def scalar(e):
        e = resolve(e)
        return dict(value=e.text or '', formatted=e.get('fmt', ''))
    keys = [c.findtext('mnemonic') for c in root.find('.//schema').findall('col')]
    selected = []
    for row in root.findall('.//row'):
        record = {k: resolve(e) for k, e in zip(keys, row)}
        process = scalar(record['process'])
        if 'fpm_native_pipeline_runner' not in (process['formatted'] or process['value']):
            continue
        result = {k: scalar(e) for k, e in record.items() if k != 'stack'}
        if 'stack' in record:
            result['stack'] = []
            for f in record['stack'].findall('frame'):
                f = resolve(f)
                b = f.find('binary')
                result['stack'].append(dict(symbol=f.get('name', '?'),
                    binary=resolve(b).get('name', '') if b is not None else ''))
        selected.append(result)
    out[name] = dict(source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(), rows=selected)
(base/'target-records.json').write_text(json.dumps(out, indent=2)+'\n')
print({k: len(v['rows']) for k, v in out.items()})
