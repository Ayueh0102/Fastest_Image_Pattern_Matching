"""Independent evidence audit, no native execution or altered thresholds."""
import json
import math
import sys
from pathlib import Path

root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'cpp-core/tools'))
from benchmark_native_pipeline import sha,save
import benchmark_closure_backends as backends
import benchmark_scale_support as support
import challenge_coverage_benchmark as challenge
import closure_lifecycle as lifecycle
from benchmark_resident_multiscale import frontend_state
from many_object_accuracy import evaluate

checks=[]
for name,fn in [('stage34-backends-results',backends.summarize),
    ('stage34-scale-support-results',support.summarize),
    ('stage34-challenge',challenge.summarize),
    ('stage34-blender/results',challenge.summarize),
    ('stage34-sequence-pilot',lifecycle.sequence_summary),
    ('stage34-soak',lifecycle.soak_summary)]:
    p=root/'build'/name
    actual=fn(json.loads((p/'formal.json').read_text()),p)
    expected=json.loads((p/'summary.json').read_text())
    assert actual==expected,name
    checks.append(dict(suite=name,summary_exact=True,
        flags={k:v for k,v in actual.items() if isinstance(v,bool)}))

base=root/'build/stage34-scale-timing'
p=json.loads((base/'protocol.json').read_text())
f=json.loads((base/'formal.json').read_text())
assert f['complete'] and f['unchanged'] and f['protocol_sha256']==sha(base/'protocol.json')
assert sha(root/'build/stage34-scale-timing.py')==p['script_sha256']
expected=[(c['name'],b,m) for b in range(p['blocks'])
    for c in (p['cases'] if b%2==0 else p['cases'][::-1])
    for m in (['baseline','support','cpu_support'] if b%2==0 else ['cpu_support','support','baseline'])]
assert [(e['case'],e['block'],e['method']) for e in f['entries']]==expected
workers={}
for e in f['entries']:
    for name,digest in e['hashes'].items():
        assert sha(base/name)==digest,name
    c=next(c for c in p['cases'] if c['name']==e['case'])
    expected_job=support.make_job(c,'support' if e['method']=='cpu_support' else e['method'])
    if e['method']=='cpu_support':expected_job.update(refinement_backend=0,pose_storage_mode=0)
    assert json.loads((base/e['job']).read_text())==expected_job
    w=json.loads((base/e['raw']).read_text())
    assert len(w['runs'])==1 and not w['warmups_ms'] and w['exact_repeat']
    for r in [w['first'],*w['runs']]:
        assert backends.route(r,'cpu' if e['method']=='cpu_support' else 'metal')
        assert support.support_route(r,'support' if e['method']=='cpu_support' else e['method'])
        assert r['matches']==w['first']['matches'] and r['proposals']==w['first']['proposals']
    workers[(e['case'],e['block'],e['method'])]=w

results=[]
for c in p['cases']:
    acc={m:[] for m in ['baseline','support','cpu_support']}
    pairs=[]
    reference_worker=workers[(c['name'],0,'baseline')]
    for b in range(p['blocks']):
        ws={m:workers[(c['name'],b,m)] for m in acc}
        for m,w in ws.items():
            for phase,r in [('first',w['first']),('repeat',w['runs'][0])]:
                reference=reference_worker['first'] if phase=='first' else reference_worker['runs'][0]
                assert frontend_state(r)==frontend_state(reference) and r['proposals']==reference['proposals']
                assert backends.frontend_valid(r,reference,c)
                assert r['frame_coarse_gpu_bytes']>0
                assert any(x['maps']>0 and x['device_ms']>=0 for x in r['work'])
                acc[m].append(evaluate(r['matches'],c['truth'])['strict'])
        for phase in ['first','repeat']:
            rows={m:w['first'] if phase=='first' else w['runs'][0] for m,w in ws.items()}
            paired=backends.final_comparison(rows['cpu_support']['matches'],rows['support']['matches'])
            # Numerical equivalence is an outcome, not evidence integrity. Preserve failures.
            deltas=[dict(index=i,position_px=math.hypot(a['pos_x']-z['pos_x'],a['pos_y']-z['pos_y']),
                angle_deg=abs((a['angle']-z['angle']+180)%360-180),
                relative_scale=abs(a['scale']/z['scale']-1),score=abs(a['score']-z['score']))
                for i,(a,z) in enumerate(zip(rows['cpu_support']['matches'],rows['support']['matches']))]
            pairs.append(dict(block=b,phase=phase,cpu_metal_support_pair=paired,ordered_deltas=deltas,
                rss_gate={m:ws[m]['final_memory']['peak_rss_bytes']<=ws['baseline']['final_memory']['peak_rss_bytes']+
                    max(16*2**20,.1*ws['baseline']['final_memory']['peak_rss_bytes']) for m in ['support','cpu_support']}))
    results.append(dict(case=c['name'],frontend_exact=True,route_valid=True,
        accuracy={m:dict(tp=min(a['tp'] for a in aa),fp=max(a['fp'] for a in aa),fn=max(a['fn'] for a in aa)) for m,aa in acc.items()},pairs=pairs))
for group in ['hashes','binary_sha256','input_sha256']:
    assert all(sha(name)==digest for name,digest in p[group].items()),group
frozen=json.loads((root/'build/stage34-frozen-sources.json').read_text())
assert all(sha(name)==digest for name,digest in frozen.items())
save(root/'build/stage34-final-audit.json',dict(evidence_integrity_passed=True,
    frozen_source_files=len(frozen),frozen_sources_unchanged=True,summary_replays=checks,
    targeted_followup=dict(workers=len(workers),calls=2*len(workers),cases=results),
    note='Integrity and repeatability do not override retained accuracy/performance failures.'))
print('All six saved summaries reproduced; targeted follow-up routes, work, outputs and hashes verified.')
