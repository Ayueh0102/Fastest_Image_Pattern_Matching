"""Usage: python stage34-replay-archive.py /path/to/extracted/stage34-closure

Verify the complete payload and recalculate saved summaries without native/GPU
execution. Needs the same Python numerical dependencies as the research tools.
"""
import collections
import hashlib
import json
from pathlib import Path
import sys

base=Path(sys.argv[1]).resolve()
manifest=json.loads((base/'manifest.json').read_text())
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
assert all(sha(base/name)==digest for name,digest in manifest.items())
sys.path.insert(0,str(base/'source/cpp-core/tools'))
import benchmark_closure_backends as backends
import benchmark_scale_support as support
import challenge_coverage_benchmark as challenge
import closure_lifecycle as lifecycle
replayed=[]
for name,fn in [('stage34-backends-results',backends.summarize),
    ('stage34-scale-support-results',support.summarize),
    ('stage34-challenge',challenge.summarize),
    ('stage34-blender/results',challenge.summarize),
    ('stage34-sequence-pilot',lifecycle.sequence_summary),
    ('stage34-soak',lifecycle.soak_summary)]:
    p=base/'evidence'/name
    actual=fn(json.loads((p/'formal.json').read_text()),p)
    assert actual==json.loads((p/'summary.json').read_text()),name
    replayed.append(dict(suite=name,exact=True,
        flags={k:v for k,v in actual.items() if isinstance(v,bool)}))

target=json.loads((base/'trace-target/target-records.json').read_text())
expected=json.loads((base/'trace-target/summary.json').read_text())
def text(v):return v['formatted'] or v['value']
def number(v):return float(v['value'] or 0)
def union(spans):
    acc=0;end=None
    for a,b in sorted(spans):
        if end is None or a>end:acc+=b-a;end=b
        elif b>end:acc+=b-end;end=b
    return acc
app=target['metal-application-intervals']['rows']
gpu=target['metal-gpu-intervals']['rows']
cpu=target['time-profile']['rows']
active=[r for r in gpu if text(r['state'])=='Active']
spans=[(number(r['start']),number(r['start'])+number(r['duration'])) for r in active]
assert len(app)==expected['application_rows'] and len(gpu)==expected['gpu_rows']
assert len({text(r['cmdbuffer-id']) for r in app})==expected['target_command_buffers']
assert union(spans)/1e6==expected['gpu_active_union_ms']
assert union(spans)/(max(b for a,b in spans)-min(a for a,b in spans))==expected['gpu_active_fraction_of_first_to_last_span']
assert union([(number(r['start']),number(r['start'])+number(r['duration'])) for r in app])/1e6==expected['encoding_union_ms']
assert sum(number(r['start-latency']) for r in active)/1e6==expected['gpu_start_latency_sum_ms']
assert sum(number(r['weight']) for r in cpu)/1e6==expected['sampled_cpu_running_weight_ms']
leaf=collections.Counter()
for r in cpu:
    if r['stack']:leaf[r['stack'][0]['symbol']]+=number(r['weight'])
assert [{'symbol':k,'weight_ms':v/1e6} for k,v in leaf.most_common(15)]==expected['cpu_leaf_ms']
print(json.dumps(dict(payload_hashes_passed=True,content_files=len(manifest),
    summaries=replayed,trace_target_replay=True,
    note='Replayed failure flags remain false. Hash/replay success is not universal algorithm success.'),indent=2))
