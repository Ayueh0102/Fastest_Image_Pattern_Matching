"""Review figure from completed raw stream; does not execute the matcher."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=Path(__file__).resolve().parents[1]
base=root/'build/stage34-soak'
s=json.loads((base/'summary.json').read_text())
rows=[json.loads(line) for line in (base/'samples.jsonl').read_text().splitlines()]
x=np.array([r['elapsed_ms']/60000 for r in rows])
lat=np.array([r['total_ms'] for r in rows])
rss=np.array([r['memory']['current_rss_bytes']/2**20 for r in rows])
fig,axes=plt.subplots(2,1,figsize=(12,7),sharex=True,layout='constrained')
fig.suptitle('Stage 34 | 512 objects, latest Metal configuration',fontsize=17,fontweight='bold')
axes[0].plot(x,lat,color='#8fa9c3',lw=.7,label='Every measured call')
med=np.array([np.median(lat[max(0,i-15):min(len(lat),i+16)]) for i in range(len(lat))])
axes[0].plot(x,med,color='#174c78',lw=1.5,label='31-call centered median')
axes[0].set_ylabel('Algorithm time (ms)')
axes[0].legend(loc='upper right',frameon=False)
axes[1].plot(x,rss,color='#1e7561',lw=1.2,label='Current process RSS')
limit=(s['rss']['first_fifth_median']+s['rss']['allowed_growth'])/2**20
axes[1].axhline(limit,color='#b77622',ls='--',lw=1,label='End-segment median limit')
for ax in axes:
    for r in rows:
        if r['recreate_ms']>0:ax.axvline(r['elapsed_ms']/60000,color='#808080',alpha=.3,lw=.8)
    ax.grid(axis='y',alpha=.18)
    ax.spines[['top','right']].set_visible(False)
axes[1].set_ylabel('Current RSS (MiB)')
axes[1].set_xlabel('Elapsed soak time (minutes); vertical lines = Session recreation')
axes[1].legend(loc='upper left',frameon=False)
axes[1].set_xlim(0,max(x))
fig.text(.01,-.035,f"{s['calls']} calls | {s['contexts_recreated']} recreations | exact outputs: {s['all_outputs_exact']} | "
    f"RSS first/last fifth medians: {s['rss']['first_fifth_median']/2**20:.2f} / {s['rss']['last_fifth_median']/2**20:.2f} MiB\n"
    'Fixed synthetic input; bounds this configuration and duration, not real-camera accuracy or indefinite leak freedom.',fontsize=10)
out=root/'build/stage34-figures/soak.png'
fig.savefig(out,dpi=160,bbox_inches='tight')
print(out)
