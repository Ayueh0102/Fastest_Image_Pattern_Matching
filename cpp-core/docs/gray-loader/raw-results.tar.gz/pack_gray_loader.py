import hashlib,io,json,shutil,subprocess,tarfile
from pathlib import Path
root=Path('/Users/Ayueh/Fastest_Image_Pattern_Matching');raw=root/'build/gray-loader-results';stage=root/'build/gray-loader-archive'
formal=json.loads((raw/'formal.json').read_text());assert formal['complete'] and formal['unchanged']
summary=json.loads((raw/'summary.json').read_text());assert summary['correctness_passed'];stage.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def cp(src,dst,expected=None):
 src,dst=Path(src),Path(dst)
 if expected:assert sha(src)==expected,str(src)
 dst.parent.mkdir(exist_ok=True,parents=True);shutil.copy2(src,dst)
for p in raw.glob('*.json'):cp(p,stage/p.name)
shutil.copytree(raw/'jobs',stage/'jobs',dirs_exist_ok=True)
for p,h in formal['source_sha256'].items():cp(root/p,stage/'source'/p,h)
for name in subprocess.check_output(['git','ls-files','macos-cli','MatchTool'],cwd=root,text=True).splitlines():cp(root/name,stage/'source'/name)
for p in ['LICENSE','AGENTS.md','CMakeLists.txt','vcpkg.json','Test Images/Src7.bmp','Test Images/Dst7.bmp']:cp(root/p,stage/'source'/p)
paths=['cpp-core/CMakeLists.txt','cpp-core/src','cpp-core/include','cpp-core/experiments','cpp-core/tests','cpp-core/tools','cpp-core/examples','macos-cli','LICENSE']
blob=subprocess.check_output(['git','archive',formal['baseline_commit'],*paths],cwd=root)
with tarfile.open(fileobj=io.BytesIO(blob)) as tf:tf.extractall(stage/'frozen-source',filter='data')
mapping={}
for p,h in formal['input_sha256'].items():
 dst=Path('inputs')/Path(p).name;assert str(dst) not in mapping.values();cp(p,stage/dst,h);mapping[p]=str(dst)
(stage/'input-paths.json').write_text(json.dumps(mapping,indent=2)+'\n')
for p,h in formal['binary_sha256'].items():cp(p,stage/'binaries'/Path(p).relative_to(root/'build'),h)
cp(root/'cpp-core/docs/fine-fused/protocol.json',stage/'frozen-protocol.json',formal['baseline_protocol_sha256'])
for p in (root/'build').glob('gray-loader*.log'):cp(p,stage/'logs'/p.name)
for folder in ['gray-loader','gray-loader-asan','fine-fused']:cp(root/'build'/folder/'CMakeCache.txt',stage/'logs'/(folder+'-CMakeCache.txt'))
for name in ['gray-loader-pilot','gray-loader-memory-tool-build','gray-loader-memory-tool-frozen-build']:
 shutil.copytree(root/'build'/name,stage/name,dirs_exist_ok=True)
cp(__file__,stage/'pack_gray_loader.py')
print('Staged',stage)
