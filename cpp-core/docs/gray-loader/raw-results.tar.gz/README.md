# Stage31: exact gray8 loading and process memory

All matcher/kernel sources are unchanged from stage30 e392a01. Only decoded QImage::Format_Grayscale8 can bypass RGB888; other formats use the previous native conversion. The GUI has the same format guard and preserves its old preview DPR and color-space behavior. GUI RSS was not measured here.

The predeclared comparison has three settings from two existing scenes, three arms, two reverse-order blocks, serial fresh processes. Each worker makes its first call and one repeat, with no warmup. Decode/conversion time, algorithm time, explicit retained capacities and whole-process RSS are distinct quantities. Existing GT is evaluated only by the parent, not passed to workers. A faster decode is not a faster NCC algorithm; preserve every performance tolerance failure.

`source/` includes current full source and GUI resources; `frozen-source/` is stage30 source; `binaries/` includes both measured runners and matching project libraries. External Qt/OpenCV and macOS Metal are still required. `input-paths.json` maps original paths to archived pixels. To run a worker from this copy, rewrite source/template paths using that mapping. The source files, inputs and measured binaries are identified in formal.json.

Replay after extraction (use the project's Python venv/dependencies):

```
python source/cpp-core/tools/benchmark_gray_loader.py --summarize formal.json --output replay.json
```

The replay output must not already exist. Build current sources:

```
DEVELOPER_DIR=/Library/Developer/CommandLineTools cmake -S source/cpp-core -B rebuilt -DCMAKE_BUILD_TYPE=Release -DFPM_BUILD_EXPERIMENTS=ON -DFPM_BUILD_TESTS=ON -DFPM_BUILD_GUI=ON -DFPM_WITH_OPENCV=ON
DEVELOPER_DIR=/Library/Developer/CommandLineTools cmake --build rebuilt --target fpm_native_pipeline_runner fpm_qt_gray_loader_test fpm_gui_test -j 6
ctest --test-dir rebuilt -R '^(qt_gray_loader|gui_workflow)$' --output-on-failure
```

Logs preserve full Release, final targeted, loader ASan/UBSan (leak detection off), harness and diagnostic-tool checks. The first GUI fixture incorrectly attached an RGB ICC profile to grayscale PNG; Qt rejected that profile and the fixture assertion failed. The corrected high-DPI fixture passed; the original failure log is retained. This was not a matcher or formal benchmark failure.

`gray-loader-memory-tool-*` are build-only compatibility checks for new and frozen source layouts. Their runners were not executed. `gray-loader-pilot/` is a small functional preflight and not formal performance evidence.

`content-sha256.json` records every packaged file except itself. External validation.json also identifies the final compressed archive. A rebuilt small worker and relocated/extracted summary replay are checked independently of the performance measurements.

The first archive verification failed because Src7/Dst7 GUI fixtures were absent. Both fixtures are now in source/Test Images and the complete GUI test passes; the failed packaging-check log is retained.
