"""Independent round-49 audit: stdlib only, no harness import, no GPU or runner.

Re-reads the formal manifest, checks every job/result SHA-256 and that no job
carries truth, rebuilds strict one-to-one GT matching with its own augmenting
paths, recomputes the per-case medians, per-arm totals, template classes and
the pre-registered verdicts from protocol.json, and compares them with the
published formal summary.
"""
import hashlib
import json
import math
import statistics
import sys
from pathlib import Path


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def strict_pairs(matches, truths):
    edges = []
    for t in truths:
        row = []
        for j, m in enumerate(matches):
            values = [m.get(k) for k in ('pos_x', 'pos_y', 'angle', 'scale')]
            if not all(isinstance(v, (int, float)) and math.isfinite(v) for v in values) or m['scale'] <= 0:
                continue
            d = math.hypot(m['pos_x']-t['pos_x'], m['pos_y']-t['pos_y'])
            a = abs((m['angle']-t['angle']+180) % 360-180)
            r = m['scale']/t['scale']
            if d <= 2 and a <= 1 and .98 <= r <= 1.02:
                row.append(j)
        edges.append(row)
    owner = [-1]*len(matches)

    def augment(i, seen):
        for j in edges[i]:
            if j in seen:
                continue
            seen.add(j)
            if owner[j] < 0 or augment(owner[j], seen):
                owner[j] = i
                return True
        return False
    sys.setrecursionlimit(10000)
    tp = sum(augment(i, set()) for i in range(len(truths)))
    return tp, len(matches)-tp, len(truths)-tp


def main(manifest_path, summary_path, protocol_path):
    root = Path(manifest_path).parent
    manifest = json.loads(Path(manifest_path).read_text())
    summary = json.loads(Path(summary_path).read_text())
    protocol = json.loads(Path(protocol_path).read_text())
    cases = {c['name']: c for c in json.loads(Path(manifest['cases_path']).read_text())}
    problems = []
    if sha(manifest['cases_path']) != manifest['cases_sha256']:
        problems.append('cases file hash')
    if manifest.get('protocol_sha256') != sha(protocol_path):
        problems.append('protocol hash differs from the run')
    cells = {}
    for e in manifest['executions']:
        if sha(root/e['job']) != e['job_sha256'] or sha(root/e['result']) != e['result_sha256']:
            problems.append('hash '+e['job'])
            continue
        job = json.loads((root/e['job']).read_text())
        if 'truth' in json.dumps(job):
            problems.append('truth in '+e['job'])
        result = json.loads((root/e['result']).read_text())
        case = cases[e['case']]
        tp, fp, fn = strict_pairs(result['first']['search_matches'], case['truth'])
        for run in result['runs']:
            if strict_pairs(run['search_matches'], case['truth']) != (tp, fp, fn):
                problems.append('run GT differs '+e['job'])
        ms = statistics.median(run['search_ms'] for run in result['runs'])
        cells.setdefault((e['case'], e['arm']), []).append((e['block'], tp, fp, fn, ms, result['first']['search_matches'],
                                                             result.get('pyramid_rule')))
    table = {}
    for key, rows in cells.items():
        rows.sort(key=lambda r: r[0])
        table[key] = dict(tp=rows[0][1], fp=rows[0][2], fn=rows[0][3], ms=statistics.median(r[4] for r in rows),
                          matches=rows[0][5], rule=rows[0][6], expected=cases[key[0]]['expected_count'])
    arms = ('original', 'stage35_manual', 'adaptive', 'budget', 'fixed512', 'adaptive_r0')
    templates = sorted({c['template_name'] for c in cases.values()})
    per = {}
    for name in templates:
        names = [n for n, c in cases.items() if c['template_name'] == name]
        per[name] = {arm: dict(tp=sum(table[(n, arm)]['tp'] for n in names if cases[n]['positive']),
                               fp=sum(table[(n, arm)]['fp'] for n in names if cases[n]['positive']),
                               expected=sum(cases[n]['expected_count'] for n in names if cases[n]['positive']),
                               ms=sum(table[(n, arm)]['ms'] for n in names if cases[n]['positive']),
                               nfp=sum(table[(n, arm)]['fp'] for n in names if not cases[n]['positive'])) for arm in arms}
        per[name]['names'] = names
    totals = {arm: {k: sum(per[n][arm][k] for n in templates) for k in ('tp', 'fp', 'expected', 'ms', 'nfp')} for arm in arms}
    g = protocol['gates']
    deficient = [n for n in templates if per[n]['original']['expected'] and per[n]['original']['tp'] < g['deficient_recall_below']*per[n]['original']['expected']]
    sufficient = [n for n in templates if per[n]['original']['expected'] and n not in deficient]
    kept = []
    for n in sufficient:
        model = table[(per[n]['names'][0], 'adaptive')]['rule']['models'][0]
        if model['selected_top'] == model['original_top']:
            kept.append(n)
    identical = [n for n in kept if all(table[(c, 'adaptive')]['matches'] == table[(c, 'original')]['matches'] for c in per[n]['names'])]
    missed = sum(per[n]['original']['expected']-per[n]['original']['tp'] for n in deficient)
    recovered = sum(per[n]['adaptive']['tp']-per[n]['original']['tp'] for n in deficient)
    worse = [c for n in deficient for c in per[n]['names'] if cases[c]['positive'] and table[(c, 'adaptive')]['tp'] < table[(c, 'original')]['tp']-1]
    a, b, s, f, o = (totals[k] for k in ('adaptive', 'budget', 'stage35_manual', 'fixed512', 'original'))
    ratio2 = sum(per[n]['adaptive']['ms'] for n in sufficient)/sum(per[n]['original']['ms'] for n in sufficient)
    reg = per[g['H2r_template']]
    reg_model = table[(reg['names'][0], 'adaptive')]['rule']['models'][0]
    verdicts = dict(
        H1=bool(deficient) and recovered >= g['H1_recovered_fraction']*missed and not worse,
        H2=len(kept) >= g['H2_kept_fraction']*len(sufficient) and len(identical) == len(kept) and ratio2 <= g['H2_time_ratio'],
        H2r=reg_model['selected_top'] == reg_model['original_top'] and reg['adaptive']['tp'] == reg['adaptive']['expected']
            and reg['adaptive']['ms']/reg['original']['ms'] <= g['H2_time_ratio'],
        H3=a['tp'] >= b['tp'] and a['ms'] <= g['H3_time_ratio']*b['ms'],
        H4=a['ms'] <= g['H4_time_ratio']*s['ms'] and a['tp'] >= s['tp']-g['H4_tp_tolerance']*a['expected'],
        H5=a['nfp'] == 0 and a['nfp'] <= o['nfp'],
        H6=a['fp'] <= o['fp']+g['H6_fp_tolerance']*a['expected'],
        H7=a['tp'] >= f['tp'] and a['ms'] <= g['H7_time_ratio']*f['ms'])
    published = {k: v['passed'] for k, v in summary['verdicts'].items()}
    if published != verdicts:
        problems.append(f'verdicts differ: published {published} audit {verdicts}')
    numbers = 0
    for arm in arms:
        pub = summary['totals'][arm]
        for mine, theirs in (('tp', 'tp'), ('fp', 'fp'), ('expected', 'expected'), ('nfp', 'negative_fp')):
            numbers += 1
            if pub[theirs] != totals[arm][mine]:
                problems.append(f'{arm} {theirs}: {pub[theirs]} vs {totals[arm][mine]}')
        numbers += 1
        if abs(pub['search_ms']-totals[arm]['ms']) > 1e-9*max(1, totals[arm]['ms']):
            problems.append(f'{arm} search_ms: {pub["search_ms"]} vs {totals[arm]["ms"]}')
    for row in summary['cells']:
        mine = table[(row['case'], row['arm'])]
        for key in ('tp', 'fp', 'fn'):
            numbers += 1
            if row[key] != mine[key]:
                problems.append(f"cell {row['case']}/{row['arm']} {key}")
        numbers += 1
        if abs(row['search_ms']-mine['ms']) > 1e-9*max(1, mine['ms']):
            problems.append(f"cell {row['case']}/{row['arm']} search_ms")
    if sorted(summary['deficient']) != sorted(deficient) or sorted(summary['sufficient']) != sorted(sufficient):
        problems.append('classes differ')
    out = dict(executions=len(manifest['executions']), cells=len(table), compared_numbers=numbers, problems=problems,
               deficient=deficient, kept=len(kept), sufficient=len(sufficient), identical=len(identical),
               recovered=recovered, missed=missed, verdicts=verdicts,
               totals={arm: dict(tp=v['tp'], fp=v['fp'], expected=v['expected'], negative_fp=v['nfp'], search_ms=v['ms'])
                       for arm, v in totals.items()})
    print(json.dumps(out, indent=2))
    return 1 if problems else 0


if __name__ == '__main__':
    sys.exit(main(*sys.argv[1:4]))
