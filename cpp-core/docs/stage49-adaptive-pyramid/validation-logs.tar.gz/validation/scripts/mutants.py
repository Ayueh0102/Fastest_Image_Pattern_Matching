"""Round-49 compiled mutants in an isolated copy of the frozen source.

Each mutant edits one source string, rebuilds the affected targets and runs the
tests that should catch it. A mutant is killed when at least one named test
fails. The copy is restored after every mutant.
"""
import json
import shutil
import subprocess
import sys
from pathlib import Path

FROZEN = Path('/Users/Ayueh/Fastest_Image_Pattern_Matching/build/stage49-frozen-src')
WORK = Path('/Users/Ayueh/Fastest_Image_Pattern_Matching/build/stage49-mutants')
SRC, BUILD, LOGS = WORK/'src', WORK/'build', WORK/'logs'
PY = '/Users/Ayueh/Fastest_Image_Pattern_Matching/python-port/venv/bin/python'
STUB = '''// SPDX-License-Identifier: BSD-2-Clause
#include "pyramid_rule.hpp"

namespace fpm::research {
// Placeholder before the round-49 implementation: keeps the original depth.
PyramidRuleDecision decidePyramid(ImageView templ, int minReducedArea, double)
{
    PyramidRuleDecision decision;
    decision.originalTop = int(Pattern(templ, minReducedArea).levels().size()) - 1;
    decision.selectedTop = decision.originalTop;
    decision.effectiveMinArea = minReducedArea;
    return decision;
}
int minAreaForTop(int, int, int) { return 0; }
double predictedTopScore(const Pattern&, int, std::uint8_t) { return 0; }
} // namespace fpm::research
'''
RULE = 'cpp-core/experiments/pyramid_rule.cpp'
PIPE = 'cpp-core/experiments/research_pipeline.cpp'
COLOR = 'cpp-core/tools/color_verify_runner.cpp'
NATIVE = 'cpp-core/tools/native_pipeline_runner.cpp'
CTEST_RULE = ['research_pyramid_rule']
NATIVE_TESTS = ['native_runner_pyramid_rule', 'native_runner_job_keys']
MUTANTS = [
    ('M0_red_stub', RULE, None, STUB, CTEST_RULE),
    ('M1_threshold_ignored', RULE, 'if (decision.predictedScores[level] >= minScore) selected = level;', 'selected = decision.originalTop;', CTEST_RULE),
    ('M2_best_background', RULE, 'decision.predictedScores.push_back(std::min(', 'decision.predictedScores.push_back(std::max(', CTEST_RULE),
    ('M3_floor_area', RULE, '    while (side * side < area) ++side;\n', '', CTEST_RULE),
    ('M4_session_ignores_area', PIPE, 'minArea=pyramidRule.back().effectiveMinArea;', 'minArea=s.minReducedArea;', CTEST_RULE),
    ('M5_no_rotate_back', RULE, 'detail::rotateCanvas(reduced.view(), topW, topH, grid, background)',
     'detail::rotateCanvas(reduced.view(), topW, topH, 0, background)', CTEST_RULE),
    ('M6_one_sd_background', RULE, 'full.mean + sign * 2 * deviation', 'full.mean + sign * deviation', CTEST_RULE),
    ('M7_shallowest_passing', RULE, 'for (int level = decision.originalTop; level >= 0 && selected < 0; --level)\n        if (decision.predictedScores[level] >= minScore)',
     'for (int level = 0; level <= decision.originalTop && selected < 0; ++level)\n        if (decision.predictedScores[level] >= minScore)', CTEST_RULE),
    ('M8_full_gpu_accepted', PIPE, 'if(s.pyramidRule && (s.fullGpu || s.sparseOrientation))', 'if(s.pyramidRule && s.sparseOrientation)', CTEST_RULE),
    ('M9_color_runner_ignores_rule', COLOR, 's.pyramidRule=integer(job,"pyramid_rule",0,0,1);', 's.pyramidRule=0*integer(job,"pyramid_rule",0,0,1);', ['color']),
    ('M10_native_orphan_accepted', NATIVE, 'if(settings.pyramidRule!=1) throw std::invalid_argument("pyramid_rule_min_score requires pyramid_rule 1");',
     '', NATIVE_TESTS),
    ('M11_unchanged_depth_new_area', RULE, 'selected == decision.originalTop ? minReducedArea : minAreaForTop', 'false ? minReducedArea : minAreaForTop', CTEST_RULE),
]


def run(command, log, cwd=None):
    with open(log, 'w') as out:
        return subprocess.run(command, cwd=cwd, stdout=out, stderr=subprocess.STDOUT).returncode


def main():
    if WORK.exists():
        raise SystemExit('Refusing to reuse '+str(WORK))
    LOGS.mkdir(parents=True)
    shutil.copytree(FROZEN, SRC)
    if run(['cmake', '-S', SRC/'cpp-core', '-B', BUILD, '-DCMAKE_BUILD_TYPE=Release', '-DFPM_BUILD_GUI=ON',
            '-DFPM_BUILD_EXPERIMENTS=ON', '-DFPM_WITH_OPENCV=ON'], LOGS/'configure.log'):
        raise SystemExit('configure failed')
    if run(['cmake', '--build', BUILD, '-j', '8'], LOGS/'baseline-build.log'):
        raise SystemExit('baseline build failed')
    results = []
    baseline = run(['ctest', '--test-dir', BUILD, '-R', 'pyramid_rule|native_runner_job_keys', '--output-on-failure'], LOGS/'baseline-tests.log')
    color = [PY, SRC/'cpp-core/tests/color_verify_runner_test.py', '--runner', BUILD/'experiments/fpm_color_verify_runner', '-k', 'pyramid']
    baseline |= run(color, LOGS/'baseline-color.log')
    results.append(dict(name='baseline', tests_failed=bool(baseline)))
    for name, path, old, new, tests in MUTANTS:
        target = SRC/path
        original = target.read_text()
        if old is None:
            mutated = new
        else:
            if original.count(old) != 1:
                raise SystemExit(f'{name}: pattern found {original.count(old)} times')
            mutated = original.replace(old, new)
        target.write_text(mutated)
        try:
            built = run(['cmake', '--build', BUILD, '-j', '8'], LOGS/f'{name}-build.log')
            if built:
                results.append(dict(name=name, file=path, built=False, killed=True, reason='compile error'))
                continue
            failed = []
            for test in tests:
                if test == 'color':
                    code = run(color, LOGS/f'{name}-color.log')
                else:
                    code = run(['ctest', '--test-dir', BUILD, '-R', f'^{test}$', '--output-on-failure'], LOGS/f'{name}-{test}.log')
                if code:
                    failed.append(test)
            results.append(dict(name=name, file=path, built=True, tests=tests, failed=failed, killed=bool(failed)))
        finally:
            target.write_text(original)
    restored = run(['cmake', '--build', BUILD, '-j', '8'], LOGS/'restored-build.log')
    restored |= run(['ctest', '--test-dir', BUILD, '-R', 'pyramid_rule|native_runner_job_keys', '--output-on-failure'], LOGS/'restored-tests.log')
    out = dict(results=results, restored_tests_failed=bool(restored),
               killed=sum(r.get('killed', False) for r in results[1:]), mutants=len(MUTANTS))
    (WORK/'mutants.json').write_text(json.dumps(out, indent=2)+'\n')
    print(json.dumps(out, indent=2))


if __name__ == '__main__':
    main()
