"""Post-hoc host sensitivity (descriptive, no verdict effect): time ratios on quiet workers only."""
import json, statistics, sys
from pathlib import Path
sys.path.insert(0, sys.argv[3])
import benchmark_adaptive_pyramid as h
manifest = json.loads(Path(sys.argv[1]).read_text())
rows = h.load_rows(manifest, Path(sys.argv[1]).parent)
def quiet(r): return r['host_load'] <= h.HOST_LOAD_LIMIT and not r['host_cpu_process'] and not r['host_busy']
cells = {}
for r in rows:
    if r['positive'] and quiet(r):
        cells.setdefault((r['case'], r['arm']), []).append(r['search_ms'])
cases = sorted({r['case'] for r in rows if r['positive']})
out = dict(quiet_workers=sum(quiet(r) for r in rows), workers=len(rows),
           quiet_positive_workers=sum(quiet(r) for r in rows if r['positive']))
for a, b in (('adaptive', 'original'), ('adaptive', 'budget'), ('adaptive', 'stage35_manual'), ('adaptive', 'fixed512')):
    common = [c for c in cases if (c, a) in cells and (c, b) in cells]
    ta = sum(statistics.median(cells[(c, a)]) for c in common); tb = sum(statistics.median(cells[(c, b)]) for c in common)
    all_a = sum(statistics.median([r['search_ms'] for r in rows if r['case'] == c and r['arm'] == a]) for c in common)
    all_b = sum(statistics.median([r['search_ms'] for r in rows if r['case'] == c and r['arm'] == b]) for c in common)
    out[f'{a}/{b}'] = dict(cases=len(common), quiet_ratio=ta/tb, all_blocks_ratio_same_cases=all_a/all_b)
print(json.dumps(out, indent=2))
