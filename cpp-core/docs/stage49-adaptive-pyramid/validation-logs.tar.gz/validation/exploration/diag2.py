import json, subprocess, sys, math, os
sys.path.insert(0,'/Users/Ayueh/Fastest_Image_Pattern_Matching/.claude/worktrees/round49-adaptive-top-level-5e0844/cpp-core/tools')
from many_object_accuracy import evaluate
import benchmark_adaptive_pyramid as h
B='/Users/Ayueh/Fastest_Image_Pattern_Matching/build/stage49-dev/experiments/fpm_native_pipeline_runner'
cases={c['name']:c for c in json.load(open('/Users/Ayueh/Fastest_Image_Pattern_Matching/build/stage49-adaptive-pyramid/development/cases.json'))}
case=cases[sys.argv[1]]
def loose(preds, truth, pos=6, ang=8):
    hit=0
    for t in truth:
        if any(math.hypot(p['pos_x']-t['pos_x'],p['pos_y']-t['pos_y'])<=pos and abs((p['angle']-t['angle']+180)%360-180)<=ang for p in preds): hit+=1
    return hit
w,hh=case['template_size']
for L in [int(x) for x in sys.argv[2:]]:
    for refine in (True, False):
        s=dict(h.BASE_SEARCH, **h.ORIGINAL); s['min_area']=h.min_area_for_top(w,hh,L)
        if L==h.depth(w,hh,256): s['min_area']=256
        s['refine']=refine
        j=dict(source=case['source'],template=case['template'],repeats=1,warmup_seconds=0,gray_load_mode='legacy_rgb',**s)
        json.dump(j,open('/tmp/claude-502/j.json','w'))
        out=subprocess.run([B,'/tmp/claude-502/j.json'],capture_output=True,text=True)
        r=json.loads(out.stdout.splitlines()[-1])['first']
        ev=evaluate(r['matches'],case['truth'])['strict']
        print('L',L,'refine',refine,'matches',len(r['matches']),'strictTP',ev['tp'],'proposals',len(r['proposals']),'prop-near-GT(6px,8deg)',loose(r['proposals'],case['truth']),'prop-near(2px,2deg)',loose(r['proposals'],case['truth'],2,2))
