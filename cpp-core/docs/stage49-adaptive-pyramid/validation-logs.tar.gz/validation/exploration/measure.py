import sys, math, numpy as np, cv2
def levels(t, min_area=256):
    side=int(math.sqrt(min_area)); area=t.shape[0]*t.shape[1]; out=[t]
    while area>side*side:
        if out[-1].shape==(1,1): break
        out.append(cv2.pyrDown(out[-1])); area//=4
    return out
def ncc(a,b):
    a=a.astype(float)-a.mean(); b=b.astype(float)-b.mean()
    d=math.sqrt((a*a).sum()*(b*b).sum()); return (a*b).sum()/d if d>0 else 0.
def score(t, L, thg, r, shift):
    h,w=t.shape; f=2**L
    T=[t]
    for _ in range(L): T.append(cv2.pyrDown(T[-1]))
    TL=T[L]; hl,wl=TL.shape
    step=math.degrees(math.atan(2/max(wl,hl)))
    S=int(math.ceil((math.hypot(w,h)+16*f)/f))*f
    b=float(np.round(t.mean()))
    c=(S-1)/2
    th=thg+r*step
    M=cv2.getRotationMatrix2D((w/2,h/2),th,1.0)  # rotate template about its center
    M[0,2]+=c-w/2+shift[0]*f/2; M[1,2]+=c-h/2+shift[1]*f/2
    C=cv2.warpAffine(t.astype(np.float32),M,(S,S),flags=cv2.INTER_LINEAR,borderValue=b)
    C=np.uint8(np.clip(np.rint(C),0,255))
    for _ in range(L): C=cv2.pyrDown(C)
    Sl=C.shape[0]; cl=(Sl-1)/2
    R=cv2.warpAffine(C,cv2.getRotationMatrix2D((cl,cl),-thg,1.0),(Sl,Sl),flags=cv2.INTER_LINEAR,borderValue=b)
    # expected object center in R ~ (c + shift*f/2 rotated by -thg)/f; just search a window
    ex=(c/f)+0; best=-1
    for oy in range(-3,4):
        for ox in range(-3,4):
            x0=int(round(cl-(wl-1)/2+ox)); y0=int(round(cl-(hl-1)/2+oy))
            win=R[y0:y0+hl,x0:x0+wl]
            if win.shape!=TL.shape: continue
            best=max(best,ncc(TL,win))
    return best
def profile(t, min_area=256):
    lv=levels(t,min_area); D=len(lv)-1; res=[]
    for L in range(D,-1,-1):
        vals=[]
        for k,thg in enumerate([20,65,110,155]):
            for r in (-.5,.5):
                sx=1 if k%2==0 else -1; sy=1 if r>0 else -1
                vals.append(score(t,L,thg,r,(sx,sy)))
        res.append((L,lv[L].shape[::-1],round(min(vals),3),round(float(np.mean(vals)),3)))
    return res
if __name__=='__main__':
    for p in sys.argv[1:]:
        t=cv2.imread(p,0); print(p.split('/')[-1], t.shape[::-1], profile(t))
