#include "pyramid_rule.hpp"
#include <cmath>
#include <cstdio>
#include <random>
#include <algorithm>
#include <vector>
#include <fstream>
#include <string>
using namespace fpm;
int main(int argc,char**argv){
    std::vector<Image> ts;
    {Image t(44,30);std::mt19937 random(49001);
    for(int y=0;y<30;++y) for(int x=0;x<44;++x)
        t.row(y)[x]=uint8_t(std::clamp(128+70*std::sin(2.6*x+1.9*y)+30*std::cos(1.3*x-2.4*y)+int(random()%9)-4.,0.,255.));
    ts.push_back(t);}
    {Image t(64,64);
    for(int y=0;y<64;++y) for(int x=0;x<64;++x)
        t.row(y)[x]=uint8_t(std::clamp(60+1.2*x+(std::hypot(x-40.,y-22.)<15?110.:0.)+(std::hypot(x-18.,y-46.)<9?-40.:0.),0.,255.));
    ts.push_back(t);}
    for(int i=1;i<argc;++i){ // PGM P5 files
        std::ifstream f(argv[i],std::ios::binary);std::string m;int w,h,mx;f>>m>>w>>h>>mx;f.get();Image t(w,h);
        for(int y=0;y<h;++y) f.read((char*)t.row(y),w); ts.push_back(t);}
    for(auto&t:ts){auto d=research::decidePyramid(t.view(),256,.5);
        std::printf("%dx%d top %d sel %d bg %d/%d ms %.2f scores:",t.width(),t.height(),d.originalTop,d.selectedTop,d.lowBackground,d.highBackground,d.ms);
        for(double s:d.predictedScores) std::printf(" %.3f",s);
        Pattern p(t.view(),256);
        std::printf(" | lo:");for(int L=0;L<=d.originalTop;++L) std::printf(" %.3f",research::predictedTopScore(p,L,d.lowBackground));
        std::printf(" hi:");for(int L=0;L<=d.originalTop;++L) std::printf(" %.3f",research::predictedTopScore(p,L,d.highBackground));
        std::printf("\n");}
}
