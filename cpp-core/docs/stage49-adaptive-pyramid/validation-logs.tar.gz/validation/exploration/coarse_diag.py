import json, sys, math, numpy as np, cv2
I='/Users/Ayueh/Fastest_Image_Pattern_Matching/build/stage35-real-rgb/inputs'
cases={c['name']:c for c in json.load(open(I+'/cases.json'))}
case=cases[sys.argv[1]]; L=int(sys.argv[2])
def gray(p):
    im=cv2.imread(p)[:,:,::-1].astype(np.uint32)
    return ((77*im[:,:,0]+150*im[:,:,1]+29*im[:,:,2]+128)>>8).astype(np.uint8)
src=gray(case['source']); t=gray(case['template'])
S=[src]; T=[t]
for _ in range(L): S.append(cv2.pyrDown(S[-1])); T.append(cv2.pyrDown(T[-1]))
s=S[L]; tl=T[L]; hl,wl=tl.shape
step=math.degrees(math.atan(2/max(wl,hl)))
H,W=s.shape; c=((W-1)/2,(H-1)/2)
angles=np.arange(-180,180,step)
scores=[]
for obj in case['truth']:
    # object center at level L
    cx,cy=obj['pos_x']/2**L, obj['pos_y']/2**L
    best=-1; ba=None
    for a in angles:
        da=abs((a-obj['angle']+180)%360-180)
        if da>step*1.01: continue
        # rotate source by -a about object center to make object upright, then crop window
        M=cv2.getRotationMatrix2D((cx,cy),-a,1.0)
        R=cv2.warpAffine(s,M,(W,H),flags=cv2.INTER_LINEAR,borderValue=0)
        x0=int(round(cx-(wl)/2)); y0=int(round(cy-(hl)/2))
        roi=R[max(0,y0-3):y0+hl+3, max(0,x0-3):x0+wl+3]
        res=cv2.matchTemplate(roi,tl,cv2.TM_CCOEFF_NORMED)
        if res.max()>best: best=float(res.max()); ba=a
    scores.append(best)
scores=np.array(scores)
print('L',L,'top',tl.shape[::-1],'step',round(step,2),'min',scores.min().round(3),'p10',np.percentile(scores,10).round(3),'median',np.median(scores).round(3),'n>=.405',(scores>=.405).sum(),'n>=.5',(scores>=.5).sum())
