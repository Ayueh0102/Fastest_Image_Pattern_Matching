import json, subprocess, sys, math, numpy as np, os
sys.path.insert(0,'/Users/Ayueh/Fastest_Image_Pattern_Matching/.claude/worktrees/round49-adaptive-top-level-5e0844/cpp-core/tools')
from many_object_accuracy import evaluate
B='/Users/Ayueh/Fastest_Image_Pattern_Matching/build/stage49-base/experiments/fpm_native_pipeline_runner'
I='/Users/Ayueh/Fastest_Image_Pattern_Matching/build/stage35-real-rgb/inputs'
cases=json.load(open(I+'/cases.json'))
case={c['name']:c for c in cases}[sys.argv[1]]
P=os.path.dirname(__file__)
def run(min_area,prop,limit):
    s=dict(case['search']); s.update(min_area=min_area,proposal_score=prop,limit=limit)
    j=dict(source=case['source'],template=case['template'],repeats=1,warmup_seconds=0,gray_load_mode='legacy_rgb',**s)
    j.pop('cpu_threads',None); j['cpu_threads']=8
    path=P+'/job.json'; json.dump(j,open(path,'w'))
    out=subprocess.run([B,path],capture_output=True,text=True)
    if out.returncode: print(out.stderr); return
    r=json.loads(out.stdout.splitlines()[-1])
    return r
for args in [(256,.5,100),(512,.5,100),(256,.25,300)]:
    r=run(*args)
    if r is None: continue
    res=r.get('result',r)
    keys=list(r.keys())
    m=r['first']['matches'] if 'first' in r else None

    pass
def loose(preds, truth, pos=6, ang=8):
    hit=set()
    for t_i,t in enumerate(truth):
        for p in preds:
            d=math.hypot(p['pos_x']-t['pos_x'],p['pos_y']-t['pos_y'])
            a=abs((p['angle']-t['angle']+180)%360-180)
            if d<=pos and a<=ang: hit.add(t_i); break
    return len(hit)
for args in [(256,.5,100),(512,.5,100),(256,.25,300),(512,.25,300)]:
    r=run(*args); f=r['first']
    ev=evaluate(f['matches'],case['truth'])
    print(args,'matches',len(f['matches']),'strictTP',ev['strict']['tp'] if 'tp' in ev['strict'] else ev['strict'].keys(),'proposals',len(f['proposals']),'proposal-near-GT',loose(f['proposals'],case['truth']), 'total_ms', round(f.get('total_ms',-1),2))
