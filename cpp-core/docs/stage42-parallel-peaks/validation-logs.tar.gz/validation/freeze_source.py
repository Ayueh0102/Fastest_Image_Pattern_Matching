"""Freeze the committed stage-42 source set into a deterministic snapshot.

Run from the repository root: python freeze_source.py <commit>. Reads committed
bytes with git show (not the working tree), using the stage-40 selection rule:
tracked cpp-core files except docs, root CMakeLists.txt, LICENSE, vcpkg.json and
macos-cli. Writes source-snapshot.tar.gz (paths plus source-sha256.json) and
source-sha256.json into cpp-core/docs/stage42-parallel-peaks.
"""
import gzip, hashlib, io, json, subprocess, sys, tarfile
from pathlib import Path
commit = sys.argv[1]
out = Path('cpp-core/docs/stage42-parallel-peaks')
names = subprocess.run(['git', 'ls-tree', '-r', '--name-only', commit], capture_output=True, text=True, check=True).stdout.split('\n')
selected = sorted(name for name in names if name and ((name.startswith('cpp-core/') and not name.startswith('cpp-core/docs/'))
                  or name in ('CMakeLists.txt', 'LICENSE', 'vcpkg.json') or name.startswith('macos-cli/')))
blobs = {name: subprocess.run(['git', 'show', f'{commit}:{name}'], capture_output=True, check=True).stdout for name in selected}
hashes = {name: hashlib.sha256(data).hexdigest() for name, data in blobs.items()}
manifest = (json.dumps(dict(commit=subprocess.run(['git', 'rev-parse', commit], capture_output=True, text=True, check=True).stdout.strip(),
                            files=hashes), indent=2)+'\n').encode()
def add(tar, name, data):
    info = tarfile.TarInfo(name); info.size = len(data); info.mtime = 0; info.mode = 0o644
    tar.addfile(info, io.BytesIO(data))
with (out/'source-snapshot.tar.gz').open('wb') as handle, gzip.GzipFile(filename='', fileobj=handle, mode='wb', compresslevel=9, mtime=0) as gz, \
        tarfile.open(fileobj=gz, mode='w') as tar:
    for name in selected:
        add(tar, name, blobs[name])
    add(tar, 'source-sha256.json', manifest)
(out/'source-sha256.json').write_bytes(manifest)
print(json.dumps(dict(files=len(selected), commit=json.loads(manifest)['commit'])))
