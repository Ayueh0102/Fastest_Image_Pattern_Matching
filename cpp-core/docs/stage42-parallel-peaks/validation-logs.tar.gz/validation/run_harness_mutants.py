"""Manual mutants of the stage-42 harness; each must make test_parallel_peaks_harness fail.

Usage: run_harness_mutants.py <repo root> <log>. Copies cpp-core/tools and the
test into a temporary tree, applies one anchored replacement, runs the test.
"""
import json, pathlib, shutil, subprocess, sys, tempfile
root, log = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
python = '/Users/Ayueh/Fastest_Image_Pattern_Matching/python-port/venv/bin/python'
TOOL = 'cpp-core/tools/benchmark_parallel_peaks.py'
MUTANTS = [
    ('exactness_unchecked', "row['ordered_matches_equal_mode1'] = all(call['matches'] == reference[0] for call in calls[arm])", "row['ordered_matches_equal_mode1'] = True"),
    ('proposals_unchecked', "row['ordered_proposals_equal_mode1'] = all(call['proposals'] == reference[1] for call in calls[arm])", "row['ordered_proposals_equal_mode1'] = True"),
    ('gt_measured_only', "return dict(**memory_summary(calls, method), **accuracy_summary(calls, case['truth']),", "return dict(**memory_summary(calls, method), **accuracy_summary(calls[1:], case['truth']),"),
    ('time_no_tolerance', "within_regression_budget=b[block_field] <= a[block_field]+max(2., .1*a[block_field]))", "within_regression_budget=b[block_field] <= a[block_field])"),
    ('rss_no_tolerance', "if static[method]['peak_rss_bytes'] > rss+max(8*1024**2, .1*rss):", "if static[method]['peak_rss_bytes'] > rss:"),
    ('target_ignores_blocks', "result['primary_target_met'] = result['consistent_direction'] and result['delta_percent'] <= PRIMARY_TARGET_PERCENT", "result['primary_target_met'] = result['delta_percent'] <= PRIMARY_TARGET_PERCENT"),
    ('target_threshold_5', "PRIMARY_TARGET_PERCENT = -10.", "PRIMARY_TARGET_PERCENT = -5."),
    ('direction_pooled_only', "consistent = pooled != 0 and signs == {pooled}", "consistent = pooled != 0"),
    ('batch_bound_unchecked', "1 <= metrics['peak_batch_maps'] <= batch and", ""),
    ('peak_mode_unchecked', "route &= (metrics['peak_mode'] == options['full_gpu_peak_mode'] and", "route &= (True and"),
    ('jobs_unchecked', "if json.dumps(json.loads(paths['job'].read_text()), sort_keys=True) != json.dumps(expected_job, sort_keys=True):", "if False:"),
    ('host_ignored', "if stage41.host_entry(entry.get('host')):", "if stage41.host_entry(entry.get('host')) and False:"),
    ('warmup_gate_off', "if warmup_wall < stage41.WARMUP_MINIMUM_MS:", "if False:"),
    ('frames_parity_off', "row['same_method_output_parity'] = all(outputs(call) == own for call in calls[arm])", "row['same_method_output_parity'] = True"),
    ('timed_includes_first', "timed = [record for _, worker, _, _ in checked for record in worker['runs']]", "timed = [record for _, worker, _, _ in checked for record in [worker['first'], *worker['runs']]]"),
    ('holdout_time_gated', "                if phase == 'holdout':\n                    continue\n", ""),
    ('phase_settings_unchecked', "raise ValueError('Blocks, measured calls, warm-up or profiling differ from the phase protocol')", "pass"),
]
rows = []
with tempfile.TemporaryDirectory() as directory:
    tree = pathlib.Path(directory)
    shutil.copytree(root/'cpp-core/tools', tree/'cpp-core/tools', ignore=shutil.ignore_patterns('__pycache__'))
    shutil.copytree(root/'cpp-core/examples', tree/'cpp-core/examples', ignore=shutil.ignore_patterns('__pycache__'))
    (tree/'cpp-core/tests').mkdir(parents=True)
    shutil.copy(root/'cpp-core/tests/test_parallel_peaks_harness.py', tree/'cpp-core/tests')
    original = (tree/TOOL).read_text()
    def run():
        return subprocess.run([python, '-m', 'unittest', 'cpp-core/tests/test_parallel_peaks_harness.py'], cwd=tree, capture_output=True, text=True)
    base = run()
    assert base.returncode == 0, base.stderr[-2000:]
    for name, anchor, replacement in MUTANTS:
        assert original.count(anchor) == 1, (name, original.count(anchor))
        (tree/TOOL).write_text(original.replace(anchor, replacement))
        result = run()
        rows.append(dict(mutant=name, killed=result.returncode != 0, tail=result.stderr.strip().splitlines()[-1]))
        print(name, 'killed' if rows[-1]['killed'] else 'SURVIVED', rows[-1]['tail'], flush=True)
    (tree/TOOL).write_text(original)
    restored = run().returncode == 0
summary = dict(mutants=rows, killed=sum(row['killed'] for row in rows), total=len(rows), restored=restored)
log.write_text(json.dumps(summary, indent=1)+'\n')
print(json.dumps(dict(killed=summary['killed'], total=summary['total'], restored=restored)))
