# Host disclosures during the stage-42 timing window

- 13:28:09Z timing-lock-round42.txt created in the shared notes folder; round 43 and the parent session were messaged.
- Round 43 reported: its last CPU work was a 7 s audit script ending 13:26:59Z and a ~20 s tar|gzip size check ending around 13:28Z, then document editing only.
  The pilot started 13:28:21Z, so that check may have overlapped the pilot's first seconds at most; the pilot is screening only.
- Parent session reported: from 13:30:27Z to about 13:33Z it ran `find /Users/Ayueh -maxdepth 6 -name 'timing-lock-*'` (one process, disk I/O and some CPU) while the formal phase (started 13:30:20Z) ran its first many128 workers. The driver's host check does not match `find`, so no host_busy gate records it. The workers whose start time falls in 13:30:20Z-13:33:30Z are listed in the report as disclosed-disturbance workers; none is removed or rerun.
- 13:48:50Z all four phases complete (pilot 13:28:24-13:30:19, formal 13:30:22-13:43:45, profile 13:43:51-13:44:41, holdout 13:44:44-13:46:40); lock file deleted.
