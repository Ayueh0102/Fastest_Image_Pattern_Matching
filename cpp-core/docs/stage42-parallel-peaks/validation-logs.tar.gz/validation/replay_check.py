"""Replay the stage-42 summaries from the published archives with the frozen tool.

Run from the worktree root after archive_artifacts.py. Extracts
source-snapshot.tar.gz and both raw-results archives into build/stage42-repro, checks
every snapshot file against source-sha256.json, re-runs the frozen
benchmark_parallel_peaks.py --summarize on each phase manifest and compares the
output byte for byte with the published summaries. No GPU work is launched.
"""
import hashlib, json, shutil, subprocess, tarfile
from pathlib import Path
root = Path.cwd()
out = root/'cpp-core/docs/stage42-parallel-peaks'
repro = root/'build/stage42-repro'
python = '/Users/Ayueh/Fastest_Image_Pattern_Matching/python-port/venv/bin/python'
if repro.exists():
    shutil.rmtree(repro)
(repro/'source').mkdir(parents=True); (repro/'raw').mkdir(); (repro/'summaries').mkdir()
for name, target in (('source-snapshot.tar.gz', 'source'), ('raw-results-formal.tar.gz', 'raw'), ('raw-results-other.tar.gz', 'raw')):
    with tarfile.open(out/name) as tar:
        tar.extractall(repro/target, filter='data')
frozen = json.loads((repro/'source/source-sha256.json').read_text())
mismatched = [name for name, digest in frozen['files'].items()
              if hashlib.sha256((repro/'source'/name).read_bytes()).hexdigest() != digest]
rows = {}
for phase in ('pilot', 'formal', 'profile', 'holdout'):
    output = repro/'summaries'/f'{phase}-summary.json'
    child = subprocess.run([python, 'benchmark_parallel_peaks.py', '--summarize', str(repro/'raw'/phase/'manifest.json'),
                            '--output', str(output)], cwd=repro/'source/cpp-core/tools', capture_output=True, text=True)
    rows[phase] = dict(exit=child.returncode, stderr=child.stderr[-2000:],
                       byte_identical=child.returncode == 0 and output.read_bytes() == (out/f'{phase}-summary.json').read_bytes())
result = dict(frozen_commit=frozen['commit'], snapshot_files=len(frozen['files']), snapshot_hash_mismatches=mismatched,
              summaries=rows, all_identical=not mismatched and all(row['byte_identical'] for row in rows.values()),
              note='Frozen tool from the snapshot, archived raw results; no GPU work.')
(root/'build/stage42-parallel-peaks/validation/replay-check.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(dict(all_identical=result['all_identical'], files=len(frozen['files']),
                      phases={phase: row['byte_identical'] for phase, row in rows.items()})))
