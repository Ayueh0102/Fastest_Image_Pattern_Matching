#!/usr/bin/env python3
# SPDX-License-Identifier: BSD-2-Clause
"""Independent audit of round 42 (stage42-parallel-peaks).

Specification: cpp-core/docs/stage42-parallel-peaks/protocol.json only.
This script does not import or read anything under cpp-core/tools and does
not launch runners, builds, tests or GPU work. It reads JSON (manifests, jobs,
worker results and the published summaries), recomputes every published
number it can from the raw worker outputs, and lists each mismatch.

Usage (from the worktree root):
    python-port/venv/bin/python -I \
        build/stage42-parallel-peaks/validation/independent_audit.py
"""

import argparse
import hashlib
import json
import math
import statistics
import sys
from pathlib import Path

PHASES = ["pilot", "formal", "profile", "holdout"]
REL_TOL = 1e-9
ABS_TOL = 1e-12
MIB = 1024 * 1024
TRUTH_KEYS = {
    "truth", "ground_truth", "groundtruth", "gt", "gt_poses", "truth_poses",
    "expected", "expected_matches", "metadata", "corners", "objects",
    "object_count", "poses", "warp_roi", "gain", "bias", "cell",
}

sys.setrecursionlimit(20000)


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def load_json(path):
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def is_num(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool)


def close(a, b):
    if is_num(a) and is_num(b):
        if a == b:
            return True
        if any(isinstance(v, float) and math.isnan(v) for v in (a, b)):
            return False
        return abs(a - b) <= max(REL_TOL * max(abs(a), abs(b)), ABS_TOL)
    if isinstance(a, list) and isinstance(b, list):
        return len(a) == len(b) and all(close(x, y) for x, y in zip(a, b))
    if isinstance(a, dict) and isinstance(b, dict):
        return set(a) == set(b) and all(close(a[k], b[k]) for k in a)
    return a == b


def inexact_leaves(a, b, path=""):
    """Numeric leaves that are within tolerance but not bit-identical."""
    if is_num(a) and is_num(b):
        if a != b:
            yield path, a, b
    elif isinstance(a, list) and isinstance(b, list):
        for i, (x, y) in enumerate(zip(a, b)):
            yield from inexact_leaves(x, y, "%s[%d]" % (path, i))
    elif isinstance(a, dict) and isinstance(b, dict):
        for k in a:
            if k in b:
                yield from inexact_leaves(a[k], b[k], "%s.%s" % (path, k))


def stats(values):
    if not values:
        return {"median": None, "min": None, "max": None, "values": []}
    return {
        "median": statistics.median(values),
        "min": min(values),
        "max": max(values),
        "values": list(values),
    }


def median(values):
    return statistics.median(values) if values else None


def angle_diff(a, b):
    d = (a - b) % 360.0
    return min(d, 360.0 - d)


def split_arm(arm):
    method, mode = arm.rsplit("_", 1)
    return method, mode


def within_time_budget(cand, base):
    return cand <= base + max(2.0, 0.10 * base)


def within_rss_budget(cand, base):
    return cand <= base + max(8 * MIB, 0.10 * base)


def walk_keys(obj, path=""):
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield path + "/" + k, k, v
            yield from walk_keys(v, path + "/" + k)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            yield from walk_keys(v, path + "[%d]" % i)


def walk_strings(obj):
    if isinstance(obj, str):
        yield obj
    elif isinstance(obj, dict):
        for v in obj.values():
            yield from walk_strings(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from walk_strings(v)


# --------------------------------------------------------------------------
# one-to-one GT matching (maximum bipartite matching, Kuhn's algorithm)
# --------------------------------------------------------------------------

def gt_match(preds, truths, th_pos, th_ang, th_scale):
    cell = 4.0  # > 2 * th_pos is not needed; > th_pos suffices with 3x3 cells
    grid = {}
    for j, t in enumerate(truths):
        key = (math.floor(t["pos_x"] / cell), math.floor(t["pos_y"] / cell))
        grid.setdefault(key, []).append(j)
    adj = []
    truth_degree = [0] * len(truths)
    for p in preds:
        cx = math.floor(p["pos_x"] / cell)
        cy = math.floor(p["pos_y"] / cell)
        edges = []
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for j in grid.get((cx + dx, cy + dy), ()):
                    t = truths[j]
                    d = math.hypot(p["pos_x"] - t["pos_x"], p["pos_y"] - t["pos_y"])
                    if d > th_pos:
                        continue
                    a = angle_diff(p["angle"], t["angle"])
                    if a > th_ang:
                        continue
                    s = abs(p["scale"] / t["scale"] - 1.0)
                    if s > th_scale:
                        continue
                    edges.append((d, j, a, s))
        edges.sort()
        for e in edges:
            truth_degree[e[1]] += 1
        adj.append(edges)

    match_t = [-1] * len(truths)

    def augment(i, seen):
        for (_, j, _, _) in adj[i]:
            if j in seen:
                continue
            seen.add(j)
            if match_t[j] == -1 or augment(match_t[j], seen):
                match_t[j] = i
                return True
        return False

    for i in range(len(preds)):
        if adj[i]:
            augment(i, set())

    tp = sum(1 for j in match_t if j != -1)
    errs = []
    for j, i in enumerate(match_t):
        if i == -1:
            continue
        for (d, jj, a, s) in adj[i]:
            if jj == j:
                errs.append((d, a, s))
                break
    ambiguous = sum(1 for e in adj if len(e) > 1) + sum(1 for k in truth_degree if k > 1)
    return {
        "tp": tp,
        "fp": len(preds) - tp,
        "fn": len(truths) - tp,
        "max_pos": max((e[0] for e in errs), default=None),
        "max_ang": max((e[1] for e in errs), default=None),
        "max_scale": max((e[2] for e in errs), default=None),
        "ambiguous": ambiguous,
    }


def max_opt(a, b):
    if a is None:
        return b
    if b is None:
        return a
    return max(a, b)


# --------------------------------------------------------------------------
# phase audit
# --------------------------------------------------------------------------

class PhaseAudit:
    def __init__(self, root, protocol, phase):
        self.root = root
        self.protocol = protocol
        self.phase = phase
        self.pspec = protocol["phases"][phase]
        self.dir = root / "build" / "stage42-parallel-peaks" / phase
        self.manifest = load_json(self.dir / "manifest.json")
        self.summary = load_json(
            root / "cpp-core" / "docs" / "stage42-parallel-peaks" / ("%s-summary.json" % phase))
        self.mismatches = []      # published value != recomputed value
        self.check_failures = []  # data fails a protocol check
        self.notes = []
        self.inexact = []         # within tolerance but not bit-identical
        self.values_compared = 0
        self.results = {}
        self.jobs = {}
        self.cases = {c["name"]: c for c in self.manifest["cases"]}
        self.recomputed = {}
        acc = protocol["accuracy"]
        self.th = (float(acc["position_px"]), float(acc["angle_deg"]), float(acc["relative_scale"]))

    # ---- recording -------------------------------------------------------
    def cmp(self, what, published, recomputed):
        self.values_compared += 1
        if not close(published, recomputed):
            self.mismatches.append({"what": what, "published": published, "recomputed": recomputed})
        else:
            for path, a, b in inexact_leaves(published, recomputed):
                self.inexact.append({"what": what + path, "published": a, "recomputed": b,
                                     "abs_diff": abs(a - b)})

    def fail(self, check, what, expected, observed):
        self.check_failures.append(
            {"check": check, "what": what, "expected": expected, "observed": observed})

    # ---- protocol-derived expectations -----------------------------------
    def expected_cases(self):
        c = self.protocol["cases"]
        if self.phase == "holdout":
            return list(c["holdout"])
        return list(c["primary"]) + list(c["controls"])

    def expected_arms(self):
        if self.phase in ("pilot", "formal"):
            return ["hybrid_best_static", "full_gpu_simd_static", "full_gpu_parallel_b1_static",
                    "full_gpu_parallel_static", "hybrid_best_frames", "full_gpu_parallel_frames"]
        return ["full_gpu_simd_static", "full_gpu_parallel_b1_static", "full_gpu_parallel_static"]

    def method_opts(self, method):
        return {k: v for k, v in self.protocol["methods"][method].items() if k != "role"}

    def warmup_calls(self, case):
        return int(self.protocol["phases"]["frame_warmup_calls"][case])

    # ---- 1. integrity, schedule and job checks ----------------------------
    def check_integrity(self):
        m = self.manifest
        p = self.pspec
        exp_cases = self.expected_cases()
        exp_arms = self.expected_arms()
        blocks = int(p["blocks"])
        self.cmp("manifest.cases", exp_cases, [c["name"] for c in m["cases"]])
        self.cmp("manifest.arms", exp_arms, list(m["arms"]))
        self.cmp("manifest.blocks", blocks, m["blocks"])
        self.cmp("manifest.measured_calls", int(p["measured_calls"]), m["measured_calls"])
        self.cmp("manifest.static_warmup_seconds", float(p["static_warmup_seconds"]),
                 m["static_warmup_seconds"])
        self.cmp("manifest.profiling", bool(p.get("profiling", False)), m["profiling"])
        if any(a.endswith("_frames") for a in exp_arms):
            fw = {k: v for k, v in self.protocol["phases"]["frame_warmup_calls"].items() if k != "rule"}
            self.cmp("manifest.frame_warmup_calls", fw, m["frame_warmup_calls"])
        for meth, opts in m["method_options"].items():
            self.cmp("manifest.method_options.%s" % meth, self.method_opts(meth), opts)
        self.cmp("manifest.complete", True, m.get("complete"))
        self.cmp("manifest.unchanged", True, m.get("unchanged"))
        after = m.get("after_sha256", {})
        for key in ("source_sha256", "binary_sha256", "input_sha256"):
            if after.get(key) != m.get(key):
                self.fail("manifest_before_after_hashes", key, "equal", "differ")
        # frozen source list
        frozen = load_json(self.root / "cpp-core" / "docs" / "stage42-parallel-peaks" / "source-sha256.json")
        if frozen.get("commit") != self.protocol["source"]["frozen_commit"]:
            self.fail("frozen_commit", "source-sha256.json commit",
                      self.protocol["source"]["frozen_commit"], frozen.get("commit"))
        fa, fb = frozen.get("files", {}), m.get("source_sha256", {})
        only_manifest = sorted(set(fb) - set(fa))
        value_diff = sorted(k for k in set(fa) & set(fb) if fa[k] != fb[k])
        if only_manifest or value_diff:
            self.fail("source_sha256_vs_frozen_snapshot_list", "manifest.source_sha256",
                      "subset of source-sha256.json files with equal hashes",
                      {"only_in_manifest": only_manifest[:20], "hash_differs": value_diff[:20]})
        self.source_coverage = {"manifest_files": len(fb), "frozen_files": len(fa),
                                "frozen_files_not_hashed_by_phase_manifest": sorted(set(fa) - set(fb))}
        # file hashes and expected set
        seen = {}
        for idx, e in enumerate(m["executions"]):
            key = (e["case"], e["arm"], e["block"])
            seen.setdefault(key, []).append(idx)
            for kind in ("job", "result"):
                path = self.dir / e[kind]
                if not path.exists():
                    self.fail("file_missing", "%s %s" % (kind, e[kind]), "exists", "missing")
                    continue
                digest = sha256_file(path)
                if digest != e[kind + "_sha256"]:
                    self.fail("sha256", e[kind], e[kind + "_sha256"], digest)
        expected = {(c, a, b) for c in exp_cases for a in exp_arms for b in range(blocks)}
        missing = sorted(expected - set(seen))
        extra = sorted(set(seen) - expected)
        dup = sorted(k for k, v in seen.items() if len(v) > 1)
        if missing:
            self.fail("schedule_complete", "missing executions", [], [list(k) for k in missing])
        if extra:
            self.fail("schedule_complete", "unexpected executions", [], [list(k) for k in extra])
        if dup:
            self.fail("schedule_once", "duplicate executions", [], [list(k) for k in dup])
        # order: each (case, block) contiguous, arms declared on even blocks, reversed on odd
        groups = []
        for e in m["executions"]:
            gk = (e["case"], e["block"])
            if not groups or groups[-1][0] != gk:
                groups.append((gk, []))
            groups[-1][1].append(e["arm"])
        gkeys = [g[0] for g in groups]
        if len(gkeys) != len(set(gkeys)):
            self.fail("schedule_order", "(case, block) groups contiguous", "each group once", "split groups")
        for (case, block), arms in groups:
            want = list(m["arms"]) if block % 2 == 0 else list(reversed(m["arms"]))
            if arms != want:
                self.fail("schedule_order", "%s block %d arm order" % (case, block), want, arms)
        self.order_note = {
            "groups": len(groups),
            "nesting": "case-major, blocks ascending within case"
            if gkeys == [(c, b) for c in exp_cases for b in range(blocks)] else "other",
        }
        # extra files on disk not referenced by manifest
        ref = {e["job"] for e in m["executions"]} | {e["result"] for e in m["executions"]}
        for sub in ("jobs", "results"):
            for f in sorted((self.dir / sub).iterdir()):
                rel = "%s/%s" % (sub, f.name)
                if rel in ref:
                    continue
                if sub == "jobs" and (f.name.endswith(".stdout.txt") or f.name.endswith(".stderr.txt")):
                    continue
                self.fail("unreferenced_file", rel, "referenced by manifest", "unreferenced")
        # host busy
        for e in m["executions"]:
            cp = e.get("host", {}).get("competing_processes")
            if cp:
                self.fail("host_busy", "%s/%s/b%d" % (e["case"], e["arm"], e["block"]), [], cp)
        for when in ("before", "after"):
            cp = m.get("host", {}).get(when, {}).get("competing_processes")
            if cp:
                self.fail("host_busy", "phase host.%s" % when, [], cp)
        self.host_busy = any(f["check"] == "host_busy" for f in self.check_failures)

    # ---- load and 2. truth isolation / job consistency --------------------
    def load(self):
        stdout_mismatch = 0
        for e in self.manifest["executions"]:
            key = (e["case"], e["arm"], e["block"])
            job = load_json(self.dir / e["job"])
            res = load_json(self.dir / e["result"])
            self.jobs[key] = job
            self.results[key] = res
            # stdout of the worker should carry the same JSON as the result file
            stdout = (self.dir / e["job"]).with_name(Path(e["job"]).stem + ".stdout.txt")
            if stdout.exists():
                try:
                    if json.loads(stdout.read_text(encoding="utf-8")) != res:
                        stdout_mismatch += 1
                        self.fail("stdout_equals_result", e["result"], "equal", "different")
                except ValueError:
                    stdout_mismatch += 1
                    self.fail("stdout_equals_result", str(stdout.name), "JSON", "unparsable")
        self.stdout_checked = sum(
            1 for e in self.manifest["executions"]
            if (self.dir / e["job"]).with_name(Path(e["job"]).stem + ".stdout.txt").exists())

    def check_jobs(self):
        truth_hits = 0
        for (case, arm, block), job in self.jobs.items():
            c = self.cases[case]
            tag = "%s/%s/b%d" % (case, arm, block)
            for path, k, _ in walk_keys(job):
                kl = k.lower()
                if kl in TRUTH_KEYS or "truth" in kl:
                    truth_hits += 1
                    self.fail("truth_isolation", tag + path, "absent", k)
            meta = c.get("metadata")
            for s in walk_strings(job):
                if meta and s == meta:
                    truth_hits += 1
                    self.fail("truth_isolation", tag, "no metadata path", s)
                if s.endswith(".json"):
                    truth_hits += 1
                    self.fail("truth_isolation", tag, "no JSON path in job", s)
            method, mode = split_arm(arm)
            opts = self.method_opts(method)
            for k, v in opts.items():
                if job.get(k) != v:
                    self.fail("job_method_options", tag + "/" + k, v, job.get(k))
            if "full_gpu_peak_batch" not in opts and "full_gpu_peak_batch" in job:
                self.fail("job_method_options", tag + "/full_gpu_peak_batch", "absent",
                          job["full_gpu_peak_batch"])
            for k in ("template", "scales", "angle", "limit", "score", "overlap", "stop_layer"):
                if job.get(k) != c.get(k):
                    self.fail("job_case_settings", tag + "/" + k, c.get(k), job.get(k))
            if bool(job.get("subpixel")) != bool(c.get("subpixel")):
                self.fail("job_case_settings", tag + "/subpixel", c.get("subpixel"), job.get("subpixel"))
            if "proposal_score" in c and job.get("proposal_score") != c["proposal_score"]:
                self.fail("job_case_settings", tag + "/proposal_score", c["proposal_score"],
                          job.get("proposal_score"))
            if job.get("full_gpu_profiling") != bool(self.pspec.get("profiling", False)):
                self.fail("job_profiling", tag, bool(self.pspec.get("profiling", False)),
                          job.get("full_gpu_profiling"))
            n = int(self.pspec["measured_calls"])
            if mode == "static":
                if job.get("source") != c["source"]:
                    self.fail("job_case_settings", tag + "/source", c["source"], job.get("source"))
                if job.get("repeats") != n:
                    self.fail("job_repeats", tag, n, job.get("repeats"))
                if job.get("warmup_seconds") != float(self.pspec["static_warmup_seconds"]):
                    self.fail("job_warmup", tag, self.pspec["static_warmup_seconds"],
                              job.get("warmup_seconds"))
            else:
                w = self.warmup_calls(case)
                if job.get("source_frames") != [c["source"]]:
                    self.fail("job_case_settings", tag + "/source_frames", [c["source"]],
                              job.get("source_frames"))
                if job.get("sequence_mode") != "reuse":
                    self.fail("job_sequence_mode", tag, "reuse", job.get("sequence_mode"))
                if job.get("warmup_seconds") != 0.0:
                    self.fail("job_warmup", tag, 0.0, job.get("warmup_seconds"))
                if job.get("repeats") != 1 + w + n:
                    self.fail("job_repeats", tag, 1 + w + n, job.get("repeats"))
        self.truth_hits = truth_hits

    # ---- call scopes -----------------------------------------------------
    def scoped_calls(self, key):
        """All GT-scoped calls: (role, call)."""
        case, arm, block = key
        r = self.results[key]
        _, mode = split_arm(arm)
        if mode == "static":
            return [("first", r["first"])] + [("measured", x) for x in r["runs"]]
        w = self.warmup_calls(case)
        out = []
        for i, x in enumerate(r["runs"]):
            role = "cold" if i == 0 else ("warmup" if i <= w else "measured")
            out.append((role, x))
        return out

    def measured_calls(self, key):
        case, arm, block = key
        r = self.results[key]
        _, mode = split_arm(arm)
        if mode == "static":
            return list(r["runs"])
        return list(r["runs"][1 + self.warmup_calls(case):])

    # ---- main recomputation -----------------------------------------------
    def recompute(self):
        blocks = int(self.manifest["blocks"])
        n_meas = int(self.manifest["measured_calls"])
        arms = list(self.manifest["arms"])
        th_pos, th_ang, th_scale = self.th
        counts = {"fresh_processes": 0, "cold_calls": 0, "gt_checked_warmup_calls": 0,
                  "native_only_warmup_calls": 0, "measured_calls": 0, "gt_evaluated_calls": 0}
        rec_cases = {}
        for case in [c["name"] for c in self.manifest["cases"]]:
            truths = self.cases[case]["truth"]
            ref_key = (case, "full_gpu_simd_static", 0)
            ref = None
            if ref_key in self.results:
                f = self.results[ref_key]["first"]
                ref = (f["matches"], f["proposals"])
            rec_arms = {}
            for arm in arms:
                method, mode = split_arm(arm)
                opts = self.method_opts(method)
                is_fg = bool(opts["full_gpu"])
                ra = {"method": method, "mode": mode, "blocks": [], "acc": set(),
                      "max_pos": None, "max_ang": None, "max_scale": None,
                      "gt_calls": 0, "gt_pass": True, "ambiguous": 0,
                      "route_valid": True, "algo_executed": True, "repeat_exact": True,
                      "native_repeat": True, "mode_route_valid": True,
                      "matches_eq_mode1": True, "proposals_eq_mode1": True,
                      "exact_calls": 0, "exact_match_fail_calls": 0, "exact_prop_fail_calls": 0,
                      "parity": True, "proposal_counts": set(), "gpu_bytes": set(),
                      "coarse_score_bytes": set(), "peak_scratch_bytes": set(),
                      "peak_batch_maps": set(), "frame_gpu_bytes": set(), "pose_gpu_bytes": set(),
                      "warmup_gate_min_ms": None, "warmup_gate_pass": True,
                      "pooled": {}, "rss_final": [], "rss_max_any": [],
                      "cold": 0, "warm": 0, "meas": 0}
                pooled = {}
                for b in range(blocks):
                    key = (case, arm, b)
                    if key not in self.results:
                        continue
                    r = self.results[key]
                    tag = "%s/%s/b%d" % (case, arm, b)
                    counts["fresh_processes"] += 1
                    counts["cold_calls"] += 1
                    ra["cold"] += 1
                    calls = self.scoped_calls(key)
                    meas = self.measured_calls(key)
                    # structure
                    if mode == "static":
                        if len(r["runs"]) != n_meas:
                            self.fail("result_structure", tag, n_meas, len(r["runs"]))
                        nw = len(r.get("warmups_ms") or [])
                        counts["native_only_warmup_calls"] += nw
                        ra["warm"] += nw
                    else:
                        w = self.warmup_calls(case)
                        if len(r["runs"]) != 1 + w + n_meas:
                            self.fail("result_structure", tag, 1 + w + n_meas, len(r["runs"]))
                        counts["gt_checked_warmup_calls"] += w
                        ra["warm"] += w
                    counts["measured_calls"] += len(meas)
                    ra["meas"] += len(meas)
                    # GT, route, exactness
                    first_out = (calls[0][1]["matches"], calls[0][1]["proposals"])
                    for ci, (role, call) in enumerate(calls):
                        g = gt_match(call["matches"], truths, th_pos, th_ang, th_scale)
                        counts["gt_evaluated_calls"] += 1
                        ra["gt_calls"] += 1
                        ra["acc"].add((g["tp"], g["fp"], g["fn"]))
                        ra["ambiguous"] += g["ambiguous"]
                        if g["fp"] or g["fn"]:
                            ra["gt_pass"] = False
                            self.fail("independent_ground_truth", "%s %s#%d" % (tag, role, ci),
                                      "FP=0 FN=0", {"tp": g["tp"], "fp": g["fp"], "fn": g["fn"]})
                        ra["max_pos"] = max_opt(ra["max_pos"], g["max_pos"])
                        ra["max_ang"] = max_opt(ra["max_ang"], g["max_ang"])
                        ra["max_scale"] = max_opt(ra["max_scale"], g["max_scale"])
                        ra["proposal_counts"].add(len(call["proposals"]))
                        fg = call.get("full_gpu", {})
                        if is_fg:
                            want_mode = opts["full_gpu_peak_mode"]
                            batch = opts.get("full_gpu_peak_batch", 1) if want_mode == 2 else 1
                            checks = {
                                "enabled": fg.get("enabled") is True,
                                "command_buffers==1": fg.get("command_buffers") == 1,
                                "cpu_waits==1": fg.get("cpu_waits") == 1,
                                "intermediate_readbacks==0": fg.get("intermediate_readbacks") == 0,
                                "cpu_algorithm_steps==0": fg.get("cpu_algorithm_steps") == 0,
                                "peak_mode": fg.get("peak_mode") == want_mode,
                                "peak_batch_maps": is_num(fg.get("peak_batch_maps"))
                                and 1 <= fg.get("peak_batch_maps") <= batch,
                                "fine_mode==4": fg.get("fine_mode") == 4,
                            }
                            bad = [k for k, v in checks.items() if not v]
                            if bad:
                                ra["route_valid"] = False
                                self.fail("route_and_residency", "%s %s#%d" % (tag, role, ci), "all pass",
                                          {k: fg.get(k.split("=")[0]) for k in bad})
                            if fg.get("fine_effective_mode") != 4:
                                ra["algo_executed"] = False
                                self.fail("requested_algorithm_not_executed", "%s %s#%d" % (tag, role, ci),
                                          4, fg.get("fine_effective_mode"))
                            ra["gpu_bytes"].add(fg.get("gpu_bytes"))
                            ra["coarse_score_bytes"].add(fg.get("coarse_score_bytes"))
                            ra["peak_scratch_bytes"].add(fg.get("peak_scratch_bytes"))
                            ra["peak_batch_maps"].add(fg.get("peak_batch_maps"))
                        else:
                            # hybrid: no full-GPU route; Metal refinement when the job refines
                            hy_bad = []
                            if fg.get("enabled") not in (False, None) or fg.get("command_buffers", 0) != 0:
                                hy_bad.append("full_gpu disabled")
                            if self.jobs[key].get("refine"):
                                if call.get("selected_refinement_backend") != 1:
                                    hy_bad.append("selected_refinement_backend==1")
                            if hy_bad:
                                ra["route_valid"] = False
                                self.fail("route_and_residency", "%s %s#%d (hybrid)" % (tag, role, ci),
                                          "hybrid Metal refinement route", hy_bad)
                            ra["frame_gpu_bytes"].add(call.get("frame_coarse_gpu_bytes", 0)
                                                      + call.get("frame_fine_gpu_bytes", 0))
                            ra["pose_gpu_bytes"].add(call.get("pose_gpu_bytes"))
                        out = (call["matches"], call["proposals"])
                        if out != first_out:
                            ra["repeat_exact"] = False
                            self.fail("exact_repeat", "%s %s#%d" % (tag, role, ci),
                                      "equal to call 0 of process", "different")
                        if method in ("full_gpu_parallel", "full_gpu_parallel_b1") and ref is not None:
                            ra["exact_calls"] += 1
                            if call["matches"] != ref[0]:
                                ra["matches_eq_mode1"] = False
                                ra["exact_match_fail_calls"] += 1
                                self.fail("exact_ordered_matches_vs_mode1", "%s %s#%d" % (tag, role, ci),
                                          "equal", "different")
                            if call["proposals"] != ref[1]:
                                ra["proposals_eq_mode1"] = False
                                ra["exact_prop_fail_calls"] += 1
                                self.fail("exact_ordered_proposals_vs_mode1", "%s %s#%d" % (tag, role, ci),
                                          "equal", "different")
                        if mode == "frames":
                            sk = (case, method + "_static", 0)
                            if sk in self.results:
                                sf = self.results[sk]["first"]
                                if out != (sf["matches"], sf["proposals"]):
                                    ra["parity"] = False
                                    self.fail("same_method_output_parity", "%s %s#%d" % (tag, role, ci),
                                              "equal to %s_static b0 first" % method, "different")
                    native = r.get("exact_repeat") if mode == "static" else r.get("exact_sequence_repeat")
                    if native is not True:
                        ra["native_repeat"] = False
                        self.fail("exact_repeat", tag + " native flag", True, native)
                    # static / sequence route
                    if mode == "static":
                        bad = [i for i, (_, c) in enumerate(calls) if c.get("source_generation") != 0]
                        if bad:
                            ra["mode_route_valid"] = False
                            self.fail("static_route", tag, "source_generation 0 on every call", bad)
                    else:
                        runs = r["runs"]
                        bad = []
                        for i, c in enumerate(runs):
                            if c.get("call") != i or c.get("source_generation") != i:
                                bad.append((i, "call/source_generation"))
                            if i >= 1 and not (is_num(c.get("source_update_ms")) and c["source_update_ms"] > 0):
                                bad.append((i, "source_update_ms"))
                            if c.get("source_path") != self.cases[case]["source"]:
                                bad.append((i, "source_path"))
                        if r.get("sequence_mode") != "reuse" or r.get("calls") != len(runs) or r.get("drained") is not True:
                            bad.append(("process", "sequence_mode/calls/drained"))
                        if bad:
                            ra["mode_route_valid"] = False
                            self.fail("sequence_route", tag, "updateSource on every call after the first", bad)
                        # 7. warm-up gate
                        w = self.warmup_calls(case)
                        wall = runs[w]["elapsed_ms"] - runs[0]["elapsed_ms"]
                        ra["warmup_gate_min_ms"] = wall if ra["warmup_gate_min_ms"] is None else min(
                            ra["warmup_gate_min_ms"], wall)
                        if not wall >= 1000.0:
                            ra["warmup_gate_pass"] = False
                            self.fail("warmup_shorter_than_1s", tag, ">= 1000 ms", wall)
                    # timing per block
                    rss_final = r["final_memory"]["peak_rss_bytes"]
                    rss_any = max([v["peak_rss_bytes"] for k, v in r.items()
                                   if k.endswith("memory") and isinstance(v, dict) and "peak_rss_bytes" in v]
                                  + [c["memory"]["peak_rss_bytes"] for _, c in calls if "memory" in c]
                                  + ([r["first"]["memory"]["peak_rss_bytes"]] if "first" in r else []))
                    ra["rss_final"].append(rss_final)
                    ra["rss_max_any"].append(rss_any)
                    blk = {"block": b}
                    if mode == "static":
                        vals = [x["total_ms"] for x in meas]
                        pooled.setdefault("total_ms", []).extend(vals)
                        if is_fg:
                            pooled.setdefault("device_ms", []).extend(x["full_gpu"]["device_ms"] for x in meas)
                        blk.update({
                            "total_median_ms": median(vals),
                            "first_total_ms": r["first"]["total_ms"],
                            "warmup_calls": len(r.get("warmups_ms") or []),
                            "construct_ms": r.get("construct_ms"),
                            "peak_rss_bytes": rss_final,
                        })
                        blk["_warmup_sum_ms"] = sum(r.get("warmups_ms") or [])
                    else:
                        w = self.warmup_calls(case)
                        fw = [x["frame_wall_ms"] for x in meas]
                        tt = [x["total_ms"] for x in meas]
                        for f in ("frame_wall_ms", "total_ms", "source_update_ms", "pose_create_ms",
                                  "source_decode_ms"):
                            pooled.setdefault(f, []).extend(x[f] for x in meas)
                        blk.update({
                            "frame_wall_median_ms": median(fw),
                            "total_median_ms": median(tt),
                            "warmup_calls": w,
                            "warmup_wall_ms": r["runs"][w]["elapsed_ms"] - r["runs"][0]["elapsed_ms"],
                            "cold_total_ms": r["runs"][0]["total_ms"],
                            "peak_rss_bytes": rss_final,
                        })
                    if self.phase == "profile" and is_fg:
                        prof = ra.setdefault("_profile", {"available": 0, "measured": 0, "stages": {},
                                                          "stage_sum": [], "remainder": []})
                        for x in meas:
                            prof["measured"] += 1
                            fgx = x["full_gpu"]
                            if fgx.get("profile_available"):
                                prof["available"] += 1
                                ssum = 0.0
                                for st in fgx.get("stages", []):
                                    prof["stages"].setdefault(st["name"], []).append(st["gpu_ms"])
                                    ssum += st["gpu_ms"]
                                prof["stage_sum"].append(ssum)
                                prof["remainder"].append(fgx["device_ms"] - ssum)
                    ra["blocks"].append(blk)
                ra["pooled"] = {k: stats(v) for k, v in pooled.items()}
                rec_arms[arm] = ra
            rec_cases[case] = {"arms": rec_arms, "truth_count": len(truths)}
        self.recomputed = rec_cases
        self.counts = counts

    # ---- comparisons -------------------------------------------------------
    def comparison(self, case, base_arm, cand_arm, metric, primary=False):
        arms = self.recomputed[case]["arms"]
        if base_arm not in arms or cand_arm not in arms:
            return None
        base, cand = arms[base_arm], arms[cand_arm]
        bm = base["pooled"][metric]["median"]
        cm = cand["pooled"][metric]["median"]
        field = "total_median_ms" if metric == "total_ms" else "frame_wall_median_ms"
        bb = {x["block"]: x[field] for x in base["blocks"]}
        cb = {x["block"]: x[field] for x in cand["blocks"]}
        delta = cm - bm
        paired = []
        for b in sorted(set(bb) & set(cb)):
            d = cb[b] - bb[b]
            paired.append({"block": b, "baseline_ms": bb[b], "candidate_ms": cb[b], "delta_ms": d,
                           "delta_percent": d / bb[b] * 100.0,
                           "within_regression_budget": within_time_budget(cb[b], bb[b])})
        faster_blocks = sum(1 for p in paired if p["delta_ms"] < 0)
        sign = (delta > 0) - (delta < 0)
        consistent = sign != 0 and all(((p["delta_ms"] > 0) - (p["delta_ms"] < 0)) == sign for p in paired)
        faster = None
        if consistent:
            faster = cand["method"] if delta < 0 else base["method"]
        out = {"baseline": base["method"], "candidate": cand["method"], "metric": metric,
               "baseline_median_ms": bm, "candidate_median_ms": cm, "delta_ms": delta,
               "delta_percent": delta / bm * 100.0, "paired": paired,
               "candidate_faster_blocks": faster_blocks, "blocks": len(paired),
               "consistent_direction": consistent, "faster": faster}
        if primary:
            out["primary_target_percent"] = -10.0
            out["primary_target_met"] = (out["delta_percent"] <= -10.0 and faster_blocks == len(paired)
                                         and len(paired) > 0)
        return out

    COMPARISONS = [
        ("full_gpu_parallel_b1_vs_mode1_static", "full_gpu_simd_static", "full_gpu_parallel_b1_static", "total_ms"),
        ("full_gpu_parallel_vs_mode1_static", "full_gpu_simd_static", "full_gpu_parallel_static", "total_ms"),
        ("batch_vs_b1_static", "full_gpu_parallel_b1_static", "full_gpu_parallel_static", "total_ms"),
        ("vs_hybrid_frames_frame_wall", "hybrid_best_frames", "full_gpu_parallel_frames", "frame_wall_ms"),
        ("vs_hybrid_frames_run_only", "hybrid_best_frames", "full_gpu_parallel_frames", "total_ms"),
        ("vs_hybrid_static_run_only", "hybrid_best_static", "full_gpu_parallel_static", "total_ms"),
        ("mode1_vs_hybrid_static_run_only", "hybrid_best_static", "full_gpu_simd_static", "total_ms"),
    ]

    def build_comparisons(self):
        primary_cases = set(self.protocol["cases"]["primary"])
        self.comparisons = {}
        if self.phase == "profile":
            return  # diagnostic only, never time-gated or compared
        for case in self.recomputed:
            cs = {}
            for name, base, cand, metric in self.COMPARISONS:
                prim = name == "full_gpu_parallel_vs_mode1_static" and case in primary_cases
                c = self.comparison(case, base, cand, metric, primary=prim)
                if c is not None:
                    cs[name] = c
            self.comparisons[case] = cs

    # ---- gates -------------------------------------------------------------
    def gates(self):
        g = []
        semantic = {"independent_ground_truth", "route_and_residency", "requested_algorithm_not_executed",
                    "exact_repeat", "static_route", "sequence_route", "same_method_output_parity",
                    "exact_ordered_matches_vs_mode1", "exact_ordered_proposals_vs_mode1",
                    "warmup_shorter_than_1s", "host_busy"}
        seen = set()
        for f in self.check_failures:
            if f["check"] in semantic:
                k = (f["check"], f["what"].split(" ")[0])
                if k not in seen:
                    seen.add(k)
                    g.append({"gate": f["check"], "where": f["what"].split(" ")[0]})
        self.rss_info = []
        timed = self.phase in ("pilot", "formal")
        for case, arms in ((c, self.recomputed[c]["arms"]) for c in self.recomputed):
            if "full_gpu_simd_static" in arms:
                base = arms["full_gpu_simd_static"]
                for cand_arm in ("full_gpu_parallel_b1_static", "full_gpu_parallel_static"):
                    if cand_arm not in arms:
                        continue
                    cand = arms[cand_arm]
                    if timed:
                        bb = {x["block"]: x["total_median_ms"] for x in base["blocks"]}
                        for x in cand["blocks"]:
                            if not within_time_budget(x["total_median_ms"], bb[x["block"]]):
                                g.append({"gate": "time_budget_vs_mode1", "where": "%s/%s/b%d" % (
                                    case, cand_arm, x["block"]), "candidate_ms": x["total_median_ms"],
                                    "baseline_ms": bb[x["block"]]})
                    for defn in ("rss_final", "rss_max_any"):
                        ok = within_rss_budget(max(cand[defn]), max(base[defn]))
                        self.rss_info.append({"case": case, "candidate": cand_arm, "baseline": "full_gpu_simd_static",
                                              "rss_definition": defn, "candidate_peak": max(cand[defn]),
                                              "baseline_peak": max(base[defn]), "within": ok})
                        if not ok and (timed or defn == "rss_final"):
                            g.append({"gate": "rss_budget_vs_mode1", "where": "%s/%s" % (case, cand_arm),
                                      "rss_definition": defn, "phase_gated": timed})
            if "hybrid_best_frames" in arms and "full_gpu_parallel_frames" in arms and timed:
                base, cand = arms["hybrid_best_frames"], arms["full_gpu_parallel_frames"]
                bb = {x["block"]: x["frame_wall_median_ms"] for x in base["blocks"]}
                for x in cand["blocks"]:
                    if not within_time_budget(x["frame_wall_median_ms"], bb[x["block"]]):
                        g.append({"gate": "time_budget_vs_hybrid", "where": "%s/full_gpu_parallel_frames/b%d" % (
                            case, x["block"]), "candidate_ms": x["frame_wall_median_ms"],
                            "baseline_ms": bb[x["block"]]})
                for defn in ("rss_final", "rss_max_any"):
                    ok = within_rss_budget(max(cand[defn]), max(base[defn]))
                    self.rss_info.append({"case": case, "candidate": "full_gpu_parallel_frames",
                                          "baseline": "hybrid_best_frames", "rss_definition": defn,
                                          "candidate_peak": max(cand[defn]), "baseline_peak": max(base[defn]),
                                          "within": ok})
                    if not ok:
                        g.append({"gate": "rss_budget_vs_hybrid", "where": "%s/full_gpu_parallel_frames" % case,
                                  "rss_definition": defn})
        if self.phase == "formal":
            for case in self.protocol["cases"]["primary"]:
                c = self.comparisons.get(case, {}).get("full_gpu_parallel_vs_mode1_static")
                if c is None or not c.get("primary_target_met"):
                    g.append({"gate": "primary_10_percent_improvement", "where": case,
                              "delta_percent": None if c is None else c["delta_percent"],
                              "faster_blocks": None if c is None else c["candidate_faster_blocks"]})
        self.failed_gates = g

    # ---- compare with the published summary --------------------------------
    def compare_summary(self):
        s = self.summary
        self.cmp("summary.phase", self.phase, s.get("phase"))
        self.cmp("summary.formal_decision_eligible", self.phase == "formal", s.get("formal_decision_eligible"))
        self.cmp("summary.profiling", bool(self.pspec.get("profiling", False)), s.get("profiling"))
        self.cmp("summary.accuracy_thresholds",
                 {"position_px": self.th[0], "angle_deg": self.th[1], "relative_scale": self.th[2]},
                 s.get("accuracy_thresholds"))
        for k, v in self.counts.items():
            self.cmp("summary.counts.%s" % k, s["counts"].get(k), v)
        all_acc = all(a["gt_pass"] for c in self.recomputed.values() for a in c["arms"].values())
        all_route = all(a["route_valid"] and a["algo_executed"] and a["mode_route_valid"]
                        for c in self.recomputed.values() for a in c["arms"].values())
        all_rep = all(a["repeat_exact"] and a["native_repeat"]
                      for c in self.recomputed.values() for a in c["arms"].values())
        all_exact = all(a["matches_eq_mode1"] and a["proposals_eq_mode1"]
                        for c in self.recomputed.values() for a in c["arms"].values())
        self.cmp("summary.all_accuracy_pass", s.get("all_accuracy_pass"), all_acc)
        self.cmp("summary.all_routes_pass", s.get("all_routes_pass"), all_route)
        self.cmp("summary.all_repeat_exact", s.get("all_repeat_exact"), all_rep)
        self.cmp("summary.all_parallel_exact_mode1", s.get("all_parallel_exact_mode1"), all_exact)
        if self.phase == "formal":
            ptm = all(self.comparisons[c]["full_gpu_parallel_vs_mode1_static"].get("primary_target_met")
                      for c in self.protocol["cases"]["primary"])
        else:
            ptm = None
        self.cmp("summary.primary_target_met", s.get("primary_target_met"), ptm)
        self.cmp("summary.failed_gates.count", len(s.get("failed_gates", [])), len(self.failed_gates))
        self.flags = {"all_accuracy_pass": all_acc, "all_routes_pass": all_route, "all_repeat_exact": all_rep,
                      "all_parallel_exact_mode1": all_exact, "primary_target_met": ptm}

        pub_cases = {c["name"]: c for c in s["cases"]}
        self.cmp("summary.case_names", list(self.recomputed), [c["name"] for c in s["cases"]])
        for case, rc in self.recomputed.items():
            pc = pub_cases.get(case)
            if pc is None:
                continue
            pre = "case[%s]" % case
            self.cmp(pre + ".truth_count", pc.get("truth_count"), rc["truth_count"])
            refine = {bool(j.get("refine")) for k, j in self.jobs.items() if k[0] == case}
            self.cmp(pre + ".refine", pc.get("refine"), refine.pop() if len(refine) == 1 else sorted(refine))
            fw = self.warmup_calls(case) if any(a.endswith("_frames") for a in rc["arms"]) else None
            self.cmp(pre + ".frame_warmup_calls", pc.get("frame_warmup_calls"), fw)
            self.cmp(pre + ".arm_names", list(rc["arms"]), list(pc["arms"]))
            for arm, ra in rc["arms"].items():
                pa = pc["arms"].get(arm)
                if pa is None:
                    continue
                ap = pre + ".arms[%s]" % arm
                self.cmp(ap + ".method", pa.get("method"), ra["method"])
                self.cmp(ap + ".mode", pa.get("mode"), ra["mode"])
                for metric, st in ra["pooled"].items():
                    if metric in pa:
                        self.cmp(ap + "." + metric, pa[metric], st)
                    else:
                        self.notes.append("%s: recomputed metric %s not published" % (ap, metric))
                pub_blocks = {x["block"]: x for x in pa.get("blocks", [])}
                self.cmp(ap + ".block_ids", sorted(pub_blocks), [x["block"] for x in ra["blocks"]])
                for x in ra["blocks"]:
                    pb = pub_blocks.get(x["block"])
                    if pb is None:
                        continue
                    for k, v in x.items():
                        if k.startswith("_"):
                            continue
                        if k in pb:
                            self.cmp(ap + ".blocks[%d].%s" % (x["block"], k), pb[k], v)
                    for k in pb:
                        if k not in x:
                            self.notes.append("%s.blocks[%d].%s published but not recomputed" % (ap, x["block"], k))
                self.cmp(ap + ".peak_rss_bytes", pa.get("peak_rss_bytes"), max(ra["rss_final"]))
                if max(ra["rss_max_any"]) != max(ra["rss_final"]):
                    self.notes.append(
                        "%s: max of all recorded peak_rss_bytes fields (%d) exceeds final_memory.peak_rss_bytes (%d) by %d bytes"
                        % (ap, max(ra["rss_max_any"]), max(ra["rss_final"]),
                           max(ra["rss_max_any"]) - max(ra["rss_final"])))
                self.cmp(ap + ".cold_calls", pa.get("cold_calls"), ra["cold"])
                self.cmp(ap + ".warmup_calls", pa.get("warmup_calls"), ra["warm"])
                self.cmp(ap + ".measured_calls", pa.get("measured_calls"), ra["meas"])
                self.cmp(ap + ".gt_evaluated_calls", pa.get("gt_evaluated_calls"), ra["gt_calls"])
                self.cmp(ap + ".all_gt_pass", pa.get("all_gt_pass"), ra["gt_pass"])
                self.cmp(ap + ".accuracy_counts", sorted(map(list, pa.get("accuracy_counts", []))),
                         sorted(map(list, ra["acc"])))
                self.cmp(ap + ".max_errors", pa.get("max_errors"),
                         {"position_px": ra["max_pos"], "angle_deg": ra["max_ang"],
                          "relative_scale": ra["max_scale"]})
                self.cmp(ap + ".route_valid", pa.get("route_valid"), ra["route_valid"])
                self.cmp(ap + ".requested_algorithm_executed", pa.get("requested_algorithm_executed"),
                         ra["algo_executed"])
                self.cmp(ap + ".repeat_exact", pa.get("repeat_exact"), ra["repeat_exact"] and ra["native_repeat"])
                self.cmp(ap + ".proposal_counts", pa.get("proposal_counts"), sorted(ra["proposal_counts"]))
                if ra["mode"] == "static":
                    self.cmp(ap + ".static_route_valid", pa.get("static_route_valid"), ra["mode_route_valid"])
                else:
                    self.cmp(ap + ".sequence_route_valid", pa.get("sequence_route_valid"), ra["mode_route_valid"])
                    self.cmp(ap + ".same_method_output_parity", pa.get("same_method_output_parity"), ra["parity"])
                if self.method_opts(ra["method"])["full_gpu"]:
                    self.cmp(ap + ".named_gpu_bytes", pa.get("named_gpu_bytes"), sorted(ra["gpu_bytes"]))
                    self.cmp(ap + ".coarse_score_bytes", pa.get("coarse_score_bytes"),
                             sorted(ra["coarse_score_bytes"]))
                    self.cmp(ap + ".peak_scratch_bytes", pa.get("peak_scratch_bytes"),
                             sorted(ra["peak_scratch_bytes"]))
                    self.cmp(ap + ".peak_batch_maps", pa.get("peak_batch_maps"), sorted(ra["peak_batch_maps"]))
                else:
                    self.cmp(ap + ".frame_gpu_bytes", pa.get("frame_gpu_bytes"), sorted(ra["frame_gpu_bytes"]))
                    self.cmp(ap + ".pose_gpu_bytes", pa.get("pose_gpu_bytes"), sorted(ra["pose_gpu_bytes"]))
                if ra["method"] in ("full_gpu_parallel", "full_gpu_parallel_b1"):
                    self.cmp(ap + ".ordered_matches_equal_mode1", pa.get("ordered_matches_equal_mode1"),
                             ra["matches_eq_mode1"])
                    self.cmp(ap + ".ordered_proposals_equal_mode1", pa.get("ordered_proposals_equal_mode1"),
                             ra["proposals_eq_mode1"])
                if "_profile" in ra:
                    pp = pa.get("profile", {})
                    prof = ra["_profile"]
                    self.cmp(ap + ".profile.measured_available_calls", pp.get("measured_available_calls"),
                             prof["available"])
                    self.cmp(ap + ".profile.measured_calls", pp.get("measured_calls"), prof["measured"])
                    self.cmp(ap + ".profile.stage_names", sorted(pp.get("stages", {})), sorted(prof["stages"]))
                    for name, vals in prof["stages"].items():
                        if name in pp.get("stages", {}):
                            self.cmp(ap + ".profile.stages[%s]" % name, pp["stages"][name], stats(vals))
                    self.cmp(ap + ".profile.stage_sum_ms", pp.get("stage_sum_ms"), stats(prof["stage_sum"]))
                    self.cmp(ap + ".profile.device_remainder_ms", pp.get("device_remainder_ms"),
                             stats(prof["remainder"]))
            # comparisons
            rcmp = self.comparisons.get(case, {})
            pcmp = pc.get("comparisons", {})
            self.cmp(pre + ".comparison_names", sorted(pcmp), sorted(rcmp))
            for name, c in rcmp.items():
                if name not in pcmp:
                    continue
                p = pcmp[name]
                cp = pre + ".comparisons[%s]" % name
                for k, v in c.items():
                    if k == "paired":
                        pubp = {x["block"]: x for x in p.get("paired", [])}
                        self.cmp(cp + ".paired.blocks", sorted(pubp), [x["block"] for x in v])
                        for x in v:
                            for kk, vv in x.items():
                                if x["block"] in pubp:
                                    self.cmp(cp + ".paired[%d].%s" % (x["block"], kk), pubp[x["block"]].get(kk), vv)
                    else:
                        self.cmp(cp + "." + k, p.get(k), v)
                for k in p:
                    if k not in c:
                        self.notes.append("%s.%s published but not recomputed" % (cp, k))

    def run(self):
        self.check_integrity()
        self.load()
        self.check_jobs()
        self.recompute()
        self.build_comparisons()
        self.gates()
        self.compare_summary()

    def report(self):
        ambiguous = sum(a["ambiguous"] for c in self.recomputed.values() for a in c["arms"].values())
        maxerr = {"position_px": None, "angle_deg": None, "relative_scale": None}
        for c in self.recomputed.values():
            for a in c["arms"].values():
                maxerr["position_px"] = max_opt(maxerr["position_px"], a["max_pos"])
                maxerr["angle_deg"] = max_opt(maxerr["angle_deg"], a["max_ang"])
                maxerr["relative_scale"] = max_opt(maxerr["relative_scale"], a["max_scale"])
        warm = [a["warmup_gate_min_ms"] for c in self.recomputed.values() for a in c["arms"].values()
                if a["warmup_gate_min_ms"] is not None]
        exact_calls = sum(a["exact_calls"] for c in self.recomputed.values() for a in c["arms"].values())
        static_warm_min = [x["_warmup_sum_ms"] for c in self.recomputed.values() for a in c["arms"].values()
                           for x in a["blocks"] if "_warmup_sum_ms" in x]
        return {
            "phase": self.phase,
            "counts": self.counts,
            "executions": len(self.manifest["executions"]),
            "files_hashed": 2 * len(self.manifest["executions"]),
            "stdout_files_compared_with_result": self.stdout_checked,
            "schedule": self.order_note,
            "source_hash_coverage": self.source_coverage,
            "truth_keys_found_in_jobs": self.truth_hits,
            "gt": {
                "evaluated_calls": self.counts["gt_evaluated_calls"],
                "all_fp_fn_zero": self.flags["all_accuracy_pass"],
                "max_errors_over_matched_pairs": maxerr,
                "ambiguous_candidate_edges": ambiguous,
            },
            "exactness_vs_mode1": {
                "calls_compared": exact_calls,
                "all_equal": self.flags["all_parallel_exact_mode1"],
            },
            "route_all_pass": self.flags["all_routes_pass"],
            "repeat_all_exact": self.flags["all_repeat_exact"],
            "frames_warmup_gate_min_ms": min(warm) if warm else None,
            "static_warmup_sum_min_ms": min(static_warm_min) if static_warm_min else None,
            "host_busy": self.host_busy,
            "primary_target_met": self.flags["primary_target_met"],
            "recomputed_failed_gates": self.failed_gates,
            "published_failed_gates": self.summary.get("failed_gates"),
            "rss_budget_details": self.rss_info,
            "values_compared_with_published": self.values_compared,
            "mismatches": self.mismatches,
            "within_tolerance_not_bit_identical": self.inexact,
            "check_failures": self.check_failures,
            "notes": self.notes,
        }


# --------------------------------------------------------------------------
# decision file cross-check
# --------------------------------------------------------------------------

def check_decision(root, audits):
    d = load_json(root / "cpp-core" / "docs" / "stage42-parallel-peaks" / "decision-and-failures.json")
    mism = []
    compared = 0

    def cmp(what, pub, rec):
        nonlocal compared
        compared += 1
        if not close(pub, rec):
            mism.append({"what": what, "published": pub, "recomputed": rec})

    semantic = {"independent_ground_truth", "route_and_residency", "requested_algorithm_not_executed",
                "exact_repeat", "static_route", "sequence_route", "same_method_output_parity",
                "exact_ordered_matches_vs_mode1", "exact_ordered_proposals_vs_mode1"}
    no_sem = not any(g["gate"] in semantic for ph in ("formal", "holdout") for g in audits[ph].failed_gates)
    prim = bool(audits["formal"].flags["primary_target_met"])
    no_budget = not any(g["gate"] in ("time_budget_vs_mode1", "rss_budget_vs_mode1")
                        for g in audits["formal"].failed_gates)
    cmp("adoption_conditions.no_semantic_gate_failures_formal_or_holdout",
        d["adoption_conditions"].get("no_semantic_gate_failures_formal_or_holdout"), no_sem)
    cmp("adoption_conditions.primary_target_both_cases", d["adoption_conditions"].get("primary_target_both_cases"), prim)
    cmp("adoption_conditions.no_time_or_rss_budget_failure_vs_mode1",
        d["adoption_conditions"].get("no_time_or_rss_budget_failure_vs_mode1"), no_budget)
    cmp("adopt_full_gpu_parallel_as_full_gpu_research_best",
        d.get("adopt_full_gpu_parallel_as_full_gpu_research_best"), no_sem and prim and no_budget)
    for ph in PHASES:
        cmp("all_failed_gates.%s.count" % ph, len(d["all_failed_gates"].get(ph, [])), len(audits[ph].failed_gates))
        cmp("failure_counts.%s" % ph, d["failure_counts"].get(ph), len(audits[ph].failed_gates))
    fc = audits["formal"].comparisons
    for case, cs in d.get("formal_comparisons", {}).items():
        for name, vals in cs.items():
            rec = fc.get(case, {}).get(name)
            if rec is None:
                mism.append({"what": "formal_comparisons.%s.%s" % (case, name), "published": "present",
                             "recomputed": "absent"})
                continue
            for k, v in vals.items():
                cmp("formal_comparisons.%s.%s.%s" % (case, name, k), v, rec.get(k))
    for case, vals in d.get("hybrid_per_new_frame", {}).items():
        rec = fc.get(case, {}).get("vs_hybrid_frames_frame_wall", {})
        for k, v in vals.items():
            cmp("hybrid_per_new_frame.%s.%s" % (case, k), v, rec.get(k))
    return {"values_compared": compared, "mismatches": mism,
            "recomputed_adoption": no_sem and prim and no_budget,
            "host_disclosures_published": len(d.get("host_disclosures", []))}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=str(Path(__file__).resolve().parents[3]))
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    root = Path(args.root)
    out = Path(args.out) if args.out else root / "build" / "stage42-parallel-peaks" / "validation" / "independent-audit.json"
    protocol = load_json(root / "cpp-core" / "docs" / "stage42-parallel-peaks" / "protocol.json")
    audits = {}
    for ph in PHASES:
        a = PhaseAudit(root, protocol, ph)
        a.run()
        audits[ph] = a
    decision = check_decision(root, audits)
    report = {
        "audit": "independent recomputation of round 42 from raw worker outputs; spec = protocol.json only",
        "tolerance": {"relative": REL_TOL, "absolute": ABS_TOL},
        "audited_files_sha256": {
            str(p.relative_to(root)): sha256_file(p) for p in
            [root / "cpp-core" / "docs" / "stage42-parallel-peaks" / n for n in
             ["protocol.json", "decision-and-failures.json", "source-sha256.json"]
             + ["%s-summary.json" % ph for ph in PHASES]]
            + [root / "build" / "stage42-parallel-peaks" / ph / "manifest.json" for ph in PHASES]
        },
        "assumptions": [
            "GT matches use `matches` only (proposals are not GT-evaluated); maximum one-to-one assignment by "
            "Kuhn augmenting paths over edges with distance <= 2 px, angle diff (mod 360) <= 1 deg, "
            "|s_pred/s_truth - 1| <= 0.02; edges tried in ascending distance.",
            "Static measured = runs; frames measured = runs[1+frame_warmup_calls:]; GT/exactness/route scope = "
            "static first + runs, frames every run.",
            "Pooled median = median of all measured values of the arm across blocks; block median = median of "
            "the block's measured values.",
            "Per-process peak RSS = final_memory.peak_rss_bytes (also computed as the max of every recorded "
            "peak_rss_bytes field; differences are listed in notes and rss_budget_details).",
            "Arm peak RSS for budgets = max over blocks; time budget = candidate block median <= baseline block "
            "median + max(2 ms, 10%); RSS budget = candidate <= baseline + max(8 MiB, 10%).",
            "time_budget gates only in pilot/formal; rss_budget vs mode 1 gated in pilot/formal and reported "
            "(not gated) in profile/holdout; primary target gated in formal only; profile has no comparisons.",
            "Declared arm order = protocol method order (hybrid_best, full_gpu_simd, full_gpu_parallel_b1, "
            "full_gpu_parallel) for static arms, then hybrid_best, full_gpu_parallel frames; pilot cases = "
            "primary + controls.",
            "Hybrid route = full_gpu disabled and selected_refinement_backend == 1 when the job refines.",
            "Frames warm-up wall = runs[w].elapsed_ms - runs[0].elapsed_ms; compared with published "
            "warmup_wall_ms.",
        ],
        "phases": {ph: audits[ph].report() for ph in PHASES},
        "decision_file": decision,
    }
    total_mism = sum(len(audits[ph].mismatches) for ph in PHASES) + len(decision["mismatches"])
    total_fail = sum(len(audits[ph].check_failures) for ph in PHASES)
    total_cmp = sum(audits[ph].values_compared for ph in PHASES) + decision["values_compared"]
    report["totals"] = {"values_compared": total_cmp, "mismatches": total_mism, "check_failures": total_fail,
                        "all_pass": total_mism == 0 and total_fail == 0}
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=1, sort_keys=False)
        fh.write("\n")

    print("Round 42 independent audit (spec: protocol.json)")
    for ph in PHASES:
        r = report["phases"][ph]
        print("  %-8s processes=%d gt_calls=%d all_fp_fn_zero=%s exact_calls=%d exact=%s routes=%s "
              "repeat=%s warmup_min_ms=%s gates=%d (published %d) mismatches=%d check_failures=%d compared=%d"
              % (ph, r["counts"]["fresh_processes"], r["gt"]["evaluated_calls"], r["gt"]["all_fp_fn_zero"],
                 r["exactness_vs_mode1"]["calls_compared"], r["exactness_vs_mode1"]["all_equal"],
                 r["route_all_pass"], r["repeat_all_exact"],
                 None if r["frames_warmup_gate_min_ms"] is None else round(r["frames_warmup_gate_min_ms"], 1),
                 len(r["recomputed_failed_gates"]), len(r["published_failed_gates"] or []),
                 len(r["mismatches"]), len(r["check_failures"]), r["values_compared_with_published"]))
        me = r["gt"]["max_errors_over_matched_pairs"]
        print("           max err pos=%s ang=%s scale=%s ambiguous_edges=%d"
              % (me["position_px"], me["angle_deg"], me["relative_scale"], r["gt"]["ambiguous_candidate_edges"]))
        for m in r["mismatches"][:20]:
            print("    MISMATCH %s: published=%r recomputed=%r" % (m["what"], m["published"], m["recomputed"]))
        inex = r["within_tolerance_not_bit_identical"]
        if inex:
            print("           %d numeric leaves within tolerance but not bit-identical (max abs diff %.3g)"
                  % (len(inex), max(x["abs_diff"] for x in inex)))
        for f in r["check_failures"][:20]:
            print("    CHECK FAIL %s %s: expected=%r observed=%r" % (f["check"], f["what"], f["expected"], f["observed"]))
        for n in r["notes"][:10]:
            print("    note: %s" % n)
    print("  decision file: compared=%d mismatches=%d recomputed_adoption=%s"
          % (decision["values_compared"], len(decision["mismatches"]), decision["recomputed_adoption"]))
    for m in decision["mismatches"][:20]:
        print("    MISMATCH %s: published=%r recomputed=%r" % (m["what"], m["published"], m["recomputed"]))
    print("TOTAL values compared=%d mismatches=%d check_failures=%d all_pass=%s"
          % (total_cmp, total_mism, total_fail, report["totals"]["all_pass"]))
    print("Output: %s" % out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
