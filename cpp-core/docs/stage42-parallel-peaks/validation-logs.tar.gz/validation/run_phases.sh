#!/bin/bash
# Stage-42 measurement chain, run from the worktree root: pilot, formal, profile,
# holdout in protocol order. Before each non-pilot phase, wait (at most 15 min)
# until the driver's own host check sees no competing process; the driver still
# refuses to start if one appears.
set -u
python=/Users/Ayueh/Fastest_Image_Pattern_Matching/python-port/venv/bin/python
work=build/stage42-parallel-peaks
for phase in pilot formal profile holdout; do
  if [ "$phase" != pilot ]; then
    for i in $(seq 1 90); do
      busy=$(cd cpp-core/tools && "$python" -c 'import benchmark_new_frame_cost as b, json; print(json.dumps(b.host_state()["competing_processes"]))')
      [ "$busy" = "[]" ] && break
      echo "$(date -u +%H:%M:%S) waiting before $phase: $busy"; /bin/sleep 10
    done
  fi
  echo "$(date -u +%H:%M:%S) start $phase"
  (cd cpp-core/tools && "$python" benchmark_parallel_peaks.py --phase "$phase" --build ../../build/stage42-release \
     --output "../../$work/$phase/manifest.json") > "$work/validation/$phase.log" 2>&1
  code=$?
  echo "$(date -u +%H:%M:%S) end $phase exit=$code"
  [ $code -eq 0 ] || exit $code
done
