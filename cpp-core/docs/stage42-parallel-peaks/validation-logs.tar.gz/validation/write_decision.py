"""Apply the stage-42 protocol decision rules to the published summaries.

Run from the worktree root after pilot/formal/profile/holdout summaries exist in
cpp-core/docs/stage42-parallel-peaks. Writes decision-and-failures.json.
"""
import json
from pathlib import Path
out = Path('cpp-core/docs/stage42-parallel-peaks')
load = lambda name: json.loads((out/name).read_text())
pilot, formal, profile, holdout = (load(f'{phase}-summary.json') for phase in ('pilot', 'formal', 'profile', 'holdout'))
CANDIDATE, ABLATION, BASELINE, HYBRID = 'full_gpu_parallel', 'full_gpu_parallel_b1', 'full_gpu_simd', 'hybrid_best'
SEMANTIC = {'independent_ground_truth', 'route_and_residency', 'requested_algorithm_not_executed', 'exact_repeat', 'static_route',
            'sequence_route', 'same_method_output_parity', 'exact_ordered_matches_vs_mode1', 'exact_ordered_proposals_vs_mode1',
            'warmup_shorter_than_1s', 'host_busy'}


def rows(summary):
    return {case['name']: case for case in summary['cases']}


def candidate_failures(summary, gates, arms=(f'{CANDIDATE}_static', f'{CANDIDATE}_frames')):
    return [row for row in summary['failed_gates'] if row['gate'] in gates and row['arm'] in arms]


semantic = [dict(phase=name, **row) for name, summary in (('formal', formal), ('holdout', holdout)) for row in summary['failed_gates']
            if row['gate'] in SEMANTIC and row['arm'].startswith(CANDIDATE+'_')]
mode1_budget = [row for row in formal['failed_gates'] if row['arm'] == f'{CANDIDATE}_static' and row['gate'] in ('time_budget', 'rss_budget')]
primary = {name: case['comparisons'][f'{CANDIDATE}_vs_mode1_static'] for name, case in rows(formal).items()
           if 'primary_target_met' in case['comparisons'][f'{CANDIDATE}_vs_mode1_static']}
adopt = not semantic and not mode1_budget and len(primary) == 2 and all(row['primary_target_met'] for row in primary.values())
cases = {}
for name, case in rows(formal).items():
    comparisons = case['comparisons']
    cases[name] = {key: dict(delta_percent=value['delta_percent'], faster=value['faster'], consistent_direction=value['consistent_direction'],
                             baseline_median_ms=value['baseline_median_ms'], candidate_median_ms=value['candidate_median_ms'],
                             candidate_faster_blocks=value['candidate_faster_blocks'], blocks=value['blocks'],
                             **({'primary_target_met': value['primary_target_met']} if 'primary_target_met' in value else {}))
                   for key, value in comparisons.items()}
decision = dict(stage=42, date='2026-10-24',
    adopt_full_gpu_parallel_as_full_gpu_research_best=adopt,
    adoption_rule='protocol.json decision_rules.adopt_as_full_gpu_research_best',
    adoption_conditions=dict(no_semantic_gate_failures_formal_or_holdout=not semantic,
                             primary_target_both_cases=all(row['primary_target_met'] for row in primary.values()) and len(primary) == 2,
                             no_time_or_rss_budget_failure_vs_mode1=not mode1_budget),
    defaults_changed=False,
    default_note='GUI, core and hybrid defaults unchanged; full_gpu_peak_mode=2 stays an explicit opt-in research option.',
    formal_comparisons=cases,
    hybrid_per_new_frame={name: dict(delta_percent=case['comparisons']['vs_hybrid_frames_frame_wall']['delta_percent'],
                                     faster=case['comparisons']['vs_hybrid_frames_frame_wall']['faster'])
                          for name, case in rows(formal).items()},
    all_failed_gates={name: summary['failed_gates'] for name, summary in
                      (('pilot', pilot), ('formal', formal), ('profile', profile), ('holdout', holdout))},
    failure_counts={name: len(summary['failed_gates']) for name, summary in
                    (('pilot', pilot), ('formal', formal), ('profile', profile), ('holdout', holdout))},
    note='Every failed gate of every phase is retained above; the pilot is screening only and the profile is diagnostic only.')
# Disclosed host disturbance (validation/host-notes.md): the parent session's file scan,
# 13:30:27Z to about 13:33Z, which the driver's process check does not match.
manifest = json.loads(Path('build/stage42-parallel-peaks/formal/manifest.json').read_text())
disturbed = [dict(case=row['case'], arm=row['arm'], block=row['block'], start_utc=row['host']['utc'])
             for row in manifest['executions'] if '2026-10-24T13:30:20' <= row['host']['utc'] <= '2026-10-24T13:33:30']
decision['host_disclosures'] = [dict(source='parent session message', activity="find /Users/Ayueh -maxdepth 6 -name 'timing-lock-*' (one process, disk I/O and some CPU)",
    window_utc=['2026-10-24T13:30:27Z', 'about 2026-10-24T13:33Z'], workers_started_in_window=disturbed,
    handling='Not removed or rerun; every arm of each affected block shares the window (interleaved schedule). The pilot before the window and the profile and holdout phases after it are reported for comparison.'),
    dict(source='round-43 session message', activity='~20 s tar|gzip size check ending about 13:28Z', window_utc=['before 2026-10-24T13:28Z'],
         handling='At most the first seconds of the pilot (screening only).')]
(out/'decision-and-failures.json').write_text(json.dumps(decision, indent=2, ensure_ascii=False, allow_nan=False)+'\n')
(out/'decision-and-failures.json').write_text(json.dumps(decision, indent=2, ensure_ascii=False, allow_nan=False)+'\n')
print(json.dumps(dict(adopt=adopt, failures=decision['failure_counts'], conditions=decision['adoption_conditions'])))
