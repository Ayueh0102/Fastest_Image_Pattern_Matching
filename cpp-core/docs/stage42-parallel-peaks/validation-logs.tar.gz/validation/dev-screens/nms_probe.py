"""Probe: sequential greedy peak selection (as fg_coarse_peaks_tiled) vs exact parallel rounds on real top-level maps.

Structure probe only: OpenCV rotation/pyrDown/TM_CCOEFF_NORMED approximate the C++ kernels; counts, not timings.
"""
import math, sys, time
import cv2, numpy as np

fx, scene = sys.argv[1], sys.argv[2]
limit = int(sys.argv[3]); proposal = .5; overlap = np.float32(.2); side = 16
src0 = cv2.imread(f'{fx}/{scene}.png', cv2.IMREAD_GRAYSCALE); tpl0 = cv2.imread(f'{fx}/many_template.png', cv2.IMREAD_GRAYSCALE)
border = 255 if tpl0.mean() < 128 else 0

def rect(x, y, tw, th, width, height):
    rw = np.float32(tw) * (np.float32(1) - overlap); rh = np.float32(th) * (np.float32(1) - overlap)
    left = np.trunc(x - rw).astype(np.int64); top = np.trunc(y - rh).astype(np.int64)
    x0 = np.maximum(0, np.minimum(x, left)); x1 = np.minimum(width, np.maximum(x + 1, left + int(2 * rw)))
    y0 = np.maximum(0, np.minimum(y, top)); y1 = np.minimum(height, np.maximum(y + 1, top + int(2 * rh)))
    return x0, x1, y0, y1

def sequential(score, thr, tw, th):
    s = score.copy(); h, w = s.shape; picks = []
    for _ in range(limit):
        i = int(np.argmax(s)); v = s.flat[i]
        if not v >= thr: break
        y, x = divmod(i, w); picks.append(i)
        if len(picks) == limit: break
        x0, x1, y0, y1 = rect(np.int64(x), np.int64(y), tw, th, w, h); s[y0:y1, x0:x1] = -np.inf
    return picks

def rounds(score, thr, tw, th):
    h, w = score.shape; R = score >= thr; idx = np.arange(h * w).reshape(h, w)
    order = np.lexsort((idx[R], -score[R])); rank = np.full((h, w), np.iinfo(np.int64).max, np.int64)
    rank[R] = np.empty(order.size, np.int64); rank[np.nonzero(R)] = np.argsort(order)  # rank 0 = best
    ys, xs = np.mgrid[0:h, 0:w]; X0, X1, Y0, Y1 = rect(xs, ys, tw, th, w, h)
    rw = float(np.float32(tw) * (1 - overlap)); rh = float(np.float32(th) * (1 - overlap))
    ox, oy = int(math.ceil(rw)) + 1, int(math.ceil(rh)) + 1
    selected = []; n_rounds = 0
    while R.any():
        n_rounds += 1; blocked = np.zeros((h, w), bool)
        for dy in range(-oy, oy + 1):
            for dx in range(-ox, ox + 1):
                if dx == 0 and dy == 0: continue
                # q = p - (dx, dy); valid p range so that q is inside
                py0, py1 = max(0, dy), min(h, h + dy); px0, px1 = max(0, dx), min(w, w + dx)
                if py0 >= py1 or px0 >= px1: continue
                q = (slice(py0 - dy, py1 - dy), slice(px0 - dx, px1 - dx)); p = (slice(py0, py1), slice(px0, px1))
                cond = R[q] & (rank[q] < rank[p]) & (X0[q] <= xs[p]) & (xs[p] < X1[q]) & (Y0[q] <= ys[p]) & (ys[p] < Y1[q])
                blocked[p] |= cond
        sel = np.nonzero(R & ~blocked)
        assert sel[0].size, 'no progress'
        for y, x in zip(*sel):
            selected.append(int(y * w + x)); sub = (slice(Y0[y, x], Y1[y, x]), slice(X0[y, x], X1[y, x]))
            R[sub] &= rank[sub] < rank[y, x]  # suppress only lower-priority points (asymmetric rectangles)
            R[y, x] = False
    selected.sort(key=lambda i: int(rank.flat[i]))
    return selected[:limit], n_rounds

t0 = time.time(); total_seq = total_rounds = total_maps = total_above = mismatches = 0; rows = []
for scale in (.75, 1., 1.25):
    tpl = cv2.resize(tpl0, (round(tpl0.shape[1] * scale), round(tpl0.shape[0] * scale)), interpolation=cv2.INTER_AREA)
    area, levels_t, levels_s = tpl.shape[0] * tpl.shape[1], [tpl], [src0]
    while area > side * side:
        levels_t.append(cv2.pyrDown(levels_t[-1])); levels_s.append(cv2.pyrDown(levels_s[-1])); area //= 4
    top = len(levels_t) - 1; T, I = levels_t[-1], levels_s[-1]; th, tw = T.shape
    thr = np.float32(proposal * .9 ** top); step = math.degrees(math.atan(2 / max(tw, th)))
    angles = [0.] + [a for k in range(1, 400) for a in (k * step, -k * step) if k * step < 180] + [180., -180.]
    for n, angle in enumerate(angles):
        hh, ww = I.shape; c, s_ = abs(math.cos(math.radians(angle))), abs(math.sin(math.radians(angle)))
        cw, ch = int(ww * c + hh * s_) + 2, int(ww * s_ + hh * c) + 2
        M = cv2.getRotationMatrix2D((ww / 2, hh / 2), angle, 1); M[0, 2] += cw / 2 - ww / 2; M[1, 2] += ch / 2 - hh / 2
        canvas = cv2.warpAffine(I, M, (cw, ch), flags=cv2.INTER_LINEAR, borderValue=border)
        score = cv2.matchTemplate(canvas, T, cv2.TM_CCOEFF_NORMED).astype(np.float32); score[~np.isfinite(score)] = 0
        seq = sequential(score, thr, tw, th); above = int((score >= thr).sum())
        total_seq += len(seq); total_maps += 1; total_above += above
        if n % 6 == 0:  # exact rounds check on a sample of maps
            par, nr = rounds(score, thr, tw, th); total_rounds += nr; same = par == seq; mismatches += not same
            rows.append((scale, round(angle, 1), score.shape, above, len(seq), nr, same))
print(f'scene={scene} limit={limit} maps={total_maps} above-threshold px total={total_above} sequential picks total={total_seq} ({time.time()-t0:.0f}s)')
print('sampled maps (scale, angle, map shape, above-thr px, sequential picks, parallel rounds, identical):')
for r in rows: print('  ', r)
print(f'sampled maps: {len(rows)}, mismatches={mismatches}, mean picks={np.mean([r[4] for r in rows]):.0f}, mean rounds={np.mean([r[5] for r in rows]):.1f}, max rounds={max(r[5] for r in rows)}')
