"""Collect the stage-42 validation record into cpp-core/docs/stage42-parallel-peaks/validation.json.

Run from the worktree root after the gate, Metal validation, sanitizer, mutant,
audit, replay and final-gate logs exist under build/stage42-parallel-peaks/validation.
"""
import json, re
from pathlib import Path
root = Path.cwd()
work = root/'build/stage42-parallel-peaks'
val = work/'validation'
out = root/'cpp-core/docs/stage42-parallel-peaks'


def ctest(log):
    text = (val/log).read_text()
    match = re.search(r'(\d+)% tests passed, (\d+) tests failed out of (\d+)', text)
    return dict(passed=int(match.group(3))-int(match.group(2)), failed=int(match.group(2)), total=int(match.group(3)), log='validation/'+log)


def unittest(log):
    text = (val/log).read_text()
    ran = [int(value) for value in re.findall(r'^Ran (\d+) tests', text, re.M)]
    return dict(ran=ran, ok=bool(re.search(r'^OK', text, re.M)) and not re.search(r'^FAILED', text, re.M), log='validation/'+log)


def gate(prefix):
    fields = dict(line.split('=', 1) for line in (val/f'{prefix}-gate.txt').read_text().splitlines() if '=' in line and line.split('=', 1)[0].isupper())
    return dict(head=fields['HEAD'], clean=fields['CLEAN'] == 'true', start=fields['START'], end=fields['END'],
                exits=dict(ctest=int(fields['CTEST_EXIT']), harness=int(fields['HARNESS_EXIT']), color=int(fields['COLOR_EXIT'])),
                ctest=ctest(f'{prefix}-ctest.log'), python_harness=unittest(f'{prefix}-python-harness.log'),
                color_verify_metal=unittest(f'{prefix}-color-verify.log'))


summaries = {phase: json.loads((out/f'{phase}-summary.json').read_text()) for phase in ('pilot', 'formal', 'profile', 'holdout')}
manifests = {phase: json.loads((work/phase/'manifest.json').read_text()) for phase in summaries}
kernel = json.loads((val/'kernel-mutants/summary.json').read_text())
harness = json.loads((val/'harness-mutants.json').read_text())
audit = json.loads((val/'independent-audit.json').read_text())
replay = json.loads((val/'replay-check.json').read_text())
host = {}
for phase, manifest in manifests.items():
    rows = manifest['executions']
    loads = [row['host']['load_average'][0] for row in rows]
    host[phase] = dict(started_utc=manifest['started_utc'], finished_utc=manifest['finished_utc'], executions=len(rows),
                       executions_with_competing_processes=sum(bool(row['host']['competing_processes']) for row in rows),
                       load_average_1min_range=[min(loads), max(loads)], before=manifest['host']['before'], after=manifest['host']['after'])
record = dict(stage=42, date='2026-10-24',
    build=dict(directory='build/stage42-release', type='Release', options=['FPM_BUILD_GUI=ON', 'FPM_BUILD_EXPERIMENTS=ON', 'FPM_WITH_OPENCV=ON'],
               build_head=(val/'build-head.txt').read_text().strip(), configure_log='validation/configure.log', build_log='validation/build.log',
               fresh_directory=True, note='Built from the frozen commit on a clean tree; the protocol commit adds only docs files.'),
    pre_measurement=dict(gate('pre-formal'), metal_validation=dict(ctest('metal-validation.log'),
        command="MTL_SHADER_VALIDATION=1 MTL_DEBUG_LAYER=1 ctest -R 'experimental_full_gpu|native_runner'")),
    sanitizers=dict(ctest('sanitized-ctest.log'), build='build/stage42-sanitized: Debug, FPM_SANITIZERS=ON, FPM_DISABLE_SIMD=ON, FPM_BUILD_EXPERIMENTS=ON, no GUI',
                    note='ASan and UBSan; LeakSanitizer not enabled, so this is not a leak proof.'),
    kernel_mutants=dict(killed=kernel['killed'], total=kernel['total'], restored=kernel['restored'], log_dir='validation/kernel-mutants',
        survivor='M05_shortcut_ignores_rectangle: output-equivalent; a false covered result in the pick phase only delays acceptance',
        tree='git archive of c36f101; compiled sources identical to the frozen 4b0ad8f'),
    harness=dict(new_tests=20, test_file='cpp-core/tests/test_parallel_peaks_harness.py',
                 mutants=dict(killed=harness['killed'], total=harness['total'], restored=harness['restored'], log='validation/harness-mutants.json')),
    datasets={phase: summary['counts'] for phase, summary in summaries.items()},
    direct_gt_calls=sum(summary['counts']['gt_evaluated_calls'] for summary in summaries.values()),
    all_zero_fp_fn=all(summary['all_accuracy_pass'] for summary in summaries.values()),
    all_parallel_exact_mode1=all(summary['all_parallel_exact_mode1'] for summary in summaries.values()),
    all_routes_pass=all(summary['all_routes_pass'] for summary in summaries.values()),
    failed_gates={phase: len(summary['failed_gates']) for phase, summary in summaries.items()},
    embedded_summary_reproduced={phase: json.dumps(manifests[phase]['summary'], sort_keys=True) == json.dumps(summary, sort_keys=True)
                                 for phase, summary in summaries.items()},
    host=host, host_notes='validation/host-notes.md',
    independent_audit=dict(file='validation/independent-audit.json', script='validation/independent_audit.py', harness_imported=False,
                           gpu_launched=False, totals=audit['totals'], self_test='validation/audit_selftest.py: 13 in-memory tamperings, all detected'),
    archive_replay=dict(file='validation/replay-check.json', **{key: replay[key] for key in ('frozen_commit', 'snapshot_files', 'snapshot_hash_mismatches', 'all_identical')}),
    final_gate=gate('final') if (val/'final-gate.txt').exists() else None)
(out/'validation.json').write_text(json.dumps(record, indent=2, ensure_ascii=False, allow_nan=False)+'\n')
print(json.dumps(dict(direct_gt=record['direct_gt_calls'], sanitizers=record['sanitizers']['passed'], audit=record['independent_audit']['totals'],
                      replay=record['archive_replay']['all_identical'], final=record['final_gate'] is not None)))
