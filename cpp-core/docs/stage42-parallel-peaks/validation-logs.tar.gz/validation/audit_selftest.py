import copy, importlib.util, json, sys
from pathlib import Path
ROOT = Path("/Users/Ayueh/Fastest_Image_Pattern_Matching/.claude/worktrees/infallible-khayyam-a25a35")
spec = importlib.util.spec_from_file_location("ia", ROOT / "build/stage42-parallel-peaks/validation/independent_audit.py")
ia = importlib.util.module_from_spec(spec); spec.loader.exec_module(ia)
protocol = ia.load_json(ROOT / "cpp-core/docs/stage42-parallel-peaks/protocol.json")

def run(phase, mutate_results=None, mutate_summary=None):
    a = ia.PhaseAudit(ROOT, protocol, phase)
    a.check_integrity(); a.load(); a.check_jobs()
    if mutate_results: mutate_results(a)
    if mutate_summary: mutate_summary(a.summary)
    a.recompute(); a.build_comparisons(); a.gates(); a.compare_summary()
    return a

def show(name, a):
    checks = sorted({f["check"] for f in a.check_failures} - {"source_sha256_vs_frozen_snapshot_list"})
    print("%-34s mismatches=%3d checks=%s gates=%s" % (name, len(a.mismatches), checks, sorted({g["gate"] for g in a.failed_gates})))

base = run("pilot"); show("baseline pilot", base)
def m1(a):  # shift one match of the parallel arm 3 px
    a.results[("many128_pose","full_gpu_parallel_static",0)]["runs"][1]["matches"][5]["pos_x"] += 3.0
show("shift one match 3px", run("pilot", m1))
def m2(a):  # swap two matches: GT ok, exactness must fail
    ms = a.results[("controlled6","full_gpu_parallel_b1_static",0)]["first"]["matches"]; ms[0], ms[1] = ms[1], ms[0]
show("swap match order", run("pilot", m2))
def m3(a):
    a.results[("many512_pose","full_gpu_parallel_frames",0)]["runs"][2]["full_gpu"]["cpu_waits"] = 2
show("cpu_waits=2", run("pilot", m3))
def m4(a):
    r = a.results[("many128_pose","full_gpu_parallel_frames",0)]["runs"]; r[0]["elapsed_ms"] = r[2]["elapsed_ms"] - 999.0
show("warm-up 999 ms", run("pilot", m4))
def m5(a):
    for x in a.results[("controlled6","full_gpu_parallel_static",0)]["runs"]: x["total_ms"] *= 1.5
show("candidate 50% slower", run("pilot", m5))
def m6(a):
    a.results[("many128_pose","full_gpu_parallel_b1_static",0)]["runs"][0]["full_gpu"]["peak_batch_maps"] = 2
show("b1 peak_batch_maps=2", run("pilot", m6))
def m7(a):
    a.results[("many128_pose","full_gpu_parallel_static",0)]["runs"][0]["full_gpu"]["fine_effective_mode"] = 3
show("fine_effective_mode=3", run("pilot", m7))
def m8(a):
    a.results[("controlled6","full_gpu_parallel_static",0)]["final_memory"]["peak_rss_bytes"] += 64*2**20
show("candidate RSS +64 MiB", run("pilot", m8))
def m9(a):
    a.results[("controlled6","hybrid_best_frames",0)]["runs"][3]["matches"].pop()
show("hybrid frames drops a match", run("pilot", m9))
def s1(s):
    s["cases"][0]["arms"]["full_gpu_simd_static"]["total_ms"]["median"] *= 1.0000001
show("summary median +1e-7 rel", run("pilot", mutate_summary=s1))
def s2(s):
    s["cases"][1]["comparisons"]["vs_hybrid_frames_frame_wall"]["paired"][0]["within_regression_budget"] = False
show("summary flips budget flag", run("pilot", mutate_summary=s2))
def s3(s):
    s["counts"]["gt_evaluated_calls"] += 1
show("summary gt count +1", run("pilot", mutate_summary=s3))
def s4(s):
    s["cases"][2]["arms"]["full_gpu_parallel_static"]["max_errors"]["angle_deg"] += 1e-6
show("summary max angle +1e-6", run("pilot", mutate_summary=s4))
