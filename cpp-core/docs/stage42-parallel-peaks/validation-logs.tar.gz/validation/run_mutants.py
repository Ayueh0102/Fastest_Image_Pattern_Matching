"""Compiled mutants for round-42 peak mode 2.

Usage: run_mutants.py <git-archive tree> <build dir> <log dir>
Each mutant replaces exactly one anchor in a source file of the scratch tree,
waits >1 s (second-resolution make timestamps), rebuilds the named target,
asserts the rebuilt binary differs from the unmutated one, runs the test and
expects a non-zero exit. The tree is restored and rebuilt at the end and every
test must pass again.
"""
import hashlib, json, pathlib, subprocess, sys, time
tree, build, logs = map(pathlib.Path, sys.argv[1:4])
logs.mkdir(parents=True, exist_ok=True)
PEAKS = 'cpp-core/experiments/full_gpu_peaks.metal'
HOST = 'cpp-core/experiments/full_gpu_metal.mm'
DIFF = ('fpm_full_gpu_parallel_peaks_test', ['experiments/fpm_full_gpu_parallel_peaks_test'])
PIPE = ('fpm_full_gpu_test', ['experiments/fpm_full_gpu_test', '--parallel-peaks'])
MUTANTS = [
    ('M01_suppress_higher_priority', PEAKS, 'if(marks[p]==FG_PEAK_LIVE && fg_better(score,q,scores[p],p))', 'if(marks[p]==FG_PEAK_LIVE)', DIFF),
    ('M02_rect_floor_not_trunc', PEAKS, 'const int left=int(float(x)-rw),top=int(float(y)-rh);\n    return {uint(max(0,min(int(x),left))),uint(min(int(width),max(int(x)+1,left+int(2*rw)))),',
     'const int left=int(floor(float(x)-rw)),top=int(floor(float(y)-rh));\n    return {uint(max(0,min(int(x),left))),uint(min(int(width),max(int(x)+1,left+int(2*rw)))),', DIFF),
    ('M03_signed_zero_not_tied', PEAKS, 'as_type<uint>(score==0 ? 0.f:score)', 'as_type<uint>(score)', DIFF),
    ('M04_stop_one_early', PEAKS, 'if(fg_peak_sum(above,indices,lane,lanes)>=c.limit) break;', 'if(fg_peak_sum(above,indices,lane,lanes)+1>=c.limit) break;', DIFF),
    ('M05_shortcut_ignores_rectangle', PEAKS, '        if(px>=r.x0 && px<r.x1 && py>=r.y0 && py<r.y1) return true;\n    }\n    return false;\n}\n\n// A SIMD group marks',
     '        return true;\n    }\n    return false;\n}\n\n// A SIMD group marks', DIFF),
    ('M06_no_infinity_stop', PEAKS, 'if(fg_peak_sum(infinite,indices,lane,lanes)) return;', 'if(false && fg_peak_sum(infinite,indices,lane,lanes)) return;', DIFF),
    ('M07_nan_threshold_rejects', PEAKS, 'const bool candidate=i<windows && isfinite(score) && !(score<c.threshold);', 'const bool candidate=i<windows && isfinite(score) && score>=c.threshold;', DIFF),
    ('M08_radix_takes_larger_bucket', PEAKS, 'if(count==need) {last=', 'if(count>=need) {last=', DIFF),
    ('M09_list_drops_first_survivor', PEAKS, 'if(keep) lists[(1-from)*capacity+at]=p;', 'if(keep && at) lists[(1-from)*capacity+at]=p;', DIFF),
    ('M10_all_maps_read_slot0', PEAKS, 'device const float* scores=scoreRing+ulong(slot)*batch.scoreStride;', 'device const float* scores=scoreRing;', DIFF),
    ('M11_pick_ignores_cover', PEAKS, 'if(simdLane==owner && !covered) marks[q]=FG_PEAK_PICKED;', 'if(simdLane==owner) marks[q]=FG_PEAK_PICKED;', DIFF),
    ('M12_reach_too_small', PEAKS, 'const uint reachX=uint(ceil(rw))+2,reachY=uint(ceil(rh))+2;', 'const uint reachX=uint(rw/2)+1,reachY=uint(rh/2)+1;', DIFF),
    ('M13_rank_reversed', PEAKS, 'rank+=uint(keys[f]<key);', 'rank+=uint(keys[f]>key);', DIFF),
    ('M14_settle_keeps_removed', PEAKS, 'if((atomic_load_explicit(&removal[p/32],memory_order_relaxed)>>(p%32))&1u)', 'if(false)', DIFF),
    ('H01_ncc_writes_slot0', HOST, '[e setBuffer:scoremap offset:slot*scoreSlotBytes atIndex:1];', '[e setBuffer:scoremap offset:0 atIndex:1];', PIPE),
    ('H02_batch_configs_from_first_map', HOST, '[e setBytes:&model.maps[k+1-count] length:count*sizeof(Coarse) atIndex:2];', '[e setBytes:&model.maps[0] length:count*sizeof(Coarse) atIndex:2];', PIPE),
]
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def build_target(target, log):
    result = subprocess.run(['cmake', '--build', str(build), '--target', target, '-j', '8'], capture_output=True, text=True)
    log.write_text(result.stdout + result.stderr)
    if result.returncode: raise RuntimeError('build failed: ' + log.name)
def run_test(command, log):
    try:
        result = subprocess.run([str(build/command[0]), *command[1:]], capture_output=True, text=True, timeout=600)
        log.write_text(f'exit={result.returncode}\n' + result.stdout + result.stderr); return result.returncode
    except subprocess.TimeoutExpired as error:
        log.write_text('timeout\n'); return 'timeout'
baseline = {}
for target, command in (DIFF, PIPE):
    build_target(target, logs/f'baseline-{target}-build.log')
    baseline[target] = sha(build/command[0])
    if run_test(command, logs/f'baseline-{target}-test.log') != 0: raise RuntimeError('baseline test fails')
rows = []
for name, relative, anchor, replacement, (target, command) in MUTANTS:
    path = tree/relative; original = path.read_text()
    if original.count(anchor) != 1: raise RuntimeError(name + ': anchor count ' + str(original.count(anchor)))
    time.sleep(1.2); path.write_text(original.replace(anchor, replacement))
    try:
        build_target(target, logs/f'{name}-build.log')
        changed = sha(build/command[0]) != baseline[target] or relative.endswith('.metal')
        # Metal source is embedded at configure time: check the generated header changed instead.
        if relative.endswith('.metal'):
            header = (build/'experiments/full_gpu_metal_source.hpp').read_text()
            changed = replacement in header
        code = run_test(command, logs/f'{name}-test.log')
    finally:
        time.sleep(1.2); path.write_text(original)
    rows.append(dict(mutant=name, file=relative, target=target, rebuilt_with_mutation=changed, exit=code, killed=changed and code != 0))
    print(name, 'killed' if rows[-1]['killed'] else 'SURVIVED', code, flush=True)
restored = {}
for target, command in (DIFF, PIPE):
    build_target(target, logs/f'restored-{target}-build.log')
    restored[target] = dict(sha_matches_baseline=sha(build/command[0]) == baseline[target], exit=run_test(command, logs/f'restored-{target}-test.log'))
summary = dict(mutants=rows, killed=sum(r['killed'] for r in rows), total=len(rows), restored=restored)
(logs/'summary.json').write_text(json.dumps(summary, indent=1))
print(json.dumps(dict(killed=summary['killed'], total=summary['total'], restored=restored)))
