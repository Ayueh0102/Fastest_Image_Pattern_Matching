#!/bin/bash
# Stage-42 test gate. Usage: gate.sh <build dir> <log prefix>; run from the worktree root.
# Release ctest, the Python harness (fine-binding tests pointed at this build) and
# color_verify_runner_test --metal. Records HEAD, tree cleanliness and exits.
set -u
build=$1; prefix=$2
python=/Users/Ayueh/Fastest_Image_Pattern_Matching/python-port/venv/bin/python
{
  echo "HEAD=$(git rev-parse HEAD)"
  echo "CLEAN=$([ -z "$(git status --porcelain --untracked-files=no)" ] && echo true || echo false)"
  echo "START=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
} > "$prefix-gate.txt"
ctest --test-dir "$build" --output-on-failure > "$prefix-ctest.log" 2>&1; ctest_exit=$?
FPM_FINE_REUSE_BUILD="$build" FPM_FINE_SEARCH_BUILD="$build" FPM_FINE_FUSED_BUILD="$build" \
  "$python" -m unittest discover -s cpp-core/tests -p 'test_*.py' > "$prefix-python-harness.log" 2>&1; harness_exit=$?
"$python" cpp-core/tests/color_verify_runner_test.py --runner "$build/experiments/fpm_color_verify_runner" --metal \
  > "$prefix-color-verify.log" 2>&1; color_exit=$?
{
  echo "END=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "CTEST_EXIT=$ctest_exit"; echo "HARNESS_EXIT=$harness_exit"; echo "COLOR_EXIT=$color_exit"
  tail -3 "$prefix-ctest.log" | head -1
  grep -E "^Ran |^OK|^FAILED" "$prefix-python-harness.log"
  grep -E "^Ran |^OK|^FAILED" "$prefix-color-verify.log"
} >> "$prefix-gate.txt"
cat "$prefix-gate.txt"
