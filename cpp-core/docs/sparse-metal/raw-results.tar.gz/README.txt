Metal sparse frontend study versus frozen ae0489f CPU.
All routes use compact maps; same-build CPU controls runtime changes.
Raw ordered proposals and work must match across CPU/Metal. Final float poses
may differ, so independentGT accuracy is checked separately. Negative scale and
unlabelled photo outcomes are preserved. CPU deterministic candidate selection remains; this is not all-GPU search.

Offline replay with NumPy/OpenCV, no GPU required:
python3 EXTRACT/formal/source-snapshot/cpp-core/tools/benchmark_sparse_metal_front.py --summarize EXTRACT/formal/results.json --output /tmp/replayed.json

Absolute paths are historical provenance; source snapshots, input fixtures,
protocol, raw worker records and validation logs are archived. Binary hashes
are recorded; executables omitted. All member hashes are in sha256.json.
