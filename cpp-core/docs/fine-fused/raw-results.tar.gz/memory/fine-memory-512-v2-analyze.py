"""Summarize observational memory phases; keep accounting categories separate."""
import json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
FIELDS=('resident_bytes','resident_peak_bytes','rusage_peak_rss_bytes','physical_footprint_bytes','physical_footprint_peak_bytes','compressed_bytes','compressed_peak_bytes','internal_bytes','external_bytes','device_bytes','reusable_bytes','malloc_in_use_bytes','malloc_reserved_bytes','malloc_max_touched_bytes')
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def mib(r):return {k:r[k]/2**20 for k in FIELDS}
def reduced(r):return dict(phase=r['phase'],event=r['event'],call=r['call'],call_kind=r['call_kind'],model=r['model'],elapsed_ms=r['elapsed_ms'],values_mib=mib(r),malloc_reserved_minus_live_mib=(r['malloc_reserved_bytes']-r['malloc_in_use_bytes'])/2**20)
def relief(rows):
 result=[]
 for i,r in enumerate(rows):
  if r['event']!='after_pressure_relief':continue
  b=rows[i-1];assert b['event']=='before_pressure_relief' and b['phase']==r['phase']
  result.append(dict(phase=r['phase'],reported_released_bytes=r['relieved_bytes'],delta_mib={k:(r[k]-b[k])/2**20 for k in FIELDS},before=reduced(b),after=reduced(r)))
 return result
def main():
 protocol=read(ROOT/'build/fine-memory-512-v2-protocol.json');report=read(ROOT/'build/fine-memory-512-v2-summary.json');assert report['complete'] and report['all_exact']
 workers=[];traces=[]
 for w in protocol['workers']:
  folder=ROOT/w['directory'];summary=read(folder/'summary.json');result=read(folder/'result.json');trace=[json.loads(s) for s in (folder/'trace.jsonl').read_text().splitlines()];traces.append(trace)
  p0=[r for r in trace if r['event']=='stage' and r['call']==0];p1=[r for r in trace if r['event']=='stage' and r['call']==1]
  workers.append(dict(directory=w['directory'],method=w['method'],summary_sha256=sha(folder/'summary.json'),exact_outputs=summary['exact_outputs'],exact_work_counters=summary['exact_work_counters'],unchanged=summary['unchanged'],peak_mib={k:summary['maxima'][k]/2**20 for k in FIELDS},before_calls=[reduced(r) for r in trace if r['event']=='stage' and r['call']==-1],first_call_phases=[reduced(r) for r in p0],repeat_call_phases=[reduced(r) for r in p1],relief=relief(trace),largest_sampled_resident=reduced(summary['resident_max_sample']),largest_sampled_footprint=reduced(summary['footprint_max_sample']),retained_capacities={k:result['first'][k] for k in result['first'] if k.endswith('_bytes')},diagnostic_first_ms=result['first']['total_ms'],diagnostic_repeat_ms=result['runs'][0]['total_ms']))
 comparisons=[]
 for a,b in ((0,1),(3,2)):
  aa={(r['event'],r['phase'],r['call'],r['model']):r for r in traces[a] if r['event']!='sample'};bb={(r['event'],r['phase'],r['call'],r['model']):r for r in traces[b] if r['event']!='sample'}
  comparisons.append(dict(off=a,reuse=b,peak_delta_mib={k:workers[b]['peak_mib'][k]-workers[a]['peak_mib'][k] for k in FIELDS},phase_delta_mib=[dict(event=key[0],phase=key[1],call=key[2],model=key[3],delta={k:(bb[key][k]-aa[key][k])/2**20 for k in FIELDS}) for key in aa if key in bb]))
 out=dict(complete=True,diagnostic_not_speed_benchmark=True,stage29_source=True,algorithm_calls=8,all_exact=all(w['exact_outputs'] and w['exact_work_counters'] and w['unchanged'] for w in workers),protocol_sha256=sha(ROOT/'build/fine-memory-512-v2-protocol.json'),analysis_script_sha256=sha(Path(__file__)),workers=workers,comparisons=comparisons,limitations=['Fresh first+repeat diagnostics with no warmup, not the original 5-call process schedule.','All CPU/GPU retained capacities, physical footprint, compressed and malloc counters overlap; no additive attribution.','Diagnostic sampling and phase hooks perturb execution; times are not performance evidence.','Original historical processes had no compressed/allocator trace, so their exact 88 MiB cause cannot be proved retrospectively from these observations alone.'])
 (ROOT/'build/fine-memory-512-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
 print('memory analysis written')
 for i,w in enumerate(workers):
  print(i,w['method'],'peak', {k:round(w['peak_mib'][k],3) for k in ('rusage_peak_rss_bytes','physical_footprint_peak_bytes','compressed_peak_bytes','malloc_reserved_bytes')},flush=True)
  for r in w['before_calls']+w['first_call_phases']:
   if r['phase'] in ('images_decoded','before_run','after_model_match','pose_created_before_temporary_release','after_pose_create','after_run'):
    print('  ',r['phase'],r['model'],{k:round(r['values_mib'][k],3) for k in ('resident_bytes','physical_footprint_bytes','compressed_bytes','malloc_in_use_bytes','malloc_reserved_bytes','reusable_bytes')},flush=True)
  for r in w['relief']:print(' relief',r['phase'],r['reported_released_bytes']/2**20,{k:round(r['delta_mib'][k],3) for k in ('resident_bytes','physical_footprint_bytes','malloc_in_use_bytes','malloc_reserved_bytes','reusable_bytes')},flush=True)
if __name__=='__main__':main()
