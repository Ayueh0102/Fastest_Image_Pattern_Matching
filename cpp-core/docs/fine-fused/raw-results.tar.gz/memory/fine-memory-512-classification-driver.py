import datetime,hashlib,json,os,subprocess,sys,time,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'cpp-core/tools'))
from profile_fine_memory import summarize
PROTOCOL=ROOT/'build/fine-memory-512-classification-protocol.json'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
def verify(p):
 for path,h in p['frozen_sha256'].items():
  if sha(ROOT/path)!=h:raise ValueError('Changed source/input '+path)
def run(worker,p):
 folder=ROOT/worker['directory'];verify(p);env=dict(os.environ,FPM_MEMORY_TRACE=str(folder/'trace.jsonl'),FPM_MEMORY_INTERVAL_MS='100',FPM_MEMORY_RELIEF='1',FPM_MEMORY_CHECKPOINT=str(folder),FPM_MEMORY_POINTER_LOG=str(folder/'decoded-pointers.jsonl'))
 (folder/'vm-before.txt').write_text(subprocess.check_output(['/usr/bin/vm_stat'],text=True));captures=[];handled=set();started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (folder/'result.json').open('x') as out,(folder/'stderr.txt').open('x') as err:
  process=subprocess.Popen([str(ROOT/p['binary']),str(folder/'job.json')],stdout=out,stderr=err,env=env)
  while process.poll() is None:
   for ready in sorted(folder.glob('*.ready.json')):
    if ready.name in handled:continue
    try:event=json.loads(ready.read_text())
    except json.JSONDecodeError:continue
    if event['pid']!=process.pid:raise ValueError('Checkpoint pid mismatch')
    label=event['phase'];capture=dict(event,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),commands=[])
    try:
     for args,suffix in ((['-summary'],'summary'),(['-wide','-noCoalesce'],'full')):
      command=['/usr/bin/vmmap',*args,str(process.pid)];result=subprocess.run(command,capture_output=True,text=True,timeout=10);path=folder/(label+'.vmmap-'+suffix+'.txt');path.write_text(result.stdout+result.stderr);capture['commands'].append(dict(command=command,returncode=result.returncode,file=path.name,sha256=sha(path)))
     capture['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save(folder/(label+'.vmmap.json'),capture);captures.append(capture)
    finally:(folder/(label+'.release')).write_text('release\n');handled.add(ready.name)
   time.sleep(.02)
  code=process.wait()
 (folder/'vm-after.txt').write_text(subprocess.check_output(['/usr/bin/vm_stat'],text=True));save(folder/'execution.json',dict(started_utc=started,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),returncode=code,protocol_sha256=sha(PROTOCOL),captures=captures))
 if code:raise RuntimeError('Worker failed '+str(folder))
 if len(captures)!=2 or any(c['returncode'] for capture in captures for c in capture['commands']):raise ValueError('Missing or failed classifications')
 summary=summarize(folder/'trace.jsonl',folder/'result.json',ROOT/worker['reference']);raw=json.loads((folder/'result.json').read_text());ref=json.loads((ROOT/worker['reference']).read_text())['first'];counters=('maps','windows','fine_maps','fine_stats_dispatches','fine_commands','fine_uploads','fine_upload_bytes','fine_roi_pixels','fine_repair_pixels','fine_peak_batch')
 assert all(all([w[k] for k in counters]==[r[k] for k in counters] for w,r in zip(call['work'],ref['work'])) and len(call['work'])==len(ref['work']) for call in [raw['first'],*raw['runs']])
 pointers=[json.loads(x) for x in (folder/'decoded-pointers.jsonl').read_text().splitlines()];rgb=pointers[0];matches=[]
 for capture in captures:
  path=folder/(capture['phase']+'.vmmap-full.txt');address=int(rgb['rgb_address'],16);found=[]
  for line in path.read_text().splitlines():
   match=re.search(r'\b([0-9a-fA-F]{8,})-([0-9a-fA-F]{8,})\b',line)
   if match and int(match[1],16)<=address<int(match[2],16):found.append(line)
  matches.append(dict(phase=capture['phase'],rgb_address=rgb['rgb_address'],rgb_bytes=rgb['rgb_bytes'],containing_regions=found))
 verify(p);summary.update(unchanged=True,exact_work_counters=True,pointer_classification=matches,decoded_pointers=pointers,diagnostic_not_speed_benchmark=True,hashes={f.name:sha(f) for f in folder.iterdir() if f.is_file() and f.name!='summary.json'});save(folder/'summary.json',summary);print(json.dumps(dict(worker=worker['directory'],max_rss_mib=summary['maxima']['rusage_peak_rss_bytes']/2**20,pointer_classification=matches)),flush=True)
 return dict(directory=worker['directory'],method=worker['method'],summary_sha256=sha(folder/'summary.json'))
def main():
 p=json.loads(PROTOCOL.read_text());verify(p);results=[]
 for worker in p['workers']:
  results.append(run(worker,p));save(ROOT/'build/fine-memory-512-classification-progress.json',results)
 save(ROOT/'build/fine-memory-512-classification-summary.json',dict(complete=True,protocol_sha256=sha(PROTOCOL),workers=results,algorithm_calls=sum(1+json.loads((ROOT/w['directory']/'job.json').read_text())['repeats'] for w in p['workers']),all_exact=True,diagnostic_not_speed_benchmark=True))
if __name__=='__main__':main()
