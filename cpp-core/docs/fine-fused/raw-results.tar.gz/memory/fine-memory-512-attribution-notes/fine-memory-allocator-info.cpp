#include <malloc/malloc.h>
#include <mach/mach.h>
#include <cstdio>
int main(){vm_address_t* zones=nullptr; unsigned count=0; auto status=malloc_get_all_zones(mach_task_self(),nullptr,&zones,&count); std::printf("status=%d count=%u\n",status,count); if(status)return 1; for(unsigned i=0;i<count;++i){auto* z=reinterpret_cast<malloc_zone_t*>(zones[i]); std::printf("zone[%u] name=%s version=%u\n",i,malloc_get_zone_name(z),z->version);}return 0;}
