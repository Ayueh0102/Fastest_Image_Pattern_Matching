"""Serial stage29 diagnostic workers. Prepared before execution; never a speed benchmark."""
import argparse,datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'cpp-core/tools'))
from profile_fine_memory import summarize
PROTOCOL=ROOT/'build/fine-memory-512-protocol.json'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):Path(p).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def verify(p):
    for path,h in p['frozen_sha256'].items():
        if sha(ROOT/path)!=h:raise ValueError('Frozen evidence changed: '+path)
def run(worker,p):
    folder=ROOT/worker['directory']
    if (folder/'trace.jsonl').exists() or (folder/'result.json').exists():raise ValueError('Refusing to overwrite existing worker '+str(folder))
    verify(p)
    env=dict(os.environ,FPM_MEMORY_TRACE=str(folder/'trace.jsonl'),FPM_MEMORY_INTERVAL_MS='100',FPM_MEMORY_RELIEF='1')
    (folder/'vm-before.txt').write_text(subprocess.check_output(['/usr/bin/vm_stat'],text=True))
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (folder/'result.json').open('w') as out,(folder/'stderr.txt').open('w') as err:
        completed=subprocess.run([str(ROOT/p['binary']),str(folder/'job.json')],stdout=out,stderr=err,env=env)
    (folder/'vm-after.txt').write_text(subprocess.check_output(['/usr/bin/vm_stat'],text=True))
    save(folder/'execution.json',dict(started_utc=started,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),returncode=completed.returncode,protocol_sha256=sha(PROTOCOL)))
    if completed.returncode:raise RuntimeError('Diagnostic failed: '+str(folder))
    summary=summarize(folder/'trace.jsonl',folder/'result.json',ROOT/worker['reference'])
    result=json.loads((folder/'result.json').read_text());reference=json.loads((ROOT/worker['reference']).read_text())['first']
    counters=('maps','windows','fine_maps','fine_stats_dispatches','fine_commands','fine_uploads','fine_upload_bytes','fine_roi_pixels','fine_repair_pixels','fine_peak_batch')
    assert all(all([w[k] for k in counters]==[r[k] for k in counters] for w,r in zip(call['work'],reference['work'])) and len(call['work'])==len(reference['work']) for call in [result['first'],*result['runs']])
    assert all(call[k]==reference[k] for call in [result['first'],*result['runs']] for k in ('frame_host_bytes','frame_coarse_gpu_bytes','frame_fine_gpu_bytes'))
    verify(p)
    summary.update(unchanged=True,exact_work_counters=True,method=worker['method'],diagnostic_not_speed_benchmark=True,hashes={f.name:sha(f) for f in folder.iterdir() if f.is_file() and f.name!='summary.json'})
    save(folder/'summary.json',summary)
    print(json.dumps(dict(worker=worker['directory'],samples=summary['sample_count'],exact=summary['exact_outputs'],maxima=summary['maxima'])),flush=True)
    return dict(directory=worker['directory'],method=worker['method'],summary_sha256=sha(folder/'summary.json'),maxima=summary['maxima'])
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=['small','full'],required=True);args=parser.parse_args()
    p=json.loads(PROTOCOL.read_text());verify(p)
    if args.mode=='small':run(p['small_validation'],p);return
    small=ROOT/p['small_validation']['directory']/'summary.json'
    if not small.exists() or not json.loads(small.read_text())['exact_outputs']:raise ValueError('Small validation must pass first')
    results=[]
    for worker in p['workers']:
        results.append(run(worker,p));save(ROOT/'build/fine-memory-512-progress.json',results)
    save(ROOT/'build/fine-memory-512-summary.json',dict(complete=True,protocol_sha256=sha(PROTOCOL),workers=results,all_exact=True,algorithm_calls=8,diagnostic_not_speed_benchmark=True))
if __name__=='__main__':main()
