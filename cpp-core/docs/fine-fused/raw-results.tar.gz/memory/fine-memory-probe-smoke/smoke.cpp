#include "fine_memory_probe.hpp"
#include <vector>
int main() {
    fpm_memory::Probe probe;
    fpm_memory::beginCall("smoke");
    {std::vector<unsigned char> payload(4*1024*1024,1);
    fpm_memory::stage("payload_live");
    std::this_thread::sleep_for(std::chrono::milliseconds(40));}
    fpm_memory::stage("payload_released");
    fpm_memory::pressureRelief("smoke_relief");
}
