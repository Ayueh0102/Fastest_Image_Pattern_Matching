import io,json,hashlib,shutil,subprocess,tarfile
from pathlib import Path
root=Path('/Users/Ayueh/Fastest_Image_Pattern_Matching');raw=root/'build/fine-fused-results';stage=root/'build/fine-fused-archive'
formal=json.loads((raw/'formal.json').read_text());assert formal['complete'] and formal['unchanged']
summary=json.loads((raw/'summary.json').read_text());assert summary['correctness_passed']
stage.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def cp(src,dst,expected=None):
 src=Path(src);dst=Path(dst)
 if expected:assert sha(src)==expected,str(src)
 dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
for p in raw.glob('*.json'):cp(p,stage/p.name)
shutil.copytree(raw/'jobs',stage/'jobs',dirs_exist_ok=True)
for p,h in formal['source_sha256'].items():cp(root/'build/fine-fused-measured-source'/p,stage/'source'/p,h)
revision=json.loads((root/'build/fine-fused/analysis-revision.json').read_text())
for change in revision['changed_files']:
 p=change['path'];cp(stage/'source'/p,stage/'measured-analysis'/p,change['measured_sha256']);cp(root/p,stage/'source'/p,change['final_sha256'])
cp(root/'build/fine-fused/analysis-original/summary.json',stage/'measured-analysis/summary-original.json')
cp(root/'build/fine-fused/analysis-revision.json',stage/'analysis-revision.json')
# Include all tracked GUI resources/build files, not only compiler sources.
for name in subprocess.check_output(['git','ls-files','macos-cli','MatchTool'],cwd=root,text=True).splitlines():
 cp(root/name,stage/'source'/name)
for p in ('LICENSE','AGENTS.md','CMakeLists.txt','vcpkg.json'):cp(root/p,stage/'source'/p)
paths=['cpp-core/CMakeLists.txt','cpp-core/src','cpp-core/include','cpp-core/experiments','cpp-core/tests','cpp-core/tools','cpp-core/examples','macos-cli','LICENSE']
blob=subprocess.check_output(['git','archive',formal['baseline_commit'],*paths],cwd=root)
with tarfile.open(fileobj=io.BytesIO(blob)) as tf:tf.extractall(stage/'frozen-source',filter='data')
mapping={}
for p,h in formal['input_sha256'].items():
 dst=Path('inputs')/Path(p).name;assert str(dst) not in mapping.values();cp(p,stage/dst,h);mapping[p]=str(dst)
(stage/'input-paths.json').write_text(json.dumps(mapping,indent=2)+'\n')
for p,h in formal['binary_sha256'].items():cp(p,stage/'binaries'/Path(p).relative_to(root/'build'),h)
for p in (root/'build/fine-fused').iterdir():
 if p.is_file() and p.suffix in ('.json','.log','.txt'):cp(p,stage/'logs'/p.name)
for name in ('fine-fused','fine-fused-asan','fine-search'):cp(root/'build'/name/'CMakeCache.txt',stage/'logs'/f'{name}-CMakeCache.txt')
shutil.copytree(root/'build/fine-fused-pilot',stage/'pilot',dirs_exist_ok=True)
cp(root/'cpp-core/docs/fine-angle-reuse/protocol.json',stage/'frozen-protocol.json',formal['previous_sha256'])
for p in (root/'build').glob('fine-memory-*'):
 if p.is_dir():shutil.copytree(p,stage/'memory'/p.name,dirs_exist_ok=True)
 elif p.suffix in ('.json','.py','.log','.txt','.cpp','.hpp'):cp(p,stage/'memory'/p.name)
cp(__file__,stage/'pack_fine_fused.py')
print('Staged',stage)
