# Stage30 reproducible evidence

The final protocol and raw jobs are preserved unchanged. Every formal worker was a new serial process. All arms use fineNccMode=2 and angle reuse; only the fusion option differs. Frozen means stage29 66d362e. Inputs are existing synthetic scenes, not new camera data.

`source/` contains the final sources and GUI resources; the measured native algorithm sources are identical. Four analysis/tool-test files were corrected after formal measurements; their original measured versions are in `measured-analysis/` and old/new hashes are listed in `analysis-revision.json`. `frozen-source/` is the baseline source tree. `binaries/` holds both native runners and their matching experimental libraries. `input-paths.json` maps original input paths to local archived copies. New measurements must rewrite job paths using that mapping. GT remains in the parent protocol, never in worker jobs.

Replay the summary from any directory:

```
python source/cpp-core/tools/benchmark_fine_fused.py --summarize formal.json --output replay-summary.json
```

Build the archived current source (Qt/OpenCV required as in normal project build):

```
DEVELOPER_DIR=/Library/Developer/CommandLineTools cmake -S source/cpp-core -B rebuilt -DCMAKE_BUILD_TYPE=Release -DFPM_BUILD_TESTS=ON -DFPM_BUILD_EXPERIMENTS=ON -DFPM_WITH_OPENCV=ON -DFPM_BUILD_GUI=ON
DEVELOPER_DIR=/Library/Developer/CommandLineTools cmake --build rebuilt --target fpm_native_pipeline_runner fpm_fine_statistics_repair_test fpm_fine_metal_test -j 6
```

`logs/` contains Release, targeted final tests, sanitizers and Metal validation. `pilot/` is exploratory, not used for formal speed claims. `memory/` contains a separate diagnostic protocol, raw samples, phase snapshots and exact-output checks. Memory instrumentation perturbs timings; it is not a speed benchmark. End-of-run allocator pressure relief is diagnostic only, not a production algorithm change. Preserve original stage29 RSS failures: a later recheck cannot erase them.

GPU timestamp -1 means unavailable. The final summarizer preserves -1 if any model timestamp is unavailable. The original measured summarizer incorrectly summed those sentinels; its original source and summary are preserved in measured-analysis/. All headline times/RSS/accuracy/decisions are unchanged. Combined fusion GPU time and standalone NCC GPU time are different quantities.

The first large memory diagnostic was rejected by exact output comparison because reconstruction used the runner compiler flags for the research target. The corrected tool reads each target flags separately (including -ffp-contract=off); the original failed attempt and the successful new protocols are retained. Memory tests and image-decode relief/vmmap controls are diagnostic interventions, not speed evidence.

`content-sha256.json` verifies every archived file except itself. Performance tolerance failures are independent of output/accuracy success and retained in summary.json.

Memory attribution: eight valid large diagnostic processes /16 calls passed exact checks. Pointer-correlated vmmap identifies a freed96MiB RGB888 decode buffer still resident before pose in the reuse path. The off path retained only about2.047MiB of the original range. This explains most of the reproduced gap, not every byte of the historical88.20MiB delta. Pressure relief had no effect. These are diagnostic controls, not timing results.

Future measurement protocols keep the verified frozen baseline commit separate from the current checkout commit. Original formal metadata is unchanged.
