Fixed-scale, full-image rotation comparison. Both methods use scales=[1].
The original-resolution route removes downsampling, keeps local refinement.
All28 workers and84 measured calls are preserved; the runtime is unchanged.
Source snapshots and original source photos support regeneration; binaries
are omitted but their hashes are recorded. Saved protocol absolute paths are
historical provenance, not paths required for summary replay.

With NumPy and OpenCV installed, run from any directory:
python3 EXTRACT/measured-sources/cpp-core/tools/benchmark_fixed_scale.py \
 --summarize EXTRACT/results.json --output /tmp/fixed-scale-summary.json
The output byte-matches replayed-summary.json. No GPU or source images needed
for this summary. All member hashes are in sha256.json (except itself).

No new algorithm is claimed. Four valid fixed-scale GT scenes all pass but
all performance gates for removing the pyramid fail. The scale+4% negative
control and unlabelled repository image are separate from normal accuracy.
