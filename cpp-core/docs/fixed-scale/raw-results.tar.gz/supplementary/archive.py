import gzip,hashlib,json,shutil,subprocess,sys,tarfile
from pathlib import Path
root=Path.cwd().resolve();base=root/'build/fixed-scale-study/formal';dest=root/'cpp-core/docs/fixed-scale';folder=root/'build/fixed-scale-study/archive'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def copy(a,b):b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(a,b)
r=json.loads((base/'results.json').read_text());protocol=r['protocol'];assert r['complete'] and r['unchanged']
assert sha(base/'results.protocol.json')==r['protocol_sha256']
for group in ('source_sha256','binary_sha256','input_sha256'):
 assert all(sha(p)==h for p,h in protocol[group].items()),group
save(dest/'results.json',r['summary']);copy(base/'results.protocol.json',dest/'protocol.json')
assert json.loads((base/'replayed-summary.json').read_text())==r['summary']
for p in sorted(base.rglob('*')):
 if p.is_file():copy(p,folder/p.relative_to(base))
for p,h in protocol['source_sha256'].items():
 target=folder/'measured-sources'/Path(p).relative_to(root);copy(p,target);assert sha(target)==h
for n in ('Src3.bmp','Src4.bmp','Dst4.bmp'):
 copy(root/'Test Images'/n,folder/'measured-sources/Test Images'/n)
for n in ('plot.py','archive.py','contract-release.log'):
 copy(root/'build/fixed-scale-study'/n,folder/'supplementary'/n)
previous=json.loads((root/'build/gui-integration-results/formal.json').read_text())
binary_parity=all(previous['binary_sha256'][p]==h for p,h in protocol['binary_sha256'].items());assert binary_parity
validation=dict(release_contract_tests='2/2 passed: CPU and Metal',test_log_sha256=sha(root/'build/fixed-scale-study/contract-release.log'),
 native_runtime_binaries_equal_previous_gui_study=binary_parity,source_binary_input_hashes_unchanged=True,
 workers=r['summary']['recorded_workers'],measured_calls=sum(len(json.loads((base/e['result']).read_text())['runs']) for e in r['execution_order'] if e['status']=='ok'),
 all_workers_succeeded=r['summary']['all_workers_succeeded'],route_integrity_passed=r['summary']['route_integrity_passed'],
 fixed_scale_gt_all_passed=r['summary']['fixed_scale_gt_all_passed'],
 all_full_resolution_performance_gates_passed=all(p['speed_gate'] for c in r['summary']['cases'] for p in c['paired_comparison']),
 limitations=['No new runtime or GUI feature implementation in this study.','New contract tests do not constitute rerunning the complete historical test suite.','Synthetic GT is not independent-camera accuracy.'])
save(dest/'validation.json',validation);save(folder/'validation.json',validation)
(folder/'README.txt').write_text('''Fixed-scale, full-image rotation comparison. Both methods use scales=[1].
The original-resolution route removes downsampling, keeps local refinement.
All28 workers and84 measured calls are preserved; the runtime is unchanged.
Source snapshots and original source photos support regeneration; binaries
are omitted but their hashes are recorded. Saved protocol absolute paths are
historical provenance, not paths required for summary replay.

With NumPy and OpenCV installed, run from any directory:
python3 EXTRACT/measured-sources/cpp-core/tools/benchmark_fixed_scale.py \\
 --summarize EXTRACT/results.json --output /tmp/fixed-scale-summary.json
The output byte-matches replayed-summary.json. No GPU or source images needed
for this summary. All member hashes are in sha256.json (except itself).

No new algorithm is claimed. Four valid fixed-scale GT scenes all pass but
all performance gates for removing the pyramid fail. The scale+4% negative
control and unlabelled repository image are separate from normal accuracy.
''')
manifest={str(p.relative_to(folder)):sha(p) for p in sorted(folder.rglob('*')) if p.is_file() and p.name!='sha256.json'};save(folder/'sha256.json',manifest)
archive=dest/'raw-results.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for p in sorted(folder.rglob('*')):
    if p.is_file():
     info=tar.gettarinfo(str(p),arcname=str(p.relative_to(folder)));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
     with p.open('rb') as data:tar.addfile(info,data)
with tarfile.open(archive) as tar:
 assert set(tar.getnames())==set(manifest)|{'sha256.json'}
 for n,h in manifest.items():assert hashlib.sha256(tar.extractfile(n).read()).hexdigest()==h
 relocated=root/'build/fixed-scale-study/relocated';relocated.mkdir(exist_ok=True);tar.extractall(relocated,filter='data')
subprocess.run([sys.executable,str(relocated/'measured-sources/cpp-core/tools/benchmark_fixed_scale.py'),'--summarize',str(relocated/'results.json'),'--output',str(relocated/'checked-summary.json')],cwd='/tmp',check=True)
assert (relocated/'checked-summary.json').read_bytes()==(dest/'results.json').read_bytes()
save(dest/'artifact-sha256.json',dict(archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,members=len(manifest),manifest_sha256=sha(folder/'sha256.json'),summary_sha256=sha(dest/'results.json'),relocated_summary_byte_identical=True,all_member_hashes_valid=True,original_source_binary_input_hashes_valid=True))
print(json.dumps(validation,indent=2));print('Archive hashes and relocated summary byte match passed.')
