import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
root=Path.cwd();base=root/'build/fixed-scale-study/formal';dest=root/'cpp-core/docs/fixed-scale';dest.mkdir(parents=True,exist_ok=True)
r=json.loads((base/'results.json').read_text());cases=[c for c in r['summary']['cases'] if c['backend']==1]
labels=['Small / 360 deg','Medium / +/-20 deg','Low contrast','Thin detail','Scale +4% (outside assumption)','Repository Src4 (no GT)']
x=np.arange(len(cases));fig,ax=plt.subplots(1,2,figsize=(13,5.8))
for i,(method,label,color) in enumerate([('pyramid','Fixed scale + pyramid','#386b8a'),('full_resolution','Fixed scale + original resolution','#c88438')]):
 times=[c['methods'][method]['total_ms']['median'] for c in cases];memory=[np.median(c['methods'][method]['peak_rss_bytes'])/2**20 for c in cases]
 for a,values in zip(ax,[times,memory]):
  bars=a.barh(x+(i-.5)*.34,values,.32,label=label,color=color)
  a.bar_label(bars,fmt='%.1f',padding=3,fontsize=8)
for a in ax:
 a.invert_yaxis();a.grid(axis='x',alpha=.15);a.spines[['top','right']].set_visible(False)
ax[0].set_yticks(x,labels,fontsize=9);ax[1].set_yticks(x,[]);ax[0].set_xlabel('Algorithm time (ms; median of 6 measured calls)');ax[1].set_xlabel('Peak process RSS (MiB; median of 2 workers)')
ax[0].set_xlim(0,430);ax[1].set_xlim(0,115);fig.legend(*ax[0].get_legend_handles_labels(), loc='upper center', bbox_to_anchor=(.6,.93), ncol=2, fontsize=9)
fig.suptitle('Fixed scale, full-image rotation search | Metal | identical search settings',fontsize=13)
fig.tight_layout(rect=[0,.055,1,.88]);fig.text(.02,.02,'Same native C++/Metal runtime. Setup and first call are recorded separately. No ground-truth location enters search.',fontsize=9)
fig.savefig(dest/'comparison.png',dpi=160);plt.close(fig)
for name,zoom in [('crop_medium20',False),('repo_src4',False)]:
 case=next(c for c in r['protocol']['cases'] if c['name']==name);fig,axes=plt.subplots(1,3,figsize=(13,4.7),gridspec_kw={'width_ratios':[.6,1.6,1.6]})
 axes[0].imshow(plt.imread(case['template']),cmap='gray');axes[0].set_title('Template (native pixels)')
 for a,method in zip(axes[1:],['pyramid','full_resolution']):
  e=next(e for e in r['execution_order'] if e['case']==name and e['backend']==1 and e['method']==method);raw=json.loads((base/e['result']).read_text())
  pixels=plt.imread(case['source']); pixels=pixels.astype(float)/255 if pixels.dtype==np.uint8 else pixels
  a.imshow(pixels,cmap='gray',vmin=0,vmax=1)
  if case['truth']:
   for gt in case['truth']:a.add_patch(Polygon(gt['corners'],closed=True,fill=False,edgecolor='#72d6a2',linewidth=2))
  for m in raw['first']['matches']:a.add_patch(Polygon(m['corners'],closed=True,fill=False,edgecolor='#f3a243',linewidth=1,linestyle='--'))
  a.set_title(('Pyramid' if method=='pyramid' else 'Original resolution')+f' | {len(raw["first"]["matches"])} detections')
 for a in axes:a.set_xticks([]);a.set_yticks([])
 caption='Green: synthetic ground truth. Orange dashed: detections. Photographed crop composited into a synthetic scene.' if case['truth'] else 'Unmodified repository image. Orange dashed: detections. No independent pose labels; equal count is not proof of accuracy.'
 fig.suptitle('Full-image search: '+name,fontsize=13);fig.tight_layout(rect=[0,.08,1,.94]);fig.text(.015,.025,caption,fontsize=9)
 fig.savefig(dest/(name+'.png'),dpi=160);plt.close(fig)
