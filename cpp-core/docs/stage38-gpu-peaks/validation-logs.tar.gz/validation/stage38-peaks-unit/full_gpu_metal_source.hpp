#pragma once
inline constexpr const char* fpmFullGpuMetalSource = R"FPMFULLGPU(// SPDX-License-Identifier: BSD-2-Clause
#include <metal_stdlib>
using namespace metal;

struct CoarseConfig {
    uint sw, tw, th, output_width;
    ulong first_window;
    uint count, reserved;
};
// Scalar fields deliberately avoid uint3's 16-byte alignment: host uses 12B.
struct Coarse32 { uint sum, square, product; };
struct Coarse64 { ulong sum, square, product; };

struct PyramidConfig { uint width, height, output_width, output_height; };
constant uint pyramid_weights[5] = {1, 4, 6, 4, 1};

// Signed 64-bit coordinates also avoid overflow in the reflection expression
// for long, narrow images. The width/height are positive by the host contract.
inline uint pyramid_reflect101(long p, uint length)
{
    if (length == 1) return 0;
    while (p < 0 || p >= long(length))
        p = p < 0 ? -p : 2 * long(length) - p - 2;
    return uint(p);
}

// Exact equivalent of the portable separable filter: all 25 integer products
// are summed before the ONE rounding operation. Maximum sum is 255*256=65280.
kernel void pyramid_direct(device const uchar* source [[buffer(0)]],
    device uchar* output [[buffer(1)]], constant PyramidConfig& cfg [[buffer(2)]],
    uint2 gid [[thread_position_in_grid]])
{
    if (gid.x >= cfg.output_width || gid.y >= cfg.output_height) return;
    uint sum = 0;
    for (int ky = -2; ky <= 2; ++ky) {
        const uint sy = pyramid_reflect101(2 * long(gid.y) + ky, cfg.height);
        for (int kx = -2; kx <= 2; ++kx) {
            const uint sx = pyramid_reflect101(2 * long(gid.x) + kx, cfg.width);
            sum += pyramid_weights[ky + 2] * pyramid_weights[kx + 2] *
                uint(source[ulong(sy) * cfg.width + sx]);
        }
    }
    output[ulong(gid.y) * cfg.output_width + gid.x] = uchar((sum + 128) >> 8);
}

kernel void pyramid_horizontal(device const uchar* source [[buffer(0)]],
    device ushort* horizontal [[buffer(1)]], constant PyramidConfig& cfg [[buffer(2)]],
    uint2 gid [[thread_position_in_grid]])
{
    if (gid.x >= cfg.output_width || gid.y >= cfg.height) return;
    uint sum = 0;
    for (int k = -2; k <= 2; ++k) {
        const uint sx = pyramid_reflect101(2 * long(gid.x) + k, cfg.width);
        sum += pyramid_weights[k + 2] * uint(source[ulong(gid.y) * cfg.width + sx]);
    }
    // Horizontal maximum is 255*16=4080; do not round between the axes.
    horizontal[ulong(gid.y) * cfg.output_width + gid.x] = ushort(sum);
}

kernel void pyramid_vertical(device const ushort* horizontal [[buffer(0)]],
    device uchar* output [[buffer(1)]], constant PyramidConfig& cfg [[buffer(2)]],
    uint2 gid [[thread_position_in_grid]])
{
    if (gid.x >= cfg.output_width || gid.y >= cfg.output_height) return;
    uint sum = 0;
    for (int k = -2; k <= 2; ++k) {
        const uint sy = pyramid_reflect101(2 * long(gid.y) + k, cfg.height);
        sum += pyramid_weights[k + 2] *
            uint(horizontal[ulong(sy) * cfg.output_width + gid.x]);
    }
    output[ulong(gid.y) * cfg.output_width + gid.x] = uchar((sum + 128) >> 8);
}

kernel void coarse_stats32(device const uchar* source [[buffer(0)]],
    device const uchar* templ [[buffer(1)]], device Coarse32* output [[buffer(2)]],
    constant CoarseConfig& cfg [[buffer(3)]], uint gid [[thread_position_in_grid]])
{
    if (gid >= cfg.count) return;
    const ulong index = cfg.first_window + gid;
    const ulong y = index / cfg.output_width, x = index % cfg.output_width;
    uint s = 0, q = 0, p = 0;
    for (uint ty = 0; ty < cfg.th; ++ty)
        for (uint tx = 0; tx < cfg.tw; ++tx) {
            const uint v = source[(y + ty) * cfg.sw + x + tx];
            const uint t = templ[ulong(ty) * cfg.tw + tx];
            s += v; q += v * v; p += v * t;
        }
    output[gid] = {s, q, p};
}

kernel void coarse_stats64(device const uchar* source [[buffer(0)]],
    device const uchar* templ [[buffer(1)]], device Coarse64* output [[buffer(2)]],
    constant CoarseConfig& cfg [[buffer(3)]], uint gid [[thread_position_in_grid]])
{
    if (gid >= cfg.count) return;
    const ulong index = cfg.first_window + gid;
    const ulong y = index / cfg.output_width, x = index % cfg.output_width;
    ulong s = 0, q = 0, p = 0;
    for (uint ty = 0; ty < cfg.th; ++ty)
        for (uint tx = 0; tx < cfg.tw; ++tx) {
            const uint v = source[(y + ty) * cfg.sw + x + tx];
            const uint t = templ[ulong(ty) * cfg.tw + tx];
            s += v; q += v * v; p += v * t;
        }
    output[gid] = {s, q, p};
}

// Four horizontally adjacent outputs per thread. The source window advances
// through a four-byte register strip: after the first pixel, only ONE new
// source byte is loaded per template column. Template values serve all four
// outputs. There is no explicit threadgroup staging or floating arithmetic.
template<typename Accum4, typename Stats>
inline void coarse_strip4(device const uchar* source, device const uchar* templ,
    device Stats* output, constant CoarseConfig& cfg, uint2 gid)
{
    const ulong x = ulong(gid.x) * 4;
    const ulong y = cfg.first_window / cfg.output_width + gid.y;
    const ulong end = cfg.first_window + cfg.count;
    if (x >= cfg.output_width || y > (end - 1) / cfg.output_width) return;
    Accum4 sum(0), square(0), product(0);
    for (uint ty = 0; ty < cfg.th; ++ty) {
        const ulong row = (y + ty) * cfg.sw;
        // Clamp only inactive right-edge lanes; valid NCC windows never need
        // padding. This also supports a source narrower than four pixels.
        uint4 values(source[row + x], source[row + min(x + 1, ulong(cfg.sw - 1))],
            source[row + min(x + 2, ulong(cfg.sw - 1))],
            source[row + min(x + 3, ulong(cfg.sw - 1))]);
        for (uint tx = 0; tx < cfg.tw; ++tx) {
            if (tx) values = uint4(values.y, values.z, values.w,
                source[row + min(x + tx + 3, ulong(cfg.sw - 1))]);
            const uint t = templ[ulong(ty) * cfg.tw + tx];
            sum += Accum4(values);
            square += Accum4(values * values);
            product += Accum4(values * t);
        }
    }
    for (uint lane = 0; lane < 4; ++lane) {
        const ulong index = y * cfg.output_width + x + lane;
        // Chunk boundaries can split a row or a strip. Only the exact original
        // [first_window, first_window + count) range may write this workspace.
        if (x + lane < cfg.output_width && index >= cfg.first_window && index < end)
            output[index - cfg.first_window] = {sum[lane], square[lane], product[lane]};
    }
}

kernel void coarse_strip4_32(device const uchar* source [[buffer(0)]],
    device const uchar* templ [[buffer(1)]], device Coarse32* output [[buffer(2)]],
    constant CoarseConfig& cfg [[buffer(3)]], uint2 gid [[thread_position_in_grid]])
{
    coarse_strip4<uint4, Coarse32>(source, templ, output, cfg, gid);
}
kernel void coarse_strip4_64(device const uchar* source [[buffer(0)]],
    device const uchar* templ [[buffer(1)]], device Coarse64* output [[buffer(2)]],
    constant CoarseConfig& cfg [[buffer(3)]], uint2 gid [[thread_position_in_grid]])
{
    coarse_strip4<ulong4, Coarse64>(source, templ, output, cfg, gid);
}

// A full 8x8 threadgroup owns an 8x8 output tile. For every <=16x16
// template tile, cooperatively load its <=23x23 source union and template.
// All 64 threads take both barriers, including inactive image/chunk edges.
template<typename Accum, typename Stats>
inline void coarse_staged8(device const uchar* source, device const uchar* templ,
    device Stats* output, constant CoarseConfig& cfg, uint2 group, uint tid,
    threadgroup uchar* sourceTile, threadgroup uchar* templateTile)
{
    const ulong baseX = ulong(group.x) * 8;
    const ulong baseY = cfg.first_window / cfg.output_width + ulong(group.y) * 8;
    const uint lx = tid % 8, ly = tid / 8;
    const ulong x = baseX + lx, y = baseY + ly;
    const ulong end = cfg.first_window + cfg.count;
    const ulong lastRow = (end - 1) / cfg.output_width;
    const ulong index = y * cfg.output_width + x;
    const bool active = x < cfg.output_width && y <= lastRow &&
        index >= cfg.first_window && index < end;
    Accum sum = 0, square = 0, product = 0;
    for (uint ty = 0; ty < cfg.th; ty += 16) {
        const uint kh = min(16u, cfg.th - ty);
        for (uint tx = 0; tx < cfg.tw; tx += 16) {
            const uint kw = min(16u, cfg.tw - tx), sw = kw + 7, sh = kh + 7;
            for (uint j = tid; j < sw * sh; j += 64) {
                const ulong sx = baseX + tx + j % sw, sy = baseY + ty + j / sw;
                // lastRow+th is at most the real source height. Zero-fill the
                // unused halo without reading outside the source or next row.
                sourceTile[j] = sx < cfg.sw && sy < lastRow + cfg.th ?
                    source[sy * cfg.sw + sx] : uchar(0);
            }
            for (uint j = tid; j < kw * kh; j += 64)
                templateTile[j] = templ[ulong(ty + j / kw) * cfg.tw + tx + j % kw];
            threadgroup_barrier(mem_flags::mem_threadgroup);
            if (active) {
                for (uint ky = 0; ky < kh; ++ky) for (uint kx = 0; kx < kw; ++kx) {
                    const uint v = sourceTile[(ly + ky) * sw + lx + kx];
                    const uint t = templateTile[ky * kw + kx];
                    sum += v; square += v * v; product += v * t;
                }
            }
            // Prevent the next tile overwriting bytes still read by peers.
            threadgroup_barrier(mem_flags::mem_threadgroup);
        }
    }
    if (active) output[index - cfg.first_window] = {sum, square, product};
}

kernel void coarse_staged8_32(device const uchar* source [[buffer(0)]],
    device const uchar* templ [[buffer(1)]], device Coarse32* output [[buffer(2)]],
    constant CoarseConfig& cfg [[buffer(3)]], uint2 group [[threadgroup_position_in_grid]],
    uint tid [[thread_index_in_threadgroup]])
{
    threadgroup uchar sourceTile[23 * 23], templateTile[16 * 16];
    coarse_staged8<uint, Coarse32>(source, templ, output, cfg, group, tid, sourceTile, templateTile);
}
kernel void coarse_staged8_64(device const uchar* source [[buffer(0)]],
    device const uchar* templ [[buffer(1)]], device Coarse64* output [[buffer(2)]],
    constant CoarseConfig& cfg [[buffer(3)]], uint2 group [[threadgroup_position_in_grid]],
    uint tid [[thread_index_in_threadgroup]])
{
    threadgroup uchar sourceTile[23 * 23], templateTile[16 * 16];
    coarse_staged8<ulong, Coarse64>(source, templ, output, cfg, group, tid, sourceTile, templateTile);
}

struct FineWarpDescriptor {
    long anchor_x, anchor_y, cosine, sine;
    ulong rounding_guard;
    uint repair_all, reserved;
};
struct FineWarpConfig {
    uint source_width, source_height, roi_width, roi_height;
    uint roi_pixels, roi_stride, count, reserved;
};
struct FineStatsConfig {
    uint roi_width, template_width, template_height, output_width;
    uint roi_stride, windows_per_map, count, reserved;
};

inline ulong fine_pixel(device const uchar* source, long x, long y,
    constant FineWarpConfig& cfg)
{
    return x < 0 || y < 0 || x >= long(cfg.source_width) || y >= long(cfg.source_height) ?
        0 : ulong(source[ulong(y) * cfg.source_width + ulong(x)]);
}

// Fast path is exact integer Q28 sampling. The host supplies a conservative
// bound on its difference from legacy double sampling. Values near any half-
// integer threshold are flagged and repaired by the ORIGINAL double formula
// before the NCC dispatch. There is no unchecked float texture interpolation.
kernel void fine_guarded_warp(device const uchar* source [[buffer(0)]],
    device uchar* rois [[buffer(1)]], device atomic_uint* repair_bits [[buffer(2)]],
    device const FineWarpDescriptor* descriptors [[buffer(3)]],
    constant FineWarpConfig& cfg [[buffer(4)]], uint gid [[thread_position_in_grid]])
{
    const uint map = gid / cfg.roi_pixels, pixel_index = gid % cfg.roi_pixels;
    if (map >= cfg.count) return;
    const FineWarpDescriptor descriptor = descriptors[map];
    const ulong target = ulong(map) * cfg.roi_stride + pixel_index;
    if (descriptor.repair_all) {
        rois[target] = 0; // Host repairs all pixels without a dense atomic mask.
        return;
    }
    const long x = long(pixel_index % cfg.roi_width), y = long(pixel_index / cfg.roi_width);
    const long unit = long(1) << 28;
    const long sx = descriptor.anchor_x + descriptor.cosine * x - descriptor.sine * y;
    const long sy = descriptor.anchor_y + descriptor.sine * x + descriptor.cosine * y;
    ulong numerator = 0;
    if (sx >= -unit && sy >= -unit && sx < long(cfg.source_width) * unit &&
        sy < long(cfg.source_height) * unit) {
        // Signed division truncates towards zero; correct it to floor for the
        // one negative border cell. Fractional coordinates stay in [0,2^28).
        const long ix = sx < 0 ? (sx - unit + 1) / unit : sx / unit;
        const long iy = sy < 0 ? (sy - unit + 1) / unit : sy / unit;
        const ulong dx = ulong(sx - ix * unit), dy = ulong(sy - iy * unit);
        const ulong one = ulong(unit);
        const ulong top = fine_pixel(source, ix, iy, cfg) * (one - dx) +
            fine_pixel(source, ix + 1, iy, cfg) * dx;
        const ulong bottom = fine_pixel(source, ix, iy + 1, cfg) * (one - dx) +
            fine_pixel(source, ix + 1, iy + 1, cfg) * dx;
        // Nonnegative terms sum to at most 255*2^56, safely below ULONG_MAX.
        numerator = top * (one - dy) + bottom * dy;
    }
    const ulong halfUnit = ulong(1) << 55;
    const ulong remainder = numerator & ((ulong(1) << 56) - 1);
    const ulong distance = remainder > halfUnit ? remainder - halfUnit : halfUnit - remainder;
    rois[target] = uchar((numerator + halfUnit) >> 56);
    if (distance <= descriptor.rounding_guard)
        atomic_fetch_or_explicit(repair_bits + (gid >> 5), uint(1) << (gid & 31), memory_order_relaxed);
}

kernel void fine_stats32(device const uchar* rois [[buffer(0)]],
    device const uchar* templ [[buffer(1)]], device Coarse32* output [[buffer(2)]],
    constant FineStatsConfig& cfg [[buffer(3)]], uint gid [[thread_position_in_grid]],
    uint lane [[thread_index_in_simdgroup]], uint simdWidth [[threads_per_simdgroup]])
{
    // Exactly one complete SIMD group owns each NCC window. Integer addition
    // is associative here: the host selects this path only when the COMPLETE
    // statistic fits uint32, so every nonnegative partial sum also fits.
    const uint index = gid / simdWidth;
    const uint map = index / cfg.windows_per_map, window = index % cfg.windows_per_map;
    if (map >= cfg.count) return;
    const ulong y = window / cfg.output_width, x = window % cfg.output_width;
    const ulong base = ulong(map) * cfg.roi_stride;
    const uint area = cfg.template_width * cfg.template_height;
    uint sum = 0, square = 0, product = 0;
    for (uint pixel = lane; pixel < area; pixel += simdWidth) {
        const uint ty = pixel / cfg.template_width, tx = pixel % cfg.template_width;
        const uint value = rois[base + (y + ty) * cfg.roi_width + x + tx];
        const uint t = templ[pixel];
        sum += value; square += value * value; product += value * t;
    }
    sum = simd_sum(sum); square = simd_sum(square); product = simd_sum(product);
    if (lane == 0) output[index] = {sum, square, product};
}

// Exact uint64 reduction using only widely supported uint32 SIMD reductions.
// Low/middle 16-bit limb reductions fit uint32 for SIMD widths <= 1024 (host
// checked). The sum of upper limbs cannot exceed the upper 32 bits of the
// complete statistic, which the host bounds below 2^53. Recombining in ulong
// preserves carries without floating point or a threadgroup memory barrier.
inline ulong fine_simd_sum64(ulong value)
{
    const uint low = simd_sum(uint(value & 65535));
    const uint middle = simd_sum(uint((value >> 16) & 65535));
    const uint high = simd_sum(uint(value >> 32));
    return ulong(low) + (ulong(middle) << 16) + (ulong(high) << 32);
}

kernel void fine_stats64(device const uchar* rois [[buffer(0)]],
    device const uchar* templ [[buffer(1)]], device Coarse64* output [[buffer(2)]],
    constant FineStatsConfig& cfg [[buffer(3)]], uint gid [[thread_position_in_grid]],
    uint lane [[thread_index_in_simdgroup]], uint simdWidth [[threads_per_simdgroup]])
{
    const uint index = gid / simdWidth;
    const uint map = index / cfg.windows_per_map, window = index % cfg.windows_per_map;
    if (map >= cfg.count) return;
    const ulong y = window / cfg.output_width, x = window % cfg.output_width;
    const ulong base = ulong(map) * cfg.roi_stride;
    const uint area = cfg.template_width * cfg.template_height;
    ulong sum = 0, square = 0, product = 0;
    for (uint pixel = lane; pixel < area; pixel += simdWidth) {
        const uint ty = pixel / cfg.template_width, tx = pixel % cfg.template_width;
        const uint value = rois[base + (y + ty) * cfg.roi_width + x + tx];
        const uint t = templ[pixel];
        sum += value; square += value * value; product += value * t;
    }
    sum = fine_simd_sum64(sum); square = fine_simd_sum64(square); product = fine_simd_sum64(product);
    if (lane == 0) output[index] = {sum, square, product};
}

// Optional fine normalization reuse. One SIMD group computes the first
// horizontal window of a ROI row, then rolls the seven neighboring sums.
// Rows are independent; vertical accumulation happens in the following pass.
struct FineRow32 { uint sum, square; };
struct FineRow64 { ulong sum, square; };
inline uint fine_reduce(uint value) { return simd_sum(value); }
inline ulong fine_reduce(ulong value) { return fine_simd_sum64(value); }

template<typename Acc, typename Row>
inline void fine_rows(device const uchar* rois, device Row* rows,
    constant FineStatsConfig& cfg, uint gid, uint lane, uint simdWidth)
{
    const uint height = cfg.template_height + cfg.windows_per_map / cfg.output_width - 1;
    const uint row = gid / simdWidth, map = row / height, y = row % height;
    if (map >= cfg.count) return; // Uniform for the entire SIMD group.
    const ulong base = ulong(map) * cfg.roi_stride + ulong(y) * cfg.roi_width;
    Acc sum = 0, square = 0;
    for (uint x = lane; x < cfg.template_width; x += simdWidth) {
        const Acc value = rois[base + x]; sum += value; square += value * value;
    }
    sum = fine_reduce(sum); square = fine_reduce(square);
    if (lane == 0) {
        rows[ulong(row) * cfg.output_width] = {sum, square};
        for (uint x = 1; x < cfg.output_width; ++x) {
            const Acc old = rois[base + x - 1], next = rois[base + x + cfg.template_width - 1];
            // Subtract first: each intermediate stays nonnegative and below
            // the host's COMPLETE-window uint32/uint64 bound.
            sum -= old; sum += next;
            square -= old * old; square += next * next;
            rows[ulong(row) * cfg.output_width + x] = {sum, square};
        }
    }
}

template<typename Acc, typename Row, typename Stats>
inline void fine_shared_stats(device const uchar* rois, device const uchar* templ,
    device Stats* output, constant FineStatsConfig& cfg, device const Row* rows,
    uint gid, uint lane, uint simdWidth)
{
    const uint index = gid / simdWidth;
    const uint map = index / cfg.windows_per_map, window = index % cfg.windows_per_map;
    if (map >= cfg.count) return;
    const ulong y = window / cfg.output_width, x = window % cfg.output_width;
    const ulong base = ulong(map) * cfg.roi_stride;
    const uint area = cfg.template_width * cfg.template_height;
    Acc product = 0, sum = 0, square = 0;
    for (uint pixel = lane; pixel < area; pixel += simdWidth) {
        const uint ty = pixel / cfg.template_width, tx = pixel % cfg.template_width;
        product += Acc(rois[base + (y + ty) * cfg.roi_width + x + tx]) * Acc(templ[pixel]);
    }
    const uint height = cfg.template_height + cfg.windows_per_map / cfg.output_width - 1;
    const ulong rowBase = (ulong(map) * height + y) * cfg.output_width + x;
    for (uint ty = lane; ty < cfg.template_height; ty += simdWidth) {
        const Row r = rows[rowBase + ulong(ty) * cfg.output_width];
        sum += r.sum; square += r.square;
    }
    product = fine_reduce(product); sum = fine_reduce(sum); square = fine_reduce(square);
    if (lane == 0) output[index] = {sum, square, product};
}

kernel void fine_rows32(device const uchar* rois [[buffer(0)]], device FineRow32* rows [[buffer(1)]],
    constant FineStatsConfig& cfg [[buffer(2)]], uint gid [[thread_position_in_grid]],
    uint lane [[thread_index_in_simdgroup]], uint width [[threads_per_simdgroup]])
{ fine_rows<uint,FineRow32>(rois,rows,cfg,gid,lane,width); }
kernel void fine_rows64(device const uchar* rois [[buffer(0)]], device FineRow64* rows [[buffer(1)]],
    constant FineStatsConfig& cfg [[buffer(2)]], uint gid [[thread_position_in_grid]],
    uint lane [[thread_index_in_simdgroup]], uint width [[threads_per_simdgroup]])
{ fine_rows<ulong,FineRow64>(rois,rows,cfg,gid,lane,width); }
kernel void fine_shared_stats32(device const uchar* rois [[buffer(0)]], device const uchar* templ [[buffer(1)]],
    device Coarse32* output [[buffer(2)]], constant FineStatsConfig& cfg [[buffer(3)]],
    device const FineRow32* rows [[buffer(4)]], uint gid [[thread_position_in_grid]],
    uint lane [[thread_index_in_simdgroup]], uint width [[threads_per_simdgroup]])
{ fine_shared_stats<uint,FineRow32,Coarse32>(rois,templ,output,cfg,rows,gid,lane,width); }
kernel void fine_shared_stats64(device const uchar* rois [[buffer(0)]], device const uchar* templ [[buffer(1)]],
    device Coarse64* output [[buffer(2)]], constant FineStatsConfig& cfg [[buffer(3)]],
    device const FineRow64* rows [[buffer(4)]], uint gid [[thread_position_in_grid]],
    uint lane [[thread_index_in_simdgroup]], uint width [[threads_per_simdgroup]])
{ fine_shared_stats<ulong,FineRow64,Coarse64>(rois,templ,output,cfg,rows,gid,lane,width); }

// Optional fine-search strip path. A complete SIMD group owns either the
// four left windows or the three right windows of one 7-wide output row.
// Its lanes partition the template into independent row/chunk jobs. Within
// each job, one template byte serves all Outputs windows and the source
// register strip advances by one byte. This reuses PIXEL LOADS, not dot-product
// values: every output still accumulates its own exact S, Q and P terms.
//
// A chunk of n template columns loads n template bytes and n+Outputs-1 source
// bytes, versus n*Outputs of each in independent window traversal. Chunk
// boundaries reload their short halos; neither threadgroup memory/barriers
// nor a separate global workspace is needed. Chunk length is a compile-time
// experiment parameter, not the SIMD width.
template<uint Chunk, uint Outputs, typename Acc, typename Stats>
inline void fine_strip_chunk(device const uchar* rois, device const uchar* templ,
    device Stats* output, constant FineStatsConfig& cfg, uint map, uint y,
    uint x, uint lane, uint simdWidth)
{
    Acc sum[Outputs] = {}, square[Outputs] = {}, product[Outputs] = {};
    const uint chunksPerRow = (cfg.template_width - 1) / Chunk + 1;
    const ulong jobs = ulong(chunksPerRow) * cfg.template_height;
    const ulong mapBase = ulong(map) * cfg.roi_stride;
    for (ulong job = lane; job < jobs; job += simdWidth) {
        const ulong ty = job / chunksPerRow;
        const uint tx = uint(job % chunksPerRow) * Chunk;
        const uint length = min(Chunk, cfg.template_width - tx);
        const ulong sourceBase = mapBase + (y + ty) * cfg.roi_width + x + tx;
        const ulong templateBase = ty * cfg.template_width + tx;
        uint values[Outputs];
        for (uint o = 0; o < Outputs; ++o) values[o] = rois[sourceBase + o];
        for (uint p = 0; p < length; ++p) {
            const uint t = templ[templateBase + p];
            for (uint o = 0; o < Outputs; ++o) {
                const uint value = values[o];
                sum[o] += value;
                square[o] += value * value;
                product[o] += value * t;
            }
            // Bound the read itself, not just the eventual output write.
            // The final chunk may be short. The right strip has exactly
            // three values, so it never reads or computes an eighth window.
            if (p + 1 < length) {
                for (uint o = 0; o + 1 < Outputs; ++o) values[o] = values[o + 1];
                values[Outputs - 1] = rois[sourceBase + p + Outputs];
            }
        }
    }
    const ulong outputBase = ulong(map) * cfg.windows_per_map + y * cfg.output_width + x;
    // All lanes, including lanes without a row/chunk job, take every
    // reduction. The complete nonnegative statistics obey the same host
    // uint32 area bound / uint64 limb-reduction bound as fine_stats32/64.
    for (uint o = 0; o < Outputs; ++o) {
        const Acc s = fine_reduce(sum[o]);
        const Acc q = fine_reduce(square[o]);
        const Acc p = fine_reduce(product[o]);
        if (lane == 0) output[outputBase + o] = {s, q, p};
    }
}

template<uint Chunk, typename Acc, typename Stats>
inline void fine_strip_dispatch(device const uchar* rois, device const uchar* templ,
    device Stats* output, constant FineStatsConfig& cfg, uint gid, uint lane, uint simdWidth)
{
    // Host contract: 7x7 outputs, 14 complete SIMD groups per map. The two
    // strip branches and the padding return are uniform within each group.
    const uint group = gid / simdWidth, map = group / 14, local = group % 14;
    if (map >= cfg.count) return;
    const uint y = local / 2;
    if ((local & 1) == 0)
        fine_strip_chunk<Chunk,4,Acc,Stats>(rois,templ,output,cfg,map,y,0,lane,simdWidth);
    else
        fine_strip_chunk<Chunk,3,Acc,Stats>(rois,templ,output,cfg,map,y,4,lane,simdWidth);
}

kernel void fine_strip_chunk32_stats32(device const uchar* rois [[buffer(0)]],
    device const uchar* templ [[buffer(1)]], device Coarse32* output [[buffer(2)]],
    constant FineStatsConfig& cfg [[buffer(3)]], uint gid [[thread_position_in_grid]],
    uint lane [[thread_index_in_simdgroup]], uint width [[threads_per_simdgroup]])
{ fine_strip_dispatch<32,uint,Coarse32>(rois,templ,output,cfg,gid,lane,width); }
kernel void fine_strip_chunk32_stats64(device const uchar* rois [[buffer(0)]],
    device const uchar* templ [[buffer(1)]], device Coarse64* output [[buffer(2)]],
    constant FineStatsConfig& cfg [[buffer(3)]], uint gid [[thread_position_in_grid]],
    uint lane [[thread_index_in_simdgroup]], uint width [[threads_per_simdgroup]])
{ fine_strip_dispatch<32,ulong,Coarse64>(rois,templ,output,cfg,gid,lane,width); }
kernel void fine_strip_chunk16_stats32(device const uchar* rois [[buffer(0)]],
    device const uchar* templ [[buffer(1)]], device Coarse32* output [[buffer(2)]],
    constant FineStatsConfig& cfg [[buffer(3)]], uint gid [[thread_position_in_grid]],
    uint lane [[thread_index_in_simdgroup]], uint width [[threads_per_simdgroup]])
{ fine_strip_dispatch<16,uint,Coarse32>(rois,templ,output,cfg,gid,lane,width); }
kernel void fine_strip_chunk16_stats64(device const uchar* rois [[buffer(0)]],
    device const uchar* templ [[buffer(1)]], device Coarse64* output [[buffer(2)]],
    constant FineStatsConfig& cfg [[buffer(3)]], uint gid [[thread_position_in_grid]],
    uint lane [[thread_index_in_simdgroup]], uint width [[threads_per_simdgroup]])
{ fine_strip_dispatch<16,ulong,Coarse64>(rois,templ,output,cfg,gid,lane,width); }

// Optional coarse path: a complete SIMD group cooperates on one NCC window.
// The host still uses the identical bounded statistics workspace, chunk/window
// ordering and binary64 normalization. All terms are nonnegative and the host
// selects uint32 only when 65025 * template_area <= UINT32_MAX, making both
// partial sums and the SIMD reductions exact.
kernel void coarse_parallel_stats32(device const uchar* source [[buffer(0)]],
    device const uchar* templ [[buffer(1)]], device Coarse32* output [[buffer(2)]],
    constant CoarseConfig& cfg [[buffer(3)]], uint gid [[thread_position_in_grid]],
    uint lane [[thread_index_in_simdgroup]], uint simdWidth [[threads_per_simdgroup]])
{
    const uint window = gid / simdWidth;
    if (window >= cfg.count) return; // Uniform within a complete SIMD group.
    const ulong index = cfg.first_window + window;
    const ulong y = index / cfg.output_width, x = index % cfg.output_width;
    const uint area = cfg.tw * cfg.th;
    uint sum = 0, square = 0, product = 0;
    for (uint pixel = lane; pixel < area; pixel += simdWidth) {
        const uint ty = pixel / cfg.tw, tx = pixel % cfg.tw;
        const uint value = source[(y + ty) * cfg.sw + x + tx];
        const uint t = templ[pixel];
        sum += value; square += value * value; product += value * t;
    }
    sum = simd_sum(sum); square = simd_sum(square); product = simd_sum(product);
    if (lane == 0) output[window] = {sum, square, product};
}

kernel void coarse_parallel_stats64(device const uchar* source [[buffer(0)]],
    device const uchar* templ [[buffer(1)]], device Coarse64* output [[buffer(2)]],
    constant CoarseConfig& cfg [[buffer(3)]], uint gid [[thread_position_in_grid]],
    uint lane [[thread_index_in_simdgroup]], uint simdWidth [[threads_per_simdgroup]])
{
    const uint window = gid / simdWidth;
    if (window >= cfg.count) return;
    const ulong index = cfg.first_window + window;
    const ulong y = index / cfg.output_width, x = index % cfg.output_width;
    // Keep large-template pixel/index arithmetic in 64 bits. Complete sums
    // are <= 2^53 by the same host guard as the original scalar uint64 path.
    const ulong area = ulong(cfg.tw) * cfg.th;
    ulong sum = 0, square = 0, product = 0;
    for (ulong pixel = lane; pixel < area; pixel += simdWidth) {
        const ulong ty = pixel / cfg.tw, tx = pixel % cfg.tw;
        const uint value = source[(y + ty) * cfg.sw + x + tx];
        const uint t = templ[pixel];
        sum += value; square += value * value; product += value * t;
    }
    // Reuse the proven 16/16/32-bit limb reduction from fine search; no
    // floating-point conversion or threadgroup memory synchronization.
    sum = fine_simd_sum64(sum); square = fine_simd_sum64(square); product = fine_simd_sum64(product);
    if (lane == 0) output[window] = {sum, square, product};
}

// SPDX-License-Identifier: BSD-2-Clause
#include <metal_stdlib>
using namespace metal;
struct Config {
    uint sw, sh, tw, th, channels, tiles, count, unused;
    float4 sourceMean, templateSum;
    float templateEnergy;
};
// 64 bytes (float4 alignment). Count is needed for the final partial tile.
struct Partial { float4 mean, m2, product; uint count; };

inline float load_pixel(device const float* source, int x, int y, uint c, constant Config& k)
{
    if (x < 0 || y < 0 || x >= int(k.sw) || y >= int(k.sh)) return -k.sourceMean[c];
    return source[(uint(y)*k.sw+uint(x))*k.channels+c];
}
// One group per pose/tile, 256 threads, four pixels per thread. Fuse bilinear
// sampling with NCC statistics: no intermediate warped image or integral map.
kernel void pose_partials(device const float* source [[buffer(0)]],
    device const float* templ [[buffer(1)]], device const float4* poses [[buffer(2)]],
    device Partial* partials [[buffer(3)]], constant Config& k [[buffer(4)]],
    uint lane [[thread_index_in_threadgroup]], uint2 group [[threadgroup_position_in_grid]])
{
    threadgroup float4 means[256], variances[256], products[256];
    threadgroup uint counts[256];
    float4 mean = 0, m2 = 0, product = 0;
    uint count = 0;
    const float4 p = poses[group.y];
    for (uint pixel = group.x*1024+lane; pixel < min((group.x+1)*1024, k.tw*k.th); pixel += 256) {
        const float u = float(pixel%k.tw)-float(k.tw)*.5f;
        const float v = float(k.th)*.5f-float(pixel/k.tw);
        const float sx = float(k.sw)*.5f+p.x+p.z*u-p.w*v;
        const float sy = float(k.sh)*.5f-p.y-(p.w*u+p.z*v);
        const int ix = int(floor(sx)), iy = int(floor(sy));
        const float dx = sx-float(ix), dy = sy-float(iy);
        float4 sample = 0;
        for (uint c = 0; c < k.channels; ++c) {
            const float a = load_pixel(source, ix, iy, c, k), b = load_pixel(source, ix+1, iy, c, k);
            const float e = load_pixel(source, ix, iy+1, c, k), f = load_pixel(source, ix+1, iy+1, c, k);
            const float value = (a+(b-a)*dx)*(1-dy)+(e+(f-e)*dx)*dy;
            sample[c] = value; product[c] += value*templ[pixel*k.channels+c];
        }
        // Welford avoids Q-S^2/N cancellation for constant / low-contrast ROIs.
        ++count;
        const float4 delta = sample-mean;
        mean += delta/float(count);
        m2 += delta*(sample-mean);
    }
    means[lane] = mean; variances[lane] = m2; products[lane] = product; counts[lane] = count;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    for (uint step = 128; step > 0; step >>= 1) {
        if (lane < step) {
            const uint a = counts[lane], b = counts[lane+step];
            const float4 delta = means[lane+step]-means[lane];
            if (a+b > 0) {
                means[lane] += delta*(float(b)/float(a+b));
                variances[lane] += variances[lane+step]+delta*delta*(float(a)*float(b)/float(a+b));
            }
            products[lane] += products[lane+step]; counts[lane] = a+b;
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }
    if (lane == 0) partials[group.y*k.tiles+group.x] = {means[0], variances[0], products[0], counts[0]};
}
kernel void pose_finish(device const Partial* partials [[buffer(0)]],
    device float* scores [[buffer(1)]], constant Config& k [[buffer(2)]], uint pose [[thread_position_in_grid]])
{
    if (pose >= k.count) return;
    float4 mean = 0, m2 = 0, product = 0;
    uint count = 0;
    for (uint i = 0; i < k.tiles; ++i) {
        Partial p = partials[pose*k.tiles+i];
        const float4 delta = p.mean-mean;
        const uint total = count+p.count;
        mean += delta*(float(p.count)/float(total));
        m2 += p.m2+delta*delta*(float(count)*float(p.count)/float(total));
        count = total; product += p.product;
    }
    const float n = float(k.tw*k.th);
    const float4 e = max(float4(0), m2);
    const float energy = e.x+e.y+e.z;
    const float4 numerator = product-mean*k.templateSum;
    scores[pose] = energy/n <= 1e-12f || k.templateEnergy/n <= 1e-12f ? -2.f :
        clamp((numerator.x+numerator.y+numerator.z)/sqrt(energy*k.templateEnergy), -1.f, 1.f);
}

// 144 bytes: scalar arrays intentionally avoid float3's 16-byte alignment.
// Each channel keeps means for [sample,Jtx,Jty,Jtheta(radians),Jlogscale].
// Centered covariance/template cross-products are summed over channels, since
// normalized NCC needs those sums only. Channel-specific means preserve exact
// centering; the small template residual mean is removed in host 4x4 assembly.
struct DerivativePartial {
    float mean[3][5], covariance[15], product[5];
    uint count;
};
static_assert(sizeof(DerivativePartial) == 144, "derivative host/device layout mismatch");

inline void merge_derivatives(thread DerivativePartial& a,
    thread const DerivativePartial& b, uint channels)
{
    const uint total = a.count+b.count;
    if (total == 0) return;
    const float weight = float(b.count)/float(total);
    const float correction = float(a.count)*float(b.count)/float(total);
    for (uint i = 0; i < 5; ++i) a.product[i] += b.product[i];
    for (uint i = 0; i < 15; ++i) a.covariance[i] += b.covariance[i];
    for (uint c = 0; c < channels; ++c) {
        float delta[5];
        for (uint i = 0; i < 5; ++i) {
            delta[i] = b.mean[c][i]-a.mean[c][i];
            a.mean[c][i] += delta[i]*weight;
        }
        uint entry = 0;
        for (uint i = 0; i < 5; ++i) for (uint j = i; j < 5; ++j) {
            a.covariance[entry] += delta[i]*delta[j]*correction;
            ++entry;
        }
    }
    a.count = total;
}

// A 128-thread group uses 9,216 bytes of threadgroup storage. Each thread
// consumes up to eight pixels of a 1024-pixel tile, fusing warp, derivatives and
// multivariate Welford updates. No warped image or per-pixel Jacobian is stored.
kernel void pose_derivative_partials(device const float* source [[buffer(0)]],
    device const float* templ [[buffer(1)]], device const float4* poses [[buffer(2)]],
    device DerivativePartial* partials [[buffer(3)]], constant Config& k [[buffer(4)]],
    uint lane [[thread_index_in_threadgroup]], uint2 group [[threadgroup_position_in_grid]])
{
    threadgroup DerivativePartial states[64];
    DerivativePartial state = {};
    const float4 p = poses[group.y];
    for (uint pixel = group.x*1024+lane; pixel < min((group.x+1)*1024, k.tw*k.th); pixel += 128) {
        const float u = float(pixel%k.tw)-float(k.tw)*.5f;
        const float v = float(k.th)*.5f-float(pixel/k.tw);
        const float rx = p.z*u-p.w*v, ry = p.w*u+p.z*v;
        // Preserve the scorer's float operation order for sampled coordinates.
        const float sx = float(k.sw)*.5f+p.x+p.z*u-p.w*v;
        const float sy = float(k.sh)*.5f-p.y-(p.w*u+p.z*v);
        const int ix = int(floor(sx)), iy = int(floor(sy));
        const float dx = sx-float(ix), dy = sy-float(iy);
        ++state.count;
        for (uint c = 0; c < k.channels; ++c) {
            const float a = load_pixel(source, ix, iy, c, k), b = load_pixel(source, ix+1, iy, c, k);
            const float e = load_pixel(source, ix, iy+1, c, k), f = load_pixel(source, ix+1, iy+1, c, k);
            const float sample = (a+(b-a)*dx)*(1-dy)+(e+(f-e)*dx)*dy;
            const float gx = (b-a)*(1-dy)+(f-e)*dy;
            const float gy = (e-a)*(1-dx)+(f-b)*dx;
            float values[5] = {sample, gx, -gy, -gx*ry-gy*rx, gx*rx-gy*ry};
            if (!(k.unused & 1u)) values[1] = values[2] = 0;
            if (!(k.unused & 2u)) values[3] = 0;
            if (!(k.unused & 4u)) values[4] = 0;
            const float t = templ[pixel*k.channels+c];
            float delta[5];
            for (uint i = 0; i < 5; ++i) {
                delta[i] = values[i]-state.mean[c][i];
                state.mean[c][i] += delta[i]/float(state.count);
                state.product[i] += values[i]*t;
            }
            uint entry = 0;
            for (uint i = 0; i < 5; ++i) for (uint j = i; j < 5; ++j)
                state.covariance[entry++] += delta[i]*(values[j]-state.mean[c][j]);
        }
    }
    // Keep the original 128-lane accumulation and exact reduction order.
    // Upper lanes publish their state; lower lanes retain theirs in registers.
    // This performs the old step=64 merge with half the shared storage and
    // leaves room for Shader Validation instrumentation on 32 KiB devices.
    if (lane >= 64) states[lane-64] = state;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (lane < 64) {
        const DerivativePartial right = states[lane];
        merge_derivatives(state, right, k.channels);
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (lane < 64) states[lane] = state;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    for (uint step = 32; step > 0; step >>= 1) {
        if (lane < step) {
            DerivativePartial left = states[lane], right = states[lane+step];
            merge_derivatives(left, right, k.channels);
            states[lane] = left;
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }
    if (lane == 0) partials[group.y*k.tiles+group.x] = states[0];
}

kernel void pose_derivative_finish(device const DerivativePartial* partials [[buffer(0)]],
    device DerivativePartial* output [[buffer(1)]], constant Config& k [[buffer(2)]],
    uint pose [[thread_position_in_grid]])
{
    if (pose >= k.count) return;
    DerivativePartial state = {};
    for (uint tile = 0; tile < k.tiles; ++tile) {
        const DerivativePartial next = partials[pose*k.tiles+tile];
        merge_derivatives(state, next, k.channels);
    }
    output[pose] = state;
}

// SPDX-License-Identifier: BSD-2-Clause
// Appended to pose_ncc.metal only when the opt-in resident solver is first used.
// The original score/derivative kernels remain the pixel-computation oracle.
// A single 64-thread control group provides a real group barrier for compacting
// independent poses. It never spins on another threadgroup's progress.
struct ResidentState {
    float4 pose, lower, upper, packed, candidate, candidatePacked;
    float h[16], g[4];
    float damping, score;
    uint iterations, evaluations, status, active, pending, proposed;
};
static_assert(sizeof(ResidentState) == 208, "resident state layout mismatch");
struct ResidentControl { uint activeCount, candidateCount, reserved[2]; };
struct ResidentDispatch { uint x, y, z, padding; };
struct ResidentOptions { uint count, finishThreads, reserved[2]; };
struct ResidentTrial { uint first, final; };
// Each indirect entry has 16-byte stride; Metal reads the first three uints.
enum ResidentGrid { ResidentOuter, ResidentDerivativeTiles, ResidentDerivativeFinish,
    ResidentTrialControl, ResidentScoreTiles, ResidentScoreFinish };

inline ResidentDispatch resident_grid(uint x, uint y = 1, uint z = 1)
{
    return x && y && z ? ResidentDispatch{x, y, z, 0} : ResidentDispatch{0, 0, 0, 0};
}
inline uint resident_covariance(uint i, uint j) { return i*5-i*(i-1)/2+j-i; }

inline float4 resident_pack(float4 pose)
{
    // Public angles stay unwrapped and bounded relative to their original seed.
    // Reducing only the trig argument avoids FP32 loss at large legal angles.
    const float angle = fmod(pose.z, 360.f)*0.01745329251994329577f;
    const float scale = exp(pose.w);
    return float4(pose.xy, scale*cos(angle), scale*sin(angle));
}

inline bool resident_assemble(thread const DerivativePartial& p,
    device ResidentState& s, device const Config& k)
{
    const float n = float(k.tw*k.th), energy = max(0.f, p.covariance[0]);
    if (!isfinite(energy) || energy/n <= 1e-12f || k.templateEnergy/n <= 1e-12f) return false;
    float product = p.product[0], jx[4], jt[4];
    for (uint i = 0; i < 4; ++i) {
        jx[i] = p.covariance[resident_covariance(0, i+1)];
        jt[i] = p.product[i+1];
    }
    for (uint c = 0; c < k.channels; ++c) {
        product -= p.mean[c][0]*k.templateSum[c];
        for (uint i = 0; i < 4; ++i) jt[i] -= p.mean[c][i+1]*k.templateSum[c];
    }
    const float denominator = sqrt(energy*k.templateEnergy);
    const float score = clamp(product/denominator, -1.f, 1.f);
    if (!isfinite(score) || !isfinite(denominator)) return false;
    for (uint i = 0; i < 4; ++i) {
        s.g[i] = jt[i]/denominator-score*jx[i]/energy;
        for (uint j = i; j < 4; ++j) {
            const float value = p.covariance[resident_covariance(i+1, j+1)]/energy
                -(jx[i]/energy)*(jx[j]/energy);
            s.h[4*i+j] = value; s.h[4*j+i] = value;
        }
    }
    return true;
}

inline bool resident_solve(device const ResidentState& s, thread float4& step)
{
    // Solve D^-1 (H + lambda diag(max(Hii,1e-12))) D^-1 z = D^-1 g,
    // then step = D^-1 z. Translation and angle/scale have very different units;
    // diagonal equilibration keeps the FP32 elimination near unit scale.
    float m[4][5], inverseDiagonal[4];
    for (uint i = 0; i < 4; ++i) {
        inverseDiagonal[i] = 1.f/sqrt(max(s.h[4*i+i], 1e-12f));
        if (!isfinite(inverseDiagonal[i])) return false;
    }
    for (uint i = 0; i < 4; ++i) {
        for (uint j = 0; j < 4; ++j)
            m[i][j] = s.h[4*i+j]*inverseDiagonal[i]*inverseDiagonal[j];
        m[i][i] += s.damping;
        m[i][4] = s.g[i]*inverseDiagonal[i];
    }
    for (uint i = 0; i < 4; ++i) {
        uint pivot = i;
        for (uint row = i+1; row < 4; ++row)
            if (abs(m[row][i]) > abs(m[pivot][i])) pivot = row;
        if (!isfinite(m[pivot][i]) || abs(m[pivot][i]) < 1e-12f) return false;
        for (uint j = i; j < 5; ++j) {
            const float temporary = m[i][j]; m[i][j] = m[pivot][j]; m[pivot][j] = temporary;
        }
        const float divisor = m[i][i];
        for (uint j = i; j < 5; ++j) m[i][j] /= divisor;
        for (uint row = 0; row < 4; ++row) if (row != i) {
            const float factor = m[row][i];
            for (uint j = i; j < 5; ++j) m[row][j] -= factor*m[i][j];
        }
    }
    for (uint i = 0; i < 4; ++i) step[i] = m[i][4]*inverseDiagonal[i];
    return all(isfinite(step));
}

kernel void resident_initialize(device ResidentState* states [[buffer(0)]],
    device const float* scores [[buffer(1)]], device ResidentControl& control [[buffer(2)]],
    device ResidentDispatch* grids [[buffer(3)]], constant ResidentOptions& options [[buffer(4)]],
    uint lane [[thread_index_in_threadgroup]])
{
    for (uint i = lane; i < options.count; i += 64) {
        device ResidentState& s = states[i];
        s.score = scores[i]; s.damping = 1e-3f;
        s.iterations = 0; s.evaluations = 1; s.pending = s.proposed = 0;
        s.status = !isfinite(s.score) ? 3u : (s.score == -2.f ? 2u : (s.score == 1.f ? 0u : 1u));
        s.active = s.status == 1u;
    }
    if (lane == 0) {
        control.activeCount = control.candidateCount = 0;
        for (uint i = 0; i < 6; ++i) grids[i] = resident_grid(0);
        grids[ResidentOuter] = resident_grid(1);
    }
}

kernel void resident_prepare(device ResidentState* states [[buffer(0)]],
    device ResidentControl& control [[buffer(1)]], device uint* activeMap [[buffer(2)]],
    device float4* packed [[buffer(3)]], device Config& k [[buffer(4)]],
    device ResidentDispatch* grids [[buffer(5)]], constant ResidentOptions& options [[buffer(6)]],
    uint lane [[thread_index_in_threadgroup]])
{
    threadgroup atomic_uint count;
    if (lane == 0) atomic_store_explicit(&count, 0u, memory_order_relaxed);
    threadgroup_barrier(mem_flags::mem_threadgroup);
    for (uint i = lane; i < options.count; i += 64) if (states[i].active) {
        const uint index = atomic_fetch_add_explicit(&count, 1u, memory_order_relaxed);
        activeMap[index] = i; packed[index] = states[i].packed;
    }
    threadgroup_barrier(mem_flags::mem_device | mem_flags::mem_threadgroup);
    if (lane == 0) {
        const uint n = atomic_load_explicit(&count, memory_order_relaxed);
        control.activeCount = n; control.candidateCount = 0; k.count = n;
        grids[ResidentOuter] = resident_grid(n ? 1u : 0u);
        grids[ResidentDerivativeTiles] = resident_grid(k.tiles, n);
        grids[ResidentDerivativeFinish] = resident_grid((n+options.finishThreads-1)/options.finishThreads);
        grids[ResidentTrialControl] = resident_grid(n ? 1u : 0u);
        grids[ResidentScoreTiles] = grids[ResidentScoreFinish] = resident_grid(0);
    }
}

// first: assemble this iteration's statistics and propose trial zero.
// otherwise: accept/reject the previous score batch, then propose the next trial.
// final: only accept/reject trial nine and terminate any still-pending pose.
kernel void resident_trial(device ResidentState* states [[buffer(0)]],
    device ResidentControl& control [[buffer(1)]], device const uint* activeMap [[buffer(2)]],
    device uint* candidateMap [[buffer(3)]], device float4* packed [[buffer(4)]],
    device const uchar* results [[buffer(5)]], device Config& k [[buffer(6)]],
    device ResidentDispatch* grids [[buffer(7)]], constant ResidentOptions& options [[buffer(8)]],
    constant ResidentTrial& trial [[buffer(9)]], uint lane [[thread_index_in_threadgroup]])
{
    threadgroup atomic_uint candidates, pending;
    if (lane == 0) {
        atomic_store_explicit(&candidates, 0u, memory_order_relaxed);
        atomic_store_explicit(&pending, 0u, memory_order_relaxed);
    }
    if (!trial.first) {
        const device float* scores = reinterpret_cast<const device float*>(results);
        for (uint j = lane; j < control.candidateCount; j += 64) {
            device ResidentState& s = states[candidateMap[j]];
            const float next = scores[j]; ++s.evaluations;
            // Both comparison scores use the unchanged pose_partials/finish
            // kernels. Ignore changes smaller than two float epsilons.
            if (isfinite(next) && next > s.score+2.384185791015625e-7f) {
                s.pose = s.candidate; s.packed = s.candidatePacked; s.score = next;
                s.damping = max(1e-8f, s.damping*.3f); s.pending = 0;
            } else s.damping *= 10.f;
            s.proposed = 0;
        }
    }
    threadgroup_barrier(mem_flags::mem_device | mem_flags::mem_threadgroup);
    for (uint j = lane; j < control.activeCount; j += 64) {
        const uint owner = activeMap[j];
        device ResidentState& s = states[owner];
        if (trial.first) {
            const device DerivativePartial* derivatives = reinterpret_cast<const device DerivativePartial*>(results);
            const DerivativePartial value = derivatives[j];
            ++s.iterations; ++s.evaluations;
            if (!resident_assemble(value, s, k)) {
                s.active = s.pending = 0; s.status = 2; continue;
            }
            s.pending = 1;
        }
        if (!s.active || !s.pending) continue;
        if (trial.final) { s.active = s.pending = 0; s.status = 3; continue; }
        float4 step;
        if (!resident_solve(s, step)) {
            s.damping *= 10.f;
            atomic_fetch_add_explicit(&pending, 1u, memory_order_relaxed);
            continue;
        }
        step.z /= 0.01745329251994329577f;
        const float ratio = max(1.f, max(max(abs(step.x)/2.f, abs(step.y)/2.f),
            max(abs(step.z)/5.f, abs(step.w)/.1f)));
        // lower/upper were rounded INWARD on the CPU from double seed-relative
        // intervals; an ordinary float clamp cannot escape those exact bounds.
        const float4 proposal = clamp(s.pose+step/ratio, s.lower, s.upper);
        step = proposal-s.pose;
        if (max(abs(step.x), abs(step.y)) < 1e-4f && abs(step.z) < 1e-4f && abs(step.w) < 1e-6f) {
            s.active = s.pending = 0; s.status = 0; continue;
        }
        s.candidate = proposal; s.candidatePacked = resident_pack(proposal);
        if (!all(isfinite(s.candidatePacked))) { s.active = s.pending = 0; s.status = 3; continue; }
        const uint index = atomic_fetch_add_explicit(&candidates, 1u, memory_order_relaxed);
        candidateMap[index] = owner; packed[index] = s.candidatePacked; s.proposed = 1;
        atomic_fetch_add_explicit(&pending, 1u, memory_order_relaxed);
    }
    threadgroup_barrier(mem_flags::mem_device | mem_flags::mem_threadgroup);
    if (lane == 0) {
        const uint n = atomic_load_explicit(&candidates, memory_order_relaxed);
        const uint remains = atomic_load_explicit(&pending, memory_order_relaxed);
        control.candidateCount = n; k.count = n;
        grids[ResidentScoreTiles] = resident_grid(k.tiles, n);
        grids[ResidentScoreFinish] = resident_grid((n+options.finishThreads-1)/options.finishThreads);
        grids[ResidentTrialControl] = resident_grid(remains ? 1u : 0u);
    }
}

// SPDX-License-Identifier: BSD-2-Clause
// Appended after pose_ncc.metal and pose_resident.metal for the opt-in,
// grayscale fused solver. The host enforces one 256-thread group per candidate
// and a nonempty template of at most 16,384 pixels. Groups never communicate.
// Pixel order, tile size and reduction trees match the separate kernels. Only
// the first 128 lanes evaluate derivatives; every lane executes every barrier.

inline void fused_score(device const float* source, device const float* templ,
    float4 p, constant Config& k, uint lane,
    threadgroup DerivativePartial* scratch, threadgroup float& result)
{
    // Scores are grayscale, so four scalar arrays fit inside the derivative
    // scratch. All accesses to the previous interpretation finish at a group
    // barrier before this function is entered or returns.
    threadgroup float* means = reinterpret_cast<threadgroup float*>(scratch);
    threadgroup float* variances = means+256;
    threadgroup float* products = means+512;
    threadgroup uint* counts = reinterpret_cast<threadgroup uint*>(means+768);
    float totalMean = 0, totalVariance = 0, totalProduct = 0;
    uint totalCount = 0;
    for (uint tile = 0; tile < k.tiles; ++tile) {
        float mean = 0, m2 = 0, product = 0;
        uint count = 0;
        for (uint pixel = tile*1024+lane;
            pixel < min((tile+1)*1024, k.tw*k.th); pixel += 256) {
            const float u = float(pixel%k.tw)-float(k.tw)*.5f;
            const float v = float(k.th)*.5f-float(pixel/k.tw);
            const float sx = float(k.sw)*.5f+p.x+p.z*u-p.w*v;
            const float sy = float(k.sh)*.5f-p.y-(p.w*u+p.z*v);
            const int ix = int(floor(sx)), iy = int(floor(sy));
            const float dx = sx-float(ix), dy = sy-float(iy);
            const float a = load_pixel(source, ix, iy, 0, k);
            const float b = load_pixel(source, ix+1, iy, 0, k);
            const float e = load_pixel(source, ix, iy+1, 0, k);
            const float f = load_pixel(source, ix+1, iy+1, 0, k);
            const float sample = (a+(b-a)*dx)*(1-dy)+(e+(f-e)*dx)*dy;
            product += sample*templ[pixel];
            ++count;
            const float delta = sample-mean;
            mean += delta/float(count);
            m2 += delta*(sample-mean);
        }
        means[lane] = mean; variances[lane] = m2;
        products[lane] = product; counts[lane] = count;
        threadgroup_barrier(mem_flags::mem_threadgroup);
        for (uint step = 128; step > 0; step >>= 1) {
            if (lane < step) {
                const uint a = counts[lane], b = counts[lane+step];
                const float delta = means[lane+step]-means[lane];
                if (a+b > 0) {
                    means[lane] += delta*(float(b)/float(a+b));
                    variances[lane] += variances[lane+step]
                        +delta*delta*(float(a)*float(b)/float(a+b));
                }
                products[lane] += products[lane+step]; counts[lane] = a+b;
            }
            threadgroup_barrier(mem_flags::mem_threadgroup);
        }
        if (lane == 0) {
            const float delta = means[0]-totalMean;
            const uint total = totalCount+counts[0];
            totalMean += delta*(float(counts[0])/float(total));
            totalVariance += variances[0]
                +delta*delta*(float(totalCount)*float(counts[0])/float(total));
            totalCount = total; totalProduct += products[0];
        }
        // The next tile must not overwrite lane zero's unread partial.
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }
    if (lane == 0) {
        const float n = float(k.tw*k.th), energy = max(0.f, totalVariance);
        const float numerator = totalProduct-totalMean*k.templateSum.x;
        result = energy/n <= 1e-12f || k.templateEnergy/n <= 1e-12f ? -2.f :
            clamp(numerator/sqrt(energy*k.templateEnergy), -1.f, 1.f);
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
}

inline void fused_derivatives(device const float* source, device const float* templ,
    float4 p, constant Config& k, uint lane,
    threadgroup DerivativePartial* scratch, threadgroup DerivativePartial& total)
{
    if (lane == 0) total = {};
    threadgroup_barrier(mem_flags::mem_threadgroup);
    for (uint tile = 0; tile < k.tiles; ++tile) {
        DerivativePartial state = {};
        if (lane < 128) {
            for (uint pixel = tile*1024+lane;
                pixel < min((tile+1)*1024, k.tw*k.th); pixel += 128) {
                const float u = float(pixel%k.tw)-float(k.tw)*.5f;
                const float v = float(k.th)*.5f-float(pixel/k.tw);
                const float rx = p.z*u-p.w*v, ry = p.w*u+p.z*v;
                const float sx = float(k.sw)*.5f+p.x+p.z*u-p.w*v;
                const float sy = float(k.sh)*.5f-p.y-(p.w*u+p.z*v);
                const int ix = int(floor(sx)), iy = int(floor(sy));
                const float dx = sx-float(ix), dy = sy-float(iy);
                ++state.count;
                const float a = load_pixel(source, ix, iy, 0, k);
                const float b = load_pixel(source, ix+1, iy, 0, k);
                const float e = load_pixel(source, ix, iy+1, 0, k);
                const float f = load_pixel(source, ix+1, iy+1, 0, k);
                const float sample = (a+(b-a)*dx)*(1-dy)+(e+(f-e)*dx)*dy;
                const float gx = (b-a)*(1-dy)+(f-e)*dy;
                const float gy = (e-a)*(1-dx)+(f-b)*dx;
                float values[5] = {sample, gx, -gy, -gx*ry-gy*rx, gx*rx-gy*ry};
                if (!(k.unused & 1u)) values[1] = values[2] = 0;
                if (!(k.unused & 2u)) values[3] = 0;
                if (!(k.unused & 4u)) values[4] = 0;
                const float t = templ[pixel];
                float delta[5];
                for (uint i = 0; i < 5; ++i) {
                    delta[i] = values[i]-state.mean[0][i];
                    state.mean[0][i] += delta[i]/float(state.count);
                    state.product[i] += values[i]*t;
                }
                uint entry = 0;
                for (uint i = 0; i < 5; ++i) for (uint j = i; j < 5; ++j)
                    state.covariance[entry++] += delta[i]*(values[j]-state.mean[0][j]);
            }
        }
        if (lane >= 64 && lane < 128) scratch[lane-64] = state;
        threadgroup_barrier(mem_flags::mem_threadgroup);
        if (lane < 64) {
            const DerivativePartial right = scratch[lane];
            merge_derivatives(state, right, 1);
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
        if (lane < 64) scratch[lane] = state;
        threadgroup_barrier(mem_flags::mem_threadgroup);
        for (uint step = 32; step > 0; step >>= 1) {
            if (lane < step) {
                DerivativePartial left = scratch[lane], right = scratch[lane+step];
                merge_derivatives(left, right, 1);
                scratch[lane] = left;
            }
            threadgroup_barrier(mem_flags::mem_threadgroup);
        }
        if (lane == 0) {
            DerivativePartial accumulated = total, next = scratch[0];
            merge_derivatives(accumulated, next, 1);
            total = accumulated;
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }
}

// Address-space-specific versions of the resident control helpers. Keeping
// the old helpers unchanged preserves the separate-kernel reference path.
inline bool fused_assemble(thread const DerivativePartial& p,
    threadgroup ResidentState& s, constant Config& k)
{
    const float n = float(k.tw*k.th), energy = max(0.f, p.covariance[0]);
    if (!isfinite(energy) || energy/n <= 1e-12f || k.templateEnergy/n <= 1e-12f) return false;
    float product = p.product[0], jx[4], jt[4];
    for (uint i = 0; i < 4; ++i) {
        jx[i] = p.covariance[resident_covariance(0, i+1)];
        jt[i] = p.product[i+1];
    }
    product -= p.mean[0][0]*k.templateSum[0];
    for (uint i = 0; i < 4; ++i) jt[i] -= p.mean[0][i+1]*k.templateSum[0];
    const float denominator = sqrt(energy*k.templateEnergy);
    const float score = clamp(product/denominator, -1.f, 1.f);
    if (!isfinite(score) || !isfinite(denominator)) return false;
    for (uint i = 0; i < 4; ++i) {
        s.g[i] = jt[i]/denominator-score*jx[i]/energy;
        for (uint j = i; j < 4; ++j) {
            const float value = p.covariance[resident_covariance(i+1, j+1)]/energy
                -(jx[i]/energy)*(jx[j]/energy);
            s.h[4*i+j] = value; s.h[4*j+i] = value;
        }
    }
    return true;
}

inline bool fused_solve(threadgroup const ResidentState& s, thread float4& step)
{
    float m[4][5], inverseDiagonal[4];
    for (uint i = 0; i < 4; ++i) {
        inverseDiagonal[i] = 1.f/sqrt(max(s.h[4*i+i], 1e-12f));
        if (!isfinite(inverseDiagonal[i])) return false;
    }
    for (uint i = 0; i < 4; ++i) {
        for (uint j = 0; j < 4; ++j)
            m[i][j] = s.h[4*i+j]*inverseDiagonal[i]*inverseDiagonal[j];
        m[i][i] += s.damping;
        m[i][4] = s.g[i]*inverseDiagonal[i];
    }
    for (uint i = 0; i < 4; ++i) {
        uint pivot = i;
        for (uint row = i+1; row < 4; ++row)
            if (abs(m[row][i]) > abs(m[pivot][i])) pivot = row;
        if (!isfinite(m[pivot][i]) || abs(m[pivot][i]) < 1e-12f) return false;
        for (uint j = i; j < 5; ++j) {
            const float temporary = m[i][j]; m[i][j] = m[pivot][j]; m[pivot][j] = temporary;
        }
        const float divisor = m[i][i];
        for (uint j = i; j < 5; ++j) m[i][j] /= divisor;
        for (uint row = 0; row < 4; ++row) if (row != i) {
            const float factor = m[row][i];
            for (uint j = i; j < 5; ++j) m[row][j] -= factor*m[i][j];
        }
    }
    for (uint i = 0; i < 4; ++i) step[i] = m[i][4]*inverseDiagonal[i];
    return all(isfinite(step));
}

kernel void pose_refine_fused(device const float* source [[buffer(0)]],
    device const float* templ [[buffer(1)]], device ResidentState* states [[buffer(2)]],
    constant Config& k [[buffer(3)]], constant uint& maxIterations [[buffer(4)]],
    uint lane [[thread_index_in_threadgroup]], uint group [[threadgroup_position_in_grid]])
{
    if (group >= k.count) return;
    // 9,216 + 144 + 208 + 4 bytes, rounded for alignment: below 10 KiB.
    threadgroup DerivativePartial scratch[64], derivative;
    threadgroup ResidentState s;
    threadgroup float trialScore;
    if (lane == 0) s = states[group];
    threadgroup_barrier(mem_flags::mem_threadgroup);
    fused_score(source, templ, s.packed, k, lane, scratch, s.score);
    if (lane == 0) {
        s.damping = 1e-3f; s.iterations = 0; s.evaluations = 1;
        s.pending = s.proposed = 0;
        s.status = !isfinite(s.score) ? 3u : (s.score == -2.f ? 2u : (s.score == 1.f ? 0u : 1u));
        s.active = s.status == 1u;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    for (uint iteration = 0; iteration < maxIterations; ++iteration) {
        const bool runIteration = s.active != 0;
        // Latch shared control before lane zero is allowed to change it.
        threadgroup_barrier(mem_flags::mem_threadgroup);
        if (!runIteration) break;
        fused_derivatives(source, templ, s.packed, k, lane, scratch, derivative);
        if (lane == 0) {
            const DerivativePartial value = derivative;
            ++s.iterations; ++s.evaluations;
            if (!fused_assemble(value, s, k)) {
                s.active = s.pending = 0; s.status = 2;
            } else s.pending = 1;
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
        for (uint trial = 0; trial < 10; ++trial) {
            const bool runTrial = s.active && s.pending;
            threadgroup_barrier(mem_flags::mem_threadgroup);
            if (!runTrial) break;
            if (lane == 0) {
                s.proposed = 0;
                float4 step;
                if (!fused_solve(s, step)) {
                    s.damping *= 10.f;
                } else {
                    step.z /= 0.01745329251994329577f;
                    const float ratio = max(1.f, max(max(abs(step.x)/2.f, abs(step.y)/2.f),
                        max(abs(step.z)/5.f, abs(step.w)/.1f)));
                    // Bounds were rounded inward from the seed on the host.
                    const float4 proposal = clamp(s.pose+step/ratio, s.lower, s.upper);
                    step = proposal-s.pose;
                    if (max(abs(step.x), abs(step.y)) < 1e-4f && abs(step.z) < 1e-4f
                        && abs(step.w) < 1e-6f) {
                        s.active = s.pending = 0; s.status = 0;
                    } else {
                        s.candidate = proposal; s.candidatePacked = resident_pack(proposal);
                        if (!all(isfinite(s.candidatePacked))) {
                            s.active = s.pending = 0; s.status = 3;
                        } else s.proposed = 1;
                    }
                }
            }
            threadgroup_barrier(mem_flags::mem_threadgroup);
            // The shared predicate was published by lane zero; all 256 lanes
            // either execute the entire scorer (including barriers), or skip it.
            if (s.proposed) {
                fused_score(source, templ, s.candidatePacked, k, lane, scratch, trialScore);
                if (lane == 0) {
                    ++s.evaluations;
                    if (isfinite(trialScore) && trialScore > s.score+2.384185791015625e-7f) {
                        s.pose = s.candidate; s.packed = s.candidatePacked; s.score = trialScore;
                        s.damping = max(1e-8f, s.damping*.3f); s.pending = 0;
                    } else s.damping *= 10.f;
                    s.proposed = 0;
                }
            }
            threadgroup_barrier(mem_flags::mem_threadgroup);
        }
        if (lane == 0 && s.active && s.pending) {
            s.active = s.pending = 0; s.status = 3;
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }
    if (lane == 0) states[group] = s;
}

// SPDX-License-Identifier: BSD-2-Clause
#pragma once
#ifdef __METAL_VERSION__
#define FG_UINT uint
#define FG_ULONG ulong
#else
#include <cstdint>
#define FG_UINT std::uint32_t
#define FG_ULONG std::uint64_t
#endif
// Scalar-only ABI; byte offsets refer to packed gray8 pyramid arenas.
struct FGLevel {
    FG_UINT sw, sh, tw, th;
    FG_UINT sourceOffset, templateOffset, statisticsIndex, reserved;
};
struct FGStats { FG_ULONG sum, square, variance, area; };
// Coarse: x/y top-left and angle is source rotation. Fine/finish: x/y center
// and angle is public counter-clockwise object angle. Invalid slots have valid=0.
struct FGCandidate {
    float x,y,angle,score,scale,coarseScore;
    FG_UINT valid,order,model,reserved0,reserved1,reserved2;
};
struct FGFineConfig {
    FG_UINT first,count,levelBase,top;
    FG_UINT stop,subpixel,rangeCount,model;
    float minScore,maxOverlap,scale,reserved;
    FG_UINT templateWidth,templateHeight,maxTargets,reserved2;
};
struct FGRange { float minimum,maximum; };
struct FGNmsConfig {
    FG_UINT first,count,outputFirst,limit;
    FG_UINT templateWidth,templateHeight,globalStage,rangeCount;
    float minScore,maxOverlap; FG_UINT reserved0,reserved1;
};
struct FGFinishConfig {
    FG_UINT sw,sh,tw,th;
    FG_UINT modelCount,proposalStride,capacity,optimizeMask;
    float minScore,maxOverlap; FG_UINT rangeCount,refine;
};
// Status counters are GPU-written. No host read is allowed before final wait.
struct FGStatus {
    FG_UINT proposals,matches,rescueParents,rescueStarts;
    FG_UINT rescueContinuations,overflow,reserved0,reserved1;
};
// GPU-formatted final/audit output. Geometry is never recomputed on the CPU.
struct FGResult {
    float x,y,angle,score,scale;
    float corners[8];
    FG_UINT reserved[3];
};
#undef FG_UINT
#undef FG_ULONG

// SPDX-License-Identifier: BSD-2-Clause
#pragma once
// Every score-map entry is retained. Padding is bounded to 255 records.
#define FG_PEAK_TILE_SIZE 256
#ifdef __METAL_VERSION__
struct FGPeakEntry { float score; uint index; };
#else
#include <cstdint>
struct FGPeakEntry { float score; std::uint32_t index; };
static_assert(sizeof(FGPeakEntry)==8,"Full GPU tiled peak ABI");
#endif

// SPDX-License-Identifier: BSD-2-Clause
// Complete resident gray8 pipeline helpers. All image-derived decisions are
// device work. FP32 interpolation/normalization is an explicit new contract.
inline float fg_angle(float a) {
    a = fmod(a,360.f); if (a > 180.f) a -= 360.f; if (a <= -180.f) a += 360.f; return a;
}
inline bool fg_allowed(float a, device const FGRange* ranges, uint count) {
    a=fg_angle(a);
    if (!count) return true;
    for(uint i=0;i<count;++i) for(int k=-1;k<=1;++k)
        if(a+360.f*k >= ranges[i].minimum-1e-5f && a+360.f*k <= ranges[i].maximum+1e-5f) return true;
    return false;
}
inline uint fg_pixel(device const uchar* src,uint w,uint h,int x,int y,uint border) {
    return x<0 || y<0 || x>=int(w) || y>=int(h) ? border : uint(src[ulong(y)*w+uint(x)]);
}
inline uchar fg_sample(device const uchar* src,uint w,uint h,float x,float y,uint border) {
    if(!isfinite(x) || !isfinite(y) || x < -1 || y < -1 || x>=float(w) || y>=float(h)) return uchar(border);
    int ix=int(floor(x)),iy=int(floor(y)); float dx=x-ix,dy=y-iy;
    float a=float(fg_pixel(src,w,h,ix,iy,border))*(1-dx)+float(fg_pixel(src,w,h,ix+1,iy,border))*dx;
    float b=float(fg_pixel(src,w,h,ix,iy+1,border))*(1-dx)+float(fg_pixel(src,w,h,ix+1,iy+1,border))*dx;
    return uchar(clamp(floor(a*(1-dy)+b*dy+.5f),0.f,255.f));
}
inline float fg_ncc(ulong s,ulong q,ulong p,FGStats t) {
    if (!t.variance) return 1;
    ulong vi=t.area*q-s*s, a=t.area*p,b=s*t.sum;
    float n=a>=b ? float(a-b) : -float(b-a);
    float denominator=float(vi)/float(t.area)>min(.5f,10.f*FLT_EPSILON*float(q)) ? sqrt(float(vi))*sqrt(float(t.variance)):0;
    if(denominator==0) return 0;
    if(abs(n)<denominator) return n/denominator;
    return abs(n)<denominator*1.125f ? (n>0 ? 1.f:-1.f):0.f;
}
struct FGScale { uint sw,sh,w,h; float inverse; uint reserved[3]; };
kernel void fg_scale_template(device const uchar* src[[buffer(0)]],device uchar* dst[[buffer(1)]],constant FGScale& c[[buffer(2)]],uint i[[thread_position_in_grid]]) {
    if(i>=c.w*c.h) return;
    if(c.inverse==1.f && c.sw==c.w && c.sh==c.h) { dst[i]=src[i]; return; }
    dst[i]=fg_sample(src,c.sw,c.sh,float(c.sw)*.5f+(float(i%c.w)-float(c.w)*.5f)*c.inverse,
        float(c.sh)*.5f+(float(i/c.w)-float(c.h)*.5f)*c.inverse,0);
}
kernel void fg_input(device const uchar* src[[buffer(0)]],device uchar* dst[[buffer(1)]],constant uint2& c[[buffer(2)]],uint i[[thread_position_in_grid]]) {
    if(i<c.x) dst[i]=c.y ? 255-src[i] : src[i];
}
kernel void fg_learn(device const uchar* src[[buffer(0)]],device FGStats* stats[[buffer(1)]],constant uint2& c[[buffer(2)]],uint lane[[thread_index_in_threadgroup]]) {
    threadgroup ulong sums[256],squares[256];ulong s=0,q=0;
    for(uint i=lane;i<c.x;i+=256) { ulong v=src[i];s+=v;q+=v*v; }
    sums[lane]=s;squares[lane]=q;threadgroup_barrier(mem_flags::mem_threadgroup);
    for(uint step=128;step;step/=2) { if(lane<step) { sums[lane]+=sums[lane+step];squares[lane]+=squares[lane+step]; } threadgroup_barrier(mem_flags::mem_threadgroup); }
    if(lane==0) stats[c.y]={sums[0],squares[0],ulong(c.x)*squares[0]-sums[0]*sums[0],c.x};
}
struct FGCoarse {
    uint sw,sh,w,h,tw,th,first,limit,statsIndex,borderIndex,windows,model;
    float cosine,sine,anchorX,anchorY,translationX,translationY,angle,threshold,overlap,scale;
    uint reserved[2];
};
kernel void fg_rotate(device const uchar* src[[buffer(0)]],device uchar* dst[[buffer(1)]],device const FGStats* stats[[buffer(2)]],constant FGCoarse& c[[buffer(3)]],uint i[[thread_position_in_grid]]) {
    if(i>=c.w*c.h) return;
    const FGStats t=stats[c.borderIndex];uint border=t.sum<128*t.area ? 255:0;
    float x=float(i%c.w),y=float(i/c.w);
    dst[i]=fg_sample(src,c.sw,c.sh,c.anchorX+c.cosine*x-c.sine*y,c.anchorY+c.sine*x+c.cosine*y,border);
}
template<typename T> inline void fg_normalize(device const T* input,device float* scores,device const FGStats* stats,constant uint4& c,uint i) {
    if(i<c.y) scores[c.x+i]=fg_ncc(input[i].sum,input[i].square,input[i].product,stats[c.z]);
}
kernel void fg_normalize32(device const Coarse32* input[[buffer(0)]],device float* scores[[buffer(1)]],device const FGStats* stats[[buffer(2)]],constant uint4& c[[buffer(3)]],uint i[[thread_position_in_grid]]) { fg_normalize(input,scores,stats,c,i); }
kernel void fg_normalize64(device const Coarse64* input[[buffer(0)]],device float* scores[[buffer(1)]],device const FGStats* stats[[buffer(2)]],constant uint4& c[[buffer(3)]],uint i[[thread_position_in_grid]]) { fg_normalize(input,scores,stats,c,i); }
inline bool fg_better(float a,uint ai,float b,uint bi) { return a>b || (a==b && ai<bi); }
kernel void fg_coarse_peaks(device float* scores[[buffer(0)]],device FGCandidate* candidates[[buffer(1)]],constant FGCoarse& c[[buffer(2)]],uint lane[[thread_index_in_threadgroup]]) {
    threadgroup float values[256];threadgroup uint indices[256];
    uint width=c.w-c.tw+1,height=c.h-c.th+1,stripe=(c.windows+255)/256;
    uint begin=min(c.windows,lane*stripe),end=min(c.windows,begin+stripe),bi=UINT_MAX;float best=-INFINITY;
    for(uint j=begin;j<end;++j) if(fg_better(scores[j],j,best,bi)){best=scores[j];bi=j;}
    for(uint iteration=0;iteration<c.limit;++iteration) {
        values[lane]=best;indices[lane]=bi;threadgroup_barrier(mem_flags::mem_threadgroup);
        for(uint step=128;step;step/=2) {
            if(lane<step && fg_better(values[lane+step],indices[lane+step],values[lane],indices[lane])) {values[lane]=values[lane+step];indices[lane]=indices[lane+step];}
            threadgroup_barrier(mem_flags::mem_threadgroup);
        }
        float score=values[0];uint index=indices[0];if(!isfinite(score)||score<c.threshold) break;
        uint x=index%width,y=index/width;
        if(lane==0) {
            float cx=float(c.sw-1)*.5f,cy=float(c.sh-1)*.5f,rx=float(x)-c.translationX-cx,ry=float(y)-c.translationY-cy;
            candidates[c.first+iteration]={cx+c.cosine*rx-c.sine*ry,cy+c.sine*rx+c.cosine*ry,c.angle,score,c.scale,score,1,c.first+iteration,c.model,0,0,0};
        }
        if(iteration+1==c.limit) break;
        float rw=c.tw*(1-c.overlap),rh=c.th*(1-c.overlap);
        int left=int(float(x)-rw),top=int(float(y)-rh);
        uint x0=uint(max(0,min(int(x),left))),x1=uint(min(int(width),max(int(x)+1,left+int(2*rw))));
        uint y0=uint(max(0,min(int(y),top))),y1=uint(min(int(height),max(int(y)+1,top+int(2*rh))));
        uint w=x1-x0,pixels=w*(y1-y0);
        for(uint j=lane;j<pixels;j+=256) scores[(y0+j/w)*width+x0+j%w]=-INFINITY;
        threadgroup_barrier(mem_flags::mem_device|mem_flags::mem_threadgroup);
        if(bi!=UINT_MAX && bi%width>=x0 && bi%width<x1 && bi/width>=y0 && bi/width<y1) {
            best=-INFINITY;bi=UINT_MAX;
            for(uint j=begin;j<end;++j) if(fg_better(scores[j],j,best,bi)){best=scores[j];bi=j;}
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }
}
// Source moments are tiled; no single workgroup scans the entire full-res image.
kernel void fg_source_moments(device const uchar* src[[buffer(0)]],device FGStats* partials[[buffer(1)]],constant uint& count[[buffer(2)]],uint lane[[thread_index_in_threadgroup]],uint group[[threadgroup_position_in_grid]]) {
    threadgroup ulong sums[256];ulong s=0;
    for(uint i=group*4096+lane;i<min((group+1)*4096,count);i+=256) s+=src[i];
    sums[lane]=s;threadgroup_barrier(mem_flags::mem_threadgroup);
    for(uint step=128;step;step/=2) {if(lane<step)sums[lane]+=sums[lane+step];threadgroup_barrier(mem_flags::mem_threadgroup);}
    if(!lane) partials[group]={sums[0],0,0,0};
}
kernel void fg_pose_config(device const FGStats* partials[[buffer(0)]],device const FGStats* stats[[buffer(1)]],device Config& k[[buffer(2)]],constant FGFinishConfig& c[[buffer(3)]],constant uint& templateStats[[buffer(4)]],uint lane[[thread_index_in_threadgroup]]) {
    threadgroup ulong sums[256];ulong sum=0;
    uint count=(c.sw*c.sh+4095)/4096;for(uint i=lane;i<count;i+=256)sum+=partials[i].sum;
    sums[lane]=sum;threadgroup_barrier(mem_flags::mem_threadgroup);
    for(uint step=128;step;step/=2) {if(lane<step)sums[lane]+=sums[lane+step];threadgroup_barrier(mem_flags::mem_threadgroup);}
    if(!lane) {
        k={};k.sw=c.sw;k.sh=c.sh;k.tw=c.tw;k.th=c.th;k.channels=1;k.tiles=(c.tw*c.th+1023)/1024;k.unused=c.optimizeMask;
        k.sourceMean.x=float(sums[0])/float(c.sw*c.sh)/255.f;
        k.templateSum.x=float(stats[templateStats].sum)/float(c.tw*c.th)/255.f; // temporary mean
    }
}
kernel void fg_center_source(device const uchar* src[[buffer(0)]],device float* dst[[buffer(1)]],constant Config& k[[buffer(2)]],uint i[[thread_position_in_grid]]) {
    if(i<k.sw*k.sh) dst[i]=float(src[i])/255.f-k.sourceMean.x;
}
kernel void fg_center_template(device const uchar* src[[buffer(0)]],device float* dst[[buffer(1)]],device Config& k[[buffer(2)]],uint lane[[thread_index_in_threadgroup]]) {
    threadgroup float sums[256],squares[256];float mean=k.templateSum.x,s=0,q=0;
    // All lanes latch the temporary mean before the final config write.
    threadgroup_barrier(mem_flags::mem_device|mem_flags::mem_threadgroup);
    for(uint i=lane;i<k.tw*k.th;i+=256) {float v=float(src[i])/255.f-mean;dst[i]=v;s+=v;q+=v*v;}
    sums[lane]=s;squares[lane]=q;threadgroup_barrier(mem_flags::mem_threadgroup);
    for(uint step=128;step;step/=2) {if(lane<step){sums[lane]+=sums[lane+step];squares[lane]+=squares[lane+step];}threadgroup_barrier(mem_flags::mem_threadgroup);}
    if(!lane) {k.templateSum=float4(sums[0],0,0,0);k.templateEnergy=max(0.f,squares[0]-sums[0]*sums[0]/float(k.tw*k.th));}
}

// SPDX-License-Identifier: BSD-2-Clause
// Exact tiled counterpart to fg_coarse_peaks, with two dispatches per map.
//
// Each tile is a complete sorted run, not a truncated local top-K. The merge
// invariant is that a lane's cached winner is the best unsuppressed entry in
// all tiles owned by that lane. Suppression can only remove entries, so that
// winner remains correct until it is suppressed. Only then are its tile heads
// advanced past suppressed entries. Each cursor is monotone. Global reduction
// uses the baseline (descending FP32 score, ascending original index) order.
//
// A private score-map is still mutated to -INFINITY for the identical half-open
// suppression rectangle. It serves as the shared tombstone map; no host reads,
// global spin barriers, per-peak dispatches, or approximate pruning are needed.

kernel void fg_coarse_sort_tiles(
    device const float* scores[[buffer(0)]],
    device FGPeakEntry* entries[[buffer(1)]],
    constant FGCoarse& c[[buffer(2)]],
    device uint* heads[[buffer(3)]],
    uint lane[[thread_index_in_threadgroup]],
    uint tile[[threadgroup_position_in_grid]]) {
    threadgroup float values[FG_PEAK_TILE_SIZE];
    threadgroup uint indices[FG_PEAK_TILE_SIZE];
    const uint index=tile*FG_PEAK_TILE_SIZE+lane;
    // Baseline comparisons never select NaN. Normalizing it to -INFINITY is
    // equivalent, since non-finite winning scores terminate without an output.
    const float score=index<c.windows ? scores[index] : -INFINITY;
    values[lane]=isnan(score) ? -INFINITY:score;
    indices[lane]=index<c.windows ? index:UINT_MAX;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    for(uint size=2;size<=FG_PEAK_TILE_SIZE;size*=2) {
        for(uint stride=size/2;stride;stride/=2) {
            const uint peer=lane^stride;
            const float ownValue=values[lane],peerValue=values[peer];
            const uint ownIndex=indices[lane],peerIndex=indices[peer];
            // Both lanes independently choose their side of the exchange.
            // The read barrier is required before either lane overwrites its
            // slot; SIMD scheduling alone is not a workgroup memory contract.
            const bool first=(lane&stride)==0;
            const bool descending=(lane&size)==0;
            const bool wantBetter=first==descending;
            const bool peerBetter=fg_better(peerValue,peerIndex,ownValue,ownIndex);
            const bool takePeer=wantBetter ? peerBetter:fg_better(ownValue,ownIndex,peerValue,peerIndex);
            threadgroup_barrier(mem_flags::mem_threadgroup);
            if(takePeer) {values[lane]=peerValue;indices[lane]=peerIndex;}
            threadgroup_barrier(mem_flags::mem_threadgroup);
        }
    }
    entries[index]={values[lane],indices[lane]};
    if(!lane) heads[tile]=0;
}

kernel void fg_coarse_peaks_tiled(
    device float* scores[[buffer(0)]],
    device FGCandidate* candidates[[buffer(1)]],
    constant FGCoarse& c[[buffer(2)]],
    device const FGPeakEntry* entries[[buffer(3)]],
    device uint* heads[[buffer(4)]],
    uint lane[[thread_index_in_threadgroup]]) {
    threadgroup float values[256];
    threadgroup uint indices[256];
    const uint width=c.w-c.tw+1,height=c.h-c.th+1;
    const uint tiles=(c.windows+FG_PEAK_TILE_SIZE-1)/FG_PEAK_TILE_SIZE;
    const uint stripe=(tiles+255)/256;
    const uint begin=min(tiles,lane*stripe),end=min(tiles,begin+stripe);
    float best=-INFINITY;uint bi=UINT_MAX;
    for(uint tile=begin;tile<end;++tile) {
        const FGPeakEntry head=entries[tile*FG_PEAK_TILE_SIZE];
        if(fg_better(head.score,head.index,best,bi)) {best=head.score;bi=head.index;}
    }
    for(uint iteration=0;iteration<c.limit;++iteration) {
        values[lane]=best;indices[lane]=bi;
        threadgroup_barrier(mem_flags::mem_threadgroup);
        for(uint step=128;step;step/=2) {
            if(lane<step && fg_better(values[lane+step],indices[lane+step],values[lane],indices[lane])) {
                values[lane]=values[lane+step];indices[lane]=indices[lane+step];
            }
            threadgroup_barrier(mem_flags::mem_threadgroup);
        }
        const float score=values[0];const uint index=indices[0];
        if(!isfinite(score)||score<c.threshold) break;
        const uint x=index%width,y=index/width;
        if(lane==0) {
            const float cx=float(c.sw-1)*.5f,cy=float(c.sh-1)*.5f;
            const float rx=float(x)-c.translationX-cx,ry=float(y)-c.translationY-cy;
            candidates[c.first+iteration]={cx+c.cosine*rx-c.sine*ry,cy+c.sine*rx+c.cosine*ry,
                c.angle,score,c.scale,score,1,c.first+iteration,c.model,0,0,0};
        }
        // Match baseline score-map mutation: its final accepted peak is not
        // suppressed when the requested output limit has been reached.
        if(iteration+1==c.limit) break;
        const float rw=c.tw*(1-c.overlap),rh=c.th*(1-c.overlap);
        const int left=int(float(x)-rw),top=int(float(y)-rh);
        const uint x0=uint(max(0,min(int(x),left)));
        const uint x1=uint(min(int(width),max(int(x)+1,left+int(2*rw))));
        const uint y0=uint(max(0,min(int(y),top)));
        const uint y1=uint(min(int(height),max(int(y)+1,top+int(2*rh))));
        const uint w=x1-x0,pixels=w*(y1-y0);
        for(uint j=lane;j<pixels;j+=256) scores[(y0+j/w)*width+x0+j%w]=-INFINITY;
        threadgroup_barrier(mem_flags::mem_device|mem_flags::mem_threadgroup);
        if(bi!=UINT_MAX && bi%width>=x0 && bi%width<x1 && bi/width>=y0 && bi/width<y1) {
            best=-INFINITY;bi=UINT_MAX;
            for(uint tile=begin;tile<end;++tile) {
                uint cursor=heads[tile];
                while(cursor<FG_PEAK_TILE_SIZE) {
                    const FGPeakEntry head=entries[tile*FG_PEAK_TILE_SIZE+cursor];
                    // A sorted suffix below threshold can never produce an
                    // accepted output. +INFINITY remains a winning sentinel,
                    // exactly as in the baseline; do not skip it here.
                    if(head.index==UINT_MAX || head.score<c.threshold || head.score==-INFINITY) {
                        cursor=FG_PEAK_TILE_SIZE;break;
                    }
                    if(scores[head.index]!=-INFINITY) {
                        if(fg_better(head.score,head.index,best,bi)) {best=head.score;bi=head.index;}
                        break;
                    }
                    ++cursor;
                }
                heads[tile]=cursor;
            }
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }
}

// SPDX-License-Identifier: BSD-2-Clause
// GPU-resident scalar-matcher control flow. Included after full_gpu_types.h
// and the shared fg_angle / fg_sample / fg_ncc / fg_allowed helpers.
// A workgroup owns one candidate throughout every layer and subpixel pass.
// FP32 coordinates/scores replace the reference CPU FP64 arithmetic; integer
// NCC moments are exact within the host-validated uint64 area bound.
constant uint FG_FINE_ANGLES = 35;
constant uint FG_FINE_WINDOWS = 49;
// Shader validation instruments threadgroup accesses and can double static
// storage. The host explicitly chooses 4096 in that mode to stay below the
// 32 KiB device limit; ordinary execution keeps its 16 KiB cache. Uncached
// pixels use exactly the same GPU sampler, with no arithmetic/CPU fallback.
#ifndef FG_FINE_ROI_CAPACITY
#define FG_FINE_ROI_CAPACITY 16384
#endif
constant uint FG_FINE_ROI_BYTES = FG_FINE_ROI_CAPACITY;
constant float FG_FINE_D2R = 0.01745329251994329577f;
constant float FG_FINE_ANGLE_EPS = 0.00004f;

struct FGFineState {
    float2 point, anchor;
    float angle, step;
    uint angleCount, nextCount, best;
    uint active, changed, maps;
    float angles[35], nextAngles[35];
    uint peakIndex[35];
    float peakScore[35];
};

inline void fg_fine_append(threadgroup float* angles, thread uint& count, float value)
{
    value = fg_angle(value);
    for (uint i = 0; i < count; ++i)
        if (fabs(fg_angle(angles[i] - value)) < 1.0e-9f) return;
    // The host enforces <=16 ranges: at most 3 + 2*16 distinct values.
    angles[count++] = value;
}

inline uint fg_fine_angles(float center, float step, device const FGRange* ranges,
    uint rangeCount, threadgroup float* angles)
{
    uint count = 0;
    for (int k = -1; k <= 1; ++k) {
        const float value = center + float(k) * step;
        if (fg_allowed(fg_angle(-value), ranges, rangeCount))
            fg_fine_append(angles, count, value);
    }
    for (uint r = 0; r < rangeCount; ++r) {
        const float values[2] = {ranges[r].minimum, ranges[r].maximum};
        for (uint e = 0; e < 2; ++e)
            if (fabs(fg_angle(-values[e] - center)) <= step + FG_FINE_ANGLE_EPS)
                fg_fine_append(angles, count, -values[e]);
    }
    // Stable insertion order matches the reference order before sorting.
    for (uint i = 1; i < count; ++i) {
        float value = angles[i];
        uint j = i;
        while (j && fg_angle(value - center) < fg_angle(angles[j - 1] - center)) {
            angles[j] = angles[j - 1]; --j;
        }
        angles[j] = value;
    }
    return count;
}

inline void fg_fine_replace_angles(threadgroup FGFineState& state)
{
    state.angleCount = state.nextCount;
    for (uint i = 0; i < state.angleCount; ++i) state.angles[i] = state.nextAngles[i];
}

inline uchar fg_fine_pixel(device const uchar* source, FGLevel level,
    float2 anchor, float c, float s, uint x, uint y)
{
    const float px = float(x) - 3.0f, py = float(y) - 3.0f;
    return fg_sample(source + level.sourceOffset, level.sw, level.sh,
        anchor.x + c * px - s * py, anchor.y + s * px + c * py, 0);
}

inline void fg_fine_evaluate(device const uchar* source, device const uchar* templ,
    FGLevel level, FGStats stats, threadgroup FGFineState& state,
    threadgroup uchar* roi, threadgroup ulong* partial, threadgroup float* maps,
    uint lane)
{
    const uint roiW = level.tw + 6, roiH = level.th + 6;
    const ulong roiArea = ulong(roiW) * roiH;
    const bool cached = roiArea <= FG_FINE_ROI_BYTES;
    const uint window = lane / 4, strip = lane % 4;
    if (lane == 0) state.best = 0xffffffffu;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    for (uint a = 0; a < state.angleCount; ++a) {
        const float radians = state.angles[a] * FG_FINE_D2R;
        const float c = cos(radians), s = sin(radians);
        if (cached) {
            for (uint p = lane; p < uint(roiArea); p += 256)
                roi[p] = fg_fine_pixel(source, level, state.anchor, c, s, p % roiW, p / roiW);
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
        if (window < FG_FINE_WINDOWS) {
            ulong sum = 0, square = 0, dot = 0;
            const uint wx = window % 7, wy = window / 7;
            const uint area = level.tw * level.th;
            for (uint p = strip; p < area; p += 4) {
                const uint x = p % level.tw, y = p / level.tw;
                const ulong pixel = cached ? roi[(wy + y) * roiW + wx + x] :
                    fg_fine_pixel(source, level, state.anchor, c, s, wx + x, wy + y);
                const ulong t = templ[level.templateOffset + p];
                sum += pixel; square += pixel * pixel; dot += pixel * t;
            }
            partial[lane * 3] = sum;
            partial[lane * 3 + 1] = square;
            partial[lane * 3 + 2] = dot;
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
        if (lane < FG_FINE_WINDOWS) {
            ulong sum = 0, square = 0, dot = 0;
            for (uint k = 0; k < 4; ++k) {
                const uint p = (lane * 4 + k) * 3;
                sum += partial[p]; square += partial[p + 1]; dot += partial[p + 2];
            }
            maps[a * FG_FINE_WINDOWS + lane] = fg_ncc(sum, square, dot, stats);
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
        if (lane == 0) {
            uint peak = 0;
            for (uint p = 1; p < FG_FINE_WINDOWS; ++p)
                if (maps[a * FG_FINE_WINDOWS + p] > maps[a * FG_FINE_WINDOWS + peak]) peak = p;
            state.peakIndex[a] = peak;
            state.peakScore[a] = maps[a * FG_FINE_WINDOWS + peak];
            if (state.best == 0xffffffffu || state.peakScore[a] > state.peakScore[state.best]) state.best = a;
            ++state.maps;
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }
    // Complete the final shared loop-bound read on every SIMD group before
    // lane zero can return and replace angleCount/angles for the next search.
    // The last in-loop barrier alone does not protect that following read.
    threadgroup_barrier(mem_flags::mem_threadgroup);
}

// On the 3^d Cartesian grid, {1, x_i, x_i*x_j, x_i^2-2/3}
// are orthogonal. Their squared norms are 3^d, 2*3^(d-1),
// 4*3^(d-2), and (2/3)*3^(d-1), respectively. These moment
// formulas equal the fixed-design least-squares fit in subpixel.cpp, without
// constructing its 27x10 matrix or doing QR for each candidate.
inline bool fg_fine_fit(threadgroup const float* maps, uint best, uint peak,
    uint dimension, thread float3& offset)
{
    float h[3][3] = {{0, 0, 0}, {0, 0, 0}, {0, 0, 0}};
    float g[3] = {0, 0, 0};
    const int planes = dimension == 3 ? 1 : 0;
    const float gradientDenominator = dimension == 3 ? 18.0f : 6.0f;
    const float diagonalDenominator = dimension == 3 ? 3.0f : 1.0f;
    const float crossDenominator = dimension == 3 ? 12.0f : 4.0f;
    // Subtract the center value to remove the large DC term before computing
    // curvature. Constant subtraction cannot change fitted gradient/Hessian.
    const float dc = maps[best * FG_FINE_WINDOWS + peak];
    for (int z = -planes; z <= planes; ++z)
        for (int y = -1; y <= 1; ++y)
            for (int x = -1; x <= 1; ++x) {
                const float value = maps[uint(int(best) + z) * FG_FINE_WINDOWS + uint(int(peak) + 7 * y + x)] - dc;
                if (!isfinite(value)) return false;
                const float v[3] = {float(x), float(y), float(z)};
                for (uint i = 0; i < dimension; ++i) {
                    g[i] += v[i] * value / gradientDenominator;
                    h[i][i] += (v[i] * v[i] - 2.0f / 3.0f) * value / diagonalDenominator;
                    for (uint j = 0; j < i; ++j) h[i][j] += v[i] * v[j] * value / crossDenominator;
                }
            }
    float lower[3][3] = {{0, 0, 0}, {0, 0, 0}, {0, 0, 0}};
    for (uint i = 0; i < dimension; ++i)
        for (uint j = 0; j <= i; ++j) {
            float value = -h[i][j];
            for (uint k = 0; k < j; ++k) value -= lower[i][k] * lower[j][k];
            if (i == j) {
                if (!isfinite(value) || value <= 1.0e-10f) return false;
                lower[i][j] = sqrt(value);
            } else lower[i][j] = value / lower[j][j];
        }
    float intermediate[3] = {0, 0, 0}, result[3] = {0, 0, 0};
    for (uint i = 0; i < dimension; ++i) {
        float value = g[i];
        for (uint j = 0; j < i; ++j) value -= lower[i][j] * intermediate[j];
        intermediate[i] = value / lower[i][i];
    }
    for (int i = int(dimension) - 1; i >= 0; --i) {
        float value = intermediate[i];
        for (uint j = uint(i) + 1; j < dimension; ++j) value -= lower[j][i] * result[j];
        result[i] = value / lower[i][i];
        if (!isfinite(result[i]) || fabs(result[i]) > 1.0f) return false;
    }
    offset = float3(result[0], result[1], result[2]);
    return true;
}

inline void fg_fine_output(device FGCandidate& candidate, float2 point,
    float angle, float score, constant FGFineConfig& config)
{
    const float c = cos(angle * FG_FINE_D2R), s = sin(angle * FG_FINE_D2R);
    const float w = float(config.templateWidth), h = float(config.templateHeight);
    candidate.x = point.x + 0.5f * (w * c - h * s);
    candidate.y = point.y + 0.5f * (w * s + h * c);
    candidate.angle = fg_angle(-angle);
    candidate.score = score;
    candidate.scale = config.scale;
    candidate.model = config.model;
    candidate.valid = 1;
}

kernel void fg_fine_search(device const uchar* source [[buffer(0)]],
    device const uchar* templ [[buffer(1)]], device const FGLevel* levels [[buffer(2)]],
    device const FGStats* statistics [[buffer(3)]], device FGCandidate* candidates [[buffer(4)]],
    constant FGFineConfig& config [[buffer(5)]], device const FGRange* ranges [[buffer(6)]],
    uint lane [[thread_index_in_threadgroup]], uint group [[threadgroup_position_in_grid]])
{
    if (group >= config.count) return;
    const uint index = config.first + group;
    const FGCandidate initial = candidates[index];
    if (!initial.valid) return;
    // Default: 16,384 + 4,704 + 6,860 + sizeof(FGFineState) = 28,560 B.
    // Validation cache4096: 16,272 B before instrumentation (32,540 B after).
    threadgroup uchar roi[FG_FINE_ROI_CAPACITY];
    threadgroup ulong partial[196 * 3];
    threadgroup float maps[35 * 49];
    threadgroup FGFineState state;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (lane == 0) {
        state.point = float2(initial.x, initial.y);
        state.angle = initial.angle;
        state.maps = 0;
        state.active = 1;
        candidates[index].valid = 0;
        candidates[index].reserved0 = 0;
        candidates[index].reserved1 = 0;
        candidates[index].reserved2 = 0;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (config.stop > 0 && config.top == config.stop) {
        if (lane == 0 && initial.score >= config.minScore)
            fg_fine_output(candidates[index], state.point * 2.0f, state.angle, initial.score, config);
        return;
    }
    for (int layer = max(0, int(config.top) - 1); layer >= int(config.stop); --layer) {
        const FGLevel level = levels[config.levelBase + uint(layer)];
        const FGStats stats = statistics[level.statisticsIndex];
        const uint passes = config.subpixel && layer == 0 ? 3 : 1;
        float threshold = config.minScore;
        for (int i = 0; i < layer; ++i) threshold *= 0.9f;
        if (lane == 0) ++candidates[index].reserved1;
        for (uint pass = 0; pass < passes; ++pass) {
            if (lane == 0) {
                ++candidates[index].reserved2;
                const float scale = config.top == 0 || pass > 0 ? 1.0f : 2.0f;
                state.anchor = state.point * scale;
                state.step = atan(2.0f / float(max(level.tw, level.th))) / FG_FINE_D2R;
                state.angleCount = fg_fine_angles(state.angle, state.step, ranges, config.rangeCount, state.angles);
            }
            threadgroup_barrier(mem_flags::mem_threadgroup);
            fg_fine_evaluate(source, templ, level, stats, state, roi, partial, maps, lane);
            if (config.subpixel && layer == 0) {
                for (uint resolution = 0; resolution < 3; ++resolution) {
                    for (uint attempt = 0; attempt < 3; ++attempt) {
                        if (lane == 0) {
                            state.changed = 0;
                            if (state.best != 0xffffffffu && state.angleCount > 1 &&
                                !(state.best > 0 && state.best + 1 < state.angleCount)) {
                                state.nextCount = fg_fine_angles(state.angles[state.best], state.step, ranges,
                                    config.rangeCount, state.nextAngles);
                                state.changed = state.nextCount != state.angleCount;
                                for (uint i = 0; i < min(state.nextCount, state.angleCount); ++i)
                                    if (state.nextAngles[i] != state.angles[i]) state.changed = 1;
                                if (state.changed) fg_fine_replace_angles(state);
                            }
                        }
                        threadgroup_barrier(mem_flags::mem_threadgroup);
                        if (!state.changed) break;
                        fg_fine_evaluate(source, templ, level, stats, state, roi, partial, maps, lane);
                    }
                    // Latch the shared decision before lane zero replaces the
                    // angle list. A narrower resolution may reduce its count
                    // to one; no late SIMD group may see that new count here.
                    const bool endResolution = resolution == 2 || state.best == 0xffffffffu || state.angleCount < 2;
                    threadgroup_barrier(mem_flags::mem_threadgroup);
                    if (endResolution) break;
                    if (lane == 0) {
                        state.step *= 0.5f;
                        state.nextCount = fg_fine_angles(state.angles[state.best], state.step,
                            ranges, config.rangeCount, state.nextAngles);
                        fg_fine_replace_angles(state);
                    }
                    threadgroup_barrier(mem_flags::mem_threadgroup);
                    fg_fine_evaluate(source, templ, level, stats, state, roi, partial, maps, lane);
                }
            }
            if (lane == 0) {
                if (state.best == 0xffffffffu || state.peakScore[state.best] < threshold) state.active = 0;
                else {
                    const uint best = state.best, peak = state.peakIndex[best];
                    const float score = state.peakScore[best];
                    float2 location = float2(peak % 7, peak / 7);
                    state.angle = state.angles[best];
                    if (config.subpixel && layer == 0 && location.x > 0 && location.y > 0 &&
                        location.x < 6 && location.y < 6) {
                        bool fitted = false;
                        float3 offset;
                        if (best > 0 && best + 1 < state.angleCount &&
                            fabs(fg_angle(state.angle - state.angles[best - 1]) - state.step) <= FG_FINE_ANGLE_EPS &&
                            fabs(fg_angle(state.angles[best + 1] - state.angle) - state.step) <= FG_FINE_ANGLE_EPS &&
                            fg_fine_fit(maps, best, peak, 3, offset) &&
                            fg_allowed(fg_angle(-(state.angle + offset.z * state.step)), ranges, config.rangeCount)) {
                            location += offset.xy;
                            state.angle += offset.z * state.step;
                            fitted = true;
                        }
                        if (!fitted && fg_fine_fit(maps, best, peak, 2, offset)) location += offset.xy;
                    }
                    const float c = cos(state.angle * FG_FINE_D2R), s = sin(state.angle * FG_FINE_D2R);
                    const float2 delta = location - 3.0f;
                    state.point = state.anchor + float2(c * delta.x - s * delta.y, s * delta.x + c * delta.y);
                    if (pass + 1 == passes && layer == int(config.stop) && score >= config.minScore &&
                        fg_allowed(fg_angle(-state.angle), ranges, config.rangeCount))
                        fg_fine_output(candidates[index], state.point * (config.stop == 0 ? 1.0f : 2.0f),
                            state.angle, score, config);
                }
            }
            threadgroup_barrier(mem_flags::mem_threadgroup);
            if (!state.active) break;
        }
        if (!state.active) break;
    }
    if (lane == 0) candidates[index].reserved0 = state.maps;
}

// SPDX-License-Identifier: BSD-2-Clause
// Appended after pose_fused.metal and full_gpu_types.h. Every data-dependent
// decision below stays on the GPU. Static dispatch capacities are upper bounds;
// GPU-written Config.count and FGStatus counters determine the work performed.
// This experiment has an FP32 geometry/score contract, not CPU-double parity.
static_assert(sizeof(FGCandidate)==48,"full GPU candidate ABI mismatch");
static_assert(sizeof(FGNmsConfig)==48,"full GPU NMS config ABI mismatch");
static_assert(sizeof(FGFinishConfig)==48,"full GPU finish config ABI mismatch");
static_assert(sizeof(FGStatus)==32,"full GPU status ABI mismatch");
static_assert(sizeof(FGResult)==64,"full GPU result ABI mismatch");

inline bool fg_finish_better(FGCandidate a, FGCandidate b)
{
    if (!a.valid) return false;
    if (!b.valid) return true;
    if (a.score != b.score) return a.score > b.score;
    if (a.y != b.y) return a.y < b.y;
    if (a.x != b.x) return a.x < b.x;
    if (a.angle != b.angle) return a.angle < b.angle;
    return a.order < b.order;
}

inline bool fg_finish_allowed(float angle, device const FGRange* ranges, uint count)
{
    if (!count) return true;
    for (uint i = 0; i < count; ++i) for (int shift = -1; shift <= 1; ++shift) {
        const float a = angle+360.f*float(shift);
        if (a >= ranges[i].minimum-1e-5f && a <= ranges[i].maximum+1e-5f) return true;
    }
    return false;
}

inline float fg_finish_cross(float2 a, float2 b, float2 p)
{
    const float2 u = b-a, v = p-a;
    return u.x*v.y-u.y*v.x;
}

inline float fg_finish_area(thread const float2* p, uint count)
{
    float sum = 0;
    for (uint i = 1; i+1 < count; ++i) sum += fg_finish_cross(p[0],p[i],p[i+1]);
    return abs(sum)*.5f;
}

inline void fg_finish_corners(FGCandidate a, float width, float height,
    thread float2* corners)
{
    const float radians = fmod(a.angle,360.f)*0.01745329251994329577f;
    const float c = cos(radians), s = sin(radians);
    const float2 horizontal = float2(c,-s)*(width*.5f);
    const float2 vertical = float2(s,c)*(height*.5f);
    const float2 center = float2(a.x,a.y);
    corners[0] = center-horizontal-vertical;
    corners[1] = center+horizontal-vertical;
    corners[2] = center+horizontal+vertical;
    corners[3] = center-horizontal+vertical;
}

// Convex rectangle intersection has at most eight distinct vertices. Twelve
// slots additionally tolerate duplicate boundary vertices; every append still
// checks its bound and marks an error rather than silently truncating geometry.
inline float fg_finish_overlap(FGCandidate a, FGCandidate b,
    constant FGNmsConfig& k, thread bool& overflow)
{
    float2 polygon[12], clip[4], next[12];
    const float sa = k.globalStage ? a.scale : 1.f;
    const float sb = k.globalStage ? b.scale : 1.f;
    fg_finish_corners(a,float(k.templateWidth)*sa,float(k.templateHeight)*sa,polygon);
    fg_finish_corners(b,float(k.templateWidth)*sb,float(k.templateHeight)*sb,clip);
    float2 amin=polygon[0],amax=polygon[0],bmin=clip[0],bmax=clip[0];
    for (uint i=1;i<4;++i) {
        amin=min(amin,polygon[i]);amax=max(amax,polygon[i]);
        bmin=min(bmin,clip[i]);bmax=max(bmax,clip[i]);
    }
    if (amax.x<=bmin.x || bmax.x<=amin.x || amax.y<=bmin.y || bmax.y<=amin.y) return 0;
    const float aa=fg_finish_area(polygon,4),ba=fg_finish_area(clip,4);
    const float denominator=k.globalStage?min(aa,ba):aa;
    if (!(denominator>0) || !isfinite(denominator)) return 0;
    uint count=4;
    for (uint edge=0;edge<4 && count;++edge) {
        uint n=0;
        const float2 v=clip[edge],w=clip[(edge+1)%4];
        float2 previous=polygon[count-1];
        float previousSide=fg_finish_cross(v,w,previous);
        for (uint i=0;i<count;++i) {
            const float2 current=polygon[i];
            const float side=fg_finish_cross(v,w,current);
            if ((side>=0)!=(previousSide>=0)) {
                if (n>=12) {overflow=true;return 0;}
                const float t=previousSide/(previousSide-side);
                next[n++]=previous+t*(current-previous);
            }
            if (side>=0) {
                if (n>=12) {overflow=true;return 0;}
                next[n++]=current;
            }
            previous=current;previousSide=side;
        }
        count=n;
        for (uint i=0;i<count;++i) polygon[i]=next[i];
    }
    return clamp(fg_finish_area(polygon,count)/denominator,0.f,1.f);
}

// Exactly one 256-thread group per dispatch. Input and output must not alias.
// Repeated reduction produces the same stable score/y/x/angle/original-order
// order as sorting all candidates, without an intermediate host sort. Each
// accepted candidate suppresses remaining inputs in parallel. Per-model NMS
// removes complete duplicates even at overlap=1; global NMS follows research
// pipeline semantics and does not add that duplicate rule.
inline void fg_finish_nms(device FGCandidate* input,device FGCandidate* output,
    device uint* modelCounts,device FGStatus& status,constant FGNmsConfig& k,
    device const FGRange* ranges,uint lane,threadgroup FGCandidate* winners,
    threadgroup uint* indices,threadgroup uint& accepted)
{
    const uint count=k.globalStage?min(k.count,status.proposals):k.count;
    if (lane==0) accepted=0;
    for (uint i=lane;i<count;i+=256) {
        device FGCandidate& a=input[k.first+i];
        if (!isfinite(a.score) || a.score<k.minScore || !isfinite(a.x) || !isfinite(a.y)
            || !isfinite(a.angle) || !isfinite(a.scale) || a.scale<=0
            || (k.globalStage && !fg_finish_allowed(a.angle,ranges,k.rangeCount))) a.valid=0;
    }
    threadgroup_barrier(mem_flags::mem_device|mem_flags::mem_threadgroup);
    for (uint selection=0;selection<k.limit;++selection) {
        FGCandidate best={};uint index=0;
        for (uint i=lane;i<count;i+=256) {
            const FGCandidate a=input[k.first+i];
            if (fg_finish_better(a,best)) {best=a;index=i;}
        }
        winners[lane]=best;indices[lane]=index;
        threadgroup_barrier(mem_flags::mem_threadgroup);
        for (uint step=128;step;step>>=1) {
            if (lane<step && fg_finish_better(winners[lane+step],winners[lane])) {
                winners[lane]=winners[lane+step];indices[lane]=indices[lane+step];
            }
            threadgroup_barrier(mem_flags::mem_threadgroup);
        }
        const FGCandidate selected=winners[0];
        const uint selectedIndex=indices[0];
        if (!selected.valid) break;
        if (lane==0) {output[k.outputFirst+accepted]=selected;++accepted;}
        for (uint i=lane;i<count;i+=256) {
            device FGCandidate& a=input[k.first+i];
            if (!a.valid) continue;
            if (i==selectedIndex) {a.valid=0;continue;}
            bool invalidGeometry=false;
            const float ratio=fg_finish_overlap(selected,a,k,invalidGeometry);
            if (invalidGeometry)
                atomic_fetch_or_explicit(reinterpret_cast<device atomic_uint*>(&status.overflow),1u,memory_order_relaxed);
            if (ratio>k.maxOverlap+1e-10f || (!k.globalStage && ratio>=1.f-1e-10f)) a.valid=0;
        }
        threadgroup_barrier(mem_flags::mem_device|mem_flags::mem_threadgroup);
    }
    if (lane==0) {
        if (k.globalStage) status.matches=accepted;
        else modelCounts[k.reserved0]=accepted;
    }
}

#define FG_NMS_KERNEL(NAME) \
kernel void NAME(device FGCandidate* input [[buffer(0)]], \
    device FGCandidate* output [[buffer(1)]],device uint* counts [[buffer(2)]], \
    device FGStatus& status [[buffer(3)]],constant FGNmsConfig& k [[buffer(4)]], \
    device const FGRange* ranges [[buffer(5)]],uint lane [[thread_index_in_threadgroup]]) \
{ \
    threadgroup FGCandidate winners[256];threadgroup uint indices[256],accepted; \
    fg_finish_nms(input,output,counts,status,k,ranges,lane,winners,indices,accepted); \
}
FG_NMS_KERNEL(fg_model_nms)
FG_NMS_KERNEL(fg_global_nms)
#undef FG_NMS_KERNEL

inline ResidentState fg_finish_seed(FGCandidate p,constant FGFinishConfig& k)
{
    ResidentState s={};
    s.pose=float4(p.x-float(k.sw)*.5f,float(k.sh)*.5f-p.y,p.angle,log(p.scale));
    // A deliberately inward FP32 bound keeps retries within the original seed
    // interval. log(1.3) is rounded down here, not enlarged by FP32 conversion.
    const float4 radius=float4((k.optimizeMask&1u)?12.f:0.f,(k.optimizeMask&1u)?12.f:0.f,
        (k.optimizeMask&2u)?15.f:0.f,(k.optimizeMask&4u)?0.26236424f:0.f);
    const float4 limit=float4(1e6f,1e6f,36000.f,3.f);
    for (uint i=0;i<4;++i) {
        s.lower[i]=radius[i]>0?max(-limit[i],nextafter(s.pose[i]-radius[i],INFINITY)):s.pose[i];
        s.upper[i]=radius[i]>0?min(limit[i],nextafter(s.pose[i]+radius[i],-INFINITY)):s.pose[i];
    }
    s.packed=resident_pack(s.pose);s.score=p.score;
    return s;
}

// One thread. Per-model outputs occupy model*proposalStride slots. The compact
// order is model order then per-model NMS order, matching research_pipeline.
// Preserve a separate compact proposal snapshot before fg_publish_states.
kernel void fg_compact_prepare(device const FGCandidate* perModel [[buffer(0)]],
    device const uint* counts [[buffer(1)]],device FGCandidate* compact [[buffer(2)]],
    device ResidentState* seeds [[buffer(3)]],device ResidentState* states [[buffer(4)]],
    device Config& poseConfig [[buffer(5)]],device FGStatus& status [[buffer(6)]],
    constant FGFinishConfig& k [[buffer(7)]],uint id [[thread_position_in_grid]])
{
    if (id) return;
    status.proposals=status.matches=status.rescueParents=status.rescueStarts=status.rescueContinuations=0;
    for (uint model=0;model<k.modelCount;++model) {
        if (counts[model]>k.proposalStride) {status.overflow|=2u;continue;}
        for (uint j=0;j<counts[model];++j) {
            if (status.proposals>=k.capacity) {status.overflow|=2u;continue;}
            FGCandidate p=perModel[model*k.proposalStride+j];
            p.order=status.proposals;p.valid=1;
            compact[status.proposals]=p;
            const ResidentState seed=fg_finish_seed(p,k);
            if (k.refine && (!all(isfinite(seed.pose)) || any(abs(seed.pose)>float4(1e6f,1e6f,36000.f,3.f))
                || !all(seed.lower<=seed.pose) || !all(seed.pose<=seed.upper))) {
                status.overflow|=8u;continue;
            }
            seeds[status.proposals]=seed;states[status.proposals]=seed;
            ++status.proposals;
        }
    }
    poseConfig.count=status.proposals;poseConfig.unused=k.optimizeMask;
}

inline float fg_finish_halton(uint index,uint base)
{
    float value=0,factor=1;
    while (index) {factor/=float(base);value+=factor*float(index%base);index/=base;}
    return value;
}

// One thread; output capacities are 64 trials, 64 owners, four parents and four
// base scores. Ranking, budget, duplicate checks and Config.count stay on GPU.
kernel void fg_prepare_rescue(device const ResidentState* seeds [[buffer(0)]],
    device const ResidentState* baseline [[buffer(1)]],device ResidentState* retries [[buffer(2)]],
    device uint* owners [[buffer(3)]],device uint* parents [[buffer(4)]],
    device float* baseScores [[buffer(5)]],device Config& retryConfig [[buffer(6)]],
    device FGStatus& status [[buffer(7)]],constant FGFinishConfig& k [[buffer(8)]],
    device const Config& baselineConfig [[buffer(9)]],uint id [[thread_position_in_grid]])
{
    if (id) return;
    retryConfig=baselineConfig;retryConfig.count=0;
    status.rescueParents=status.rescueStarts=status.rescueContinuations=0;
    if (!k.refine) return;
    uint ranked[4],ranks=0;
    const float upper=min(.8f,k.minScore),lower=min(.1f,upper);
    for (uint rank=0;rank<4;++rank) {
        uint best=0;float bestScore=-INFINITY;bool found=false;
        for (uint i=0;i<status.proposals;++i) {
            const float score=baseline[i].score;
            if (!isfinite(score) || score<lower || score>=upper) continue;
            bool used=false;for (uint j=0;j<ranks;++j) used|=ranked[j]==i;
            if (!used && (!found || score>bestScore)) {best=i;bestScore=score;found=true;}
        }
        if (!found) break;
        ranked[ranks++]=best;
    }
    const ulong perParent=ulong(k.tw)*ulong(k.th)*ulong(16u*8u+30u);
    ulong remaining=ulong(512u)*1024u*1024u;
    const uint bases[4]={2,3,5,7};
    const float4 radii=float4((k.optimizeMask&1u)?3.f:0.f,(k.optimizeMask&1u)?3.f:0.f,
        (k.optimizeMask&2u)?6.f:0.f,(k.optimizeMask&4u)?.06f:0.f);
    for (uint rank=0;rank<ranks;++rank) {
        if (perParent>remaining) continue;
        const uint parent=ranked[rank],first=status.rescueStarts;
        const ResidentState original=seeds[parent];
        for (uint index=1;index<=16;++index) {
            ResidentState trial=original;
            for (uint d=0;d<4;++d)
                trial.pose[d]=clamp(original.pose[d]+(2.f*fg_finish_halton(index,bases[d])-1.f)*radii[d],
                    original.lower[d],original.upper[d]);
            if (all(trial.pose==original.pose)) continue;
            bool duplicate=false;
            for (uint previous=first;previous<status.rescueStarts;++previous)
                duplicate|=all(trial.pose==retries[previous].pose);
            if (duplicate) continue;
            trial.packed=resident_pack(trial.pose);
            if (status.rescueStarts>=64) {status.overflow|=4u;break;}
            retries[status.rescueStarts]=trial;owners[status.rescueStarts]=parent;++status.rescueStarts;
        }
        if (status.rescueStarts==first) continue;
        parents[status.rescueParents]=parent;baseScores[status.rescueParents]=baseline[parent].score;
        ++status.rescueParents;remaining-=perParent;
    }
    retryConfig.count=status.rescueStarts;
}

kernel void fg_select_continuations(device ResidentState* baseline [[buffer(0)]],
    device const ResidentState* retries [[buffer(1)]],device const uint* owners [[buffer(2)]],
    device const uint* parents [[buffer(3)]],device const float* baseScores [[buffer(4)]],
    device ResidentState* continuations [[buffer(5)]],device uint* continuationOwners [[buffer(6)]],
    device Config& continuationConfig [[buffer(7)]],device FGStatus& status [[buffer(8)]],
    device const Config& retryConfig [[buffer(9)]],uint id [[thread_position_in_grid]])
{
    if (id) return;
    for (uint i=0;i<status.rescueStarts;++i) {
        const uint owner=owners[i];
        if (isfinite(retries[i].score) && retries[i].score>baseline[owner].score) baseline[owner]=retries[i];
    }
    status.rescueContinuations=0;
    for (uint i=0;i<status.rescueParents;++i) {
        const uint parent=parents[i];
        if (!(baseline[parent].score>baseScores[i])) continue;
        continuations[status.rescueContinuations]=baseline[parent];
        continuationOwners[status.rescueContinuations]=parent;++status.rescueContinuations;
    }
    continuationConfig=retryConfig;continuationConfig.count=status.rescueContinuations;
}

kernel void fg_accept_continuations(device ResidentState* baseline [[buffer(0)]],
    device const ResidentState* continuations [[buffer(1)]],device const uint* owners [[buffer(2)]],
    device const FGStatus& status [[buffer(3)]],uint id [[thread_position_in_grid]])
{
    if (id) return;
    for (uint i=0;i<status.rescueContinuations;++i) {
        const uint owner=owners[i];
        if (isfinite(continuations[i].score) && continuations[i].score>baseline[owner].score)
            baseline[owner]=continuations[i];
    }
}

// Optional common score pass before comparisons/final publication. Uses exactly
// the fused solver's FP32 score arithmetic; no CPU score verifier participates.
kernel void fg_score_states(device const float* source [[buffer(0)]],
    device const float* templ [[buffer(1)]],device ResidentState* states [[buffer(2)]],
    constant Config& k [[buffer(3)]],uint lane [[thread_index_in_threadgroup]],
    uint group [[threadgroup_position_in_grid]])
{
    if (group>=k.count) return;
    threadgroup DerivativePartial scratch[64];threadgroup float score;
    fused_score(source,templ,states[group].packed,k,lane,scratch,score);
    if (lane==0) states[group].score=score;
}

kernel void fg_publish_states(device FGCandidate* candidates [[buffer(0)]],
    device const ResidentState* states [[buffer(1)]],device const FGStatus& status [[buffer(2)]],
    constant FGFinishConfig& k [[buffer(3)]],uint id [[thread_position_in_grid]])
{
    if (id>=status.proposals) return;
    const ResidentState s=states[id];
    device FGCandidate& p=candidates[id];
    p.x=s.pose.x+float(k.sw)*.5f;p.y=float(k.sh)*.5f-s.pose.y;
    float angle=fmod(s.pose.z+180.f,360.f);if (angle<0) angle+=360.f;
    p.angle=angle-180.f;p.scale=exp(s.pose.w);p.score=s.score;
    p.valid=all(isfinite(s.pose)) && isfinite(s.score) && s.score>=-1.f;
}

// Format only the declared GPU output count. kind=0 reads an immutable snapshot
// made after compaction and before refinement; kind=1 reads global NMS output.
// The CPU receives these records after the sole final wait and only serializes.
kernel void fg_write_results(device const FGCandidate* candidates [[buffer(0)]],
    device FGResult* output [[buffer(1)]],device const FGStatus& status [[buffer(2)]],
    constant FGFinishConfig& k [[buffer(3)]],constant uint& kind [[buffer(4)]],
    uint id [[thread_position_in_grid]])
{
    const uint count=kind?status.matches:status.proposals;
    if (id>=count) return;
    const FGCandidate p=candidates[id];FGResult r={};
    r.x=p.x;r.y=p.y;r.angle=p.angle;r.score=p.score;r.scale=p.scale;
    float2 corners[4];
    fg_finish_corners(p,float(k.tw)*p.scale,float(k.th)*p.scale,corners);
    for (uint i=0;i<4;++i) {r.corners[2*i]=corners[i].x;r.corners[2*i+1]=corners[i].y;}
    output[id]=r;
}
)FPMFULLGPU";
