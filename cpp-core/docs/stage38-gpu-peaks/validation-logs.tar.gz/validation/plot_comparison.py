import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
root=Path.cwd();data=root/'cpp-core/docs/stage38-gpu-peaks'
s=json.loads((data/'formal-summary.json').read_text())
methods=['hybrid_best','full_gpu','full_gpu_tiled']
labels=['Hybrid','Original full GPU','Tiled full GPU']
colors=['#65758b','#ba6c42','#157e83']
fig,axes=plt.subplots(1,2,figsize=(12,5),layout='constrained')
x=np.arange(len(s['cases']));width=.24
for i,(method,label,color) in enumerate(zip(methods,labels,colors)):
 rows=[c['methods'][method] for c in s['cases']];med=np.array([r['total_ms']['median'] for r in rows]);lo=np.array([r['total_ms']['min'] for r in rows]);hi=np.array([r['total_ms']['max'] for r in rows]);at=x+(i-1)*width
 axes[0].bar(at,med,width,label=label,color=color,yerr=[med-lo,hi-med],capsize=3,error_kw={'lw':1})
 axes[1].bar(at,[r['peak_rss_bytes']/2**20 for r in rows],width,label=label,color=color)
for ax in axes:
 ax.set_xticks(x,['128 objects','512 objects','6 objects','8K / 6 objects']);ax.tick_params(axis='x',labelsize=9)
 ax.spines[['right','top']].set_visible(False);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
axes[0].set_yscale('log');axes[0].set_ylabel('Algorithm time (ms, log scale)');axes[0].set_title('Median with measured min–max')
axes[1].set_ylabel('Process peak RSS (MiB)');axes[1].set_title('Maximum across 3 fresh processes')
fig.legend(handles=axes[0].get_legend_handles_labels()[0],labels=labels,loc='outside lower center',ncol=3,frameon=False)
fig.suptitle('Stage 38 · M4 Pro · profiling disabled\n3 alternating blocks × 2 measured calls; separate first calls and warmups',fontsize=12)
fig.savefig(data/'comparison.png',dpi=170)
