from pathlib import Path
import json,subprocess,hashlib
root=Path.cwd();formal=root/'build/stage38-gpu-peaks/formal'
out=root/'build/stage38-gpu-peaks/validation/rebuilt';out.mkdir(exist_ok=True)
source=root/'build/stage38-review/source'
binary=root/'build/stage38-review/release/experiments/fpm_native_pipeline_runner'
m=json.loads((formal/'manifest.json').read_text());checks={}
for method in ['hybrid_best','full_gpu','full_gpu_tiled']:
 e=next(e for e in m['executions'] if e['case']=='controlled6' and e['method']==method)
 job=json.loads((formal/e['job']).read_text())
 for key in ['source','template']:job[key]=str(source/Path(job[key]).relative_to(root))
 job.update(repeats=1,warmup_seconds=0)
 jp=out/(method+'-job.json');jp.write_text(json.dumps(job,indent=2)+'\n')
 try:r=subprocess.run([str(binary),str(jp)],text=True,capture_output=True,timeout=180)
 except subprocess.TimeoutExpired as exc:
  (out/(method+'-timeout.log')).write_text(str(exc)+'\n');raise
 (out/(method+'-stdout.json')).write_text(r.stdout);(out/(method+'-stderr.log')).write_text(r.stderr)
 assert r.returncode==0,r.stderr
 result=json.loads(r.stdout);ref=json.loads((formal/e['result']).read_text())
 checks[method]={'calls':len(result['runs'])+1,'ordered_matches_and_proposals_exact':all(call[key]==ref['first'][key] for call in [result['first'],*result['runs']] for key in ['matches','proposals'])}
 assert checks[method]['ordered_matches_and_proposals_exact'],method
 (out/'parity.json').write_text(json.dumps({'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'checks':checks},indent=2)+'\n')
 print(method,checks[method],flush=True)
