#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <cstdio>
int main(){@autoreleasepool {
 id<MTLDevice> d=MTLCreateSystemDefaultDevice();
 printf("device=%s stage_boundary=%d dispatch_boundary=%d blit_boundary=%d\n",d.name.UTF8String,[d supportsCounterSampling:MTLCounterSamplingPointAtStageBoundary],[d supportsCounterSampling:MTLCounterSamplingPointAtDispatchBoundary],[d supportsCounterSampling:MTLCounterSamplingPointAtBlitBoundary]);
 for(id<MTLCounterSet> s in d.counterSets){ printf("set=%s",s.name.UTF8String); for(id<MTLCounter> c in s.counters)printf(" counter=%s",c.name.UTF8String);puts(""); }
 MTLTimestamp c,g;[d sampleTimestamps:&c gpuTimestamp:&g];printf("cpu=%llu gpu=%llu\n",(unsigned long long)c,(unsigned long long)g);
}}
