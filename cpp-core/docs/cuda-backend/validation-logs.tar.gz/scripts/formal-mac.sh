#!/bin/bash
# Formal CUDA-round gate, Mac side (protocol 078a109): the core refactor and the
# experiment changes must leave arm64 outputs and tests unchanged.
# Usage: formal-mac.sh BASE_TAR AFTER_TAR   (run from the repo root)
set -u
R=build/cuda-formal-mac2
mkdir -p $R/out $R/logs
tar -xf "$1" -C $R && tar -xf "$2" -C $R || exit 2
log() { echo "$*" >> $R/logs/formal.log; }
lock() { ls "$HOME/Library/Application Support/Claude/side-session-notes/"*/timing-lock-*.txt 2>/dev/null && { log "timing lock present, refusing"; exit 3; }; return 0; }
log "start $(date -u +%FT%TZ) $(uptime)"
python3 build/x86simd-formal-kit/check_pgm.py build/x86simd-formal-kit/pgm-manifest.json build/x86simd-transfer/fixtures-pgm > $R/logs/pgm-check.log 2>&1; log "pgm $?"
for n in base after; do
  lock
  cmake -S $R/src-$n/cpp-core -B $R/build-core-$n -DCMAKE_BUILD_TYPE=Release > $R/logs/core-$n-configure.log 2>&1 && \
  cmake --build $R/build-core-$n -j 8 > $R/logs/core-$n-build.log 2>&1 || { log "$n build failed"; exit 4; }
  ctest --test-dir $R/build-core-$n --output-on-failure > $R/logs/core-$n-ctest.log 2>&1; log "core-$n ctest $?"
done
lock
python3 $R/src-after/cpp-core/tools/check_backend_identity.py --lib base=$R/build-core-base/libfpm_c.dylib \
  --lib after=$R/build-core-after/libfpm_c.dylib --pgm-dir build/x86simd-transfer/fixtures-pgm \
  --output $R/out/core-identity-mac.json > $R/logs/core-identity.log 2>&1; log "core-identity $?"
lock
cmake -S $R/src-after/cpp-core -B $R/build-research-after -DCMAKE_BUILD_TYPE=Release -DFPM_BUILD_GUI=ON \
  -DFPM_BUILD_EXPERIMENTS=ON -DFPM_WITH_OPENCV=ON > $R/logs/research-configure.log 2>&1 && \
  cmake --build $R/build-research-after -j 8 > $R/logs/research-build.log 2>&1 || { log "research build failed"; exit 5; }
ctest --test-dir $R/build-research-after --output-on-failure > $R/logs/research-ctest.log 2>&1; log "research ctest $?"
log "formal-finished $(date -u +%FT%TZ)"
