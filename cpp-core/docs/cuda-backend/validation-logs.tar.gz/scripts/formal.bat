@echo off
rem Formal CUDA backend gates and timing (protocol 078a109). Each step runs in its own cmd.
set F=C:\r-cuda\formal
set PY=C:\r50\venv\Scripts\python.exe
set VC="C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
set CUDA_ROOT=C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.2
set PGM=C:\r51\bundle\pgm
cd /d %F%
if not exist logs mkdir logs
if not exist results mkdir results
echo start attempt2 %date% %time% > logs\formal.log
rem 1. CUDA build of 9623880 and ctest
cmd /c %F%\build-cuda.bat
echo step1 %errorlevel% >> logs\formal.log
rem 2. pure core builds for the core identity gate
cmd /c "call %VC% >nul && cmake -S %F%\src-base\cpp-core -B %F%\build-core-base -G Ninja -DCMAKE_BUILD_TYPE=Release > logs\core-base-configure.log 2>&1 && cmake --build %F%\build-core-base > logs\core-base-build.log 2>&1 && ctest --test-dir %F%\build-core-base > logs\core-base-ctest.log 2>&1"
echo step2a %errorlevel% >> logs\formal.log
cmd /c "call %VC% >nul && cmake -S %F%\src-after\cpp-core -B %F%\build-core-after -G Ninja -DCMAKE_BUILD_TYPE=Release > logs\core-after-configure.log 2>&1 && cmake --build %F%\build-core-after > logs\core-after-build.log 2>&1 && ctest --test-dir %F%\build-core-after > logs\core-after-ctest.log 2>&1"
echo step2b %errorlevel% >> logs\formal.log
rem 3. inputs
%PY% %F%\check_pgm.py %F%\pgm-manifest.json %PGM% > logs\pgm-check.log 2>&1
echo step3 %errorlevel% >> logs\formal.log
rem 4. kernel test output (guard gate)
%F%\build-after-cuda\experiments\fpm_cuda_kernel_test.exe > logs\cuda-kernel-test.log 2>&1
echo step4 %errorlevel% >> logs\formal.log
rem 5. core identity base vs after
%PY% %F%\src-after\cpp-core\tools\check_backend_identity.py --pgm-dir %PGM% --lib base=%F%\build-core-base\fpm_c.dll --lib after=%F%\build-core-after\fpm_c.dll --output results\core-identity-pc.json > logs\core-identity.log 2>&1
echo step5 %errorlevel% >> logs\formal.log
rem 6. identity-only ablation arms
%PY% %F%\src-after\cpp-core\tools\benchmark_frame_backend.py --bench %F%\build-after-cuda\experiments\fpm_frame_bench.exe --pgm-dir %PGM% --arm cpu=0,0,0,0 --arm cuda_unfused=2,1,256,1 --arm cuda_batch8=2,1,8,0 --arm cuda_cpu_pyramid=2,0,256,0 --rounds 2 --repeat 1 --warmup-ms 0 --output results\identity-ablations.json > logs\identity-ablations.log 2>&1
echo step6 %errorlevel% >> logs\formal.log
rem 7. formal timing on P-cores
start /wait /b /affinity C03C02 %PY% %F%\src-after\cpp-core\tools\benchmark_frame_backend.py --bench %F%\build-after-cuda\experiments\fpm_frame_bench.exe --pgm-dir %PGM% --arm cpu=0,0,0,0 --arm cuda=2,1,256,0 --arm cuda_coarse=2,0,0,0 --rounds 8 --repeat 5 --warmup-ms 500 --output results\timing.json > logs\timing.log 2>&1
echo step7 %errorlevel% >> logs\formal.log
echo FORMALDONE %date% %time% >> logs\formal.log
