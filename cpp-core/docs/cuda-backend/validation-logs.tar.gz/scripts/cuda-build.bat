@echo off
rem usage: cuda-build.bat SOURCE_ROOT BUILD_DIR [extra cmake args]  (SOURCE_ROOT holds cpp-core)
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul
set "CUDA_ROOT=C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.2"
set "PATH=%CUDA_ROOT%\bin;%PATH%"
cmake -S %~1\cpp-core -B %~2 -G Ninja -DCMAKE_BUILD_TYPE=Release -DFPM_BUILD_EXPERIMENTS=ON -DFPM_WITH_CUDA=ON "-DCMAKE_CUDA_COMPILER=%CUDA_ROOT%\bin\nvcc.exe" "-DCUDAToolkit_ROOT=%CUDA_ROOT%" -DCMAKE_CUDA_ARCHITECTURES=120 %~3 %~4
if errorlevel 1 exit /b 1
cmake --build %~2
if errorlevel 1 exit /b 1
ctest --test-dir %~2 --output-on-failure
