@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul
set "CUDA_ROOT=C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.2"
set "PATH=%CUDA_ROOT%\bin;%PATH%"
C:\r50\venv\Scripts\python.exe C:\r-cuda\wt12\cpp-core\tools\cuda_mutants.py C:\r-cuda\build-wt12 C:\r-cuda\wt12 C:\r-cuda\out\red-check-n1.json N1 > C:\r-cuda\out\red-check-n1.log 2>&1
echo REDDONE >> C:\r-cuda\out\red-check-n1.log
