# sync.sh NAME : send the cpp-core working tree (no docs) to C:\r-cuda\NAME and build it in C:\r-cuda\build-NAME.
S=/private/tmp/claude-502/-Users-Ayueh-Fastest-Image-Pattern-Matching/83f4c8b6-9b21-4bb7-91d2-7ce4afc1001d/scratchpad
source $S/rps.sh
cd /Users/Ayueh/Fastest_Image_Pattern_Matching
rm -f $S/cuda/xfer/$1.tar
COPYFILE_DISABLE=1 tar --exclude='cpp-core/docs' -cf $S/cuda/xfer/$1.tar cpp-core
/Applications/Tailscale.app/Contents/MacOS/Tailscale file cp $S/cuda/xfer/$1.tar ptri-pro-4000: || exit 1
sleep 2
rps "
if (Test-Path C:\r-cuda\\$1) { Remove-Item -Recurse -Force C:\r-cuda\\$1 }
New-Item -ItemType Directory -Force C:\r-cuda\\$1 | Out-Null
tar -m -xf C:\Users\ptri\Downloads\\$1.tar -C C:\r-cuda\\$1; Remove-Item C:\Users\ptri\Downloads\\$1.tar
cmd /c \"C:\r-cuda\cuda-build.bat C:\r-cuda\\$1 C:\r-cuda\build-$1\" > C:\r-cuda\out\build-$1.log 2>&1
\"build exit=\$LASTEXITCODE\"
Select-String -Path C:\r-cuda\out\build-$1.log -Pattern 'tests passed|\*\*\*Failed|error C|error:|: error' | Select-Object -First 12 | ForEach-Object { \$_.Line }
"
