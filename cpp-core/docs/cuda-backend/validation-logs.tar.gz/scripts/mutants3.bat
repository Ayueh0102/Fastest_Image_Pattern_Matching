@echo off
rem Post-hoc mutant rerun on 7f5737b (strengthened tests); not part of the registered gate.
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul
set "CUDA_ROOT=C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.2"
set "PATH=%CUDA_ROOT%\bin;%PATH%"
cd /d C:\r-cuda\formal
if not exist mut3 mkdir mut3
tar -xf C:\r-cuda\formal\src-tests2.tar -C mut3
cmake -S C:\r-cuda\formal\mut3\src-tests2\cpp-core -B C:\r-cuda\formal\mut3-build -G Ninja -DCMAKE_BUILD_TYPE=Release -DFPM_BUILD_EXPERIMENTS=ON -DFPM_WITH_CUDA=ON "-DCMAKE_CUDA_COMPILER=%CUDA_ROOT%\bin\nvcc.exe" "-DCUDAToolkit_ROOT=%CUDA_ROOT%" -DCMAKE_CUDA_ARCHITECTURES=120 > logs\mut3-configure.log 2>&1
cmake --build C:\r-cuda\formal\mut3-build > logs\mut3-build.log 2>&1
ctest --test-dir C:\r-cuda\formal\mut3-build --output-on-failure > logs\mut3-ctest.log 2>&1
echo ctest %errorlevel% > logs\mutants3.log
C:\r50\venv\Scripts\python.exe C:\r-cuda\formal\mut3\src-tests2\cpp-core\tools\cuda_mutants.py C:\r-cuda\formal\mut3-build C:\r-cuda\formal\mut3\src-tests2 results\mutants-7f5737b.json >> logs\mutants3.log 2>&1
echo MUTDONE %errorlevel% >> logs\mutants3.log
