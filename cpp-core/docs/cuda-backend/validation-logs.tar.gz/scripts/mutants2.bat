@echo off
rem Post-hoc mutant rerun on 1714c97 (strengthened tests); not part of the registered gate.
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul
set "CUDA_ROOT=C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.2"
set "PATH=%CUDA_ROOT%\bin;%PATH%"
cd /d C:\r-cuda\formal
if not exist mut2 mkdir mut2
tar -xf C:\r-cuda\formal\src-tests.tar -C mut2
cmake -S C:\r-cuda\formal\mut2\src-tests\cpp-core -B C:\r-cuda\formal\mut2-build -G Ninja -DCMAKE_BUILD_TYPE=Release -DFPM_BUILD_EXPERIMENTS=ON -DFPM_WITH_CUDA=ON "-DCMAKE_CUDA_COMPILER=%CUDA_ROOT%\bin\nvcc.exe" "-DCUDAToolkit_ROOT=%CUDA_ROOT%" -DCMAKE_CUDA_ARCHITECTURES=120 > logs\mut2-configure.log 2>&1
cmake --build C:\r-cuda\formal\mut2-build > logs\mut2-build.log 2>&1
ctest --test-dir C:\r-cuda\formal\mut2-build --output-on-failure > logs\mut2-ctest.log 2>&1
echo ctest %errorlevel% > logs\mutants2.log
C:\r50\venv\Scripts\python.exe C:\r-cuda\formal\mut2\src-tests\cpp-core\tools\cuda_mutants.py C:\r-cuda\formal\mut2-build C:\r-cuda\formal\mut2\src-tests results\mutants-1714c97.json >> logs\mutants2.log 2>&1
echo MUTDONE %errorlevel% >> logs\mutants2.log
