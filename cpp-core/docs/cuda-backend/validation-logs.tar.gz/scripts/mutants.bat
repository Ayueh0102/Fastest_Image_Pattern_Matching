@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul
set "CUDA_ROOT=C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.2"
set "PATH=%CUDA_ROOT%\bin;%PATH%"
cd /d C:\r-cuda\formal
if not exist mut mkdir mut
tar -xf src-after.tar -C mut
cmake -S C:\r-cuda\formal\mut\src-after\cpp-core -B C:\r-cuda\formal\mut-build -G Ninja -DCMAKE_BUILD_TYPE=Release -DFPM_BUILD_EXPERIMENTS=ON -DFPM_WITH_CUDA=ON "-DCMAKE_CUDA_COMPILER=%CUDA_ROOT%\bin\nvcc.exe" "-DCUDAToolkit_ROOT=%CUDA_ROOT%" -DCMAKE_CUDA_ARCHITECTURES=120 > logs\mut-configure.log 2>&1
C:\r50\venv\Scripts\python.exe C:\r-cuda\formal\cuda_mutants.py C:\r-cuda\formal\mut-build C:\r-cuda\formal\mut\src-after results\mutants.json > logs\mutants.log 2>&1
echo MUTDONE %errorlevel% >> logs\mutants.log
