@echo off
rem usage: pilot-build.bat CUDA_VERSION BUILD_DIR
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul
set "CUDA_ROOT=C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v%~1"
set "PATH=%CUDA_ROOT%\bin;%PATH%"
cmake -S C:\r-cuda\src\pilot -B %~2 -G Ninja -DCMAKE_BUILD_TYPE=Release "-DCMAKE_CUDA_COMPILER=%CUDA_ROOT%\bin\nvcc.exe" "-DCUDAToolkit_ROOT=%CUDA_ROOT%" -DFPM_SOURCE=C:/r-cuda/src/fpm/cpp-core
if errorlevel 1 exit /b 1
cmake --build %~2
