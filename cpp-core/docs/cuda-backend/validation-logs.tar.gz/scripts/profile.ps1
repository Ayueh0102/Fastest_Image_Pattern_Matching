# Nsight profiles of the formal build (9623880); not formal timings.
$ErrorActionPreference = "Continue"
$nsys = "C:\Program Files\NVIDIA Corporation\Nsight Systems 2025.6.3\target-windows-x64\nsys.exe"
$ncu = "C:\Program Files\NVIDIA Corporation\Nsight Compute 2026.1.1\ncu.bat"
$b = "C:\r-cuda\formal\build-after-cuda\experiments\fpm_frame_bench.exe"; $p = "C:\r51\bundle\pgm"
$o = "C:\r-cuda\formal\profile"; New-Item -ItemType Directory -Force $o | Out-Null
$cases = @(@("Src7","Dst7","5","0.8","180","0","256","exhaustive"), @("Src6","Dst6","15","0.8","180","0","256","exhaustive"),
           @("Src9","Dst9","100","0.5","0","0.5","1024","exhaustive"), @("Src6","Dst6","15","0.8","180","0","256","subpixel"))
foreach ($c in $cases) {
  $n = "$($c[0])-$($c[7])"
  cmd /c "`"$nsys`" profile --trace=cuda,nvtx,wddm --force-overwrite=true -o $o\$n $b 2 1 256 0 $($c[7]) 20 1000 $p\$($c[0]).pgm $p\$($c[1]).pgm $($c[2]) $($c[3]) $($c[4]) $($c[5]) $($c[6]) > $o\$n.stdout.txt 2>&1"
  foreach ($rep in "cuda_gpu_kern_sum","nvtx_sum","cuda_api_sum","cuda_gpu_mem_time_sum") {
    cmd /c "`"$nsys`" stats --report $rep --format csv --force-export=true $o\$n.nsys-rep > $o\$n.$rep.csv 2>nul"
  }
}
foreach ($k in "coarseFused","fineStripes") {
  cmd /c "`"$ncu`" --kernel-name regex:$k --launch-skip 6 --launch-count 1 --set full -f -o $o\ncu-$k-Src7 $b 2 1 256 0 exhaustive 3 0 $p\Src7.pgm $p\Dst7.pgm 5 0.8 180 0 256 > $o\ncu-$k.stdout.txt 2>&1"
  cmd /c "`"$ncu`" --import $o\ncu-$k-Src7.ncu-rep --page details > $o\ncu-$k-Src7.txt 2>&1"
}
"PROFILEDONE" | Out-File $o\done.txt
