"""Write validation.json and decision-and-failures.json of the CUDA backend evidence from the result files."""
import json, sys
from pathlib import Path
S = Path(sys.argv[1]); D = Path(sys.argv[2])
F = S / 'formal-out'
timing = json.loads((F / 'results/timing.json').read_text())
abl = json.loads((F / 'results/identity-ablations.json').read_text())
summary = json.loads((F / 'results/timing-summary.json').read_text())
core_pc = json.loads((F / 'results/core-identity-pc.json').read_text())
core_mac = json.loads(Path('build/cuda-formal-mac2/out/core-identity-mac.json').read_text())
m1 = json.loads((S / 'mutants-9623880.json').read_text())
m2 = json.loads((S / 'mutants-1714c97.json').read_text())
m3 = json.loads((S / 'mutants-7f5737b.json').read_text())
red = json.loads((D / 'formal/red-check-1714c97.json').read_text())
ctest_pc = (F / 'logs/after-cuda-ctest.log').read_text(errors='replace')
kernel = (F / 'logs/cuda-kernel-test.log').read_text(errors='replace')
mac_log = Path('build/cuda-formal-mac2/logs/formal.log').read_text()
cuda_runs = sum(1 for r in timing['records'] if r['arm'] != 'cpu') + sum(1 for r in abl['records'] if r['arm'] != 'cpu')
h = summary['hypotheses']['cuda']
def survivors(m): return [r['mutant'] for r in m['results'] if r['status'] == 'SURVIVED' and not r['mutant'].startswith(('baseline', 'restored'))]
validation = {
 'protocol': 'protocol.json (078a109, registered 2026-10-31T16:53:49Z)',
 'commits': {'base': 'c67ca33', 'core_hooks': '500d1cd', 'after': '9623880', 'tests_strengthened': '1714c97', 'test_sequence_fixed': '7f5737b'},
 'gates': {
  'ctest_pc': {'pass': '100% tests passed, 0 tests failed out of 35' in ctest_pc and 'experimental_cuda_kernels .............   Passed' in ctest_pc,
               'detail': '35/35 at 9623880; experimental_cuda_backend and experimental_cuda_kernels ran; 6 Metal tests skipped'},
  'ctest_mac': {'pass': True, 'detail': 'pure core c67ca33 3/3 and 9623880 3/3; research build 9623880 90/91 with gui_workflow failing because the archive lacked Test Images/, then gui_workflow passed after Test Images/ of 9623880 was added to the same tree', 'log': mac_log.strip().split('\n')},
  'identity': {'pass': not timing['mismatches'] and not timing['failures'] and not abl['mismatches'] and not abl['failures'],
               'runs': len(timing['records']) + len(abl['records']), 'cuda_runs_compared': cuda_runs,
               'timing_records': len(timing['records']), 'ablation_records': len(abl['records'])},
  'core_unchanged': {'pass': core_pc['different_runs'] == 0 and core_mac['different_runs'] == 0,
                     'pc_runs': core_pc['runs'], 'mac_runs': core_mac['runs'], 'different': core_pc['different_runs'] + core_mac['different_runs']},
  'guard_exercised': {'pass': '24 poses' in kernel and 'PASS fine' in kernel, 'log': kernel.strip().split('\n')},
  'mutants': {'pass': not survivors(m1), 'killed': m1['totals'].get('KILLED', 0), 'survived': survivors(m1), 'totals': m1['totals']},
 },
 'hypotheses': {'H1': h['H1'], 'H2': h['H2'],
   'per_mode': {k: {x: v[x] for x in ('geomean', 'total_ratio', 'faster', 'cases', 'not_faster', 'cold_geomean')} for k, v in h['modes'].items()}},
 'after_the_gate': {
   'red_check_1714c97': {'totals': red['totals'], 'results': [(r['mutant'], r['status']) for r in red['results']]},
   'mutants_1714c97': {'totals': m2['totals'], 'survived': survivors(m2), 'note': 'N1 survived because the new threshold cases changed the random coarse trials'},
   'red_check_7f5737b_N1': 'KILLED (coarse mode 1 trial 29 angle 26)',
   'mutants_7f5737b': {'totals': m3['totals'], 'survived': survivors(m3)},
 },
 'not_formal': ['pilot/ (cuda_pilot.cu outputs)', 'explore1.json and explore2.json in raw-results.tar.gz', 'pilot/ncu-*.txt', 'profile/ (Nsight Systems of 9623880 after the formal runs)'],
}
(D / 'validation.json').write_text(json.dumps(validation, indent=1, ensure_ascii=False))
decision = {
 'decision': 'Keep the CUDA backend as opt-in backend 2 of the research coarse/frame API (FPM_WITH_CUDA, default OFF). Defaults, the stable core path and the GUI are unchanged.',
 'gates_passed': ['ctest_pc', 'ctest_mac (after the Test Images rerun)', 'identity', 'core_unchanged', 'guard_exercised'],
 'gates_failed': ['mutants: 19 of 24 killed at 9623880'],
 'hypotheses': {'H1': 'held', 'H2': 'held (16/17 in every mode; Src9 slower, as predicted)'},
 'failures': [
  {'what': 'pilot reference used border 0 while the GPU used borderColor()', 'effect': '11 of 17 fixtures mismatched in the first pilot run', 'fix': 'pilot reference fixed; pilot1-border-bug.jsonl kept'},
  {'what': 'exploratory timing without warm-up', 'effect': 'a GPU left idle ran at low clocks (Src8 calls 15.3, 14.7, 14.7, 12.2, 1.8 ms)', 'fix': 'fpm_frame_bench reports the cold first call and times only after 500 ms of untimed calls'},
  {'what': 'PC formal attempt 1: formal.bat expanded %PATH% before vcvars ran on the same line', 'effect': 'CUDA configure failed (cmake not found); steps 6 and 7 failed for the missing bench; no timing data; step 5 (core identity) completed', 'fix': 'build-cuda.bat runs vcvars and extends PATH on separate lines; attempt 2 passed every step; attempt 1 logs kept'},
  {'what': 'Mac formal attempts 1 and 2: the git archive lacked macos-cli/ and then Test Images/', 'effect': 'attempt 1: research configure failed; attempt 2: gui_workflow failed (90/91)', 'fix': 'Test Images/ of 9623880 added to the attempt-2 tree and gui_workflow rerun: passed; both attempts logged'},
  {'what': 'SSH during timing', 'effect': 'the poll waiting for step 6 read formal.log once within the first two minutes of the timing step (round 0, the warm-up round, which is not in the summary); no other connection until the timing finished', 'fix': 'disclosed'},
  {'what': 'gpu_bytes left out the per-match fine template copies', 'effect': 'formal gpu_bytes are up to 0.79 MiB low (the copies are in fine.retained_gpu_bytes)', 'fix': '1714c97 counts them; formal numbers reported as measured'},
  {'what': 'mutant gate', 'effect': 'W1, W2 (re-associated / FMA-contracted warp coordinates) and C1 (scores equal to the threshold dropped) survived: no test reached an exact rounding tie or a score exactly at the threshold; N2 (saturation band 1.25) and F2 (repairAll ignored) survived and are equivalent on reachable inputs',
   'fix': '1714c97: FP64 fine sampling mode with structured tie poses, flat template at threshold 1, flat source at threshold 0; red check kills W1, W2, C1; full rerun on 1714c97: ' + json.dumps(m2['totals']) + ' (N1 survived: the new cases changed the random coarse trials); 7f5737b gives the threshold cases their own generator and adds a bright near-flat dense case; full rerun on 7f5737b: ' + json.dumps(m3['totals']) + ', survivors ' + ', '.join(survivors(m3))},
  {'what': 'Nsight Compute of coarseFused on 9623880', 'effect': '--launch-skip 6 exceeded the four coarse launches of a three-call run, so no kernel was profiled (profile/ncu-coarseFused-nomatch.txt)', 'fix': 'kernel analysis cites the pre-commit ncu reports in pilot/'},
 ],
 'equivalent_mutants': {
  'N2': 'With exact integer statistics |product - sum*mean| <= sqrt(variance)*norm (Cauchy-Schwarz); the binary64 error is far below 12.5%, so ratios in [1.125, 1.25) are unreachable. The CPU core has the same branch.',
  'F2': 'repairAll is set only when the Q28 range check fails (|anchor|+extent+1 > 2^31) or the error bound reaches 0.25, which needs 510*(1+extent)/2^29 >= 0.25, i.e. ROI width+height above about 263,000 pixels; the template limits keep it below about 131,600. Out-of-range ROIs sample border zeros in FP64; the mutant samples one pixel with the zeroed descriptor. Both are constant ROIs with NCC 0.',
 },
 'limits': ['one GPU (RTX PRO 4000 Blackwell, sm_120), one driver (596.71, WDDM), Windows only', 'bit identity assumes a host that does not contract warpPixel (x86-64 without FMA); an aarch64 host whose compiler contracts needs __fma_rn on the device', 'only the research coarse/frame API; no CUDA for fpm_match(), the GUI, Session, pose refinement or the full GPU pipeline', '17 fixed fixtures only; no many-object or 8K scenes; no comparison with Metal', 'prepare (source copy, PCIe) not optimized; no Tensor cores or CUDA Graphs'],
}
(D / 'decision-and-failures.json').write_text(json.dumps(decision, indent=1, ensure_ascii=False))
print(json.dumps(validation['gates'], ensure_ascii=False)[:1500])
