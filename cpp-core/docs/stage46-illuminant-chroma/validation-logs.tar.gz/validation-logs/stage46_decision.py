"""Write cpp-core/docs/stage46-illuminant-chroma/decision-and-failures.json from the summary (run from the repo root)."""
import hashlib
import json
from pathlib import Path

DOCS = Path('cpp-core/docs/stage46-illuminant-chroma')
summary = json.loads((DOCS / 'summary.json').read_text())
pc = summary['per_condition']


def cell(arm, group, condition):
    c = pc[arm][group][condition]
    return dict(same_accepted=c['same']['accepted'], same_n=c['same']['n'], same_abstained=c['same']['abstained'],
                different_wrongly_accepted=c['different']['wrongly_accepted'], different_n=c['different']['n'],
                different_abstained=c['different']['abstained'], auc=c['auc'])


failed = [c for c in summary['hypotheses'] if not c['passed']]
decision = dict(
    stage=46, protocol_sha256=summary['protocol_sha256'], summary_sha256=hashlib.sha256((DOCS / 'summary.json').read_bytes()).hexdigest(),
    runner_sha256=summary['runner_sha256'], base_runner_sha256=summary['base_runner_sha256'],
    integrity=dict(passed=summary['integrity_passed'], failures=summary['integrity_failures'],
                   note='241 workers exit 0 with exact repeat; search matches identical across the 9 (synthetic) or 7 (Blender) methods of every '
                        'scene; gray_ncc, rgb_ncc, chroma and chroma_masked equal the pre-change base runner; no GT in any job'),
    localization=dict(all_equal_testbed_v1=summary['localization_matches_testbed_v1'],
                      per_scene={k: [v['tp'], v['fp'], v['fn']] for k, v in summary['localization'].items()}),
    hypotheses=summary['hypotheses'], hypotheses_passed=summary['hypotheses_passed'],
    failed_checks=[dict(name=c['name'], condition=c.get('condition'), group=c.get('group'), value=c['value'],
                        target=c.get('target'), baseline=c.get('baseline'), n=c['n']) for c in failed],
    recommended=summary['recommended'],
    decision='NOT recommended. chroma_vk stays an opt-in research method; the pre-registered gates H1a (spot_warm, noise_jpeg), '
             'H2a (warm3200, mixed) and H3 (spot_warm, both families, both baselines) failed. No default changes.',
    defaults='unchanged: chroma, rgb_ncc and gray_ncc are byte-identical in output to the base runner; GUI, core and research defaults untouched',
    predictions=[
        dict(id='P1', held=True, observed='exposure_bright: vk_region abstained on all 64 synthetic objects (62 status 3, clipped panel; 2 status 2, clipped colour field); vk_none_region did not abstain, '
             'AUC red 1.000 / teal 0.864, accepted 0/20 same-colour', evidence=dict(red=cell('vk_region', 'syn_red', 'exposure_bright'),
             teal=cell('vk_region', 'syn_teal', 'exposure_bright'), none_red=cell('vk_none_region', 'syn_red', 'exposure_bright'),
             none_teal=cell('vk_none_region', 'syn_teal', 'exposure_bright'))),
        dict(id='P2', held=True, observed='card_white abstained on every object under exposure_bright and wb_warm; it ALSO abstained under wb_cool '
             '(blue clipped, .9 x 1.22 > 1), which the prediction missed; card_gray never abstained on the reference (5 colour-support abstentions)',
             evidence=dict(wb_cool_red=cell('card_white_region', 'syn_red', 'wb_cool'), wb_warm_red=cell('card_white_region', 'syn_red', 'wb_warm'))),
        dict(id='P3', held=True, observed='card_gray: wb_warm 9/10 and 10/10 same-colour accepted, spot_warm 0/10 and 0/10',
             evidence=dict(red=cell('card_gray_region', 'syn_red', 'spot_warm'), teal=cell('card_gray_region', 'syn_teal', 'spot_warm'))),
        dict(id='P4', held='partly', observed='wb_warm same-colour accepted: vk_drop_region red 0/10 vs vk_region 10/10; teal 8/10 for both',
             evidence=dict(red=cell('vk_drop_region', 'syn_red', 'wb_warm'), teal=cell('vk_drop_region', 'syn_teal', 'wb_warm'))),
        dict(id='P5', held='partly', observed='noise_jpeg: vk_pixel accepted 0/10 and 0/10 (held); the existing chroma and chroma_masked accepted 10/10 '
             'because their calibration thresholds absorb the wb_cool shift (not held); vk_region accepted 1/10 and 3/10, so the region '
             'statistic is also shifted by JPEG (not held)', evidence=dict(vk_pixel=cell('vk_pixel', 'syn_red', 'noise_jpeg'),
             vk_region=cell('vk_region', 'syn_red', 'noise_jpeg'), chroma_masked=cell('chroma_masked', 'syn_red', 'noise_jpeg'))),
        dict(id='P6', held=False, observed='vk_region rejected every lightness+ object (lightness at fixed a*, b* changes RGB chromaticity); '
             'the uncorrected chroma arms detected lightness+ weakly as predicted'),
    ],
    post_hoc=dict(note='after the summary, not evidence: stage46-posthoc.json in validation-logs.tar.gz',
                  findings=['Primary-arm separation is wide in every non-abstained cell: same-colour max 0.0002-0.0061 against the '
                            'closest gated different colour 0.017 (red) / 0.029 (teal) and DeltaE 2 at 0.008 / 0.013; no different-colour '
                            'object of any direction or DeltaE was accepted in any of the 19 scenes',
                            'The one-class p95 thresholds (red 0.00039, teal 0.00137, Blender 0.00094) sit just above the clean calibration '
                            'distances; JPEG (same-colour median 0.0014 / 0.0026), the light gradient inside an object near the spot (up to '
                            '0.006) and Blender mixed light (0.0027) exceed them while staying 5-10x below the closest different colour',
                            'spot_warm: every object within 1.24 sigma of the spot centre abstained (panel red clipped); every object beyond '
                            '1.37 sigma was valid; abstentions rank as +inf in AUC, which is why H3 failed there (vk_none_region AUC '
                            '0.959 / 1.000 without abstentions)',
                            'The fallback policy (uncorrected when the reference abstains) wrongly accepted 8/22 and 11/22 different-colour '
                            'objects under exposure_bright, so falling back is unsafe',
                            'card_gray_region accepted 57/80 held-out synthetic same-colour objects with 0 wrong acceptances, but 0/20 under '
                            'spot_warm'],
                  not_claimed='No post-hoc threshold is adopted; a margin-based or noise-aware threshold rule needs its own pre-registered round'),
)
(DOCS / 'decision-and-failures.json').write_text(json.dumps(decision, indent=1) + '\n')
print('recommended', decision['recommended'], 'failed', len(failed))
