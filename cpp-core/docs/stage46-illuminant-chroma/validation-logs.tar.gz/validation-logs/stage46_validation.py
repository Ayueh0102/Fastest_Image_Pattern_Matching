"""Write validation.json, validation-logs.tar.gz and archive.json for stage 46 (run from the repository root).
Usage: python stage46_validation.py LOGDIR  (LOGDIR holds validation-logs/ with every script, log and attest)"""
import hashlib
import json
from pathlib import Path
import re
import sys
import tarfile

DOCS = Path('cpp-core/docs/stage46-illuminant-chroma')
logs = Path(sys.argv[1]) / 'validation-logs'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def attest(name):
    fields = dict(line.split('=', 1) for line in (logs / f'{name}.attest').read_text().splitlines() if '=' in line)
    log = logs / f'{name}.log'
    if sha(log) != fields['LOG_SHA256']:
        raise ValueError(f'{name}: log hash differs from attest')
    text = log.read_text(errors='replace')
    results = re.findall(r'\d+% tests passed, \d+ tests failed out of \d+', text) + re.findall(r'Ran \d+ tests? in [\d.]+s', text)
    return dict(command=fields['COMMAND'], exit=int(fields['EXIT']), head_before=fields['HEAD_BEFORE'], head_after=fields['HEAD_AFTER'],
                clean_before=fields['CLEAN_BEFORE'] == 'true', clean_after=fields['CLEAN_AFTER'] == 'true', start=fields['START'], end=fields['END'],
                log=f'validation-logs/{name}.log', log_sha256=fields['LOG_SHA256'], results=results)


def mutants(log):
    rows = []
    for line in (logs / log).read_text().splitlines():
        m = re.match(r'^(\S+ .*?) (KILLED|SURVIVED|BUILD FAILED) ?(.*)$', line)
        if m and not line.startswith('restored'):
            rows.append(dict(name=m.group(1), killed=m.group(2) == 'KILLED', by=m.group(3)))
    return rows


gates = {name: attest(name) for name in ('build', 'ctest', 'harness', 'color', 'other-py', 'asan')}
tested = {g['head_before'] for g in gates.values()} | {g['head_after'] for g in gates.values()}
if len(tested) != 1:
    raise ValueError('gates ran at different heads')
compiled, tool = mutants('stage46-compiled-mutants.log'), mutants('stage46-tool-mutants.log')
recount = json.loads((logs / 'stage46-recount-result.json').read_text())
negative = json.loads((logs / 'stage46-recount-negative.json').read_text())
replay = json.loads((logs / 'stage46-replay-result.json').read_text())
validation = dict(
    stage=46, tested_commit=tested.pop(), platform='Apple M4 Pro, 48 GiB, macOS',
    gates=gates,
    gate_notes=dict(build='fresh Release research build (GUI+experiments+OpenCV) in the worktree',
                    ctest='full research ctest, includes experimental_color_illuminant',
                    harness='python unittest discover cpp-core/tests test_*.py with FPM_FINE_*_BUILD=build/research; includes the stage-46 harness tests',
                    color='color_verify_runner_test.py --runner build/research/... --metal (8 tests: 5 existing + 3 chroma_vk)',
                    other_py='blender_challenge, challenge_coverage, real_rgb_benchmark',
                    asan='Debug, FPM_SANITIZERS, FPM_DISABLE_SIMD, experiments on; includes the new native test'),
    all_gates_passed=all(g['exit'] == 0 and g['clean_before'] and g['clean_after'] for g in gates.values()),
    frozen_runner=dict(path='build/stage46-release', sha256=replay['frozen_runner_sha256'], built_from='2a66cd6 (clean tree)'),
    compiled_mutants=dict(total=len(compiled), killed=sum(m['killed'] for m in compiled), mutants=compiled,
                          log='validation-logs/stage46-compiled-mutants.log', script='validation-logs/stage46_compiled_mutants.py',
                          note='each mutant of experiments/color_illuminant.cpp is compiled into build/stage46-mutants and run against '
                               'fpm_color_illuminant_test and the runner contract tests'),
    tool_mutants=dict(total=len(tool), killed=sum(m['killed'] for m in tool), mutants=tool,
                      log='validation-logs/stage46-tool-mutants.log', script='validation-logs/stage46_tool_mutants.py',
                      first_run='T9 (p95 replaced by the maximum) survived the first run, before the implementation commit, because the '
                                'fixture calibration values were all equal; test_thresholds_use_calibration_only was tightened. '
                                'Reproduced on temporary copies by validation-logs/stage46_t9_first_run.py (log stage46-t9-first-run.log)'),
    independent_recount=dict(script='validation-logs/stage46_recount.py', imports_harness=False, checks=recount['checks'],
                             problems=recount['problems'],
                             negative_control=dict(change='summary per_condition vk_region syn_red wb_warm wrongly_accepted + 1',
                                                   detected=negative['problems'])),
    summary_replay=dict(result='summarize on the extracted raw-results.tar.gz is byte-identical to summary.json',
                        summary_sha256=sha(DOCS / 'summary.json')),
    job_replay=dict(script='validation-logs/stage46_replay.py', runner='rebuilt from source-snapshot.tar.gz into build/stage46-replay',
                    runner_sha256=replay['runner_sha256'], jobs=replay['jobs'], equal=replay['equal'], differences=replay['differences'],
                    note='first-call scores and search matches of every candidate job equal the archive; the binary hash differs from the '
                         'frozen runner because the build path differs'),
    post_hoc=dict(script='validation-logs/stage46_posthoc.py', output='validation-logs/stage46-posthoc.json',
                  note='computed after the summary; diagnostic only, not adoption evidence'),
    smoke=dict(script='validation-logs/stage46_smoke_testbed.py', note='pre-protocol plumbing smoke on seed-shifted regenerated data; '
               'disclosed in the protocol; its outputs are not evidence and were not archived'),
)
(DOCS / 'validation.json').write_text(json.dumps(validation, indent=1) + '\n')
with tarfile.open(DOCS / 'validation-logs.tar.gz', 'w:gz', compresslevel=9) as tar:
    for path in sorted(p for p in logs.rglob('*') if p.is_file()):
        info = tar.gettarinfo(str(path), arcname=str(path.relative_to(logs.parent)))
        info.uid = info.gid = 0
        info.uname = info.gname = ''
        info.mtime = 0
        with open(path, 'rb') as handle:
            tar.addfile(info, handle)
roles = {'protocol.json': 'pre-registered protocol', 'source-snapshot.tar.gz': 'frozen source of 2a66cd6',
         'source-sha256.json': 'per-file SHA-256 of the frozen source', 'raw-results.tar.gz': 'masks, run manifest, jobs, stderr and results',
         'raw-files-sha256.json': 'SHA-256 of every raw archive member', 'input-sha256.json': 'every input image and mask',
         'summary.json': 'harness summary (every arm, cell, threshold and check)', 'decision-and-failures.json': 'decision, failed checks, predictions, post-hoc notes',
         'validation.json': 'gates, mutants, recount and replays', 'validation-logs.tar.gz': 'validation scripts, logs and attests'}
files = {}
for name, role in roles.items():
    path = DOCS / name
    files[name] = dict(bytes=path.stat().st_size, sha256=sha(path), role=role)
    if path.stat().st_size >= 100 * 1000 * 1000:
        raise ValueError(f'{name} at or above 100 MB')
extra = sorted(p.name for p in DOCS.iterdir() if p.name not in roles and p.name != 'archive.json')
if extra:
    raise ValueError(f'unlisted evidence files: {extra}')
(DOCS / 'archive.json').write_text(json.dumps(dict(stage=46, report='../ILLUMINANT_CHROMA_zh-TW.md', files=files), indent=1) + '\n')
print('gates passed', validation['all_gates_passed'], 'compiled', validation['compiled_mutants']['killed'], '/', len(compiled),
      'tool', validation['tool_mutants']['killed'], '/', len(tool), 'tested', validation['tested_commit'])
