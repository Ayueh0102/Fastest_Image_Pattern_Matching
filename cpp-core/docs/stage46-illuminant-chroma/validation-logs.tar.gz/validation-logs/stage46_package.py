"""Package stage-46 evidence into cpp-core/docs/stage46-illuminant-chroma (raw archive, inputs, summary, decision).
Run from the repository root after summarize; refuses to archive a file twice or exceed 100 MB."""
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

BUILD = Path('build')
RAW = BUILD / 'stage46-illuminant'
DOCS = Path('cpp-core/docs/stage46-illuminant-chroma')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


members = sorted(p for p in RAW.rglob('*') if p.is_file() and p.name not in ('summary.json',))
with tarfile.open(DOCS / 'raw-results.tar.gz', 'w:gz', compresslevel=9) as tar:
    for path in members:
        info = tar.gettarinfo(str(path), arcname=str(path.relative_to(BUILD)))
        info.uid = info.gid = 0
        info.uname = info.gname = ''
        info.mtime = 0
        with open(path, 'rb') as handle:
            tar.addfile(info, handle)
size = (DOCS / 'raw-results.tar.gz').stat().st_size
if size >= 100 * 1000 * 1000:
    raise ValueError('raw archive at or above 100 MB')
(DOCS / 'raw-files-sha256.json').write_text(json.dumps(dict(stage=46, note='every member of raw-results.tar.gz, path relative to build/',
    files={str(p.relative_to(BUILD)): sha(p) for p in members}), indent=1) + '\n')
manifest = json.loads((RAW / 'run' / 'manifest.json').read_text())
(DOCS / 'input-sha256.json').write_text(json.dumps(dict(stage=46, note='Every source, template and mask read by a stage-46 worker; '
    'test-bed images are checked against build/testbed-v1/final/manifest.json before the run.',
    testbed_generator_sha256=manifest['testbed_generator_sha256'], inputs=manifest['input_sha256']), indent=1) + '\n')
shutil.copyfile(RAW / 'summary.json', DOCS / 'summary.json')
print(len(members), 'raw files', size, 'bytes')
