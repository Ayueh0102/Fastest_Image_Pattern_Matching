"""Plumbing smoke data for stage 46: the test-bed v1 synthetic generator with different layout, noise and
background seeds (same label artwork). Never the evaluation data. Usage: python stage46_smoke_testbed.py OUTPUT"""
import sys
from pathlib import Path
sys.path.insert(0, 'cpp-core/tools')
import testbed_generate as tb
out = Path(sys.argv[1])
tb.SEEDS.update(layout={'red': 46000001, 'teal': 46000002}, noise=46000003, background=46000004)
tb.make_textures(out / 'textures')
tb.make_synthetic(out / 'textures', out / 'synthetic')
tb.finalize(out / 'blender', out / 'synthetic', out / 'final')
