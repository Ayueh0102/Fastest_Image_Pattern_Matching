"""Stage-46 POST-HOC diagnostics (written after the formal summary; not adoption evidence, no gate).

Reads the harness summary, the run manifest (scene list) and the GT files. Reports for the primary
arm the separation margin per cell, and for spot_warm each object's distance from the spot centre
with its reference clipping, status and distance. Usage:
  python stage46_posthoc.py MANIFEST SUMMARY OUTPUT.json
"""
import json
import math
from pathlib import Path
import statistics
import sys

sys.path.insert(0, 'cpp-core/tools')
import testbed_generate as tb  # noqa: E402

manifest, summary = (json.loads(Path(p).read_text()) for p in sys.argv[1:3])
rows = summary['rows']
thresholds = {(t['arm'], t['group']): t['value'] for t in summary['thresholds']}
out = dict(note='POST-HOC: computed after the pre-registered summary; describes why gates failed; no threshold here is evidence',
           margins={}, spot_warm=[], distributions={})
for group in ('syn_red', 'syn_teal', 'bl_red'):
    for condition in dict.fromkeys(r['condition'] for r in rows if r['group'] == group):
        R = [r for r in rows if r['group'] == group and r['condition'] == condition and r['found']]
        def values(pred):
            return [r['values']['vk_region'] for r in R if pred(r) and r['values'].get('vk_region') is not None]
        same = values(lambda r: r['same_colour'])
        gated = values(lambda r: not r['same_colour'] and r['direction'] != 'lightness+' and r['delta_e00_target'] >= 4)
        de2 = values(lambda r: not r['same_colour'] and r['direction'] != 'lightness+' and r['delta_e00_target'] == 2)
        light = values(lambda r: r['direction'] == 'lightness+')
        out['margins'][f'{group}/{condition}'] = dict(
            threshold=thresholds[('vk_region', group)], same_valid=len(same), same_abstained=sum(r['values']['vk_region'] is None for r in R if r['same_colour']),
            same_median=statistics.median(same) if same else None, same_max=max(same) if same else None,
            different_gated_min=min(gated) if gated else None, delta_e2_min=min(de2) if de2 else None, lightness_min=min(light) if light else None,
            gap_ratio=(min(gated) / max(same)) if same and gated and max(same) > 0 else None)
spot = tb.CONDITIONS['spot_warm']
height, width = tb.scene_shape()
cx, cy, sigma = spot['centre'][0] * width, spot['centre'][1] * height, spot['sigma'] * width
for scene in manifest['scenes']:
    if scene['condition'] != 'spot_warm':
        continue
    truth = {t['index']: t for t in json.loads(Path(scene['truth']).read_text())['truth']}
    for r in rows:
        if r['scene'] != scene['name'] or not r['found']:
            continue
        t = truth[r['index']]
        d = r['diagnostics']['vk_object']
        radius = math.hypot(t['pos_x'] - cx, t['pos_y'] - cy) / sigma
        out['spot_warm'].append(dict(scene=r['scene'], index=r['index'], same_colour=r['same_colour'], direction=r['direction'],
            delta_e00_target=r['delta_e00_target'], radius_sigma=round(radius, 3), status=d['status'],
            reference_clip_max=max(d['reference_clip_fraction']), vk_region=r['values']['vk_region'],
            vk_none_region=r['values']['vk_none_region'], masked_region=r['values']['masked_region']))
for arm in ('vk_region', 'vk_pixel', 'card_gray_region', 'chroma_masked'):
    for group in ('syn_red', 'syn_teal', 'bl_red'):
        for condition in dict.fromkeys(r['condition'] for r in rows if r['group'] == group):
            v = [r['values'][arm] for r in rows if r['group'] == group and r['condition'] == condition and r['found'] and r['same_colour']
                 and r['values'].get(arm) is not None]
            if v:
                out['distributions'][f'{arm}/{group}/{condition}'] = dict(n=len(v), median=statistics.median(v), max=max(v),
                                                                        threshold=thresholds.get((arm, group)))
abstained = [s for s in out['spot_warm'] if s['status'] == 3]
valid = [s for s in out['spot_warm'] if s['status'] == 0]
out['spot_warm_summary'] = dict(objects=len(out['spot_warm']), abstained=len(abstained), valid=len(valid),
    abstained_radius_max=max(s['radius_sigma'] for s in abstained) if abstained else None,
    valid_radius_min=min(s['radius_sigma'] for s in valid) if valid else None)
Path(sys.argv[3]).write_text(json.dumps(out, indent=1) + '\n')
print(json.dumps(out['spot_warm_summary']))
for key, m in out['margins'].items():
    print(key, {k: (round(v, 5) if isinstance(v, float) else v) for k, v in m.items()})
