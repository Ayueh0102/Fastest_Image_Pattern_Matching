"""Stage-46 compiled mutants of experiments/color_illuminant.cpp.

Each mutant is compiled into build/stage46-mutants and must make the native test
(fpm_color_illuminant_test) or the runner contract tests fail. The source is restored afterwards.
Run from the repository root: python stage46_compiled_mutants.py
"""
import subprocess, sys
from pathlib import Path
PY = '/Users/Ayueh/Fastest_Image_Pattern_Matching/python-port/venv/bin/python'
SOURCE = Path('cpp-core/experiments/color_illuminant.cpp')
BUILD = Path('build/stage46-mutants')
MUTANTS = [
 ('C1 per-pixel gain not applied', [('corrected[c] = values[c]*out.gain[c];', 'corrected[c] = values[c];')]),
 ('C2 region gain not applied', [('corrected[c] = sourceSum[c]*out.gain[c];', 'corrected[c] = sourceSum[c];')]),
 ('C3 gain inverted', [('out.gain[c] = templateWhite_[c]/reference.white[c];', 'out.gain[c] = reference.white[c]/templateWhite_[c];')]),
 ('C4 clip fraction check disabled', [('out.usable = out.usable && *std::max_element(out.clip.begin(), out.clip.end()) <= config_.maxReferenceClipFraction;', 'out.usable = out.usable;')]),
 ('C5 rank policy drops clipped samples', [('if (any && config_.clipPolicy == ReferenceClipPolicy::Drop) continue;', 'if (any && config_.clipPolicy != ReferenceClipPolicy::None) continue;')]),
 ('C6 mean instead of median', [('#include <limits>', '#include <limits>\n#include <numeric>'),
     ('for (int c = 0; c < 3; ++c) out.white[c] = median(channels[c]);', 'for (int c = 0; c < 3; ++c) out.white[c] = std::accumulate(channels[c].begin(), channels[c].end(), 0.)/double(channels[c].size());')]),
 ('C7 even-count median takes the upper value', [('return (*std::max_element(values.begin(), middle)+upper)*.5;', 'return upper;')]),
 ('C8 reference ignores the pose rotation', [('const float sx = width_*.5f+pose[0]+cs*sample[0]-sn*sample[1];', 'const float sx = width_*.5f+pose[0]+sample[0];'),
     ('const float sy = height_*.5f-pose[1]-(sn*sample[0]+cs*sample[1]);', 'const float sy = height_*.5f-pose[1]-sample[1];')]),
 ('C9 reference uses floor instead of nearest', [('const int x = int(std::floor(double(sx)+.5)), y = int(std::floor(double(sy)+.5));', 'const int x = int(std::floor(double(sx))), y = int(std::floor(double(sy)));')]),
 ('C10 clipped colour samples kept', [('if (clipped) { ++out.clippedPixels; continue; }', 'if (clipped) { ++out.clippedPixels; }')]),
 ('C11 abstention reports a distance', [('    if (out.status == 0) {\n        out.meanDistance', '    if (out.status == 0 || out.status == 3) {\n        out.meanDistance')]),
 ('C12 reference saturation strict >', [('if (pixel[c] >= config_.saturationLevel)', 'if (pixel[c] > config_.saturationLevel)')]),
 ('C13 colour saturation strict >', [('clipped |= source_[index+c] >= config_.saturationLevel;', 'clipped |= source_[index+c] > config_.saturationLevel;')]),
 ('C14 reference fraction not enforced', [('out.usable = out.samples > 0 && out.fraction >= config_.minReferenceFraction;', 'out.usable = out.samples > 0;')]),
 ('C15 reference status before colour support', [('out.status = !support ? 2 : reference.usable ? 0 : 3;', 'out.status = !reference.usable ? 3 : support ? 0 : 2;')]),
 ('C16 template reference not validated', [('if (!white.usable) throw std::invalid_argument("Template reference is empty, clipped or dark");', '')]),
]
def run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True)
original = SOURCE.read_text()
survived = 0
try:
    if not (BUILD/'CMakeCache.txt').exists():
        r = run(['cmake', '-S', 'cpp-core', '-B', str(BUILD), '-DCMAKE_BUILD_TYPE=Release', '-DFPM_BUILD_GUI=ON',
                 '-DFPM_BUILD_EXPERIMENTS=ON', '-DFPM_WITH_OPENCV=ON'])
        assert r.returncode == 0, r.stderr
    for name, edits in MUTANTS:
        text = original
        for old, new in edits:
            assert text.count(old) == 1, (name, old)
            text = text.replace(old, new)
        SOURCE.write_text(text)
        build = run(['cmake', '--build', str(BUILD), '-j', '--target', 'fpm_color_illuminant_test', 'fpm_color_verify_runner'])
        if build.returncode:
            print(name, 'BUILD FAILED', build.stdout[-1500:], build.stderr[-1500:], flush=True)
            survived += 1
            continue
        native = run([str(BUILD/'experiments/fpm_color_illuminant_test')])
        contract = run([PY, 'cpp-core/tests/color_verify_runner_test.py', '--runner', str(BUILD/'experiments/fpm_color_verify_runner'), '--metal'])
        killed_by = [k for k, r in (('native', native), ('runner_contract', contract)) if r.returncode]
        detail = native.stderr.strip().splitlines()[-1:] if native.returncode else []
        survived += not killed_by
        print(name, 'KILLED' if killed_by else 'SURVIVED', killed_by, detail, flush=True)
finally:
    SOURCE.write_text(original)
build = run(['cmake', '--build', str(BUILD), '-j', '--target', 'fpm_color_illuminant_test', 'fpm_color_verify_runner'])
native = run([str(BUILD/'experiments/fpm_color_illuminant_test')])
print('restored:', build.returncode == 0 and native.returncode == 0, native.stdout.strip(), 'survived:', survived)
sys.exit(1 if survived or native.returncode else 0)
