"""Stage-46 tool mutants: each must make tests/test_illuminant_colour_harness.py fail. Restores the tool afterwards.
Run from the repository root."""
import subprocess, sys
PY = '/Users/Ayueh/Fastest_Image_Pattern_Matching/python-port/venv/bin/python'
p = 'cpp-core/tools/benchmark_illuminant_colour.py'
TEST = 'cpp-core/tests/test_illuminant_colour_harness.py'
orig = open(p).read()
mutants = [
 ('T1 thresholds include held-out lighting', "if r['split'] == 'calibration' and r['group'] == group and r['same_colour']", "if r['group'] == group and r['same_colour']"),
 ('T2 abstention accepted', "return value is not None and threshold is not None and value <= threshold", "return value is None or (threshold is not None and value <= threshold)"),
 ('T3 AUC ties counted as wins', "1. if a > b else .5 if a == b else 0.", "1. if a >= b else 0."),
 ('T4 localization identity skipped', "if any(m != matches[0] for m in matches[1:]):", "if False:"),
 ('T5 existing-method scores not compared', "if reference['first']['scores'] != result['first']['scores'] or \\", "if False and reference['first']['scores'] != result['first']['scores'] or \\"),
 ('T6 GT keys in jobs ignored', "if key in FORBIDDEN_JOB_KEYS:", "if False:"),
 ('T7 lightness+ gated', "GATED_DIRECTIONS = ('hue+', 'hue-', 'chroma-', 'isogray0', 'isogray90')", "GATED_DIRECTIONS = ('hue+', 'hue-', 'chroma-', 'isogray0', 'isogray90', 'lightness+')"),
 ('T8 DeltaE 2 gated', "GATED_MIN_DELTA_E = 4.", "GATED_MIN_DELTA_E = 2."),
 ('T9 p95 replaced by maximum', "return float(np.max(values)) if rule == 'max' else float(np.percentile(values, PERCENTILE))", "return float(np.max(values))"),
 ('T10 H3 compares one baseline only', "for other in COMPARED:", "for other in COMPARED[:1]:"),
 ('T11 fallback ignores the corrected value', "if row['values'].get(corrected) is not None:", "if False:"),
 ('T12 targets need strict improvement', "passed=value is not None and value >= target", "passed=value is not None and value > target"),
 ('T13 exposure_bright gated', "GATED_SYNTHETIC = ('wb_warm', 'spot_warm', 'noise_jpeg')", "GATED_SYNTHETIC = ('wb_warm', 'exposure_bright', 'spot_warm', 'noise_jpeg')"),
 ('T14 result hash not checked', "elif sha(root / entry['result']) != entry['result_sha256']:", "elif False:"),
 ('T15 input hash not checked', "if not Path(path).exists() or sha(path) != digest:", "if not Path(path).exists():"),
 ('T16 Blender transfer uses Blender thresholds', "cell([r for r in blender if r['condition'] == c], arm, table, group='syn_red')", "cell([r for r in blender if r['condition'] == c], arm, table)"),
 ('T17 NCC similarity used as dissimilarity', "return None if score <= -1.5 else 1. - float(score)", "return None if score <= -1.5 else float(score)"),
 ('T18 card methods run on Blender', "return [m for m in METHODS if scene['source'] == 'synthetic' or m not in SYNTHETIC_ONLY]", "return list(METHODS)"),
 ('T19 incomplete run accepted', "if not manifest.get('complete') or not manifest.get('unchanged'):", "if not manifest.get('complete'):"),
 ('T20 exact repeat not checked', "if not result['exact_repeat']:", "if False:"),
]
survived = 0
try:
    for name, old, new in mutants:
        assert orig.count(old) == 1, name
        open(p, 'w').write(orig.replace(old, new))
        r = subprocess.run([PY, '-m', 'unittest', TEST], capture_output=True, text=True)
        failed = [l.split(' (')[0].split(': ')[1] for l in r.stderr.splitlines() if l.startswith(('FAIL:', 'ERROR:'))]
        survived += r.returncode == 0
        print(name, 'KILLED' if r.returncode else 'SURVIVED', failed, flush=True)
finally:
    open(p, 'w').write(orig)
r = subprocess.run([PY, '-m', 'unittest', TEST], capture_output=True, text=True)
print('restored:', r.stderr.strip().splitlines()[-1], 'survived:', survived)
sys.exit(1 if survived or r.returncode else 0)
