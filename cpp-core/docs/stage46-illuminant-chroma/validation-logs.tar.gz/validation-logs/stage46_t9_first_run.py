"""Reproduce the first tool-mutant run's T9 survival: the T9 mutant (p95 -> maximum) against the
pre-fix version of test_thresholds_use_calibration_only (all calibration values equal, so p95 == max).
Works on temporary copies only; the repository is not modified. Run from the repository root."""
import shutil, subprocess, sys, tempfile
from pathlib import Path
PY = '/Users/Ayueh/Fastest_Image_Pattern_Matching/python-port/venv/bin/python'
fixed = """    def test_thresholds_use_calibration_only(self):
        rows = fixture()
        hits = [r for r in rows if r['group'] == 'syn_red' and r['split'] == 'calibration' and r['same_colour']]
        for k, r in enumerate(hits):
            r['values'][stage46.PRIMARY] = .0005 + .00001 * k
        table = stage46.thresholds(rows)
        self.assertLess(table[(stage46.PRIMARY, 'syn_red')], max(r['values'][stage46.PRIMARY] for r in hits))"""
original = """    def test_thresholds_use_calibration_only(self):
        rows = fixture()
        table = stage46.thresholds(rows)"""
with tempfile.TemporaryDirectory() as d:
    root = Path(d) / 'cpp-core'  # tools resolve the repository as parents[2]
    shutil.copytree('cpp-core/tools', root / 'tools')
    shutil.copytree('cpp-core/examples', root / 'examples')  # tools import examples/python_ctypes.py
    (root / 'tests').mkdir(parents=True)
    test = Path('cpp-core/tests/test_illuminant_colour_harness.py').read_text()
    assert test.count(fixed) == 1
    (root / 'tests' / 'test_illuminant_colour_harness.py').write_text(test.replace(fixed, original))
    tool = root / 'tools' / 'benchmark_illuminant_colour.py'
    old = "return float(np.max(values)) if rule == 'max' else float(np.percentile(values, PERCENTILE))"
    text = tool.read_text(); assert text.count(old) == 1
    for label, body in (('pre-fix tests, original tool', text), ('pre-fix tests, T9 mutant', text.replace(old, 'return float(np.max(values))'))):
        tool.write_text(body)
        r = subprocess.run([PY, '-m', 'unittest', 'test_illuminant_colour_harness'], cwd=root / 'tests', capture_output=True, text=True)
        print(label, 'tests', 'PASS' if r.returncode == 0 else 'FAIL', r.stderr.strip().splitlines()[-1])
