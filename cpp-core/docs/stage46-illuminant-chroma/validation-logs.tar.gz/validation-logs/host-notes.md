# Stage-46 host notes

- Formal evaluation 2026-10-25 12:36:46-12:38:58 UTC: no timing-lock file of another session in the shared notes folder and no competing build/benchmark process (manifest host.before/after). No timing is claimed.
- Gates at b9572e0: during the ASan gate's ctest (about 12:51 UTC) the author edited two documentation files in the worktree (ILLUMINANT_CHROMA_zh-TW.md P1 wording, decision-and-failures.json P1 text) for under a minute, then restored them with git checkout before the gate ended (the attest records CLEAN_AFTER=true). No source file changed; the edits were reapplied in the validation-record commit.
- Mutant reruns after the measurement commit ran on temporary copies of HEAD (tool mutants: tools/examples/harness test; compiled mutants: git archive of the source tree with its own build directory), so the worktree was never modified while gates ran.
