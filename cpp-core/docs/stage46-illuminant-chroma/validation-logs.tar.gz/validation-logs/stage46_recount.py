"""Independent stage-46 recount. Does not import the harness or many_object_accuracy.

Re-derives, from the run manifest, worker outputs and GT files only: strict assignment (own matcher),
per-object dissimilarities, p95 thresholds (own percentile), decisions, cells, AUC and the H1-H3 checks,
then compares every number with the harness summary. Usage:
  python stage46_recount.py MANIFEST SUMMARY OUTPUT.json [--negative]
"""
import hashlib
import json
import math
from pathlib import Path
import sys

manifest_path, summary_path, output_path = map(Path, sys.argv[1:4])
negative = '--negative' in sys.argv
root = manifest_path.resolve().parent
manifest = json.loads(manifest_path.read_text())
summary = json.loads(summary_path.read_text())
if negative:  # one wrongly accepted object more than the harness reported must be detected
    summary['per_condition']['vk_region']['syn_red']['wb_warm']['different']['wrongly_accepted'] += 1

CAL = {'neutral', 'exposure_dark', 'wb_cool', 'shading', 'white'}
ARM = {'gray_ncc': ('gray_ncc', 'ncc'), 'rgb_ncc': ('rgb_ncc', 'ncc'), 'chroma': ('chroma', 'mean_distance'),
       'chroma_masked': ('chroma_masked', 'mean_distance'), 'masked_region': ('vk_object_none', 'uncorrected_region_distance'),
       'vk_pixel': ('vk_object', 'mean_distance'), 'vk_region': ('vk_object', 'region_distance'),
       'vk_drop_region': ('vk_object_drop', 'region_distance'), 'vk_none_region': ('vk_object_none', 'region_distance'),
       'card_white_region': ('card_white', 'region_distance'), 'card_gray_region': ('card_gray', 'region_distance'),
       'vk_uncorrected_region': ('vk_object', 'uncorrected_region_distance')}
problems, checks = [], 0


def same(label, mine, theirs, tol=0.):
    global checks
    checks += 1
    if mine is None or theirs is None:
        ok = mine is None and theirs is None
    elif isinstance(mine, float) or isinstance(theirs, float):
        ok = abs(mine - theirs) <= tol
    else:
        ok = mine == theirs
    if not ok:
        problems.append(f'{label}: recount {mine!r} vs summary {theirs!r}')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def wrap(angle):
    return (angle + 180.) % 360. - 180.


def value(score, statistic):
    if statistic == 'ncc':
        return None if score < -1 else 1 - score
    v = score[statistic]
    return None if v < 0 else v


def p95(values):
    xs = sorted(values)
    h = (len(xs) - 1) * .95
    lo = int(math.floor(h))
    return xs[lo] if lo + 1 >= len(xs) else xs[lo] + (h - lo) * (xs[lo + 1] - xs[lo])


# ---------------------------------------------------------------- raw outputs
executions = {}
for e in manifest['executions']:
    same(f"job hash {e['job']}", digest(root / e['job']), e['job_sha256'])
    same(f"returncode {e['job']}", e['returncode'], 0)
    if e['returncode'] == 0:
        same(f"result hash {e['result']}", digest(root / e['result']), e['result_sha256'])
    executions[(e['scene'], e['method'], e['runner_kind'])] = e
for path, h in manifest['input_sha256'].items():
    same(f'input {path}', digest(path), h)
rows = []
for scene in manifest['scenes']:
    name = scene['name']
    methods = [m for m in manifest['methods'] if scene['source'] == 'synthetic' or not m.startswith('card')]
    results = {m: json.loads((root / executions[(name, m, 'candidate')]['result']).read_text()) for m in methods}
    for m in methods:
        same(f'{name} {m} exact_repeat', results[m]['exact_repeat'], True)
        job = json.loads((root / executions[(name, m, 'candidate')]['job']).read_text())
        text = json.dumps(job)
        same(f'{name} {m} job has no GT', any(k in text for k in ('"truth"', '"same_colour"', '"direction"', '.truth.json', 'delta_e')), False)
        if (name, m, 'base') in executions:
            base = json.loads((root / executions[(name, m, 'base')]['result']).read_text())
            same(f'{name} {m} base scores', base['first']['scores'] == results[m]['first']['scores'], True)
            same(f'{name} {m} base matches', base['first']['search_matches'] == results[m]['first']['search_matches'], True)
    matches = results['gray_ncc']['first']['search_matches']
    for m in methods:
        same(f'{name} {m} localization identity', results[m]['first']['search_matches'] == matches, True)
    meta = json.loads(Path(scene['truth']).read_text())
    if scene['source'] == 'synthetic':
        truth = meta['truth']
    else:
        truth = [dict(o, pos_x=o['projected_center'][0], pos_y=o['projected_center'][1]) for o in meta['objects']]
    # Own strict matcher: candidates within 2 px, 1 degree, 2% scale; objects are >= 200 px apart, so
    # every truth must have at most one candidate and every candidate at most one truth.
    candidates = {}
    for t_index, t in enumerate(truth):
        hits = [k for k, p in enumerate(matches) if math.hypot(p['pos_x'] - t['pos_x'], p['pos_y'] - t['pos_y']) <= 2
                and abs(wrap(p['angle'] - t['angle'])) <= 1 and abs(p['scale'] / t['scale'] - 1) <= .02]
        same(f'{name} truth {t_index} ambiguous', len(hits) <= 1, True)
        candidates[t_index] = hits[0] if hits else None
    used = [p for p in candidates.values() if p is not None]
    same(f'{name} prediction used twice', len(used) == len(set(used)), True)
    loc = summary['localization'][name]
    same(f'{name} tp', len(used), loc['tp'])
    same(f'{name} fp', len(matches) - len(used), loc['fp'])
    same(f'{name} fn', len(truth) - len(used), loc['fn'])
    for t_index, t in enumerate(truth):
        p = candidates[t_index]
        rows.append(dict(scene=name, group=scene['group'], condition=scene['condition'], cal=scene['condition'] in CAL,
                         same=bool(t['same_colour']), direction=t['direction'], target=float(t['delta_e00_target']), found=p is not None,
                         values={arm: value(results[m]['first']['scores'][p], st) for arm, (m, st) in ARM.items() if m in results}
                         if p is not None else {}))
same('row count', len(rows), len(summary['rows']))
for mine, theirs in zip(rows, summary['rows']):
    same(f"row {mine['scene']} {theirs['index']} found", mine['found'], theirs['found'])
    same(f"row {mine['scene']} {theirs['index']} values", mine['values'] == theirs['values'], True)

# ---------------------------------------------------------------- thresholds, decisions, AUC
groups = sorted({r['group'] for r in rows})
table = {}
for arm in ARM:
    for g in groups:
        vals = [r['values'][arm] for r in rows if r['group'] == g and r['cal'] and r['same'] and r['found'] and r['values'].get(arm) is not None]
        if any(arm in r['values'] for r in rows if r['group'] == g and r['found']):
            table[(arm, g)] = p95(vals) if vals else None
reported = {(t['arm'], t['group']): t['value'] for t in summary['thresholds']}
same('threshold keys', sorted(table), sorted(reported))
for key, v in table.items():
    same(f'threshold {key}', v, reported.get(key), 1e-15)


def ok(r, arm, g=None):
    v, t = r['values'].get(arm), table.get((arm, g or r['group']))
    return v is not None and t is not None and v <= t


def auc(s, d):
    if not s or not d:
        return None
    s = [math.inf if v is None else v for v in s]
    d = [math.inf if v is None else v for v in d]
    wins = 0.
    for a in d:
        for b in s:
            wins += 1 if a > b else .5 if a == b else 0
    return wins / len(s) / len(d)


for arm in ARM:
    for g in groups:
        for c in sorted({r['condition'] for r in rows if r['group'] == g}):
            sub = [r for r in rows if r['group'] == g and r['condition'] == c and r['found'] and arm in r['values']]
            s = [r for r in sub if r['same']]
            d = [r for r in sub if not r['same']]
            cell = summary['per_condition'][arm][g][c]
            same(f'{arm} {g} {c} same n', len(s), cell['same']['n'])
            same(f'{arm} {g} {c} accepted', sum(ok(r, arm) for r in s), cell['same']['accepted'])
            same(f'{arm} {g} {c} same abstained', sum(r['values'][arm] is None for r in s), cell['same']['abstained'])
            same(f'{arm} {g} {c} wrongly accepted', sum(ok(r, arm) for r in d), cell['different']['wrongly_accepted'])
            same(f'{arm} {g} {c} different abstained', sum(r['values'][arm] is None for r in d), cell['different']['abstained'])
            same(f'{arm} {g} {c} auc', auc([r['values'][arm] for r in s], [r['values'][arm] for r in d]), cell['auc'], 1e-12)

# ---------------------------------------------------------------- H1-H3
GATED = ('hue+', 'hue-', 'chroma-', 'isogray0', 'isogray90')
gated = lambda r: not r['same'] and r['direction'] in GATED and r['target'] >= 4
mine = []
found = [r for r in rows if r['found'] and 'vk_region' in r['values']]
for c in ('wb_warm', 'spot_warm', 'noise_jpeg'):
    s = [r for r in found if r['condition'] == c and r['same']]
    d = [r for r in found if r['condition'] == c and gated(r)]
    mine.append(sum(ok(r, 'vk_region') for r in s) / len(s) >= .90)
    mine.append(sum(not ok(r, 'vk_region') for r in d) / len(d) >= .95)
iso = [r for r in found if r['condition'] in ('wb_warm', 'spot_warm', 'noise_jpeg') and gated(r) and r['direction'].startswith('isogray')]
mine.append(sum(not ok(r, 'vk_region') for r in iso) / len(iso) >= .95)
for c in ('warm3200', 'mixed'):
    s = [r for r in found if r['condition'] == c and r['same']]
    d = [r for r in found if r['condition'] == c and gated(r)]
    mine.append(sum(ok(r, 'vk_region') for r in s) / len(s) >= 1)
    mine.append(sum(not ok(r, 'vk_region') for r in d) / len(d) >= 1)
for g, c in [(g, c) for g in ('syn_red', 'syn_teal') for c in ('wb_warm', 'spot_warm', 'noise_jpeg')] + [('bl_red', 'warm3200'), ('bl_red', 'mixed')]:
    sub = [r for r in rows if r['group'] == g and r['condition'] == c and r['found']]
    primary = auc([r['values']['vk_region'] for r in sub if r['same']], [r['values']['vk_region'] for r in sub if not r['same']])
    for other in ('chroma_masked', 'masked_region'):
        mine.append(primary >= auc([r['values'][other] for r in sub if r['same']], [r['values'][other] for r in sub if not r['same']]))
same('hypothesis count', len(mine), len(summary['hypotheses']))
for k, (a, b) in enumerate(zip(mine, summary['hypotheses'])):
    same(f"hypothesis {k} {b['name']} {b.get('condition')} {b.get('group')}", a, b['passed'])
same('hypotheses_passed', all(mine), summary['hypotheses_passed'])
same('integrity_passed', not problems, summary['integrity_passed'])
result = dict(script='stage46_recount.py', imports_harness=False, negative_control=negative, checks=checks, problems=problems)
Path(output_path).write_text(json.dumps(result, indent=1) + '\n')
print(json.dumps(dict(checks=checks, problems=len(problems), first=problems[:5])))
sys.exit(0 if negative == bool(problems) else 1)
