from pathlib import Path
import json,sys,time,hashlib
import numpy as np
import cv2
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'cpp-core/tools'))
from pose_experiment import Scorer,library_path
folder=Path(__file__).parent;gpu=json.loads((folder/'results.json').read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
lib=library_path(root/'build/sparse-compact');assert sha(lib)==gpu['library_sha256']
prior=json.loads((root/'build/sparse-backends-study/formal/results.json').read_text())
out={'scope':'Separate CPU isolated refinement observation; not interleaved performance comparison. Iteration/evaluation counts describe different CPU/GPU numerical trajectories, not equal-cost work.', 'source_sha256':sha(__file__),'library_sha256':sha(lib),'cases':[]}
for g in gpu['cases']:
 case=next(c for c in prior['protocol']['cases'] if c['name']==g['name'])
 images=[]
 for key in ['source','template']:
  assert sha(case[key])==g['input_sha256'][case[key]]
  x=cv2.imread(case[key],cv2.IMREAD_UNCHANGED);assert x.ndim==2 and x.dtype==np.uint8
  images.append(x.astype(np.float32)/np.float32(255.))
 seeds=np.asarray(g['seeds'],dtype=np.float32);item={'name':g['name'],'runs':[]}
 with Scorer(root/'build/sparse-compact',*images,backend='cpu',threads=8) as scorer:
  reference=scorer.refine_rescue(seeds,resident=False,optimize_scale=False)
  assert reference[3]['rescue']['selected_seeds']==0
  warm_end=time.perf_counter()+1
  while time.perf_counter()<warm_end:scorer.refine(seeds,optimize_scale=False)
  for _ in range(7):
   poses,scores,stats,metrics=scorer.refine(seeds,optimize_scale=False)
   assert np.array_equal(poses,reference[0]) and np.array_equal(scores,reference[1])
   item['runs'].append({'metrics':metrics,'stats':stats,'poses':poses.tolist(),'scores':scores.tolist()})
 rep=sorted(item['runs'],key=lambda r:r['metrics']['wall_ms'])[3]
 item['representative']=rep['metrics'];item['identical_to_rescue_entry_point']=True
 out['cases'].append(item)
 print(json.dumps({'case':g['name'],'wall_ms':rep['metrics']['wall_ms'],'iterations_total':sum(s['iterations'] for s in rep['stats']),'iterations_max':max(s['iterations'] for s in rep['stats']),'evaluations_total':sum(s['evaluations'] for s in rep['stats'])}),flush=True)
(folder/'cpu-results.json').write_text(json.dumps(out,indent=2)+'\n')
assert sha(lib)==out['library_sha256']
