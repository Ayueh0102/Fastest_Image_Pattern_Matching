from pathlib import Path
import json,sys,time,hashlib,statistics
import numpy as np
import cv2
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'cpp-core/tools'))
from pose_experiment import Scorer,library_path
base=root/'build/sparse-backends-study/formal'
prior=json.loads((base/'results.json').read_text())
build=root/'build/sparse-compact'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
lib=library_path(build)
assert prior['protocol']['binary_sha256'][str(lib)]==sha(lib)
report={'scope':'Isolated Metal resident refinement diagnosis on two saved proposal batches without rescue. Not full-image performance or a new accuracy dataset.', 'library_sha256':sha(lib),'source_sha256':sha(__file__),'cases':[]}
for name in ['crop_small360','heldout_crowd128_20']:
 case=next(c for c in prior['protocol']['cases'] if c['name']==name)
 entry=next(e for e in prior['execution_order'] if e['case']==name and e['method']=='compact' and e['backend']==1 and e['block']==0)
 workerpath=base/entry['result']
 worker=json.loads(workerpath.read_text())
 raw=worker['first']
 assert raw['rescued_seeds']==0
 images=[]
 for key in ['source','template']:
  p=Path(case[key]);assert sha(p)==prior['protocol']['input_sha256'][str(p)]
  x=cv2.imread(str(p),cv2.IMREAD_UNCHANGED)
  assert x.ndim==2 and x.dtype==np.uint8, 'Use native gray fixtures only'
  images.append(x.astype(np.float32)/np.float32(255.))
 h,w=images[0].shape
 seeds=np.array([[p['pos_x']-w/2,h/2-p['pos_y'],p['angle'],np.log(p['scale'])] for p in raw['proposals']],dtype=np.float32)
 item={'name':name,'proposal_count':len(seeds),'worker_sha256':sha(workerpath),'input_sha256':{case[k]:sha(case[k]) for k in ['source','template']},'seeds':seeds.tolist(),'runs':[]}
 with Scorer(build,*images,backend='metal',threads=8) as scorer:
  reference=scorer.refine_rescue(seeds,resident=True,optimize_scale=False)
  assert reference[3]['rescue']['selected_seeds']==0
  warm_end=time.perf_counter()+1
  while time.perf_counter()<warm_end:scorer.refine_resident(seeds,optimize_scale=False)
  for _ in range(7):
   poses,scores,stats,metrics=scorer.refine_resident(seeds,optimize_scale=False)
   assert np.array_equal(poses,reference[0]) and np.array_equal(scores,reference[1]),'Resident output differs from full rescue entry point'
   item['runs'].append({'metrics':metrics,'stats':stats,'poses':poses.tolist(),'scores':scores.tolist()})
  representative=sorted(item['runs'],key=lambda x:x['metrics']['wall_ms'])[3]
  item['representative']=representative['metrics']
  item['identical_to_rescue_entry_point']=True
 report['cases'].append(item)
 assert sha(lib)==report['library_sha256']
 out=Path(__file__).with_name('results.json');out.write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'case':name,'candidates':len(seeds),'representative':item['representative'],'iterations':[min(s['iterations'] for s in representative['stats']),max(s['iterations'] for s in representative['stats'])]},indent=2),flush=True)
