CPU versus hybrid backend study on unchanged native C++ runtime ae0489f.
Eight-plane and compact representations are separate controlled comparisons.
Raw ordered proposals and work must match across CPU/Metal. Final float poses
may differ, so independentGT accuracy is checked separately. Negative scale and
unlabelled photo outcomes are preserved. This does not test all-GPU search.

Offline replay with NumPy/OpenCV, no GPU required:
python3 EXTRACT/formal/source-snapshot/cpp-core/tools/benchmark_sparse_backends.py --summarize EXTRACT/formal/results.json --output /tmp/replayed.json

Absolute paths are historical provenance; source snapshots, input fixtures,
protocol, raw worker records and validation logs are archived. Binary hashes
are recorded; executables omitted. All member hashes are in sha256.json.
