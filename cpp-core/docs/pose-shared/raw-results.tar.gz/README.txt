Shared CPU/Metal image storage versus frozen SIMD128 06eecd6.
All four routes use identical compact maps and split-submission Metal frontend.
Frozen SIMD128, current CPU, copied SIMD128 and shared SIMD128 refiners are
compared with identical seeds and rescue settings. Ordered proposals and sparse
integer work must match. Frozen/copied/shared SIMD128 final poses must match exactly;
CPU requires a complete one-to-one pose/score tolerance comparison and
independent GT checks. Negative scale and unlabeled photo outcomes are retained.
CPU candidate selection, rescue orchestration and final verification remain.
This is not an all-GPU pipeline. Refinement counts include initial and rescue
batches. GPU device intervals overlap CPU wait; buffer capacity overlaps RSS.

Offline replay with NumPy/OpenCV, no GPU required:
python3 EXTRACT/formal/source-snapshot/cpp-core/tools/benchmark_pose_shared_pipeline.py --summarize EXTRACT/formal/results.json --output /tmp/replayed.json

Absolute paths are historical provenance; source snapshots, input fixtures,
protocol, raw worker records and validation logs are archived. Binary hashes
are recorded; executables omitted. All member hashes are in sha256.json.
Identical immutable input fixtures share archive hardlinks; copy before editing.
