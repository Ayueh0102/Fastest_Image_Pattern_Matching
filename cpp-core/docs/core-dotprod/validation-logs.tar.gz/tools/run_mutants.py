"""Compiled mutants for the UDOT dot-product kernel (scratch, not committed).

Usage: run_mutants.py <worktree> <scratch dir>
Each mutant replaces one anchor (asserted to occur exactly once) in a copy of
cpp-core/src/ncc.cpp, rebuilds fpm_core_test in Release, and must make it fail.
The unmutated copy is built and must pass first.
"""
import json
import shutil
import subprocess
import sys
from pathlib import Path

MUTANTS = {
    "M1_mask_off_by_one": ("tail + (size - x))", "tail + (size - x - 1))"),
    "M2_one_lane_only": ("total += vaddvq_u32(sum);", "total += vgetq_lane_u32(sum, 0);"),
    "M3_unmasked_tail": ("vandq_u8(vld1q_u8(a + size - 16), vld1q_u8(tail + (size - x)))", "vld1q_u8(a + size - 16)"),
    "M4_no_chunk_bound": ("std::min(4096, (size - x) / 16 * 16)", "std::min(1 << 30, (size - x) / 16 * 16)"),
    "M5_tail_counted_twice": ("\t\t\tx = size;\n", "\n"),
}


def build_and_test(src: Path, build: Path, log: Path) -> int:
    with log.open("w") as out:
        subprocess.run(["cmake", "-S", str(src / "cpp-core"), "-B", str(build), "-DCMAKE_BUILD_TYPE=Release"],
                       stdout=out, stderr=subprocess.STDOUT, check=True)
        subprocess.run(["cmake", "--build", str(build), "--target", "fpm_core_test", "-j", "8"],
                       stdout=out, stderr=subprocess.STDOUT, check=True)
        return subprocess.run([str(build / "fpm_core_test")], stdout=out, stderr=subprocess.STDOUT).returncode


def main():
    worktree, scratch = Path(sys.argv[1]), Path(sys.argv[2])
    scratch.mkdir(parents=True, exist_ok=True)
    original = (worktree / "cpp-core/src/ncc.cpp").read_text()
    results = {}
    for name in ["M0_unmutated", *MUTANTS]:
        src = scratch / name / "src"
        if src.exists():
            shutil.rmtree(src)
        for part in ("cpp-core/src", "cpp-core/include", "cpp-core/tests", "cpp-core/tools", "cpp-core/examples"):
            shutil.copytree(worktree / part, src / part)
        shutil.copy(worktree / "cpp-core/CMakeLists.txt", src / "cpp-core/CMakeLists.txt")
        shutil.copytree(worktree / "macos-cli", src / "macos-cli")
        shutil.copy(worktree / "LICENSE", src / "LICENSE")
        text = original
        if name in MUTANTS:
            old, new = MUTANTS[name]
            assert original.count(old) == 1, (name, original.count(old))
            text = original.replace(old, new)
        (src / "cpp-core/src/ncc.cpp").write_text(text)
        status = build_and_test(src, scratch / name / "build", scratch / name / "log.txt")
        tail = (scratch / name / "log.txt").read_text().strip().splitlines()[-1]
        expected_fail = name != "M0_unmutated"
        results[name] = {"exit": status, "killed_or_passed": (status != 0) == expected_fail, "last_line": tail}
        print(name, results[name], flush=True)
    (scratch / "summary.json").write_text(json.dumps(results, indent=2) + "\n")
    return int(not all(r["killed_or_passed"] for r in results.values()))


if __name__ == "__main__":
    sys.exit(main())
