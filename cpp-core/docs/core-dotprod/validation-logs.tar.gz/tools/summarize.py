"""Summarize the DOTPROD before/after evidence (scratch helper)."""
import json
import statistics
import sys
from pathlib import Path

bench = Path(sys.argv[1])
out = {}
modes = {}
for side in ("before", "after"):
    for i in (1, 2, 3):
        d = json.loads((bench / f"modes-{side}-{i}.json").read_text())
        for m in d["modes"]:
            modes.setdefault(m["mode"], {}).setdefault(side, []).append(
                {"session": i, "backend": m["backend"], "median_ms": m["median_match_ms"], "times_ms": m["times_ms"],
                 "matches": m["matches"]})
summary = {}
for mode, sides in modes.items():
    before = [s["median_ms"] for s in sides["before"]]
    after = [s["median_ms"] for s in sides["after"]]
    pooled_b = statistics.median([t for s in sides["before"] for t in s["times_ms"]])
    pooled_a = statistics.median([t for s in sides["after"] for t in s["times_ms"]])
    same = all(s["matches"] == sides["before"][0]["matches"] for s in sides["before"] + sides["after"])
    paired = [a / b - 1 for a, b in zip(after, before)]
    summary[mode] = {"before_session_medians_ms": before, "after_session_medians_ms": after,
                     "before_pooled_median_ms": pooled_b, "after_pooled_median_ms": pooled_a,
                     "pooled_change_percent": 100 * (pooled_a / pooled_b - 1),
                     "paired_session_change_percent": [100 * p for p in paired],
                     "matches_identical_across_sessions_and_builds": same,
                     "backends": sorted({s["backend"] for s in sides["before"] + sides["after"]})}
    print(f"{mode:18s} before {pooled_b:9.3f} after {pooled_a:9.3f} change {summary[mode]['pooled_change_percent']:+6.1f}% "
          f"paired {[round(100 * p, 1) for p in paired]} same={same}")
out["benchmark_modes"] = summary
ab = json.loads((bench / "fixtures-ab.json").read_text())
rows = []
for c in ab["cases"]:
    b, a = c["median_ms"]["before"], c["median_ms"]["after"]
    rows.append({"source": c["source"], "count": c["count"], "before_median_ms": b, "after_median_ms": a,
                 "change_percent": 100 * (a / b - 1),
                 "after_faster_rounds": sum(x < y for x, y in zip(c["times_ms"]["after"], c["times_ms"]["before"])),
                 "rounds": len(c["times_ms"]["after"])})
    print(f"{c['source']:14s} {b:9.3f} {a:9.3f} {rows[-1]['change_percent']:+6.1f}% after-faster {rows[-1]['after_faster_rounds']}/{rows[-1]['rounds']}")
out["fixtures_ab"] = {"cases": rows, "load_average_start": ab["load_average_start"], "load_average_end": ab["load_average_end"],
                      "geomean_ratio": statistics.geometric_mean([r["after_median_ms"] / r["before_median_ms"] for r in rows])}
print("geomean ratio", out["fixtures_ab"]["geomean_ratio"])
(bench / "summary.json").write_text(json.dumps(out, indent=2) + "\n")
