"""Assemble cpp-core/docs/core-dotprod evidence from the scratch runs (scratch helper)."""
import hashlib
import io
import json
import shutil
import sys
import tarfile
from pathlib import Path

S, W = Path(sys.argv[1]), Path(sys.argv[2])
D = W / "cpp-core/docs/core-dotprod"
if D.exists():
    shutil.rmtree(D)
for sub in ("formal", "candidate1", "pilot"):
    (D / sub).mkdir(parents=True)
shutil.copy(S / "final/bench/protocol.json", D / "protocol.json")
for p in sorted((S / "final/bench").iterdir()):
    if p.name not in ("protocol.json", "summarize.py"):
        shutil.copy(p, D / "formal" / p.name)
for p in sorted(S.joinpath("cand1").iterdir()):
    if p.is_file() and p.name != "summarize.py":
        shutil.copy(p, D / "candidate1" / p.name)
shutil.copy(S / "cand1/extra/candidate1-ncc.cpp", D / "candidate1/candidate1-ncc.cpp")
shutil.copy(S / "pilot/pilot1.json", D / "pilot/pilot-variants.json")
for name in ("make_variants.py", "time_variants.py"):
    shutil.copy(S / "pilot" / name, D / "pilot" / name)
shutil.copy(S / "micro/dot_micro.cpp", D / "pilot/dot_micro.cpp")


def load(path):
    return json.loads(Path(path).read_text())


identity = load(S / "final/identity.json")
cand_identity = load(S / "cand1/extra/identity-3builds.json")
mutants = load(S / "final/mutants/summary.json")
cand_mutants = load(S / "cand1/extra/mutants-run/summary.json")
cv = {b: load(S / f"final/compare-versions-{b}.json") for b in ("base", "new")}
gate = (S / "final/gate.log").read_text()
validation = {
    "date": "2026-10-24",
    "head_before_change": "4a78498f8ffd7d7eb9d79bb5f85c9fe435b3400e",
    "gate_log_sha256": hashlib.sha256(gate.encode()).hexdigest(),
    "final_kernel": {
        "ncc_cpp_sha256": gate.split("ncc_sha256=")[1].split()[0],
        "core_test_sha256": gate.split("test_sha256=")[1].split()[0],
        "release_ctest": "3/3 (portable_core, c_abi, opencv_stage_comparison)",
        "fallback_ctest_march_armv8_a": "3/3, compiledBackend NEON, no UDOT in libfpm_core.a",
        "asan_ubsan_scalar_ctest": "2/2 (Debug, FPM_SANITIZERS=ON, FPM_DISABLE_SIMD=ON)",
        "asan_ubsan_udot_ctest": "2/2 (Debug, FPM_SANITIZERS=ON, SIMD on; UDOT present)",
        "research_ctest": "73/73 (Release, GUI + experiments + OpenCV)",
        "python_harness": "570 tests OK (unittest discover -p 'test_*.py', FPM_FINE_* builds = research build)",
        "identity": {"runs": identity["runs"], "different_runs": identity["different_runs"],
                     "libraries": list(identity["libraries"]), "reference": identity["reference"],
                     "cases": len(identity["cases"]),
                     "matches_compared": sum(c["count"] for c in identity["cases"])},
        "compare_versions": {b: {"outside_tolerance": [c["source"] for c in d["cases"]
                                                       if not c["portable_vs_legacy"]["within_tolerance"]],
                                 "cases": len(d["cases"])} for b, d in cv.items()},
        "compare_versions_portable_matches_identical_base_vs_new":
            sum(a["portable_cpp"]["matches"] == b["portable_cpp"]["matches"]
                for a, b in zip(cv["base"]["cases"], cv["new"]["cases"])),
        "compiled_mutants": {k: {"exit": v["exit"], "expected_outcome": v["killed_or_passed"]} for k, v in mutants.items()},
    },
    "candidate1": {
        "identity": {"runs": cand_identity["runs"], "different_runs": cand_identity["different_runs"]},
        "compiled_mutants": {k: {"exit": v["exit"], "expected_outcome": v["killed_or_passed"]} for k, v in cand_mutants.items()},
        "release_ctest": "3/3", "fallback_ctest": "3/3", "asan_ubsan_scalar": "2/2", "asan_ubsan_udot": "2/2",
        "research_ctest": "73/73", "python_harness": "570 OK",
    },
}
(D / "validation.json").write_text(json.dumps(validation, indent=2) + "\n")

formal = load(S / "final/bench/summary.json")
cand = load(S / "cand1/summary.json")
decision = {
    "adopted": "candidate 2: one UDOT accumulator per 4096-byte chunk + masked 16-byte tail; compile-time __ARM_FEATURE_DOTPROD && __aarch64__",
    "rejected": [
        {"variant": "candidate 1: two UDOT accumulators + masked tail",
         "reason": "formal fixture A/B: Src4 (single level, template width 33) slower in 7/7 rounds",
         "src4_change_percent": next(r["change_percent"] for r in cand["fixtures_ab"]["cases"] if r["source"] == "Src4.bmp"),
         "note": "faster than candidate 2 on Src7 large-template modes (simd -16.6% vs -13.7%); kept in candidate1/"},
        {"variant": "pilot v2/v3/v5/v6 (scalar tail or tail mask only for >= 4 / >= 8 bytes)",
         "reason": "pilot only: no gain on Src1 (v2) or Src4 regressions of +19.5..+27.6% (v3, v5, v6); see pilot/"},
    ],
    "failures_and_caveats": [
        "candidate 1 Src4 regression (+9.9%, 0/7 rounds faster) is the reason for the second candidate",
        "candidate 1 session 2 legacy control median 322.6 ms vs 188.6..199.6 ms elsewhere: environment disturbance, kept",
        "candidate 2 Src5 eight rotations: -1.9..+0.6%, 3..6/7 rounds faster; no measurable change, not claimed as a speedup",
        "pilot numbers are selection-only; the kernel was changed after seeing candidate 1 formal results, disclosed in protocol.json history",
        "other Claude sessions were active on the machine; load averages recorded per session",
        "only one Apple M4 Pro; Linux/Jetson/Windows-on-ARM and x86 not run",
    ],
    "formal_benchmark_modes": formal["benchmark_modes"],
    "formal_fixtures_ab_geomean_ratio": formal["fixtures_ab"]["geomean_ratio"],
}
(D / "decision-and-failures.json").write_text(json.dumps(decision, indent=2) + "\n")

# Logs, scratch drivers and large validation outputs in one archive.
members = {
    "final/gate.sh": S / "final/gate.sh", "final/gate.log": S / "final/gate.log",
    "final/identity.json": S / "final/identity.json",
    "final/compare-versions-base.json": S / "final/compare-versions-base.json",
    "final/compare-versions-new.json": S / "final/compare-versions-new.json",
    "final/mutants/summary.json": S / "final/mutants/summary.json",
    "final/profile/loop.py": S / "final/profile/loop.py",
    "final/profile/sample-Src7.bmp.txt": S / "final/profile/sample-Src7.bmp.txt",
    "final/profile/sample-Src10.bmp.txt": S / "final/profile/sample-Src10.bmp.txt",
    "candidate1/identity-3builds.json": S / "cand1/extra/identity-3builds.json",
    "candidate1/compare-versions-new.json": S / "cand1/extra/compare-versions-new.json",
    "candidate1/mutants/summary.json": S / "cand1/extra/mutants-run/summary.json",
    "tools/run_mutants.py": S / "mutants/run_mutants.py",
    "tools/summarize.py": S / "final/bench/summarize.py",
    "tools/assemble.py": S / "assemble.py",
}
for p in sorted((S / "final/logs").iterdir()):
    members[f"final/logs/{p.name}"] = p
for p in sorted((S / "cand1/extra/logs").iterdir()):
    members[f"candidate1/logs/{p.name}"] = p
for root, prefix in ((S / "final/mutants", "final/mutants"), (S / "cand1/extra/mutants-run", "candidate1/mutants")):
    for m in sorted(root.glob("M*")):
        members[f"{prefix}/{m.name}.log"] = m / "log.txt"
with tarfile.open(D / "validation-logs.tar.gz", "w:gz") as tar:
    for name, path in sorted(members.items()):
        data = Path(path).read_bytes()
        info = tarfile.TarInfo(name)
        info.size, info.mtime, info.mode = len(data), 0, 0o644
        tar.addfile(info, io.BytesIO(data))
files = sorted(p for p in D.rglob("*") if p.is_file() and p.name != "archive.json")
(D / "archive.json").write_text(json.dumps({str(p.relative_to(D)): hashlib.sha256(p.read_bytes()).hexdigest()
                                            for p in files}, indent=2) + "\n")
print("files", len(files), "bytes", sum(p.stat().st_size for p in files))
