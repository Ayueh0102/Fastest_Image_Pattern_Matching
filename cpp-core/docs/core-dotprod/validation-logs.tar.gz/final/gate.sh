#!/bin/bash
# Final verification gate for the selected UDOT kernel (scratch driver).
set -u
W=/Users/Ayueh/Fastest_Image_Pattern_Matching/.claude/worktrees/silly-engelbart-a33cd2
S=/private/tmp/claude-502/-Users-Ayueh-Fastest-Image-Pattern-Matching--claude-worktrees-silly-engelbart-a33cd2/1faf111a-de10-411b-a203-192b58aa70e1/scratchpad
PY=/Users/Ayueh/Fastest_Image_Pattern_Matching/python-port/venv/bin/python
L=$S/final/logs
cd "$W"
echo "HEAD=$(git rev-parse HEAD) ncc_sha256=$(shasum -a 256 cpp-core/src/ncc.cpp | cut -d' ' -f1) test_sha256=$(shasum -a 256 cpp-core/tests/core_test.cpp | cut -d' ' -f1)"
status=0
step() { local name=$1; shift; "$@" > "$L/$name.log" 2>&1; local rc=$?; echo "$name exit=$rc"; [ $rc -eq 0 ] || status=1; }
step new-configure cmake -S cpp-core -B build/dotprod-new -DCMAKE_BUILD_TYPE=Release -DFPM_WITH_OPENCV=ON
step new-build cmake --build build/dotprod-new -j 8
step new-ctest ctest --test-dir build/dotprod-new --output-on-failure
step fallback-configure cmake -S cpp-core -B build/dotprod-fallback -DCMAKE_BUILD_TYPE=Release -DFPM_WITH_OPENCV=ON -DCMAKE_CXX_FLAGS=-march=armv8-a
step fallback-build cmake --build build/dotprod-fallback -j 8
step fallback-ctest ctest --test-dir build/dotprod-fallback --output-on-failure
step asan-scalar-configure cmake -S cpp-core -B build/dotprod-asan-scalar -DCMAKE_BUILD_TYPE=Debug -DFPM_SANITIZERS=ON -DFPM_DISABLE_SIMD=ON
step asan-scalar-build cmake --build build/dotprod-asan-scalar -j 8
step asan-scalar-ctest ctest --test-dir build/dotprod-asan-scalar --output-on-failure
step asan-udot-configure cmake -S cpp-core -B build/dotprod-asan-udot -DCMAKE_BUILD_TYPE=Debug -DFPM_SANITIZERS=ON
step asan-udot-build cmake --build build/dotprod-asan-udot -j 8
step asan-udot-ctest ctest --test-dir build/dotprod-asan-udot --output-on-failure
step research-configure cmake -S cpp-core -B build/dotprod-research -DCMAKE_BUILD_TYPE=Release -DFPM_BUILD_GUI=ON -DFPM_BUILD_EXPERIMENTS=ON -DFPM_WITH_OPENCV=ON
step research-build cmake --build build/dotprod-research -j 8
step research-ctest ctest --test-dir build/dotprod-research --output-on-failure
step python-harness env FPM_FINE_REUSE_BUILD=build/dotprod-research FPM_FINE_SEARCH_BUILD=build/dotprod-research FPM_FINE_FUSED_BUILD=build/dotprod-research $PY -m unittest discover -s cpp-core/tests -p 'test_*.py'
for b in new fallback asan-udot asan-scalar research; do
  lib=build/dotprod-$b/libfpm_core.a
  echo "$b udot=$(objdump -d --no-show-raw-insn $lib | grep -c 'udot') vector_umull=$(objdump -d --no-show-raw-insn $lib | grep -c 'umull[2]*\.')"
done
for b in base new fallback; do echo "$b backend=$(build/dotprod-$b/fpm_cli --src 'Test Images/Src9.bmp' --tmpl 'Test Images/Dst9.bmp' | cut -c1-30)"; done
step identity $PY cpp-core/tools/check_backend_identity.py --lib before_neon=build/dotprod-base/libfpm_c.dylib --lib after_udot=build/dotprod-new/libfpm_c.dylib --lib after_fallback_neon=build/dotprod-fallback/libfpm_c.dylib --output $S/final/identity.json
step compare-versions-new $PY cpp-core/tools/compare_versions.py --build build/dotprod-new --output $S/final/compare-versions-new.json
step compare-versions-base $PY cpp-core/tools/compare_versions.py --build build/dotprod-base --output $S/final/compare-versions-base.json
for n in new-ctest fallback-ctest asan-scalar-ctest asan-udot-ctest research-ctest; do echo "$n: $(grep 'tests passed' $L/$n.log)"; done
echo "python-harness: $(tail -3 $L/python-harness.log | tr '\n' ' ')"
echo "identity: $(tail -1 $L/identity.log)"
echo "compare-versions-new: $(tail -1 $L/compare-versions-new.log)"
echo "compare-versions-base: $(tail -1 $L/compare-versions-base.log)"
echo "GATE status=$status"
exit $status
