import sys, time
sys.path.insert(0, sys.argv[1] + "/cpp-core/tools")
import check_backend_identity as h
from python_ctypes import Library
lib = Library(sys.argv[2])
case = next(c for c in h.CASES if c[0] == sys.argv[3])
h.run(lib, case, "exhaustive", False)  # warm-up + decode cache
print("ready", flush=True)
t = time.time()
n = 0
while time.time() - t < float(sys.argv[4]):
    h.run(lib, case, "exhaustive", False); n += 1
print("runs", n, flush=True)
