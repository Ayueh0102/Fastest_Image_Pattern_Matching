30-minute native Metal stability,512 separated instances of one template.
The complete stream and native summary are preserved without editing.
The original soak helper includes an older10min/2min explanatory note; this run
uses seconds_requested=1800 and the actual duration_ms. New protocol controls.

Source snapshots are the same runtime previously benchmarked in GUI integration.
Binary and large image files are omitted; hashes and deterministic generators
are kept. reference/formal.json supplies GT and immutable benchmark provenance;
only the selected native_combined reference job/result is copied here. Replaying
all6-way performance comparisons requires the preceding GUI study archive.

Run supplementary/summarize.py --data EXTRACT --output /tmp/summary.json with
Python3; it uses only the archived records and standard library. Its output
must byte-match summary.json. sha256.json authenticates all members except itself.
The external artifact-sha256.json authenticates this gzip and member manifest.
