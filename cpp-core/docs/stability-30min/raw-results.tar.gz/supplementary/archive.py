"""Freeze a30-minute run without changing its original benchmark or results."""
import gzip,hashlib,json,shutil,subprocess,sys,tarfile
from pathlib import Path
root=Path.cwd().resolve();data=root/'build/stability-30min';dest=root/'cpp-core/docs/stability-30min';folder=data/'archive'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def copy(src,dst):dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
protocol=json.loads((dest/'protocol.json').read_text());formal_path=Path(protocol['formal_report']);assert sha(formal_path)==protocol['formal_report_sha256']
formal=json.loads(formal_path.read_text());run=json.loads((data/'soak512.json').read_text());raw=json.loads((data/'soak512.raw.json').read_text());rows=[json.loads(line) for line in (data/'soak512.jsonl').read_text().splitlines()]
assert run['seconds_requested']==1800 and run['duration_ms']>=1800000 
assert len(rows)==run['calls'] and all(sha(p)==h for p,h in run['sha256'].items())
assert all(isinstance(r['exact'],bool) for r in rows)
assert rows[-1]['context_index']==run['contexts_recreated']
# Verify recorded input settings against the formally validated route. GT stays
# solely in the reference report; it never appears in the native job.
job=json.loads((data/'soak512.job.json').read_text());assert 'truth' not in job
reference=next(e for e in formal['execution_order'] if e['case']==run['case'] and e['method']=='native_combined')
refjob_path=formal_path.parent/reference['job'];refresult_path=formal_path.parent/reference['result'];assert sha(refjob_path)==reference['job_sha256'] and sha(refresult_path)==reference['sha256']
refjob=json.loads(refjob_path.read_text());assert all(job[k]==v for k,v in refjob.items())
reference_first=json.loads(refresult_path.read_text())['first'];assert raw['first']['matches']==reference_first['matches'] and raw['first']['proposals']==reference_first['proposals']
for name in ('soak512.json','soak512.job.json','soak512.raw.json','soak512.jsonl','soak512.stderr.txt','run.log'):copy(data/name,folder/name)
copy(dest/'protocol.json',folder/'protocol.json');copy(formal_path,folder/'reference/formal.json');copy(refjob_path,folder/'reference'/reference['job']);copy(refresult_path,folder/'reference'/reference['result'])
source_manifest={}
for p,h in formal['source_sha256'].items():
 dst=folder/'measured-sources'/Path(p).relative_to(root);copy(p,dst);assert sha(dst)==h;source_manifest[str(dst.relative_to(folder))]=h
save(folder/'measured-source-sha256.json',source_manifest)
copy(data/'archive.py',folder/'supplementary/archive.py')
if (data/'summarize.py').exists():copy(data/'summarize.py',folder/'supplementary/summarize.py')
if (data/'plot.py').exists():copy(data/'plot.py',folder/'supplementary/plot.py')
copy(data/'summary.json',folder/'summary.json');copy(data/'summary.json',dest/'summary.json')
# The legacy explanatory note is preserved verbatim in the original report;
# the new protocol and duration fields unambiguously describe30 minutes.
(folder/'README.txt').write_text('''30-minute native Metal stability,512 separated instances of one template.
The complete stream and native summary are preserved without editing.
The original soak helper includes an older10min/2min explanatory note; this run
uses seconds_requested=1800 and the actual duration_ms. New protocol controls.

Source snapshots are the same runtime previously benchmarked in GUI integration.
Binary and large image files are omitted; hashes and deterministic generators
are kept. reference/formal.json supplies GT and immutable benchmark provenance;
only the selected native_combined reference job/result is copied here. Replaying
all6-way performance comparisons requires the preceding GUI study archive.

Run supplementary/summarize.py --data EXTRACT --output /tmp/summary.json with
Python3; it uses only the archived records and standard library. Its output
must byte-match summary.json. sha256.json authenticates all members except itself.
The external artifact-sha256.json authenticates this gzip and member manifest.
''')
manifest={str(p.relative_to(folder)):sha(p) for p in sorted(folder.rglob('*')) if p.is_file() and p.name!='sha256.json'};save(folder/'sha256.json',manifest)
archive=dest/'raw-results.tar.gz'
with archive.open('wb') as rawfile:
 with gzip.GzipFile(filename='',mode='wb',fileobj=rawfile,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for p in sorted(folder.rglob('*')):
    if p.is_file():
     info=tar.gettarinfo(str(p),arcname=str(p.relative_to(folder)));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
     with p.open('rb') as src:tar.addfile(info,src)
with tarfile.open(archive) as tar:
 assert set(tar.getnames())==set(manifest)|{'sha256.json'}
 for p,h in manifest.items():assert hashlib.sha256(tar.extractfile(p).read()).hexdigest()==h
check=data/'relocated';check.mkdir(exist_ok=True)
with tarfile.open(archive) as tar:tar.extractall(check,filter='data')
subprocess.run([sys.executable,str(check/'supplementary/summarize.py'),'--data',str(check),'--output',str(check/'replayed-summary.json')],check=True,cwd='/tmp')
assert (check/'replayed-summary.json').read_bytes()==(dest/'summary.json').read_bytes()
save(dest/'artifact-sha256.json',dict(archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,manifest_sha256=sha(folder/'sha256.json'),members=len(manifest),summary_sha256=sha(dest/'summary.json'),extracted_summary_byte_identical=True,original_sources_binaries_inputs_hashes_valid=True,settings_equal_formal_native_combined=True,reference_outputs_exact=True,stability_passed=run['passed']))
print('Archived run, all member hashes and relocated replay verified.')
