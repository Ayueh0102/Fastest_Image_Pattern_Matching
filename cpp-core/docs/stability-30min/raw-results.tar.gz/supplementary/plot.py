import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path('build/stability-30min');rows=[json.loads(line) for line in (root/'soak512.jsonl').read_text().splitlines()];s=json.loads((root/'summary.json').read_text())
x=[r['elapsed_ms']/60000 for r in rows];rss=[r['memory']['current_rss_bytes']/2**20 for r in rows];times=[r['total_ms']/1000 for r in rows]
fig,axes=plt.subplots(2,1,figsize=(11.6,7.4),sharex=True)
axes[0].plot(x,rss,color='#346080',lw=1.4,label='Current process RSS')
first=s['current_rss_bytes']['first_fifth_median']/2**20;last=s['current_rss_bytes']['last_fifth_median']/2**20;allowed=s['current_rss_bytes']['allowed_delta']/2**20
axes[0].axhline(first,color='#5b9b6f',ls='--',lw=1,label=f'First-fifth median: {first:.1f} MiB')
axes[0].axhline(last,color='#ba8441',ls=':',lw=1.1,label=f'Last-fifth median: {last:.1f} MiB')
axes[0].set_ylabel('Current process RSS (MiB)');axes[0].legend(loc='upper right',fontsize=9)
axes[1].plot(x,times,color='#346080',lw=1,label='Complete algorithm call')
for ax in axes:
 for r in rows:
  if r['recreate_ms']>0:ax.axvline(r['elapsed_ms']/60000,color='#ba8441',alpha=.35,lw=.8)
 ax.grid(alpha=.17);ax.spines[['top','right']].set_visible(False)
axes[1].set_ylabel('Algorithm call (seconds)');axes[1].set_xlabel('Elapsed minutes');axes[1].set_xlim(0,30.1)
fig.suptitle(f'30-minute native Metal stability: 512 objects | {s["calls"]} calls | {s["contexts_recreated"]} recreations',fontsize=14)
fig.text(.015,.018,f"Ordered-output equality: {s['all_outputs_exact']}. Vertical lines: session recreation every 100 calls.\nRSS median growth gate: {allowed:.1f} MiB. Timing is descriptive; excludes context construction and includes lazy pose setup.",fontsize=9,color='#454e58')
fig.tight_layout(rect=[0,.065,1,.96]);fig.savefig('cpp-core/docs/stability-30min/trace.png',dpi=180)
