"""Replay30-minute stability evidence using only archived data and stdlib."""
import argparse,hashlib,json,statistics
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--data',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
run=json.loads((a.data/'soak512.json').read_text());raw=json.loads((a.data/'soak512.raw.json').read_text());rows=[json.loads(line) for line in (a.data/'soak512.jsonl').read_text().splitlines()]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert len(rows)==run['calls'] and rows and all(r['call']==i for i,r in enumerate(rows))
assert run['seconds_requested']==1800 and raw['duration_ms']==run['duration_ms'] and run['duration_ms']>=1800000
caps=('frame_host_bytes','frame_coarse_gpu_bytes','frame_fine_gpu_bytes','pose_host_bytes','pose_gpu_bytes');work=lambda r:[{k:w[k] for k in ('maps','windows','fine_maps')} for w in r['work']]
capacities_ok=all(all(r[k]==rows[0][k] for k in caps) for r in rows)
work_ok=all(work(r)==work(rows[0]) and r['models_matched']==3 for r in rows)
exact_ok=raw['exact'] and run['all_outputs_exact'] and all(r['exact'] for r in rows)
async_ok=raw['drained'] and all(sum(w['async_submitted'] for w in r['work'])>0 and all(w['async_submitted']==w['async_completed'] for w in r['work']) for r in rows)
generation_ok=True
for i,r in enumerate(rows):
 if not i:continue
 previous=rows[i-1];assert r['elapsed_ms']>=previous['elapsed_ms']
 if r['context_index']==previous['context_index']:generation_ok &= r['generation']==previous['generation']+1
 else:generation_ok &= r['context_index']==previous['context_index']+1 and r['generation']==1 and i%100==0
assert rows[-1]['context_index']==run['contexts_recreated']
n=max(1,len(rows)//5);rss=[r['memory']['current_rss_bytes'] for r in rows];times=[r['total_ms'] for r in rows];first=statistics.median(rss[:n]);last=statistics.median(rss[-n:]);allowed=max(32*2**20,first*.1)
rss_ok=last-first<=allowed
assert first==run['current_rss_bytes']['first_fifth_median'] and last==run['current_rss_bytes']['last_fifth_median']
def percentile(v,q):
 v=sorted(v);i=(len(v)-1)*q;lo=int(i);return v[lo]+(v[min(lo+1,len(v)-1)]-v[lo])*(i-lo)
recreates=[r for r in rows if r['recreate_ms']>0];normal=[r['total_ms'] for r in rows if r['generation']>1]
s=dict(case=run['case'],duration_seconds=run['duration_ms']/1000,calls=len(rows),contexts_recreated=run['contexts_recreated'],
 all_outputs_exact=exact_ok,all_async_batches_drained=async_ok,all_frame_generations_valid=generation_ok,all_logical_work_constant=work_ok,all_retained_capacities_constant=capacities_ok,
 current_rss_bytes=dict(min=min(rss),max=max(rss),first_fifth_median=first,last_fifth_median=last,median_delta=last-first,allowed_delta=allowed),
 process_peak_rss_bytes=max([r['memory']['peak_rss_bytes'] for r in rows]+[raw['first']['memory']['peak_rss_bytes'],raw['before']['peak_rss_bytes'],raw['after']['peak_rss_bytes']]),retained_capacities_bytes={k:rows[0][k] for k in caps},logical_work_per_call=work(rows[0]),
 timing_ms=dict(all_median=statistics.median(times),all_min=min(times),all_max=max(times),all_p95=percentile(times,.95),first_fifth_median=statistics.median(times[:n]),last_fifth_median=statistics.median(times[-n:]),excluding_context_first_median=statistics.median(normal)),
 initial_setup_ms=raw['construct_ms'],initial_first_call_ms=raw['first']['total_ms'],recreated_setup_ms=[r['recreate_ms'] for r in recreates],
 five_minute_windows=[dict(start_seconds=start,end_seconds=start+300,calls=len(selected),median_ms=statistics.median(r['total_ms'] for r in selected),current_rss_median=statistics.median(r['memory']['current_rss_bytes'] for r in selected)) for start in range(0,1800,300) if (selected:=[r for r in rows if start<=r['elapsed_ms']/1000<start+300])],
 passed=bool(run['passed'] and all((exact_ok,async_ok,generation_ok,work_ok,capacities_ok,rss_ok))),note='Agreed30-minute fixed-image stability check.512 separated instances of one template. Timing is descriptive, not a new paired speed benchmark. Native Session checks full ordered outputs; stream stores flags to keep memory bounded.',
 input_record_sha256={p.name:sha(p) for p in [a.data/'soak512.json',a.data/'soak512.raw.json',a.data/'soak512.job.json',a.data/'soak512.jsonl']})
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(s,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
print(json.dumps({k:s[k] for k in ('duration_seconds','calls','contexts_recreated','passed','current_rss_bytes')},indent=2))
