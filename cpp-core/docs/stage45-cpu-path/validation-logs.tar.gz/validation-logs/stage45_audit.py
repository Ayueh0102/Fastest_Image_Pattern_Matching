"""Independent stage-45 audit: reads only the committed archives and summaries, never imports the harness.

Usage: stage45_audit.py DOCS_STAGE45 DOCS_STAGE43 WORKDIR
"""
import json
import math
from pathlib import Path
import statistics
import sys
import tarfile

S45, S43, WORK = (Path(arg) for arg in sys.argv[1:4])
checks, problems = 0, []


def check(condition, message):
    global checks
    checks += 1
    if not condition:
        problems.append(message)


def strict(matches, truth):
    edges = []
    for t in truth:
        row = []
        for j, m in enumerate(matches):
            ok = all(math.isfinite(m[k]) for k in ('pos_x', 'pos_y', 'angle', 'scale')) and m['scale'] > 0
            ratio = m['scale']/t['scale'] if ok else 0
            if ok and math.hypot(m['pos_x']-t['pos_x'], m['pos_y']-t['pos_y']) <= 2 and \
                    abs((m['angle']-t['angle']+180) % 360-180) <= 1 and .98 <= ratio <= 1.02:
                row.append(j)
        edges.append(row)
    owner = {}

    def augment(i, seen):
        for j in edges[i]:
            if j not in seen:
                seen.add(j)
                if j not in owner or augment(owner[j], seen):
                    owner[j] = i
                    return True
        return False
    tp = sum(augment(i, set()) for i in range(len(truth)))
    return tp, len(matches)-tp, len(truth)-tp


def outputs(record):
    return record['matches'], record['proposals']


def r43(archive, phase, suffix):
    found = {}
    with tarfile.open(archive) as tar:
        for member in tar.getmembers():
            parts = Path(member.name).parts
            if len(parts) == 4 and parts[1:3] == (phase, 'results') and not parts[3].startswith('._') and parts[3].endswith(suffix+'.json'):
                case, path, arm = parts[3][:-len(suffix+'.json')].rsplit('-', 2)
                found[(case, path, arm)] = json.load(tar.extractfile(member))['first']
    return found


def no_metal(record):
    g = record['full_gpu']
    return (not g['enabled'] and g['command_buffers'] == 0 and g['gpu_bytes'] == 0 and record['frame_coarse_gpu_bytes'] == 0 and
            record['frame_fine_gpu_bytes'] == 0 and record['pose_gpu_bytes'] == 0 and record['refinement_dispatches'] == 0 and
            record['refinement_command_buffers'] == 0 and record['selected_refinement_backend'] == 0 and
            record['configured_refinement_backend'] == 0 and
            all(w['coarse_commands'] == 0 and w['fine_commands'] == 0 and w['coarse_gpu_bytes'] == 0 for w in record['work']))


for archive in sorted(S45.glob('raw-results-*.tar.gz')):
    with tarfile.open(archive) as tar:
        tar.extractall(WORK, filter='data')
RAW = WORK/'stage45-cpu-path'
PATH = {'cpu_full': 'hybrid', 'hybrid_best': 'hybrid', 'full_gpu_parallel': 'full_gpu'}

# ---- formal run 2 ----
manifest = json.loads((RAW/'formal-2/manifest.json').read_text())
summary = json.loads((S45/'formal-summary.json').read_text())
ref = r43(S43/'raw-results-timing.tar.gz', 'formal', '-b0')
cases = {c['name']: c for c in manifest['cases']}
arms, blocks, measured = manifest['arms'], manifest['blocks'], manifest['measured_calls']
check(manifest['complete'] and manifest['unchanged'] and len(manifest['executions']) == len(cases)*len(arms)*blocks == 144, 'formal-2 manifest')
order = [(c, a, b) for c in cases for b in range(blocks) for a in (arms if b % 2 == 0 else arms[::-1])]
check([(e['case'], e['arm'], e['block']) for e in manifest['executions']] == order, 'formal-2 worker order')
check(all(not e['host'].get('competing_processes') for e in manifest['executions']), 'competing processes recorded')
values, block_medians = {}, {}
for entry in manifest['executions']:
    worker = json.loads((RAW/'formal-2'/entry['result']).read_text())
    case, arm, block = entry['case'], entry['arm'], entry['block']
    method, dedup = arm.split('_frames_')
    warmup = manifest['frame_warmup_calls'][case]
    rows = worker['runs']
    check(len(rows) == 1+warmup+measured, f'call count {case} {arm} {block}')
    check(rows[warmup]['elapsed_ms']-rows[0]['elapsed_ms'] >= 1000, f'warm-up {case} {arm} {block}')
    timed = [row['frame_wall_ms'] for row in rows[1+warmup:]]
    values.setdefault((case, arm), []).extend(timed)
    block_medians.setdefault((case, arm), {})[block] = statistics.median(timed)
    for row in rows:
        check(strict(row['matches'], cases[case]['truth'])[1:] == (0, 0), f'GT {case} {arm} {block}')
        check(row['candidate_dedup']['top_k'] == (3 if dedup == 'k3' else 0), f'dedup arm {case} {arm}')
        check(outputs(row) == outputs(rows[0]), f'repeat {case} {arm} {block}')
        if method == 'cpu_full':
            check(no_metal(row), f'CPU used Metal {case} {arm} {block}')
        else:
            check(outputs(row) == outputs(ref[(case, PATH[method], dedup)]), f'round-43 identity {case} {arm} {block}')
        if method == 'full_gpu_parallel':
            check(row['full_gpu']['peak_mode'] == 2 and row['full_gpu']['command_buffers'] == 1, f'GPU route {case} {arm}')
        if method == 'hybrid_best':
            check(row['frame_coarse_gpu_bytes'] > 0, f'hybrid without Metal {case} {arm}')
rows = {row['name']: row for row in summary['cases']}
medians = {}
for (case, arm), samples in values.items():
    medians[(case, arm)] = statistics.median(samples)
    check(len(samples) == blocks*measured and abs(medians[(case, arm)]-rows[case]['arms'][arm]['frame_wall_ms']['median']) < 1e-9, f'median {case} {arm}')


def compare(case, base, cand):
    pairs = [(block_medians[(case, base)][k], block_medians[(case, cand)][k]) for k in range(blocks)]
    a, b = medians[(case, base)], medians[(case, cand)]
    pooled = (b > a)-(b < a)
    return 100*(b/a-1), sum(y < x for x, y in pairs), pooled != 0 and {(y > x)-(y < x) for x, y in pairs} == {pooled}


table = {}
for case, row in rows.items():
    for key, got in row['comparisons'].items():
        if key == 'frames_ranking':
            continue
        delta, faster, consistent = compare(case, got['baseline'], got['candidate'])
        check(abs(delta-got['delta_percent']) < 1e-9 and faster == got['candidate_faster_blocks'] and consistent == got['consistent_direction'],
              f'comparison {case} {key}')
        table[f'{case}|{key}'] = dict(delta_percent=round(delta, 3), faster_blocks=faster, consistent=consistent)
    ranked = sorted(arms, key=lambda arm: medians[(case, arm)])
    beats = [compare(case, other, ranked[0]) for other in ranked[1:]]
    fastest = ranked[0] if all(d < 0 and c for d, _, c in beats) else None
    check(fastest == summary['frames_fastest'][case], f'fastest {case}')
    table[f'{case}|fastest'] = fastest

# ---- GT phase ----
gt = json.loads((RAW/'gt/manifest.json').read_text())
gt_summary = json.loads((S45/'gt-summary.json').read_text())
gt_ref = r43(S43/'raw-results-gt.tar.gz', 'gt', '')
gt_cases = {c['name']: c for c in gt['cases']}
check(len(gt['executions']) == 224 == 2*len(gt_cases) and all(e['returncode'] == 0 for e in gt['executions']), 'GT workers')
counts, hybrid_counts = {}, {}
for entry in gt['executions']:
    worker = json.loads((RAW/'gt'/entry['result']).read_text())
    calls = [worker['first'], *worker['runs']]
    key = (entry['case'], entry['arm'])
    counts[key] = strict(calls[0]['matches'], gt_cases[key[0]]['truth'])
    check(all(strict(call['matches'], gt_cases[key[0]]['truth']) == counts[key] for call in calls), f'GT repeat {key}')
    check(all(no_metal(call) for call in calls), f'GT CPU used Metal {key}')
    old = gt_ref[(key[0], 'hybrid', key[1])]
    hybrid_counts[key] = strict(old['matches'], gt_cases[key[0]]['truth'])
regressions = [n for n in gt_cases if counts[(n, 'k3')][0] < counts[(n, 'off')][0] or counts[(n, 'k3')][1] > counts[(n, 'off')][1]]
check(regressions == [] and gt_summary['gt_neutral'] is True, f'GT regressions {regressions}')
differs = [key for key in counts if counts[key] != hybrid_counts[key]]
check(differs == [] and not any(gt_summary['cpu_versus_round43_hybrid'][k] for k in ('fewer_tp', 'more_fp', 'more_tp', 'fewer_fp')),
      f'CPU vs Metal hybrid counts differ {differs[:5]}')
for row in gt_summary['cases']:
    for arm, cell in row['arms'].items():
        tp, fp, fn = counts[(row['case'], arm)]
        check(cell['strict'][0] == dict(tp=tp, fp=fp, fn=fn), f'GT summary counts {row["case"]} {arm}')
totals = {arm: [sum(counts[(n, arm)][i] for n in gt_cases) for i in range(3)] for arm in ('off', 'k3')}
result = dict(checks=checks, problems=problems, formal=table, gt=dict(case_variants=len(gt_cases), regressions=regressions,
              cpu_strict_totals=totals, cpu_counts_differing_from_round43_hybrid=len(differs)))
print(json.dumps(result, indent=1))
sys.exit(1 if problems else 0)
