"""Stage-45 tool mutants: each must make tests/test_cpu_path_harness.py fail. Restores the tool afterwards."""
import subprocess, sys
PY = '/Users/Ayueh/Fastest_Image_Pattern_Matching/python-port/venv/bin/python'
p = 'cpp-core/tools/benchmark_cpu_path.py'
orig = open(p).read()
mutants = [
 ('M1 CPU route ignores pose GPU bytes', "            record['pose_gpu_bytes'] == 0 and record['refinement_dispatches'] == 0", "            True and record['refinement_dispatches'] == 0"),
 ('M2 CPU route ignores work-row Metal commands', "            all(row['coarse_commands'] == 0 and row['fine_commands'] == 0 and row['coarse_gpu_bytes'] == 0 for row in record['work']))", "            True)"),
 ('M3 CPU route ignores the selected refinement backend', "record['selected_refinement_backend'] == 0 and\n", "True and\n"),
 ('M4 hybrid archive identity ignored', "row['exact_vs_round43_archive'] = archived is not None and \\\n                    all(", "row['exact_vs_round43_archive'] = True or all("),
 ('M5 cross-block identity ignored', "row['cross_block_identity'] = all(stage42.outputs(call) == stage42.outputs(arm_calls[0]) for call in arm_calls)", "row['cross_block_identity'] = True"),
 ('M6 fastest named by median only', "fastest=order[0] if all(result['faster'] == order[0] for result in versus) else None", "fastest=order[0]"),
 ('M7 GT regression not recorded', "                failures.append(dict(gate='gt_regression'", "                0 and failures.append(dict(gate='gt_regression'"),
 ('M8 inputs compared by path again', "            all(manifest['input_sha256'][mine[k]] == inputs43.get(old[k]) for k in ('source', 'template'))", "            all(mine[k] == old[k] for k in ('source', 'template'))"),
 ('M9 RSS budget skipped', "                if arm_rows[right]['peak_rss_bytes'] > rss+max(RSS_GATE[0], RSS_GATE[1]*rss):", "                if False:"),
 ('M10 warm-up gate skipped', "        if warmup_wall < stage41.WARMUP_MINIMUM_MS:", "        if False:"),
]
survived = 0
try:
    for name, old, new in mutants:
        assert orig.count(old) == 1, (name, orig.count(old))
        open(p, 'w').write(orig.replace(old, new))
        r = subprocess.run([PY, '-m', 'unittest', 'cpp-core/tests/test_cpu_path_harness.py'], capture_output=True, text=True)
        failed = [l.split(' (')[0].split(': ')[1] for l in r.stderr.splitlines() if l.startswith(('FAIL:', 'ERROR:'))]
        survived += r.returncode == 0
        print(name, 'KILLED' if r.returncode else 'SURVIVED', failed, flush=True)
finally:
    open(p, 'w').write(orig)
r = subprocess.run([PY, '-m', 'unittest', 'cpp-core/tests/test_cpu_path_harness.py'], capture_output=True, text=True)
print('restored:', r.stderr.strip().splitlines()[-1], 'survived:', survived)
sys.exit(1 if survived or r.returncode else 0)
