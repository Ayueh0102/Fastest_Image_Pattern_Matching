"""Package stage-45 evidence (summaries, inputs, raw archives, run-1 comparison, decision) into cpp-core/docs/stage45-cpu-path."""
import json
from pathlib import Path
import shutil
import statistics
import tarfile

BUILD = Path('/Users/Ayueh/Fastest_Image_Pattern_Matching/build')
RAW = BUILD/'stage45-cpu-path'
DOCS = Path('/Users/Ayueh/Fastest_Image_Pattern_Matching/.claude/worktrees/round45-cpu-path/cpp-core/docs/stage45-cpu-path')
METHODS = ('cpu_full', 'hybrid_best', 'full_gpu_parallel')


def archive(name, members):
    target = DOCS/name
    with tarfile.open(target, 'w:gz', compresslevel=9) as tar:
        for path in sorted(members):
            info = tar.gettarinfo(str(path), arcname=str(path.relative_to(BUILD)))
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            with open(path, 'rb') as handle:
                tar.addfile(info, handle)
    return target


def files(*folders, keep=lambda path: True):
    return [path for folder in folders for path in (RAW/folder).rglob('*') if path.is_file() and keep(path)]


summaries = {phase: json.loads((RAW/f'{phase}-summary.json').read_text()) for phase in ('gt', 'pilot', 'formal')}
for phase in summaries:
    shutil.copyfile(RAW/f'{phase}-summary.json', DOCS/f'{phase}-summary.json')
manifests = {name: json.loads((RAW/name/'manifest.json').read_text()) for name in ('gt', 'pilot', 'formal', 'formal-2')}
inputs = {}
for name, manifest in manifests.items():
    for path, digest in manifest['input_sha256'].items():
        if inputs.setdefault(path, digest) != digest:
            raise ValueError('Input hash differs between phases: '+path)
(DOCS/'input-sha256.json').write_text(json.dumps(dict(version=1, note='Every source/template read by any stage-45 worker, from the phase '
    'manifests (identical across phases); the round-43 control scenes are regenerated under gt/inputs.', inputs=dict(sorted(inputs.items()))), indent=1)+'\n')

archives = {'raw-results-gt.tar.gz': files('gt'), 'raw-results-pilot.tar.gz': files('pilot')}
for run, label in (('formal-2', 'formal'), ('formal', 'formal-run1-interrupted')):
    for index, method in enumerate(METHODS):
        members = files(f'{run}/jobs', f'{run}/results', keep=lambda p, m=method: p.name.split('-')[-2].startswith(m) or
                        f'-{m}_frames_' in p.name)
        if index == 0:
            members.append(RAW/run/'manifest.json')
        archives[f'raw-results-{label}-{method.replace("_", "-")}.tar.gz'] = members
covered = [path for members in archives.values() for path in members]
everything = files('gt', 'pilot', 'formal', 'formal-2')
if sorted(covered) != sorted(everything) or len(set(covered)) != len(covered):
    missing = sorted(set(everything)-set(covered))[:5]
    raise ValueError(f'Archives do not cover every raw file exactly once; missing e.g. {missing}')
for name, members in archives.items():
    target = archive(name, members)
    print(name, len(members), 'files', target.stat().st_size, 'bytes')
    if target.stat().st_size >= 100*1000*1000:
        raise ValueError('Archive at or above 100 MB: '+name)

# Run 1 (interrupted, 140/144) against run 2: descriptive only, never decision evidence.
def frames_values(run):
    manifest = manifests[run]
    values, blocks = {}, {}
    for entry in manifest['executions']:
        worker = json.loads((RAW/run/entry['result']).read_text())
        warmup = manifest['frame_warmup_calls'][entry['case']]
        timed = [row['frame_wall_ms'] for row in worker['runs'][1+warmup:]]
        values.setdefault((entry['case'], entry['arm']), []).extend(timed)
        blocks.setdefault((entry['case'], entry['arm']), {})[entry['block']] = statistics.median(timed)
    return values, blocks
run1, blocks1 = frames_values('formal')
run2, _ = frames_values('formal-2')
rows = {row['name']: row for row in summaries['formal']['cases']}
comparison = []
for (case, arm), samples in sorted(run2.items()):
    one = run1.get((case, arm), [])
    m1, m2 = (statistics.median(one) if one else None), statistics.median(samples)
    comparison.append(dict(case=case, arm=arm, run1_blocks=len(blocks1.get((case, arm), {})), run1_median_ms=m1, run2_median_ms=m2,
                           run1_vs_run2_percent=100*(m1/m2-1) if m1 else None))
directions = []
for case, row in rows.items():
    for key, result in row['comparisons'].items():
        if key == 'frames_ranking':
            continue
        left, right = result['baseline'], result['candidate']
        common = sorted(set(blocks1[(case, left)]) & set(blocks1[(case, right)]))
        pooled1 = statistics.median(run1[(case, right)])/statistics.median(run1[(case, left)])-1
        same = all((blocks1[(case, right)][b] < blocks1[(case, left)][b]) == (pooled1 < 0) for b in common)
        directions.append(dict(case=case, comparison=key, run2_delta_percent=result['delta_percent'], run2_consistent=result['consistent_direction'],
                               run1_delta_percent=100*pooled1, run1_paired_blocks=len(common), run1_consistent=same,
                               same_direction=(pooled1 < 0) == (result['delta_percent'] < 0)))
(DOCS/'run1-comparison.json').write_text(json.dumps(dict(note='Interrupted formal run 1 (140/144 workers, 8K block 5 missing for four arms) against the '
    'complete run 2. Descriptive only (amendment 2); run 1 is never decision evidence.', arms=comparison, comparisons=directions), indent=1)+'\n')
print('run1 vs run2 arm medians within', round(min(c['run1_vs_run2_percent'] for c in comparison), 2), round(max(c['run1_vs_run2_percent'] for c in comparison), 2),
      '% ; comparisons same direction where run 2 consistent:',
      all(d['same_direction'] for d in directions if d['run2_consistent']))

formal, gt = summaries['formal'], summaries['gt']
decision = dict(stage=45, protocol_sha256=manifests['formal-2']['protocol_sha256'], decision_run='formal-2 (amendment 2)',
    q1=dict(question='fastest of the six per-new-frame arms, named only when faster than each other arm in all 6 blocks', fastest=formal['frames_fastest'],
            ranking={case: row['comparisons']['frames_ranking'] for case, row in rows.items()}),
    q2={case: {key: dict(baseline_median_ms=c['baseline_median_ms'], candidate_median_ms=c['candidate_median_ms'], delta_percent=c['delta_percent'],
                         candidate_faster_blocks=c['candidate_faster_blocks'], consistent_direction=c['consistent_direction'])
               for key, c in row['comparisons'].items() if key != 'frames_ranking'} for case, row in rows.items()},
    q3=dict(gt_neutral=gt['gt_neutral'], case_variants=gt['aggregate']['cases'], regressions=gt['aggregate']['regressions'],
            cpu_routes=gt['all_cpu_routes'], cpu_versus_round43_hybrid={k: (len(v) if isinstance(v, list) else v)
                                                                      for k, v in gt['cpu_versus_round43_hybrid'].items()}),
    defaults='unchanged',
    failures=dict(gt=gt['failures'], pilot=summaries['pilot']['failed_gates'], formal=formal['failed_gates']),
    amendments=['amendment-1.json: GT summarizer input lookup by path (before the GT summary, pilot and formal)',
                'amendment-2.json: formal run 1 interrupted at 140/144 by an application restart; kept, unused for decisions; complete run 2 used'],
    notes=['CPU outputs are not bit-identical to the round-43 Metal hybrid (binary64 against FP32 coarse scores) except on 8K; '
           'per GT case variant the CPU strict counts equal the Metal hybrid exactly.'])
(DOCS/'decision-and-failures.json').write_text(json.dumps(decision, indent=1)+'\n')
print('fastest', formal['frames_fastest'], 'gt_neutral', gt['gt_neutral'])
