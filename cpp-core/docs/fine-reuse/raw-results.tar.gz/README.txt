Stage 27 exact measurement records and source snapshots.
formal.json/protocol.json are immutable measurement manifests.
source/ is final source; measurement-source/ preserves the original measured versions.
Only post-processing failure handling/tests changed after measurement.
Verify every content-sha256.json entry before replay.
Replay from any cwd: python source/cpp-core/tools/benchmark_fine_reuse.py --summarize formal.json --output summary-replayed.json
Input filenames are mapped by input-paths.json; original worker paths are historical.
Frozen binaries need the recorded macOS/Qt/Metal environment; rebuild current source for another environment.
No claim of executable portability or identical timing.
