Direct uint8 image initialization versus frozen shared SIMD128 54ae7b6.
All five routes use identical compact maps and split-submission Metal frontend.
Frozen shared SIMD128, current float/direct CPU and current float/direct shared
SIMD128 refiners are compared with identical seeds and rescue settings. Ordered
proposals and sparse integer work must match. All GPU final poses must match
exactly; current float/direct CPU poses must also match exactly. CPU/GPU complete
one-to-one pose/score tolerance comparison is reported separately; independent
normal GT checks are mandatory. Negative scale and unlabeled outcomes retained.
Direct initialization avoids source/template temporary float vectors; retained
image storage and solver work must be identical within each backend pair.
Temporary capacity is an initialization metric, not retained memory or peak RSS.
Warm timings, first call and first pose creation timings are reported separately.
CPU candidate selection, rescue orchestration and final verification remain.
This is not an all-GPU pipeline. Refinement counts include initial and rescue
batches. GPU device intervals overlap CPU wait; buffer capacity overlaps RSS.

Offline replay with NumPy/OpenCV, no GPU required:
python3 EXTRACT/formal/source-snapshot/cpp-core/tools/benchmark_pose_u8_pipeline.py --summarize EXTRACT/formal/results.json --output /tmp/replayed.json

Absolute paths are historical provenance; source snapshots, input fixtures,
protocol, raw worker records and validation logs are archived. Binary hashes
are recorded; executables omitted. All member hashes are in sha256.json.
Identical immutable input fixtures share archive hardlinks; copy before editing.
