"""Collate stage-41 decisions and every failed gate from the archived summaries.

Run from the worktree root. Reads only cpp-core/docs/stage41-new-frame-cost/*-summary.json.
"""
import json
from pathlib import Path
out = Path('cpp-core/docs/stage41-new-frame-cost')
summaries = {name: json.loads((out/f'{name}-summary.json').read_text()) for name in ('pilot', 'formal')}
formal = summaries['formal']
HYBRID, GPU = 'hybrid_best', 'full_gpu_simd'
per_frame, pose, estimate, residual, memory = {}, {}, {}, {}, {}
for case in formal['cases']:
    name, arms, comparisons = case['name'], case['arms'], case['comparisons']
    row = {}
    for key, comparison in comparisons.items():
        row[key] = dict(hybrid_median_ms=comparison['hybrid_median_ms'], gpu_median_ms=comparison['gpu_median_ms'],
                        gpu_vs_hybrid_percent=comparison['delta_percent'], faster=comparison['faster'],
                        gpu_faster_blocks=f"{comparison['gpu_faster_blocks']}/{comparison['blocks']}",
                        consistent_direction=comparison['consistent_direction'])
    per_frame[name] = row
    frames = arms[f'{HYBRID}_frames']
    pose[name] = dict(measured_median_ms=frames['pose_create_ms']['median'], measured_min_ms=frames['pose_create_ms']['min'],
                      measured_max_ms=frames['pose_create_ms']['max'], measured_calls=len(frames['pose_create_ms']['values']),
                      cold_call_ms=frames['cold_pose_create_ms'], static_first_call_ms=arms[f'{HYBRID}_static']['first_pose_create_ms'],
                      static_measured_max_ms=arms[f'{HYBRID}_static']['measured_pose_create_ms']['max'])
    archived = formal['round40_estimate'][name]
    estimate[name] = dict(archived_estimate_percent=archived['archived_estimate_percent'], measured_percent=archived['measured_percent'],
                          measured_minus_estimate_points=archived['measured_minus_estimate_points'],
                          archived_first_call_pose_create_median_ms=archived['archived_first_call_pose_create_median_ms'],
                          direction_held=archived['direction_held'])
    same = case['same_build_estimate']
    residual[name] = dict(estimate_ms=same['estimate_ms'], measured_run_ms=same['measured_run_ms'], measured_frame_wall_ms=same['measured_frame_wall_ms'],
                          measured_run_minus_estimate_ms=same['measured_run_minus_estimate_ms'],
                          measured_frame_wall_minus_estimate_ms=same['measured_frame_wall_minus_estimate_ms'],
                          reuse_effect=case['reuse_effect'])
    memory[name] = {arm: dict(peak_rss_bytes=row['peak_rss_bytes'], named_gpu_bytes=row['named_gpu_bytes'],
                              frame_gpu_bytes=row['frame_gpu_bytes'], pose_gpu_bytes=row['pose_gpu_bytes'])
                    for arm, row in arms.items()}
failures = [dict(gate, dataset=dataset) for dataset, summary in summaries.items() for gate in summary['failed_gates']]
counts = {}
for gate in failures:
    key = f"{gate['dataset']}:{gate['gate']}:{gate['case']}"
    counts[key] = counts.get(key, 0)+1
decision = dict(stage=41, date='2026-10-19',
    question='Per-new-frame cost (every call through Session::updateSource) of hybrid_best versus full_gpu_simd (peak1/fine4).',
    measurement_complete=True, formal_decision_eligible=formal['formal_decision_eligible'],
    per_frame_faster={name: row['frames_frame_wall']['faster'] for name, row in per_frame.items()},
    per_frame=per_frame, pose_context=pose, round40_estimate=estimate,
    estimate_held=dict(direction_all_cases=all(row['direction_held'] for row in estimate.values()),
        statement='Direction held at 128, 512, six-object and 8K; magnitudes differ by the reported points. The estimate added the first-call pose_create_ms only; this build shows further per-frame hybrid cost (search stage and refinement on new buffers).'),
    same_build_estimate_residual=residual, memory=memory,
    universal_default_changed=False, gui_default_changed=False,
    research_recommendation='Unchanged explicit full-GPU research option peak1/fine4; with a new frame per call it is faster than the hybrid at the 128-object and 8K workloads and slower at 512 objects and the six-object control.',
    accuracy=dict(direct_gt_calls=sum(summary['counts']['gt_evaluated_calls'] for summary in summaries.values()),
                  formal_direct_gt_calls=formal['counts']['gt_evaluated_calls'], pilot_direct_gt_calls=summaries['pilot']['counts']['gt_evaluated_calls'],
                  all_zero_fp_fn=all(summary['all_accuracy_pass'] for summary in summaries.values())),
    all_routes_pass=all(summary['all_routes_pass'] for summary in summaries.values()),
    all_repeat_exact=all(summary['all_repeat_exact'] for summary in summaries.values()),
    all_failed_gates=failures, failed_gate_counts=counts,
    failure_reading='All retained failures are time_budget gates of full GPU against the hybrid per new frame (pilot 512 block 0; formal 512 and six-object, every block). No GT, route, parity, warm-up, RSS or host gate failed.',
    not_run=['Changing-content camera sequence', 'Other Metal devices, CUDA, Windows/Linux',
             'Hardware counters for the extra hybrid search time or the 8K full-GPU per-frame slowdown'])
(out/'decision-and-failures.json').write_text(json.dumps(decision, indent=2, ensure_ascii=False, allow_nan=False)+'\n')
print(json.dumps(dict(failures=len(failures), counts=counts, faster=decision['per_frame_faster'], held=decision['estimate_held']['direction_all_cases'])))
