#!/usr/bin/env python3
"""Independent audit of the stage-41 per-new-frame cost evidence.

Reads the protocol, the pilot/formal manifests and the raw worker outputs and
recomputes, without the experiment harness:

1. integrity (job/result SHA256, fingerprints, input/binary/source re-hash)
2. schedule order and job contents
3. strict ground truth on every call that has outputs (own max matching)
4. timing medians, paired block medians, deltas and directions
5. sequence routes (call index, pose context, warm-up span, frame_wall scope)
6. output exactness within arms and between frames and static arms
7. gates (time budget, RSS budget, plus the other protocol gates)
8. counts
9. comparison of every recomputed number with the published summaries

Standard library only. Nothing under cpp-core/tools is imported, no build,
test, worker or GPU program is launched; the only subprocess is a read-only
`git ls-tree` of the frozen commit. Run from the worktree root:

    python -I build/stage41-new-frame-cost/validation/independent_audit.py
"""

import hashlib
import json
import math
import re
import statistics
import subprocess
import sys
import tarfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

SCRIPT = Path(__file__).resolve()
ROOT = SCRIPT.parents[3]
DOCS = ROOT / "cpp-core" / "docs" / "stage41-new-frame-cost"
RUN = ROOT / "build" / "stage41-new-frame-cost"
OUTPUT = RUN / "validation" / "independent-audit.json"
STAGE40_DOCS = ROOT / "cpp-core" / "docs" / "stage40-ncc-closure"

TOLERANCE = 1e-9
MIB = 1024 * 1024
SUBPROCESSES = []
LIST_CAP = 20

HYBRID = "hybrid_best"
GPU = "full_gpu_simd"


def read_json(path):
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def rel(path):
    try:
        return str(Path(path).resolve().relative_to(ROOT))
    except ValueError:
        return str(path)


def distribution(values):
    values = list(values)
    if not values:
        return None
    return {
        "median": statistics.median(values),
        "min": min(values),
        "max": max(values),
        "values": values,
    }


def sign(value):
    return (value > 0) - (value < 0)


def method_of(arm):
    return arm.rsplit("_", 1)[0]


def mode_of(arm):
    return arm.rsplit("_", 1)[1]


def capped(items):
    items = list(items)
    return items[:LIST_CAP] + ([f"... {len(items) - LIST_CAP} more"] if len(items) > LIST_CAP else [])


def blocks_with(labels):
    """Block indices named by labels such as 'b3/call2: ...' or 'b0: 5 rows'."""
    found = set()
    for label in labels:
        match = re.match(r"b(\d+)", str(label))
        if match:
            found.add(int(match.group(1)))
    return sorted(found)


def png_size(path):
    with open(path, "rb") as handle:
        head = handle.read(24)
    if head[:8] != b"\x89PNG\r\n\x1a\n" or head[12:16] != b"IHDR":
        return None
    return int.from_bytes(head[16:20], "big"), int.from_bytes(head[20:24], "big")


# ---------------------------------------------------------------- protocol --

PROTOCOL_PATH = DOCS / "protocol.json"
PROTOCOL = read_json(PROTOCOL_PATH)
POSITION_TOL = float(PROTOCOL["accuracy"]["position_px"])
ANGLE_TOL = float(PROTOCOL["accuracy"]["angle_deg"])
SCALE_TOL = float(PROTOCOL["accuracy"]["relative_scale"])
SCALE_LO = 1.0 - SCALE_TOL
SCALE_HI = 1.0 + SCALE_TOL
PROTOCOL_BLOCKS = int(PROTOCOL["schedule"]["blocks"])
PROTOCOL_MEASURED = int(PROTOCOL["schedule"]["measured_calls_per_process"])
PROTOCOL_WARMUPS = dict(PROTOCOL["warmup"]["planned_calls"])
PROTOCOL_CASES = list(PROTOCOL["cases"]["primary"]) + list(PROTOCOL["cases"]["controls"])
PROTOCOL_METHODS = {name: PROTOCOL["methods"][name] for name in (HYBRID, GPU)}
# schedule.order: "per case, per block: a, b, c, d in even blocks; reversed in odd blocks"
_order_text = PROTOCOL["schedule"]["order"]
PROTOCOL_ARMS = [
    item.strip()
    for item in _order_text.split("per block:", 1)[1].split(" in even blocks", 1)[0].split(",")
]
# methods.shared_settings: "...job): pose_input_mode 1, ..., fine_fused, fine_angle_reuse, stop_layer 1."
_shared_text = PROTOCOL["methods"]["shared_settings"].split(":", 1)[1].strip().rstrip(".")
SHARED_SETTINGS = {}
for _item in _shared_text.split(","):
    _parts = _item.split()
    SHARED_SETTINGS[_parts[0]] = int(_parts[1]) if len(_parts) == 2 else True
# gates: time_budget max(2 ms, 10%), rss_budget max(8 MiB, 10%), warm-up >= 1000 ms
TIME_BUDGET_MS, TIME_BUDGET_FRACTION = 2.0, 0.10
RSS_BUDGET_BYTES, RSS_BUDGET_FRACTION = 8 * MIB, 0.10
WARMUP_GATE_MS = 1000.0
STATIC_WARMUP_SECONDS = 1.0
FRAMES_MODE_KEYS = {"source_frames", "sequence_mode", "repeats", "warmup_seconds", "source"}
DERIVED_LEAVES = {  # published numbers computed by arithmetic rather than selected from raw floats
    "delta_ms", "delta_percent", "warmup_wall_ms", "warmup_frame_wall_ms", "warmup_algorithm_ms",
    "run_ms", "run_percent", "frame_wall_minus_static_run_ms", "frame_wall_vs_static_run_percent",
    "estimate_ms", "measured_run_minus_estimate_ms", "measured_frame_wall_minus_estimate_ms",
    "gpu_static_vs_estimate_percent", "gpu_vs_hybrid_percent", "run_only_gpu_vs_hybrid_percent",
    "static_gpu_vs_hybrid_percent", "archived_estimate_percent", "archived_static_percent",
    "archived_hybrid_with_pose_create_ms", "measured_percent", "measured_run_only_percent",
    "measured_minus_estimate_points", "position_px", "angle_deg", "relative_scale",
}
BLOCKING_GATES = {
    "independent_ground_truth",
    "route_and_residency",
    "requested_algorithm_not_executed",
    "exact_repeat",
    "sequence_route",
    "static_route",
    "same_method_output_parity",
    "warmup_shorter_than_1s",
    "host_busy",
}


# ------------------------------------------------------------ ground truth --

def wrapped_angle_error(predicted, truth):
    diff = abs(float(predicted) - float(truth)) % 360.0
    return min(diff, 360.0 - diff)


def evaluate_ground_truth(truth, predictions):
    """Maximum one-to-one matching between truth poses and predictions."""
    cell = 4.0  # >= 2 * position tolerance, so the 3x3 neighbourhood is complete
    grid = {}
    for index, pred in enumerate(predictions):
        key = (math.floor(float(pred["pos_x"]) / cell), math.floor(float(pred["pos_y"]) / cell))
        grid.setdefault(key, []).append(index)
    adjacency = []
    errors = {}
    pred_degree = [0] * len(predictions)
    for t_index, item in enumerate(truth):
        tx, ty = float(item["pos_x"]), float(item["pos_y"])
        ta, ts = float(item["angle"]), float(item["scale"])
        cx, cy = math.floor(tx / cell), math.floor(ty / cell)
        candidates = []
        for gx in (cx - 1, cx, cx + 1):
            for gy in (cy - 1, cy, cy + 1):
                for p_index in grid.get((gx, gy), ()):
                    pred = predictions[p_index]
                    position = math.hypot(float(pred["pos_x"]) - tx, float(pred["pos_y"]) - ty)
                    if position > POSITION_TOL:
                        continue
                    angle = wrapped_angle_error(pred["angle"], ta)
                    if angle > ANGLE_TOL:
                        continue
                    ratio = float(pred["scale"]) / ts
                    if not (SCALE_LO <= ratio <= SCALE_HI):
                        continue
                    candidates.append(p_index)
                    errors[(t_index, p_index)] = (position, angle, abs(ratio - 1.0))
        candidates.sort()
        adjacency.append(candidates)
        for p_index in candidates:
            pred_degree[p_index] += 1

    owner = [-1] * len(predictions)

    def augment(t_index, seen):
        for p_index in adjacency[t_index]:
            if p_index in seen:
                continue
            seen.add(p_index)
            if owner[p_index] < 0 or augment(owner[p_index], seen):
                owner[p_index] = t_index
                return True
        return False

    for t_index in range(len(truth)):
        if adjacency[t_index]:
            augment(t_index, set())
    pairs = [(owner[p], p) for p in range(len(predictions)) if owner[p] >= 0]
    matched = len(pairs)
    pair_errors = [errors[pair] for pair in pairs]
    return {
        "truths": len(truth),
        "predictions": len(predictions),
        "matched": matched,
        "fp": len(predictions) - matched,
        "fn": len(truth) - matched,
        "max_position_px": max((e[0] for e in pair_errors), default=0.0),
        "max_angle_deg": max((e[1] for e in pair_errors), default=0.0),
        "max_relative_scale": max((e[2] for e in pair_errors), default=0.0),
        "ambiguous_truths": sum(1 for a in adjacency if len(a) > 1),
        "ambiguous_predictions": sum(1 for d in pred_degree if d > 1),
    }


class GroundTruthAccumulator:
    def __init__(self):
        self.calls = 0
        self.failing = []
        self.tuples = set()
        self.max_position = 0.0
        self.max_angle = 0.0
        self.max_scale = 0.0
        self.ambiguous_truths = 0
        self.ambiguous_predictions = 0

    def add(self, label, result):
        self.calls += 1
        self.tuples.add((result["matched"], result["fp"], result["fn"]))
        if result["fp"] or result["fn"]:
            self.failing.append({"call": label, "fp": result["fp"], "fn": result["fn"]})
        self.max_position = max(self.max_position, result["max_position_px"])
        self.max_angle = max(self.max_angle, result["max_angle_deg"])
        self.max_scale = max(self.max_scale, result["max_relative_scale"])
        self.ambiguous_truths += result["ambiguous_truths"]
        self.ambiguous_predictions += result["ambiguous_predictions"]

    def merge(self, other):
        self.calls += other.calls
        self.failing.extend(other.failing)
        self.tuples |= other.tuples
        self.max_position = max(self.max_position, other.max_position)
        self.max_angle = max(self.max_angle, other.max_angle)
        self.max_scale = max(self.max_scale, other.max_scale)
        self.ambiguous_truths += other.ambiguous_truths
        self.ambiguous_predictions += other.ambiguous_predictions

    def report(self):
        return {
            "calls_evaluated": self.calls,
            "calls_with_fp_or_fn": len(self.failing),
            "failing_calls": capped(self.failing),
            "matched_fp_fn_tuples": sorted([list(t) for t in self.tuples]),
            "max_position_px": self.max_position,
            "max_angle_deg": self.max_angle,
            "max_relative_scale": self.max_scale,
            "ambiguous_truth_rows": self.ambiguous_truths,
            "ambiguous_prediction_rows": self.ambiguous_predictions,
            "pass": not self.failing,
        }


# -------------------------------------------------------------- comparator --

def short(value):
    if isinstance(value, list) and len(value) > 6:
        return {"list_len": len(value), "head": value[:3]}
    if isinstance(value, dict):
        return {"dict_keys": sorted(value)[:12]}
    return value


class Comparator:
    def __init__(self):
        self.compared = 0
        self.mismatches = []
        self.missing = []
        self.max_abs_numeric_difference = 0.0
        self.inexact = []  # within tolerance but not bit-identical

    def compare(self, path, mine, theirs):
        if isinstance(mine, dict):
            if not isinstance(theirs, dict):
                self.mismatches.append({"path": path, "recomputed": short(mine), "published": short(theirs)})
                return
            for key, value in mine.items():
                if key not in theirs:
                    self.missing.append(f"{path}/{key}")
                    continue
                self.compare(f"{path}/{key}", value, theirs[key])
            return
        if isinstance(mine, list):
            if not isinstance(theirs, list) or len(mine) != len(theirs):
                self.mismatches.append({"path": path, "recomputed": short(mine), "published": short(theirs)})
                return
            for index, (a, b) in enumerate(zip(mine, theirs)):
                self.compare(f"{path}[{index}]", a, b)
            return
        self.compared += 1
        if isinstance(mine, bool) or isinstance(theirs, bool):
            ok = isinstance(mine, bool) and isinstance(theirs, bool) and mine == theirs
        elif isinstance(mine, (int, float)) and isinstance(theirs, (int, float)):
            difference = abs(float(mine) - float(theirs))
            ok = difference <= TOLERANCE
            if ok:
                self.max_abs_numeric_difference = max(self.max_abs_numeric_difference, difference)
                if difference > 0:
                    self.inexact.append({"path": path, "abs_difference": difference})
        else:
            ok = mine == theirs
        if not ok:
            entry = {"path": path, "recomputed": mine, "published": theirs}
            if isinstance(mine, (int, float)) and isinstance(theirs, (int, float)) and not isinstance(mine, bool):
                entry["abs_difference"] = abs(float(mine) - float(theirs))
            self.mismatches.append(entry)

    def report(self):
        # Medians, per-block medians, min/max and raw values are selections of the same floats and
        # must be bit-identical; only the derived arithmetic leaves below may differ by rounding.
        inexact_selections = []
        for item in self.inexact:
            leaf = re.sub(r"\[\d+\]$", "", item["path"].rsplit("/", 1)[-1])
            if leaf not in DERIVED_LEAVES:
                inexact_selections.append(item)
        return {
            "compared_values": self.compared,
            "tolerance": TOLERANCE,
            "max_abs_numeric_difference_within_tolerance": self.max_abs_numeric_difference,
            "values_not_bit_identical": len(self.inexact),
            "not_bit_identical_paths": capped(self.inexact),
            "selected_values_not_bit_identical": inexact_selections,
            "mismatches": self.mismatches,
            "missing_in_published": self.missing,
            "pass": not self.mismatches and not self.missing and not inexact_selections,
        }


# ------------------------------------------------------------- phase audit --

def scan_keys(value, path=""):
    """Yield (path, key) for every key and string value that could carry GT."""
    if isinstance(value, dict):
        for key, item in value.items():
            lowered = key.lower()
            if "truth" in lowered or lowered in {"gt", "ground_truth", "corners", "metadata", "expected"}:
                yield (f"{path}/{key}", "forbidden_key")
            yield from scan_keys(item, f"{path}/{key}")
    elif isinstance(value, list):
        for index, item in enumerate(value):
            yield from scan_keys(item, f"{path}[{index}]")
    elif isinstance(value, str) and value.lower().endswith(".json"):
        yield (path, "json_path_value")


def route_problems(row, method, refine):
    problems = []
    fg = row.get("full_gpu") or {}
    if method == GPU:
        wanted = {
            "enabled": True,
            "command_buffers": 1,
            "cpu_waits": 1,
            "intermediate_readbacks": 0,
            "peak_mode": 1,
            "fine_mode": 4,
        }
        for key, value in wanted.items():
            if fg.get(key) != value or type(fg.get(key)) is not type(value):
                problems.append(f"full_gpu.{key}={fg.get(key)!r}")
    else:
        if fg.get("enabled") is not False:
            problems.append(f"full_gpu.enabled={fg.get('enabled')!r}")
        if row.get("configured_refinement_backend") != 1:
            problems.append("configured_refinement_backend")
        if refine:
            if row.get("selected_refinement_backend") != 1:
                problems.append(f"selected_refinement_backend={row.get('selected_refinement_backend')!r}")
            if not (row.get("refinement_command_buffers") or 0) > 0:
                problems.append("refinement_command_buffers=0")
        elif row.get("selected_refinement_backend") != 0:
            problems.append(f"core_only selected_refinement_backend={row.get('selected_refinement_backend')!r}")
    return problems


class PhaseAudit:
    def __init__(self, phase, expected_blocks, loader=None):
        self.phase = phase
        self.expected_blocks = expected_blocks
        self.loader = loader or read_json  # negative controls inject in-memory mutations here
        self.run_dir = RUN / phase
        self.manifest_path = self.run_dir / "manifest.json"
        self.manifest = self.loader(self.manifest_path)
        self.summary_path = DOCS / f"{phase}-summary.json"
        self.summary = self.loader(self.summary_path)
        self.blocks = int(self.manifest["blocks"])
        self.arms = list(self.manifest["arms"])
        self.cases = [c["name"] for c in self.manifest["cases"]]
        self.case = {c["name"]: c for c in self.manifest["cases"]}
        self.executions = list(self.manifest["executions"])
        self.index = {}
        for entry in self.executions:
            self.index.setdefault((entry["case"], entry["arm"], entry["block"]), []).append(entry)
        self.measured = int(self.manifest["measured_calls"])
        self.warmups = dict(self.manifest["warmup_calls"])
        self.source_size = {}
        for name, case in self.case.items():
            self.source_size[name] = png_size(case["source"])
        # filled by scan()
        self.gt = {}
        self.block_data = {}
        self.sequence = {}
        self.exact = {}
        self.routes = {}
        self.algorithm = {}
        self.refs = {}
        self.stdout_check = {"compared": 0, "equal": 0, "problems": [], "nonempty_stderr": []}
        self.worker_flags = []

    # ------------------------------------------------------------ section 1
    def integrity(self):
        failures = []
        listed = set()
        hash_problems = []
        job_ok = result_ok = 0
        for entry in self.executions:
            for kind in ("job", "result"):
                listed.add(entry[kind])
                path = self.run_dir / entry[kind]
                if not path.is_file():
                    hash_problems.append({"file": entry[kind], "problem": "missing"})
                    continue
                actual = sha256_file(path)
                if actual != entry[f"{kind}_sha256"]:
                    hash_problems.append({"file": entry[kind], "expected": entry[f"{kind}_sha256"], "actual": actual})
                elif kind == "job":
                    job_ok += 1
                else:
                    result_ok += 1
        if hash_problems:
            failures.append("execution file SHA256 mismatch")
        unlisted = []
        for sub in ("jobs", "results"):
            for path in sorted((self.run_dir / sub).iterdir()):
                name = f"{sub}/{path.name}"
                if name in listed:
                    continue
                if sub == "jobs" and (path.name.endswith(".stdout.txt") or path.name.endswith(".stderr.txt")):
                    continue
                unlisted.append(name)
        if unlisted:
            failures.append("unlisted files in jobs/ or results/")

        flags = {
            "complete": self.manifest.get("complete") is True,
            "unchanged": self.manifest.get("unchanged") is True,
        }
        after = self.manifest.get("after_sha256") or {}
        for key in ("source_sha256", "binary_sha256", "input_sha256"):
            flags[f"{key}_equals_after"] = key in self.manifest and self.manifest[key] == after.get(key)
        for key, value in flags.items():
            if not value:
                failures.append(f"manifest flag {key} false")

        rehash = {}
        for key in ("input_sha256", "binary_sha256"):
            ok, problems = 0, []
            for path, expected in self.manifest[key].items():
                file_path = Path(path)
                if not file_path.is_file():
                    problems.append({"path": path, "problem": "missing"})
                    continue
                actual = sha256_file(file_path)
                if actual == expected:
                    ok += 1
                else:
                    problems.append({"path": path, "expected": expected, "actual": actual})
            rehash[key] = {"listed": len(self.manifest[key]), "match": ok, "problems": problems}
            if problems:
                failures.append(f"{key} re-hash mismatch")

        compiled_prefixes = (
            "cpp-core/src/",
            "cpp-core/include/",
            "cpp-core/experiments/",
            "cpp-core/tools/",
            "cpp-core/tests/",
        )
        differ_code, differ_other, missing = [], [], []
        for path, expected in self.manifest["source_sha256"].items():
            file_path = ROOT / path
            if not file_path.is_file():
                missing.append(path)
                continue
            if sha256_file(file_path) != expected:
                if path.startswith(compiled_prefixes) or path.endswith("CMakeLists.txt"):
                    differ_code.append(path)
                else:
                    differ_other.append(path)
        worktree = {
            "listed": len(self.manifest["source_sha256"]),
            "match": len(self.manifest["source_sha256"]) - len(differ_code) - len(differ_other) - len(missing),
            "differ_tools_tests_src_experiments_cmake": differ_code,
            "differ_other": differ_other,
            "missing": missing,
            "note": "Report-only per audit brief (current worktree vs the run fingerprint); not part of all_checks_pass.",
        }

        # host records: competing processes (host_busy) and monotonic timestamps
        busy = []
        for entry in self.executions:
            competitors = entry.get("host", {}).get("competing_processes")
            if competitors is None or competitors:
                busy.append({"case": entry["case"], "arm": entry["arm"], "block": entry["block"], "competing": competitors})
        stamps = [entry.get("host", {}).get("utc", "") for entry in self.executions]
        host = {
            "executions_with_host_record": sum(1 for e in self.executions if "host" in e),
            "busy_executions": busy,
            "before_competing": self.manifest.get("host", {}).get("before", {}).get("competing_processes"),
            "after_competing": self.manifest.get("host", {}).get("after", {}).get("competing_processes"),
            "utc_strictly_increasing": all(a < b for a, b in zip(stamps, stamps[1:])),
            "max_load_average_1m": max(e["host"]["load_average"][0] for e in self.executions if "host" in e),
            "info_max_gpu_utilization_percent_before_worker": max(
                max(e["host"].get("gpu_device_utilization_percent") or [0]) for e in self.executions if "host" in e
            ),
            "info_workers_started_with_gpu_utilization_over_50_percent": sum(
                1 for e in self.executions
                if "host" in e and max(e["host"].get("gpu_device_utilization_percent") or [0]) > 50
            ),
        }
        if not host["utc_strictly_increasing"]:
            failures.append("host utc not increasing")
        if host["before_competing"] or host["after_competing"]:
            failures.append("competing processes before/after run")

        # run log order equals manifest execution order
        log_path = RUN / "validation" / f"{self.phase}.log"
        log = {"path": rel(log_path)}
        if log_path.is_file():
            lines = log_path.read_text(encoding="utf-8").splitlines()
            running = [line[len("Running "):] for line in lines if line.startswith("Running ")]
            expected = [Path(e["result"]).name[: -len(".json")] for e in self.executions]
            log["running_lines"] = len(running)
            log["order_equals_manifest"] = running == expected
            log["exit_line"] = next((line for line in reversed(lines) if line.startswith("exit=")), None)
            if not log["order_equals_manifest"] or log["exit_line"] != "exit=0":
                failures.append("run log order or exit status differs")
        else:
            log["missing"] = True
            failures.append("run log missing")

        return {
            "manifest_path": rel(self.manifest_path),
            "manifest_sha256": sha256_file(self.manifest_path),
            "execution_files": {
                "executions": len(self.executions),
                "job_sha256_ok": job_ok,
                "result_sha256_ok": result_ok,
                "problems": hash_problems,
                "unlisted_files": unlisted,
            },
            "worker_stdout_equals_result_json": self.stdout_check,
            "manifest_flags": flags,
            "rehash": rehash,
            "worktree_sources": worktree,
            "host": host,
            "run_log": log,
            "failures": failures,
            "pass": not failures and self.stdout_check["equal"] == len(self.executions)
            and not self.stdout_check["problems"] and not self.stdout_check["nonempty_stderr"],
        }

    # ------------------------------------------------------------ section 2
    def order(self):
        failures = []
        details = {
            "manifest_arms": self.arms,
            "protocol_arm_order": PROTOCOL_ARMS,
            "arms_match_protocol": self.arms == PROTOCOL_ARMS,
            "cases_match_protocol": sorted(self.cases) == sorted(PROTOCOL_CASES),
            "blocks": self.blocks,
            "blocks_expected": self.expected_blocks,
            "measured_calls": self.measured,
            "warmup_calls": self.warmups,
            "warmup_calls_match_protocol_plan": self.warmups == PROTOCOL_WARMUPS,
            "static_warmup_seconds": self.manifest.get("static_warmup_seconds"),
        }
        for key in ("arms_match_protocol", "cases_match_protocol", "warmup_calls_match_protocol_plan"):
            if not details[key]:
                failures.append(key)
        if self.blocks != self.expected_blocks:
            failures.append("block count")
        if self.measured != PROTOCOL_MEASURED:
            failures.append("measured calls")
        if self.manifest.get("static_warmup_seconds") != STATIC_WARMUP_SECONDS:
            failures.append("static warm-up seconds")

        counts = Counter((e["case"], e["arm"], e["block"]) for e in self.executions)
        expected_keys = {(c, a, b) for c in self.cases for a in self.arms for b in range(self.blocks)}
        duplicates = [list(k) for k, v in counts.items() if v != 1]
        missing = [list(k) for k in sorted(expected_keys - set(counts))]
        unexpected = [list(k) for k in sorted(set(counts) - expected_keys)]
        if duplicates or missing or unexpected:
            failures.append("execution set")
        per_case = {}
        for case in self.cases:
            sequence = [(e["block"], e["arm"]) for e in self.executions if e["case"] == case]
            expected = []
            for block in range(self.blocks):
                arms = self.arms if block % 2 == 0 else list(reversed(self.arms))
                expected.extend((block, arm) for arm in arms)
            per_case[case] = sequence == expected
            if not per_case[case]:
                failures.append(f"order {case}")
        details.update({
            "unique_case_arm_block": not duplicates and not missing and not unexpected,
            "duplicates": duplicates,
            "missing": missing,
            "unexpected": unexpected,
            "per_case_alternating_order": per_case,
        })

        # job contents
        job_problems = []
        jobs = {}
        for entry in self.executions:
            job = self.loader(self.run_dir / entry["job"])
            key = (entry["case"], entry["arm"], entry["block"])
            jobs[key] = job
            case = self.case[entry["case"]]
            method, mode = method_of(entry["arm"]), mode_of(entry["arm"])
            label = f"{entry['case']}/{entry['arm']}/b{entry['block']}"
            problems = []
            for path, kind in scan_keys(job):
                problems.append(f"{kind} {path}")
            warm = self.warmups[entry["case"]]
            if mode == "frames":
                if job.get("warmup_seconds") != 0:
                    problems.append(f"warmup_seconds={job.get('warmup_seconds')!r}")
                if job.get("sequence_mode") != "reuse":
                    problems.append(f"sequence_mode={job.get('sequence_mode')!r}")
                frames = job.get("source_frames")
                if not isinstance(frames, list) or len(frames) != 1 or frames[0] != case["source"]:
                    problems.append(f"source_frames={frames!r}")
                if "source" in job:
                    problems.append("frames job has source")
                if job.get("repeats") != 1 + warm + self.measured:
                    problems.append(f"repeats={job.get('repeats')!r} expected {1 + warm + self.measured}")
            else:
                if job.get("warmup_seconds") != STATIC_WARMUP_SECONDS:
                    problems.append(f"warmup_seconds={job.get('warmup_seconds')!r}")
                if job.get("repeats") != self.measured:
                    problems.append(f"repeats={job.get('repeats')!r} expected {self.measured}")
                if job.get("source") != case["source"]:
                    problems.append("static source differs from case source")
                if "source_frames" in job or "sequence_mode" in job:
                    problems.append("static job has sequence keys")
            for key in ("template", "scales", "angle", "limit", "score", "overlap", "stop_layer", "proposal_score"):
                if key in case and job.get(key) != case[key]:
                    problems.append(f"{key}={job.get(key)!r} case={case[key]!r}")
                if key not in case and key in job:
                    problems.append(f"{key} present in job but not in case")
            if job.get("subpixel") is not bool(case.get("subpixel", 0)):
                problems.append(f"subpixel={job.get('subpixel')!r}")
            refine = case["workflow"] == "full_rescue"
            if job.get("refine") is not refine:
                problems.append(f"refine={job.get('refine')!r} workflow={case['workflow']}")
            for key, value in PROTOCOL_METHODS[method].items():
                if job.get(key) != value:
                    problems.append(f"{key}={job.get(key)!r} protocol={value!r}")
            arm_options = self.manifest["arm_options"][entry["arm"]]
            if arm_options.get("method") != method or arm_options.get("mode") != mode:
                problems.append("manifest arm_options method/mode")
            for key, value in PROTOCOL_METHODS[method].items():
                if arm_options.get(key) != value:
                    problems.append(f"manifest arm_options {key}")
            for key, value in SHARED_SETTINGS.items():
                if job.get(key) != value:
                    problems.append(f"shared {key}={job.get(key)!r} protocol={value!r}")
            for path in [job.get("template"), job.get("source")] + list(job.get("source_frames") or []):
                if path is not None and path not in self.manifest["input_sha256"]:
                    problems.append(f"input not fingerprinted: {path}")
            if problems:
                job_problems.append({"job": label, "problems": problems})
        # jobs identical across blocks; frames and static differ only in mode keys
        cross = []
        for case in self.cases:
            for arm in self.arms:
                ref = jobs.get((case, arm, 0))
                for block in range(1, self.blocks):
                    if jobs.get((case, arm, block)) != ref:
                        cross.append(f"{case}/{arm}/b{block} differs from b0")
            for method in (HYBRID, GPU):
                for block in range(self.blocks):
                    frames = jobs.get((case, f"{method}_frames", block)) or {}
                    static = jobs.get((case, f"{method}_static", block)) or {}
                    a = {k: v for k, v in frames.items() if k not in FRAMES_MODE_KEYS}
                    b = {k: v for k, v in static.items() if k not in FRAMES_MODE_KEYS}
                    if a != b:
                        cross.append(f"{case}/{method}/b{block} frames/static settings differ")
        if job_problems or cross:
            failures.append("job contents")
        details.update({
            "jobs_checked": len(jobs),
            "jobs_without_ground_truth": sum(
                1 for j in jobs.values() if not any(k == "forbidden_key" for _, k in scan_keys(j))
            ),
            "job_problems": job_problems,
            "cross_job_problems": cross,
            "shared_settings_from_protocol": SHARED_SETTINGS,
            "failures": failures,
            "pass": not failures,
        })
        return details

    # ------------------------------------------------------- results scanning
    def scan(self):
        for case in self.cases:
            info = self.case[case]
            truth = info["truth"]
            refine = info["workflow"] == "full_rescue"
            warm = self.warmups[case]
            scales = len(info["scales"])
            size = self.source_size[case]
            for arm in self.arms:
                method, mode = method_of(arm), mode_of(arm)
                key = (case, arm)
                self.gt[key] = GroundTruthAccumulator()
                self.block_data[key] = []
                self.sequence[key] = {
                    "rows_checked": 0,
                    "violations": [],
                    "min_warmup_span_ms": None,
                    "warmup_span_ms": [],
                    "min_frame_wall_slack_ms": None,
                    "max_frame_wall_slack_ms": None,
                    "min_source_decode_ms_after_call0": None,
                    "frame_wall_slack_violations": 0,
                    "call0_frame_wall_minus_total_plus_construct_ms": [],
                    "static_warmup_ms_sums": [],
                }
                self.exact[key] = {"calls_compared": 0, "differences": [], "worker_flags_true": True}
                self.routes[key] = []
                self.algorithm[key] = []
                for block in range(self.blocks):
                    entries = self.index.get((case, arm, block)) or []
                    if len(entries) != 1:
                        self.sequence[key]["violations"].append(f"b{block}: {len(entries)} executions")
                        continue
                    entry = entries[0]
                    result = self.loader(self.run_dir / entry["result"])
                    self._check_stdout(entry, result)
                    if mode == "frames":
                        self._scan_frames(case, arm, method, block, result, truth, refine, warm, scales, size)
                    else:
                        self._scan_static(case, arm, method, block, result, truth, refine)
                    del result

    def _check_stdout(self, entry, result):
        stem = Path(entry["job"]).name[: -len(".json")]
        stdout_path = self.run_dir / "jobs" / f"{stem}.stdout.txt"
        stderr_path = self.run_dir / "jobs" / f"{stem}.stderr.txt"
        self.stdout_check["compared"] += 1
        try:
            stdout = json.loads(stdout_path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as error:
            self.stdout_check["problems"].append({"stem": stem, "error": str(error)})
            return
        if stdout == result:
            self.stdout_check["equal"] += 1
        else:
            self.stdout_check["problems"].append({"stem": stem, "error": "stdout JSON differs from result JSON"})
        if not stderr_path.is_file() or stderr_path.stat().st_size:
            self.stdout_check["nonempty_stderr"].append(stem)

    def _exact(self, key, block, label, call):
        record = self.exact[key]
        if key not in self.refs:
            self.refs[key] = {"matches": call["matches"], "proposals": call["proposals"], "label": f"b{block}/{label}"}
        ref = self.refs[key]
        record["calls_compared"] += 1
        if call["matches"] != ref["matches"]:
            record["differences"].append(f"b{block}/{label} matches")
        if call["proposals"] != ref["proposals"]:
            record["differences"].append(f"b{block}/{label} proposals")

    def _scan_frames(self, case, arm, method, block, result, truth, refine, warm, scales, size):
        key = (case, arm)
        seq = self.sequence[key]
        rows = result.get("runs") or []
        expected_rows = 1 + warm + self.measured
        violations = seq["violations"]
        if len(rows) != expected_rows:
            violations.append(f"b{block}: {len(rows)} rows, expected {expected_rows}")
        for flag in ("drained", "exact_sequence_repeat"):
            if result.get(flag) is not True:
                violations.append(f"b{block}: {flag}={result.get(flag)!r}")
        if result.get("exact_sequence_repeat") is not True:
            self.exact[key]["worker_flags_true"] = False
        if result.get("sequence_mode") != "reuse" or result.get("source_frames") != [self.case[case]["source"]]:
            violations.append(f"b{block}: sequence_mode/source_frames")
        if result.get("calls") != len(rows) or result.get("cycles") != len(rows):
            violations.append(f"b{block}: calls/cycles {result.get('calls')}/{result.get('cycles')} rows {len(rows)}")
        for index, row in enumerate(rows):
            seq["rows_checked"] += 1
            label = f"call{index}"
            if row.get("call") != index:
                violations.append(f"b{block}/{label}: call={row.get('call')!r}")
            if row.get("exact_sequence_repeat") is not True:
                self.exact[key]["worker_flags_true"] = False
            pose = row.get("pose_create_ms")
            if method == HYBRID and refine:
                if not (isinstance(pose, (int, float)) and pose > 0):
                    violations.append(f"b{block}/{label}: pose_create_ms={pose!r} (refining hybrid needs > 0)")
            elif pose != 0:
                violations.append(f"b{block}/{label}: pose_create_ms={pose!r} (must be 0)")
            if size is not None and (row.get("source_width"), row.get("source_height")) != size:
                violations.append(f"b{block}/{label}: source dims {row.get('source_width')}x{row.get('source_height')} png {size}")
            if row.get("source_path") != self.case[case]["source"] or row.get("source_index") != 0:
                violations.append(f"b{block}/{label}: source_path/index")
            if index == 0:
                if not (row.get("construct_ms") or 0) > 0:
                    violations.append(f"b{block}/{label}: call 0 did not construct")
                if row.get("source_copy_bytes") != 0 or row.get("source_generation") != 0:
                    violations.append(f"b{block}/{label}: call 0 copy/generation")
                if row.get("pose_invalidated") is not False:
                    violations.append(f"b{block}/{label}: call 0 pose_invalidated")
                if row.get("source_decode_ms") != 0:
                    violations.append(f"b{block}/{label}: call 0 source_decode_ms={row.get('source_decode_ms')!r}")
                seq["call0_frame_wall_minus_total_plus_construct_ms"].append(
                    row["frame_wall_ms"] - (row["total_ms"] + row["construct_ms"])
                )
            else:
                if row.get("construct_ms") != 0:
                    violations.append(f"b{block}/{label}: construct_ms={row.get('construct_ms')!r} after call 0")
                expected_copy = size[0] * size[1] if size else None
                if row.get("source_copy_bytes") != expected_copy:
                    violations.append(f"b{block}/{label}: source_copy_bytes={row.get('source_copy_bytes')!r} expected {expected_copy}")
                if row.get("source_generation") != index:
                    violations.append(f"b{block}/{label}: source_generation={row.get('source_generation')!r}")
                if row.get("retained_template_models") != scales:
                    violations.append(f"b{block}/{label}: retained_template_models={row.get('retained_template_models')!r}")
                if row.get("source_dimensions_changed") is not False:
                    violations.append(f"b{block}/{label}: source_dimensions_changed")
                wanted = method == HYBRID and refine
                if row.get("pose_invalidated") is not wanted:
                    violations.append(f"b{block}/{label}: pose_invalidated={row.get('pose_invalidated')!r} expected {wanted}")
                decode = row.get("source_decode_ms")
                if not (isinstance(decode, (int, float)) and decode > 0):
                    violations.append(f"b{block}/{label}: no fresh decode (source_decode_ms={decode!r})")
                elif seq["min_source_decode_ms_after_call0"] is None or decode < seq["min_source_decode_ms_after_call0"]:
                    seq["min_source_decode_ms_after_call0"] = decode
                slack = row["frame_wall_ms"] - (row["total_ms"] + row["source_update_ms"])
                if seq["max_frame_wall_slack_ms"] is None or slack > seq["max_frame_wall_slack_ms"]:
                    seq["max_frame_wall_slack_ms"] = slack
                if seq["min_frame_wall_slack_ms"] is None or slack < seq["min_frame_wall_slack_ms"]:
                    seq["min_frame_wall_slack_ms"] = slack
                if slack < 0:
                    seq["frame_wall_slack_violations"] += 1
                    violations.append(f"b{block}/{label}: frame_wall_ms < total_ms + source_update_ms by {-slack}")
            problems = route_problems(row, method, refine)
            if problems:
                self.routes[key].append(f"b{block}/{label}: {', '.join(problems)}")
            if method == GPU and (row.get("full_gpu") or {}).get("fine_effective_mode") != 4:
                self.algorithm[key].append(f"b{block}/{label}: fine_effective_mode={(row.get('full_gpu') or {}).get('fine_effective_mode')!r}")
            self.gt[key].add(f"b{block}/{label}", evaluate_ground_truth(truth, row["matches"]))
            self._exact(key, block, label, row)

        span = None
        if len(rows) > warm:
            span = rows[warm]["elapsed_ms"] - rows[0]["elapsed_ms"]
            seq["warmup_span_ms"].append(span)
            if seq["min_warmup_span_ms"] is None or span < seq["min_warmup_span_ms"]:
                seq["min_warmup_span_ms"] = span
        warm_rows = rows[1 : 1 + warm]
        measured = rows[1 + warm : 1 + warm + self.measured]
        self.block_data[key].append({
            "block": block,
            "measured_frame_wall": [r["frame_wall_ms"] for r in measured],
            "measured_total": [r["total_ms"] for r in measured],
            "measured_source_update": [r["source_update_ms"] for r in measured],
            "measured_pose_create": [r["pose_create_ms"] for r in measured],
            "measured_source_decode": [r["source_decode_ms"] for r in measured],
            "measured_current_rss": [r["memory"]["current_rss_bytes"] for r in measured],
            "warm_pose_create": [r["pose_create_ms"] for r in warm_rows],
            "warmup_calls": len(warm_rows),
            "warmup_wall_ms": span,
            "warmup_frame_wall_ms": sum(r["frame_wall_ms"] for r in warm_rows),
            "cold_frame_wall_ms": rows[0]["frame_wall_ms"],
            "cold_total_ms": rows[0]["total_ms"],
            "cold_construct_ms": rows[0]["construct_ms"],
            "cold_pose_create_ms": rows[0]["pose_create_ms"],
            "peak_rss_bytes": result["final_memory"]["peak_rss_bytes"],
            "after_release_current_rss_bytes": result["after_release_memory"]["current_rss_bytes"],
            "after_release_peak_rss_bytes": result["after_release_memory"]["peak_rss_bytes"],
            "rows": len(rows),
        })

    def _scan_static(self, case, arm, method, block, result, truth, refine):
        key = (case, arm)
        seq = self.sequence[key]
        violations = seq["violations"]
        first = result.get("first")
        runs = result.get("runs") or []
        warmups = result.get("warmups_ms") or []
        if first is None:
            violations.append(f"b{block}: no first call")
            return
        if len(runs) != self.measured:
            violations.append(f"b{block}: {len(runs)} runs, expected {self.measured}")
        if result.get("exact_repeat") is not True:
            self.exact[key]["worker_flags_true"] = False
            violations.append(f"b{block}: exact_repeat={result.get('exact_repeat')!r}")
        seq["static_warmup_ms_sums"].append(sum(warmups))
        calls = [("first", first)] + [(f"run{i}", run) for i, run in enumerate(runs)]
        for label, call in calls:
            seq["rows_checked"] += 1
            pose = call.get("pose_create_ms")
            if method == HYBRID and refine and label == "first":
                if not (isinstance(pose, (int, float)) and pose > 0):
                    violations.append(f"b{block}/{label}: first-call pose_create_ms={pose!r} (refining hybrid needs > 0)")
            elif pose != 0:
                violations.append(f"b{block}/{label}: pose_create_ms={pose!r} (must be 0)")
            problems = route_problems(call, method, refine)
            if problems:
                self.routes[key].append(f"b{block}/{label}: {', '.join(problems)}")
            if method == GPU and (call.get("full_gpu") or {}).get("fine_effective_mode") != 4:
                self.algorithm[key].append(f"b{block}/{label}: fine_effective_mode")
            self.gt[key].add(f"b{block}/{label}", evaluate_ground_truth(truth, call["matches"]))
            self._exact(key, block, label, call)
        self.block_data[key].append({
            "block": block,
            "runs_total": [r["total_ms"] for r in runs],
            "runs_pose_create": [r["pose_create_ms"] for r in runs],
            "first_total_ms": first["total_ms"],
            "first_pose_create_ms": first["pose_create_ms"],
            "warmup_calls": len(warmups),
            "warmup_algorithm_ms": sum(warmups),
            "construct_ms": result.get("construct_ms"),
            "peak_rss_bytes": result["final_memory"]["peak_rss_bytes"],
        })

    # ---------------------------------------------------------- sections 3-8
    def ground_truth(self):
        by_case_arm = {}
        by_arm = {arm: GroundTruthAccumulator() for arm in self.arms}
        total = GroundTruthAccumulator()
        for case in self.cases:
            by_case_arm[case] = {}
            for arm in self.arms:
                acc = self.gt[(case, arm)]
                by_case_arm[case][arm] = acc.report()
                by_arm[arm].merge(acc)
                total.merge(acc)
        total_report = total.report()
        return {
            "thresholds": {
                "position_px": POSITION_TOL,
                "angle_deg": ANGLE_TOL,
                "scale_ratio_range": [SCALE_LO, SCALE_HI],
                "matching": "maximum one-to-one bipartite matching (augmenting paths); FP = predictions - matched, FN = truths - matched",
            },
            "by_case_arm": by_case_arm,
            "by_arm": {arm: acc.report() for arm, acc in by_arm.items()},
            "total": total_report,
            "pass": total_report["pass"],
        }

    def arm_summary(self, case, arm):
        method, mode = method_of(arm), mode_of(arm)
        blocks = self.block_data[(case, arm)]
        acc = self.gt[(case, arm)]
        refine = self.case[case]["workflow"] == "full_rescue"
        common = {
            "all_gt_pass": not acc.failing,
            "accuracy_counts": sorted([list(t) for t in acc.tuples]),
            "max_errors": {
                "position_px": acc.max_position,
                "angle_deg": acc.max_angle,
                "relative_scale": acc.max_scale,
            },
            "route_valid": not self.routes[(case, arm)],
            "requested_algorithm_executed": not self.algorithm[(case, arm)],
            "repeat_exact": not self.exact[(case, arm)]["differences"] and self.exact[(case, arm)]["worker_flags_true"],
            "cold_calls": len(blocks),
            "measured_calls": sum(
                len(b["measured_frame_wall"]) if mode == "frames" else len(b["runs_total"]) for b in blocks
            ),
            "gt_evaluated_calls": acc.calls,
        }
        if mode == "frames":
            out = {
                "method": method,
                "mode": mode,
                "frame_wall_ms": distribution(v for b in blocks for v in b["measured_frame_wall"]),
                "total_ms": distribution(v for b in blocks for v in b["measured_total"]),
                "source_update_ms": distribution(v for b in blocks for v in b["measured_source_update"]),
                "pose_create_ms": distribution(v for b in blocks for v in b["measured_pose_create"]),
                "source_decode_ms": distribution(v for b in blocks for v in b["measured_source_decode"]),
                "blocks": [
                    {
                        "block": b["block"],
                        "frame_wall_median_ms": statistics.median(b["measured_frame_wall"]),
                        "total_median_ms": statistics.median(b["measured_total"]),
                        "warmup_calls": b["warmup_calls"],
                        "warmup_wall_ms": b["warmup_wall_ms"],
                        "warmup_frame_wall_ms": b["warmup_frame_wall_ms"],
                        "cold_frame_wall_ms": b["cold_frame_wall_ms"],
                        "cold_total_ms": b["cold_total_ms"],
                        "cold_construct_ms": b["cold_construct_ms"],
                        "cold_pose_create_ms": b["cold_pose_create_ms"],
                        "peak_rss_bytes": b["peak_rss_bytes"],
                        "after_release_current_rss_bytes": b["after_release_current_rss_bytes"],
                    }
                    for b in blocks
                ],
                "cold_pose_create_ms": [b["cold_pose_create_ms"] for b in blocks],
                "warmup_pose_create_ms": distribution(v for b in blocks for v in b["warm_pose_create"]),
                "peak_rss_bytes": max(b["peak_rss_bytes"] for b in blocks),
                "measured_current_rss_bytes": distribution(v for b in blocks for v in b["measured_current_rss"]),
                "sequence_route_valid": not self.sequence[(case, arm)]["violations"],
                "warmup_calls": sum(b["warmup_calls"] for b in blocks),
            }
        else:
            out = {
                "method": method,
                "mode": mode,
                "total_ms": distribution(v for b in blocks for v in b["runs_total"]),
                "blocks": [
                    {
                        "block": b["block"],
                        "total_median_ms": statistics.median(b["runs_total"]),
                        "first_total_ms": b["first_total_ms"],
                        "first_pose_create_ms": b["first_pose_create_ms"],
                        "warmup_calls": b["warmup_calls"],
                        "warmup_algorithm_ms": b["warmup_algorithm_ms"],
                        "construct_ms": b["construct_ms"],
                        "peak_rss_bytes": b["peak_rss_bytes"],
                    }
                    for b in blocks
                ],
                "first_pose_create_ms": [b["first_pose_create_ms"] for b in blocks],
                "measured_pose_create_ms": distribution(v for b in blocks for v in b["runs_pose_create"]),
                "peak_rss_bytes": max(b["peak_rss_bytes"] for b in blocks),
                "static_route_valid": not self.sequence[(case, arm)]["violations"],
                "warmup_calls": sum(b["warmup_calls"] for b in blocks),
            }
        out.update(common)
        out["_refine"] = refine
        return out

    def paired_comparison(self, metric, hybrid_blocks, gpu_blocks):
        hybrid_pooled = [v for b in hybrid_blocks for v in b]
        gpu_pooled = [v for b in gpu_blocks for v in b]
        hybrid_median = statistics.median(hybrid_pooled)
        gpu_median = statistics.median(gpu_pooled)
        paired = []
        for index, (h, g) in enumerate(zip(hybrid_blocks, gpu_blocks)):
            hm, gm = statistics.median(h), statistics.median(g)
            paired.append({
                "block": index,
                "hybrid_ms": hm,
                "gpu_ms": gm,
                "delta_ms": gm - hm,
                "delta_percent": 100.0 * (gm / hm - 1.0),
                "within_regression_budget": gm <= hm + max(TIME_BUDGET_MS, TIME_BUDGET_FRACTION * hm),
            })
        pooled_sign = sign(gpu_median - hybrid_median)
        consistent = pooled_sign != 0 and all(sign(p["gpu_ms"] - p["hybrid_ms"]) == pooled_sign for p in paired)
        faster = (GPU if pooled_sign < 0 else HYBRID) if consistent else None
        return {
            "metric": metric,
            "hybrid_median_ms": hybrid_median,
            "gpu_median_ms": gpu_median,
            "delta_ms": gpu_median - hybrid_median,
            "delta_percent": 100.0 * (gpu_median / hybrid_median - 1.0),
            "paired": paired,
            "gpu_faster_blocks": sum(1 for p in paired if p["gpu_ms"] < p["hybrid_ms"]),
            "blocks": len(paired),
            "consistent_direction": consistent,
            "faster": faster,
        }

    def timing(self, arms_summary):
        out = {}
        for case in self.cases:
            data = {arm: self.block_data[(case, arm)] for arm in self.arms}
            comparisons = {
                "frames_frame_wall": self.paired_comparison(
                    "frame_wall_ms",
                    [b["measured_frame_wall"] for b in data[f"{HYBRID}_frames"]],
                    [b["measured_frame_wall"] for b in data[f"{GPU}_frames"]],
                ),
                "frames_run_only": self.paired_comparison(
                    "total_ms",
                    [b["measured_total"] for b in data[f"{HYBRID}_frames"]],
                    [b["measured_total"] for b in data[f"{GPU}_frames"]],
                ),
                "static_run_only": self.paired_comparison(
                    "total_ms",
                    [b["runs_total"] for b in data[f"{HYBRID}_static"]],
                    [b["runs_total"] for b in data[f"{GPU}_static"]],
                ),
            }
            arms = arms_summary[case]
            reuse = {}
            for method in (HYBRID, GPU):
                frames, static = arms[f"{method}_frames"], arms[f"{method}_static"]
                run = frames["total_ms"]["median"]
                wall = frames["frame_wall_ms"]["median"]
                base = static["total_ms"]["median"]
                reuse[method] = {
                    "run_ms": run - base,
                    "run_percent": 100.0 * (run / base - 1.0),
                    "frame_wall_minus_static_run_ms": wall - base,
                    "frame_wall_vs_static_run_percent": 100.0 * (wall / base - 1.0),
                }
            hybrid_static = arms[f"{HYBRID}_static"]["total_ms"]["median"]
            first_pose = statistics.median(arms[f"{HYBRID}_static"]["first_pose_create_ms"])
            estimate = hybrid_static + first_pose
            hybrid_frames = arms[f"{HYBRID}_frames"]
            estimate_block = {
                "hybrid_static_median_ms": hybrid_static,
                "first_call_pose_create_median_ms": first_pose,
                "estimate_ms": estimate,
                "measured_run_ms": hybrid_frames["total_ms"]["median"],
                "measured_frame_wall_ms": hybrid_frames["frame_wall_ms"]["median"],
                "measured_run_minus_estimate_ms": hybrid_frames["total_ms"]["median"] - estimate,
                "measured_frame_wall_minus_estimate_ms": hybrid_frames["frame_wall_ms"]["median"] - estimate,
                "measured_pose_create_median_ms": hybrid_frames["pose_create_ms"]["median"],
                "gpu_static_vs_estimate_percent": 100.0 * (arms[f"{GPU}_static"]["total_ms"]["median"] / estimate - 1.0),
            }
            primary = comparisons["frames_frame_wall"]
            decision = {
                "metric": "frame_wall_ms",
                "faster_per_frame": primary["faster"],
                "consistent_direction": primary["consistent_direction"],
                "gpu_vs_hybrid_percent": primary["delta_percent"],
                "run_only_faster": comparisons["frames_run_only"]["faster"],
                "run_only_gpu_vs_hybrid_percent": comparisons["frames_run_only"]["delta_percent"],
                "static_faster": comparisons["static_run_only"]["faster"],
                "static_gpu_vs_hybrid_percent": comparisons["static_run_only"]["delta_percent"],
            }
            out[case] = {
                "truth_count": len(self.case[case]["truth"]),
                "refine": self.case[case]["workflow"] == "full_rescue",
                "warmup_calls": self.warmups[case],
                "comparisons": comparisons,
                "reuse_effect": reuse,
                "same_build_estimate": estimate_block,
                "decision": decision,
                "hybrid_frames_measured_pose_create_median_ms": hybrid_frames["pose_create_ms"]["median"],
                "hybrid_static_first_pose_create_median_ms": first_pose,
                "gpu_static_first_pose_create_median_ms": statistics.median(arms[f"{GPU}_static"]["first_pose_create_ms"]),
            }
        return out

    def sequence_section(self):
        per = {}
        failures = []
        for case in self.cases:
            per[case] = {}
            for arm in self.arms:
                seq = self.sequence[(case, arm)]
                entry = {
                    "rows_checked": seq["rows_checked"],
                    "violations": capped(seq["violations"]),
                    "violation_count": len(seq["violations"]),
                }
                if mode_of(arm) == "frames":
                    entry.update({
                        "min_warmup_span_ms": seq["min_warmup_span_ms"],
                        "warmup_span_gate_ms": WARMUP_GATE_MS,
                        "warmup_span_failures": sum(1 for s in seq["warmup_span_ms"] if s < WARMUP_GATE_MS),
                        "min_frame_wall_minus_total_plus_update_ms": seq["min_frame_wall_slack_ms"],
                        "max_frame_wall_minus_total_plus_update_ms": seq["max_frame_wall_slack_ms"],
                        "min_source_decode_ms_after_call0": seq["min_source_decode_ms_after_call0"],
                        "decode_excluded_from_frame_wall": (
                            seq["max_frame_wall_slack_ms"] is not None
                            and seq["min_source_decode_ms_after_call0"] is not None
                            and seq["max_frame_wall_slack_ms"] < seq["min_source_decode_ms_after_call0"]
                        ),
                        "frame_wall_slack_violations": seq["frame_wall_slack_violations"],
                        "info_min_call0_frame_wall_minus_total_plus_construct_ms": min(
                            seq["call0_frame_wall_minus_total_plus_construct_ms"], default=None
                        ),
                    })
                    if entry["warmup_span_failures"]:
                        failures.append(f"{case}/{arm} warm-up span < {WARMUP_GATE_MS} ms")
                    if not entry["decode_excluded_from_frame_wall"]:
                        failures.append(f"{case}/{arm} frame_wall slack not below decode time")
                else:
                    entry["info_min_static_warmup_algorithm_ms_sum"] = min(seq["static_warmup_ms_sums"], default=None)
                entry["route_problems"] = capped(self.routes[(case, arm)])
                entry["requested_algorithm_problems"] = capped(self.algorithm[(case, arm)])
                if seq["violations"]:
                    failures.append(f"{case}/{arm} sequence violations")
                if self.routes[(case, arm)]:
                    failures.append(f"{case}/{arm} route problems")
                if self.algorithm[(case, arm)]:
                    failures.append(f"{case}/{arm} fine_effective_mode")
                per[case][arm] = entry
        return {"per_case_arm": per, "failures": failures, "pass": not failures}

    def exactness(self):
        per = {}
        failures = []
        parity = {}
        for case in self.cases:
            per[case] = {}
            for arm in self.arms:
                record = self.exact[(case, arm)]
                per[case][arm] = {
                    "calls_compared_to_block0_first_call": record["calls_compared"],
                    "differences": capped(record["differences"]),
                    "worker_exact_flags_true": record["worker_flags_true"],
                    "pass": not record["differences"] and record["worker_flags_true"],
                }
                if not per[case][arm]["pass"]:
                    failures.append(f"{case}/{arm} not exact")
            parity[case] = {}
            for method in (HYBRID, GPU):
                frames = self.refs.get((case, f"{method}_frames"))
                static = self.refs.get((case, f"{method}_static"))
                same = (
                    frames is not None
                    and static is not None
                    and frames["matches"] == static["matches"]
                    and frames["proposals"] == static["proposals"]
                )
                parity[case][method] = same
                if not same:
                    failures.append(f"{case}/{method} frames vs static outputs differ")
        return {
            "within_arm": per,
            "frames_equal_static_same_method": parity,
            "failures": failures,
            "pass": not failures,
        }

    def gates(self, timing, arms_summary):
        recomputed = []
        rss = {}
        for case in self.cases:
            for paired in timing[case]["comparisons"]["frames_frame_wall"]["paired"]:
                if not paired["within_regression_budget"]:
                    recomputed.append({
                        "case": case, "arm": f"{GPU}_frames", "method": GPU,
                        "baseline": f"{HYBRID}_frames", "gate": "time_budget", "block": paired["block"],
                    })
            gpu_peak = arms_summary[case][f"{GPU}_frames"]["peak_rss_bytes"]
            hybrid_peak = arms_summary[case][f"{HYBRID}_frames"]["peak_rss_bytes"]
            limit = hybrid_peak + max(RSS_BUDGET_BYTES, RSS_BUDGET_FRACTION * hybrid_peak)
            rss[case] = {"gpu_frames_peak_rss_bytes": gpu_peak, "hybrid_frames_peak_rss_bytes": hybrid_peak,
                         "limit_bytes": limit, "pass": gpu_peak <= limit}
            if gpu_peak > limit:
                recomputed.append({"case": case, "arm": f"{GPU}_frames", "method": GPU,
                                   "baseline": f"{HYBRID}_frames", "gate": "rss_budget", "block": None})
            for arm in self.arms:
                key = (case, arm)
                for block in blocks_with(c["call"] for c in self.gt[key].failing):
                    recomputed.append({"case": case, "arm": arm, "gate": "independent_ground_truth", "block": block})
                for block in blocks_with(self.routes[key]):
                    recomputed.append({"case": case, "arm": arm, "gate": "route_and_residency", "block": block})
                for block in blocks_with(self.algorithm[key]):
                    recomputed.append({"case": case, "arm": arm, "gate": "requested_algorithm_not_executed", "block": block})
                for block in blocks_with(self.exact[key]["differences"]):
                    recomputed.append({"case": case, "arm": arm, "gate": "exact_repeat", "block": block})
                gate = "sequence_route" if mode_of(arm) == "frames" else "static_route"
                for block in blocks_with(self.sequence[key]["violations"]):
                    recomputed.append({"case": case, "arm": arm, "gate": gate, "block": block})
                if mode_of(arm) == "frames":
                    for block, span in enumerate(self.sequence[key]["warmup_span_ms"]):
                        if span < WARMUP_GATE_MS:
                            recomputed.append({"case": case, "arm": arm, "gate": "warmup_shorter_than_1s", "block": block})
            for method in (HYBRID, GPU):
                frames = self.refs.get((case, f"{method}_frames"))
                static = self.refs.get((case, f"{method}_static"))
                if not (frames and static and frames["matches"] == static["matches"]
                        and frames["proposals"] == static["proposals"]):
                    recomputed.append({"case": case, "arm": f"{method}_frames", "gate": "same_method_output_parity", "block": None})
        for entry in self.executions:
            competitors = entry.get("host", {}).get("competing_processes")
            if competitors is None or competitors:
                recomputed.append({"case": entry["case"], "arm": entry["arm"], "gate": "host_busy", "block": entry["block"]})

        def keyset(items):
            return sorted({(g["case"], g["arm"], g["gate"], g.get("block")) for g in items},
                          key=lambda t: (t[0], t[1], t[2], -1 if t[3] is None else t[3]))

        mine = keyset(recomputed)
        published = keyset(self.summary.get("failed_gates", []))
        detail_mismatch = []
        published_full = {(g["case"], g["arm"], g["gate"], g.get("block")): g for g in self.summary.get("failed_gates", [])}
        for gate in recomputed:
            key = (gate["case"], gate["arm"], gate["gate"], gate.get("block"))
            other = published_full.get(key)
            if other is not None:
                for field in ("method", "baseline"):
                    if field in gate and other.get(field) != gate[field]:
                        detail_mismatch.append({"gate": list(key), "field": field, "recomputed": gate[field], "published": other.get(field)})
        only_mine = [list(k) for k in mine if k not in published]
        only_published = [list(k) for k in published if k not in mine]
        time_budget_detail = {
            case: [
                {"block": p["block"], "hybrid_ms": p["hybrid_ms"], "gpu_ms": p["gpu_ms"],
                 "limit_ms": p["hybrid_ms"] + max(TIME_BUDGET_MS, TIME_BUDGET_FRACTION * p["hybrid_ms"]),
                 "pass": p["within_regression_budget"]}
                for p in timing[case]["comparisons"]["frames_frame_wall"]["paired"]
            ]
            for case in self.cases
        }
        return {
            "recomputed_failed_gates": [list(k) for k in mine],
            "published_failed_gates": [list(k) for k in published],
            "only_recomputed": only_mine,
            "only_published": only_published,
            "field_mismatches": detail_mismatch,
            "time_budget": time_budget_detail,
            "rss_budget": rss,
            "blocking_gate_failures": [list(k) for k in mine if k[2] in BLOCKING_GATES],
            "pass": not only_mine and not only_published and not detail_mismatch,
        }

    def counts(self):
        fresh = len(self.executions)
        cold = gt_warm = native = measured = evaluated = 0
        for case in self.cases:
            for arm in self.arms:
                blocks = self.block_data[(case, arm)]
                evaluated += self.gt[(case, arm)].calls
                cold += len(blocks)
                if mode_of(arm) == "frames":
                    gt_warm += sum(b["warmup_calls"] for b in blocks)
                    measured += sum(len(b["measured_frame_wall"]) for b in blocks)
                else:
                    native += sum(b["warmup_calls"] for b in blocks)
                    measured += sum(len(b["runs_total"]) for b in blocks)
        mine = {
            "fresh_processes": fresh,
            "cold_calls": cold,
            "gt_checked_warmup_calls": gt_warm,
            "native_only_warmup_calls": native,
            "measured_calls": measured,
            "gt_evaluated_calls": evaluated,
        }
        published = self.summary.get("counts", {})
        return {"recomputed": mine, "published": published, "pass": mine == {k: published.get(k) for k in mine}}

    # -------------------------------------------------------------- run all
    def run(self, round40):
        order = self.order()
        self.scan()
        integrity = self.integrity()
        ground_truth = self.ground_truth()
        arms_summary = {case: {arm: self.arm_summary(case, arm) for arm in self.arms} for case in self.cases}
        timing = self.timing(arms_summary)
        sequence = self.sequence_section()
        exactness = self.exactness()
        gates = self.gates(timing, arms_summary)
        counts = self.counts()

        # same-method parity flag lives in the published frames arms
        for case in self.cases:
            for method in (HYBRID, GPU):
                arms_summary[case][f"{method}_frames"]["same_method_output_parity"] = exactness[
                    "frames_equal_static_same_method"][case][method]

        blocking = gates["blocking_gate_failures"]
        eligible = self.phase == "formal" and not blocking
        for case in self.cases:
            timing[case]["decision"] = {"formal_decision_eligible": eligible, **timing[case]["decision"]}

        comparator = Comparator()
        published_cases = {c["name"]: c for c in self.summary.get("cases", [])}
        for case in self.cases:
            theirs = published_cases.get(case)
            if theirs is None:
                comparator.mismatches.append({"path": f"/cases/{case}", "recomputed": "present", "published": None})
                continue
            for field in ("truth_count", "refine", "warmup_calls"):
                comparator.compare(f"/cases/{case}/{field}", timing[case][field], theirs.get(field))
            for arm in self.arms:
                mine = {k: v for k, v in arms_summary[case][arm].items() if not k.startswith("_")}
                comparator.compare(f"/cases/{case}/arms/{arm}", mine, theirs.get("arms", {}).get(arm))
            for section in ("comparisons", "reuse_effect", "same_build_estimate", "decision"):
                comparator.compare(f"/cases/{case}/{section}", timing[case][section], theirs.get(section))
        all_accuracy = all(a["all_gt_pass"] for c in arms_summary.values() for a in c.values())
        all_routes = all(
            a["route_valid"] and a["requested_algorithm_executed"]
            and a.get("sequence_route_valid", True) and a.get("static_route_valid", True)
            for c in arms_summary.values() for a in c.values()
        )
        all_exact = all(a["repeat_exact"] for c in arms_summary.values() for a in c.values()) and all(
            all(v.values()) for v in exactness["frames_equal_static_same_method"].values()
        )
        top = {
            "phase": self.phase,
            "formal_decision_eligible": eligible,
            "all_accuracy_pass": all_accuracy,
            "all_routes_pass": all_routes,
            "all_repeat_exact": all_exact,
            "counts": counts["recomputed"],
            "accuracy_thresholds": {"position_px": POSITION_TOL, "angle_deg": ANGLE_TOL, "relative_scale": SCALE_TOL},
        }
        comparator.compare("", top, self.summary)
        round40_report = None
        if round40 is not None and "round40_estimate" in self.summary:
            mine_r40 = {}
            for case in self.cases:
                arch = round40["cases"].get(case)
                if arch is None:
                    continue
                measured = timing[case]["comparisons"]["frames_frame_wall"]
                measured_percent = measured["delta_percent"]
                estimate_percent = arch["archived_estimate_percent"]
                consistent = measured["consistent_direction"]
                mine_r40[case] = {
                    **{k: v for k, v in arch.items() if k.startswith("archived_")},
                    "measured_percent": measured_percent,
                    "measured_run_only_percent": timing[case]["comparisons"]["frames_run_only"]["delta_percent"],
                    "measured_minus_estimate_points": measured_percent - estimate_percent,
                    "measured_pose_create_median_ms": timing[case]["hybrid_frames_measured_pose_create_median_ms"],
                    "consistent_direction": consistent,
                    "direction_held": (sign(measured_percent) == sign(estimate_percent)) if consistent else None,
                }
            comparator.compare("/round40_estimate", mine_r40, self.summary["round40_estimate"])
            comparator.compare("/round40_raw_sha256", round40["raw_sha256"], self.summary.get("round40_raw_sha256"))
            round40_report = mine_r40
        comparisons = comparator.report()

        timing_out = {}
        for case in self.cases:
            arms = arms_summary[case]
            timing_out[case] = {
                "warmup_calls": self.warmups[case],
                "arms": {
                    arm: (
                        {
                            "frame_wall_ms": {k: arms[arm]["frame_wall_ms"][k] for k in ("median", "min", "max")},
                            "total_ms": {k: arms[arm]["total_ms"][k] for k in ("median", "min", "max")},
                            "block_frame_wall_median_ms": [b["frame_wall_median_ms"] for b in arms[arm]["blocks"]],
                            "block_total_median_ms": [b["total_median_ms"] for b in arms[arm]["blocks"]],
                            "pose_create_ms_median": arms[arm]["pose_create_ms"]["median"],
                            "source_update_ms_median": arms[arm]["source_update_ms"]["median"],
                            "peak_rss_bytes": arms[arm]["peak_rss_bytes"],
                        }
                        if mode_of(arm) == "frames"
                        else {
                            "total_ms": {k: arms[arm]["total_ms"][k] for k in ("median", "min", "max")},
                            "block_total_median_ms": [b["total_median_ms"] for b in arms[arm]["blocks"]],
                            "first_pose_create_ms": arms[arm]["first_pose_create_ms"],
                            "first_pose_create_median_ms": statistics.median(arms[arm]["first_pose_create_ms"]),
                            "measured_pose_create_ms_max": arms[arm]["measured_pose_create_ms"]["max"],
                            "peak_rss_bytes": arms[arm]["peak_rss_bytes"],
                        }
                    )
                    for arm in self.arms
                },
                **{k: timing[case][k] for k in ("comparisons", "reuse_effect", "same_build_estimate", "decision")},
            }

        all_pass = all([
            integrity["pass"], order["pass"], ground_truth["pass"], sequence["pass"],
            exactness["pass"], gates["pass"], counts["pass"], comparisons["pass"],
        ])
        return {
            "phase": self.phase,
            "summary_path": rel(self.summary_path),
            "summary_sha256": sha256_file(self.summary_path),
            "manifest_embedded_summary_vs_published": self._embedded_summary_diff(),
            "integrity": integrity,
            "order": order,
            "ground_truth": ground_truth,
            "timing": timing_out,
            "sequence": sequence,
            "exactness": exactness,
            "gates": gates,
            "counts": counts,
            "round40_estimate_recomputed": round40_report,
            "comparisons_with_summary": comparisons,
            "all_checks_pass": all_pass,
        }

    def _embedded_summary_diff(self):
        embedded = self.manifest.get("summary")
        if not isinstance(embedded, dict):
            return {"embedded_present": False}
        keys_only_published = sorted(set(self.summary) - set(embedded))
        keys_only_embedded = sorted(set(embedded) - set(self.summary))
        differing = sorted(k for k in set(embedded) & set(self.summary) if embedded[k] != self.summary[k])
        return {
            "embedded_present": True,
            "keys_only_in_published": keys_only_published,
            "keys_only_in_manifest": keys_only_embedded,
            "common_keys_differing": differing,
        }


# ---------------------------------------------------------- shared extras --

def snapshot_section(manifests):
    failures = []
    listing_path = DOCS / "source-sha256.json"
    listing = read_json(listing_path)
    files = listing["files"]
    commit = listing["commit"]
    out = {
        "listing": rel(listing_path),
        "commit": commit,
        "commit_matches_protocol_frozen_commit": commit == PROTOCOL["source"]["frozen_commit"],
        "listed_files": len(files),
    }
    if not out["commit_matches_protocol_frozen_commit"]:
        failures.append("snapshot commit differs from protocol")
    for phase, manifest in manifests.items():
        source = manifest["source_sha256"]
        outside = sorted(set(source) - set(files))
        differ = sorted(k for k in source if k in files and source[k] != files[k])
        out[f"{phase}_manifest_fingerprint"] = {
            "files": len(source),
            "outside_snapshot": outside,
            "hash_differs_from_snapshot": differ,
            "snapshot_files_not_fingerprinted": sorted(set(files) - set(source)),
        }
        if outside or differ:
            failures.append(f"{phase} manifest source fingerprint vs snapshot")
    tar_path = DOCS / "source-snapshot.tar.gz"
    hashes, blobs, listing_copy = {}, {}, None
    with tarfile.open(tar_path, "r:gz") as tar:
        for member in tar:
            if not member.isfile():
                continue
            data = tar.extractfile(member).read()
            name = member.name[2:] if member.name.startswith("./") else member.name
            if name == "source-sha256.json":
                listing_copy = data
                continue
            hashes[name] = hashlib.sha256(data).hexdigest()
            blobs[name] = hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()
    tar_differ = sorted(k for k in files if hashes.get(k) != files[k])
    tar_extra = sorted(set(hashes) - set(files))
    out["snapshot_tar"] = {
        "path": rel(tar_path),
        "sha256": sha256_file(tar_path),
        "file_members": len(hashes),
        "members_matching_listing": len(files) - len(tar_differ),
        "listing_entries_missing_or_differing": tar_differ,
        "members_not_in_listing": tar_extra,
        "embedded_listing_equals_docs_listing": listing_copy == listing_path.read_bytes(),
    }
    if tar_differ or tar_extra or not out["snapshot_tar"]["embedded_listing_equals_docs_listing"]:
        failures.append("snapshot tar vs listing")
    command = ["git", "-C", str(ROOT), "ls-tree", "-r", "-z", "--full-tree", commit]
    SUBPROCESSES.append(" ".join(command))
    process = subprocess.run(command, capture_output=True, check=False)
    tree = {}
    for record in process.stdout.split(b"\0"):
        if not record:
            continue
        meta, path = record.split(b"\t", 1)
        mode, kind, oid = meta.decode().split()
        if kind == "blob":
            tree[path.decode("utf-8")] = oid
    git_differ = sorted(k for k in blobs if tree.get(k) != blobs[k])
    out["frozen_commit_blobs"] = {
        "git_exit_code": process.returncode,
        "tree_blobs": len(tree),
        "snapshot_files_equal_to_commit_blob": len(blobs) - len(git_differ),
        "snapshot_files_differing_or_absent": git_differ,
    }
    if process.returncode != 0 or git_differ:
        failures.append("snapshot vs frozen commit")
    out["failures"] = failures
    out["pass"] = not failures
    return out


def fixtures_section(formal_manifest, pilot_manifest):
    failures = []
    path = Path(formal_manifest["fixtures_manifest"])
    actual = sha256_file(path)
    out = {
        "fixtures_manifest": str(path),
        "sha256_matches_manifest": actual == formal_manifest["fixtures_manifest_sha256"],
        "pilot_cases_equal_formal_cases": pilot_manifest["cases"] == formal_manifest["cases"],
        "pilot_inputs_equal_formal_inputs": pilot_manifest["input_sha256"] == formal_manifest["input_sha256"],
        "pilot_binaries_equal_formal_binaries": pilot_manifest["binary_sha256"] == formal_manifest["binary_sha256"],
    }
    for key in ("sha256_matches_manifest", "pilot_cases_equal_formal_cases",
                "pilot_inputs_equal_formal_inputs", "pilot_binaries_equal_formal_binaries"):
        if not out[key]:
            failures.append(key)
    stage37 = read_json(path)
    input_mismatch = [p for p, h in formal_manifest["input_sha256"].items() if stage37["input_sha256"].get(p) != h]
    out["inputs_equal_stage37_fingerprint"] = not input_mismatch
    out["input_mismatches"] = input_mismatch
    if input_mismatch:
        failures.append("inputs vs stage-37 fingerprint")
    stage37_cases = {c["name"]: c for c in stage37["cases"]}
    truth = {}
    for case in formal_manifest["cases"]:
        name = case["name"]
        entry = {"truth_count": len(case["truth"])}
        other = stage37_cases.get(name)
        entry["equals_stage37_manifest_truth"] = other is not None and other.get("truth") == case["truth"]
        if not entry["equals_stage37_manifest_truth"]:
            failures.append(f"{name} truth vs stage-37 manifest")
        if "metadata" in case:
            meta = read_json(case["metadata"])
            entry["equals_scene_metadata_truth"] = meta.get("truth") == case["truth"]
            entry["metadata_source_png_sha256_matches"] = (
                meta.get("source_png_sha256") == formal_manifest["input_sha256"].get(case["source"])
            )
            entry["metadata_template_png_sha256_matches"] = (
                meta.get("template_png_sha256") == formal_manifest["input_sha256"].get(case["template"])
            )
            entry["metadata_object_count"] = meta.get("object_count")
            for key in ("equals_scene_metadata_truth", "metadata_source_png_sha256_matches",
                        "metadata_template_png_sha256_matches"):
                if not entry[key]:
                    failures.append(f"{name} {key}")
            if meta.get("object_count") != len(case["truth"]):
                failures.append(f"{name} metadata object_count")
        truth[name] = entry
    out["truth"] = truth
    out["failures"] = failures
    out["pass"] = not failures
    return out


def round40_section(formal_manifest):
    failures = []
    summary_path = STAGE40_DOCS / "formal-summary.json"
    raw_path = STAGE40_DOCS / "raw-results.tar.gz"
    summary_sha = sha256_file(summary_path)
    raw_sha = sha256_file(raw_path)
    out = {
        "summary_path": rel(summary_path),
        "summary_sha256": summary_sha,
        "summary_matches_manifest": summary_sha == formal_manifest["round40_summary_sha256"],
        "raw_path": rel(raw_path),
        "raw_sha256": raw_sha,
    }
    if not out["summary_matches_manifest"]:
        failures.append("round-40 summary hash")
    summary = read_json(summary_path)
    medians = {
        case["name"]: {m: case["methods"][m]["total_ms"]["median"] for m in (HYBRID, GPU)}
        for case in summary["cases"]
    }
    firsts = {}
    pattern = re.compile(r"formal/results/(.+)-hybrid_best-b(\d+)\.json")
    with tarfile.open(raw_path, "r:gz") as tar:
        for member in tar:
            match = pattern.fullmatch(member.name)
            if match and member.isfile():
                data = json.load(tar.extractfile(member))
                firsts.setdefault(match.group(1), {})[int(match.group(2))] = data["first"]["pose_create_ms"]
    cases = {}
    plan = {}
    for name, values in medians.items():
        hybrid, gpu = values[HYBRID], values[GPU]
        first_values = [firsts.get(name, {})[b] for b in sorted(firsts.get(name, {}))]
        if not first_values:
            failures.append(f"{name} round-40 first calls missing")
            continue
        pose = statistics.median(first_values)
        cases[name] = {
            "archived_estimate_percent": 100.0 * (gpu / (hybrid + pose) - 1.0),
            "archived_static_percent": 100.0 * (gpu / hybrid - 1.0),
            "archived_hybrid_with_pose_create_ms": hybrid + pose,
            "archived_gpu_median_ms": gpu,
            "archived_first_call_pose_create_median_ms": pose,
        }
        plan[name] = max(1, math.ceil(1500.0 / min(hybrid, gpu)))
    out["first_call_pose_create_ms_by_case"] = {k: [v[b] for b in sorted(v)] for k, v in firsts.items()}
    out["warmup_plan_recomputed"] = plan
    out["warmup_plan_matches_protocol"] = all(plan.get(k) == v for k, v in PROTOCOL_WARMUPS.items())
    if not out["warmup_plan_matches_protocol"]:
        failures.append("warm-up plan vs protocol")
    out["cases"] = cases
    out["failures"] = failures
    out["pass"] = not failures
    return out


def git(*args):
    command = ["git", "-C", str(ROOT), *args]
    SUBPROCESSES.append(" ".join(command))
    return subprocess.run(command, capture_output=True, text=True, check=False)


def build_records_section(formal_manifest, pilot_manifest):
    """Build head, compiled-source claim, cache options and pre-formal logs (read-only)."""
    failures = []
    validation = RUN / "validation"
    source = PROTOCOL["source"]
    build = PROTOCOL["build"]
    head_text = (validation / "build-head.txt").read_text(encoding="utf-8").strip()
    resolved = git("rev-parse", source["build_head"]).stdout.strip()
    changed = sorted(line for line in git("diff", "--name-only", resolved, source["frozen_commit"]).stdout.splitlines() if line)
    claimed = sorted(re.findall(r"cpp-core/[\w/.-]+\.\w+", source["compiled_source_changes_since_build_head"]))
    out = {
        "build_head_file": head_text,
        "protocol_build_head_resolved": resolved,
        "build_head_matches": bool(resolved) and head_text == resolved,
        "files_changed_build_head_to_frozen_commit": changed,
        "protocol_claimed_changes": claimed,
        "only_claimed_files_changed": changed == claimed,
    }
    for key in ("build_head_matches", "only_claimed_files_changed"):
        if not out[key]:
            failures.append(key)
    build_dir = ROOT / build["directory"]
    cache = {}
    for line in (build_dir / "CMakeCache.txt").read_text(encoding="utf-8", errors="replace").splitlines():
        match = re.match(r"^([A-Za-z0-9_]+):[A-Z]+=(.*)$", line)
        if match:
            cache[match.group(1)] = match.group(2)
    wanted = {"CMAKE_BUILD_TYPE": build["type"]}
    for option in build["options"]:
        name, value = option.split("=", 1)
        wanted[name] = value
    out["cmake_cache"] = {key: cache.get(key) for key in list(wanted) + ["FPM_SANITIZERS", "FPM_DISABLE_SIMD"]}
    out["cmake_cache_matches_protocol"] = all(cache.get(k) == v for k, v in wanted.items())
    if not out["cmake_cache_matches_protocol"]:
        failures.append("cmake cache vs protocol build options")
    binaries = list(formal_manifest["binary_sha256"])
    out["binaries_in_protocol_build_directory"] = all(Path(p).resolve().is_relative_to(build_dir.resolve()) for p in binaries)
    if not out["binaries_in_protocol_build_directory"]:
        failures.append("binaries outside protocol build directory")
    claimed_tests = PROTOCOL["build"]["pre_measurement_validation"]
    expected = {
        "ctest": tuple(int(x) for x in re.search(r"ctest (\d+)/(\d+)", claimed_tests).groups()),
        "python_harness": tuple(int(x) for x in re.search(r"Python harness (\d+)/(\d+)", claimed_tests).groups()),
        "color_verify": tuple(int(x) for x in re.search(r"--metal (\d+)/(\d+)", claimed_tests).groups()),
    }
    ctest = (validation / "pre-formal-ctest.log").read_text(encoding="utf-8")
    harness = (validation / "pre-formal-python-harness.log").read_text(encoding="utf-8")
    color = (validation / "pre-formal-color-verify.log").read_text(encoding="utf-8")
    ctest_match = re.search(r"100% tests passed, 0 tests failed out of (\d+)", ctest)
    harness_ran = re.search(r"Ran (\d+) tests", harness)
    color_ran = re.search(r"Ran (\d+) tests", color)
    logs = {
        "ctest_passed_of": int(ctest_match.group(1)) if ctest_match else None,
        "ctest_exit_zero": "ctest exit=0" in ctest,
        "python_harness_ran": int(harness_ran.group(1)) if harness_ran else None,
        "python_harness_ok": "\nOK" in harness and "harness exit=0" in harness,
        "color_verify_ran": int(color_ran.group(1)) if color_ran else None,
        "color_verify_ok": "\nOK" in color and "color exit=0" in color,
        "protocol_claim": claimed_tests,
    }
    logs["match_protocol_claim"] = (
        logs["ctest_passed_of"] == expected["ctest"][1] == expected["ctest"][0] and logs["ctest_exit_zero"]
        and logs["python_harness_ran"] == expected["python_harness"][1] and logs["python_harness_ok"]
        and logs["color_verify_ran"] == expected["color_verify"][1] and logs["color_verify_ok"]
    )
    pilot_start = datetime.fromisoformat(pilot_manifest["started_utc"]).timestamp()
    before = {}
    for path in [validation / "pre-formal-ctest.log", validation / "pre-formal-python-harness.log",
                 validation / "pre-formal-color-verify.log"] + [Path(p) for p in binaries]:
        before[rel(path)] = path.stat().st_mtime < pilot_start
    logs["mtimes_before_pilot_start"] = before
    out["pre_formal_validation"] = logs
    if not logs["match_protocol_claim"] or not all(before.values()):
        failures.append("pre-formal validation logs")
    out["failures"] = failures
    out["pass"] = not failures
    return out


def negative_controls(round40):
    """Mutate one input in memory at a time and confirm the audit reports it."""
    def pose(x, y, angle=0.0, scale=1.0):
        return {"pos_x": x, "pos_y": y, "angle": angle, "scale": scale}

    unit = []
    gt_cases = [
        ("exact hit matched", [pose(10, 10)], [pose(10, 10)], (1, 0, 0)),
        ("2.000 px admissible", [pose(10, 10)], [pose(12, 10)], (1, 0, 0)),
        ("2.001 px rejected", [pose(10, 10)], [pose(12.001, 10)], (0, 1, 1)),
        ("angle wraps across +-180", [pose(10, 10, 179.6)], [pose(10, 10, -179.9)], (1, 0, 0)),
        ("1.01 deg rejected", [pose(10, 10, 30.0)], [pose(10, 10, 31.01)], (0, 1, 1)),
        ("scale ratio 1.021 rejected", [pose(10, 10)], [pose(10, 10, 0.0, 1.021)], (0, 1, 1)),
        ("scale ratio 0.981 admissible", [pose(10, 10)], [pose(10, 10, 0.0, 0.981)], (1, 0, 0)),
        ("duplicate prediction is FP", [pose(10, 10)], [pose(10, 10), pose(10.5, 10)], (1, 1, 0)),
        ("augmenting path beats greedy", [pose(0, 0), pose(1.5, 0)], [pose(0.75, 0), pose(-1.0, 0)], (2, 0, 0)),
        ("missing object is FN", [pose(10, 10), pose(50, 50)], [pose(10, 10)], (1, 0, 1)),
    ]
    for name, truth, preds, expected in gt_cases:
        result = evaluate_ground_truth(truth, preds)
        got = (result["matched"], result["fp"], result["fn"])
        unit.append({"control": f"ground truth: {name}", "expected": list(expected), "got": list(got), "pass": got == expected})
    for name, mine, theirs, mismatches, missing in [
        ("2e-9 difference flagged", {"a": 1.0}, {"a": 1.0 + 2e-9}, 1, 0),
        ("5e-10 difference tolerated", {"a": 1.0}, {"a": 1.0 + 5e-10}, 0, 0),
        ("bool vs int flagged", {"a": True}, {"a": 1}, 1, 0),
        ("list length flagged", {"a": [1, 2]}, {"a": [1]}, 1, 0),
        ("missing published key flagged", {"a": 1, "b": 2}, {"a": 1}, 0, 1),
    ]:
        comparator = Comparator()
        comparator.compare("", mine, theirs)
        got = (len(comparator.mismatches), len(comparator.missing))
        unit.append({"control": f"comparator: {name}", "expected": [mismatches, missing], "got": list(got),
                     "pass": got == (mismatches, missing)})
    for name, mine, theirs, expect_pass in [
        ("1 ulp on a selected median fails", {"median": 0.1 + 0.2}, {"median": 0.3}, False),
        ("1 ulp on a derived delta_percent passes", {"delta_percent": 0.1 + 0.2}, {"delta_percent": 0.3}, True),
    ]:
        comparator = Comparator()
        comparator.compare("", mine, theirs)
        got = comparator.report()["pass"]
        unit.append({"control": f"comparator: {name}", "expected": expect_pass, "got": got, "pass": got == expect_pass})

    warm6 = PROTOCOL_WARMUPS["controlled6"]

    def shift_match(d): d["runs"][-1]["matches"][0]["pos_x"] += 3.0
    def add_truth(d): d["truth"] = []
    def slow_frame(d): d["runs"][-1]["frame_wall_ms"] += 100.0
    def bad_hash(d): d["executions"][0]["result_sha256"] = "0" * 64
    def swap_order(d): d["executions"][0], d["executions"][1] = d["executions"][1], d["executions"][0]
    def static_pose(d): d["runs"][0]["pose_create_ms"] = 5.0
    def no_pose(d): d["runs"][2]["pose_create_ms"] = 0
    def short_warmup(d): d["runs"][warm6]["elapsed_ms"] = d["runs"][0]["elapsed_ms"] + 999.0
    def parity(d):
        for call in [d["first"]] + d["runs"]:
            call["proposals"][0]["score"] += 1e-12
    def rss(d): d["final_memory"]["peak_rss_bytes"] = 10 ** 10
    def scope(d): d["runs"][3]["total_ms"] = d["runs"][3]["frame_wall_ms"] + 1.0
    def construct(d): d["runs"][1]["construct_ms"] = 5.0
    def decode(d): d["runs"][2]["source_decode_ms"] = 0
    def route(d): d["runs"][1]["full_gpu"]["cpu_waits"] = 2
    def algorithm(d): d["runs"][1]["full_gpu"]["fine_effective_mode"] = 2
    def summary_value(d): d["cases"][0]["comparisons"]["frames_frame_wall"]["delta_percent"] += 1e-6
    def summary_gates(d): d["failed_gates"] = []
    def summary_counts(d): d["counts"]["gt_evaluated_calls"] += 1

    def gate(name):
        return lambda r: any(g[2] == name for g in r["gates"]["only_recomputed"])

    summary_target = "stage41-new-frame-cost/pilot-summary.json"
    controls = [
        ("shift one measured match by 3 px", "results/many128_pose-hybrid_best_frames-b0.json", shift_match,
         {"ground_truth_fails": lambda r: not r["ground_truth"]["pass"],
          "exactness_fails": lambda r: not r["exactness"]["pass"],
          "stdout_equality_fails": lambda r: not r["integrity"]["pass"],
          "gt_gate_recomputed": gate("independent_ground_truth")}),
        ("job carries a truth key", "jobs/controlled6-full_gpu_simd_static-b0.json", add_truth,
         {"order_fails": lambda r: not r["order"]["pass"]}),
        ("measured frame_wall +100 ms", "results/many512_pose-full_gpu_simd_frames-b0.json", slow_frame,
         {"summary_mismatch": lambda r: bool(r["comparisons_with_summary"]["mismatches"])}),
        ("manifest result hash altered", "pilot/manifest.json", bad_hash,
         {"integrity_fails": lambda r: not r["integrity"]["pass"]}),
        ("execution order swapped", "pilot/manifest.json", swap_order,
         {"order_fails": lambda r: not r["order"]["pass"]}),
        ("static hybrid measured run creates a pose", "results/many128_pose-hybrid_best_static-b0.json", static_pose,
         {"sequence_fails": lambda r: not r["sequence"]["pass"], "static_route_gate": gate("static_route")}),
        ("refining hybrid call without pose creation", "results/many128_pose-hybrid_best_frames-b0.json", no_pose,
         {"sequence_fails": lambda r: not r["sequence"]["pass"], "sequence_route_gate": gate("sequence_route")}),
        ("warm-up span 999 ms", "results/controlled6-hybrid_best_frames-b0.json", short_warmup,
         {"warmup_gate": gate("warmup_shorter_than_1s")}),
        ("static outputs differ from frames (consistently within arm)",
         "results/8k_t256_angle180_3scales-full_gpu_simd_static-b0.json", parity,
         {"parity_fails": lambda r: r["exactness"]["frames_equal_static_same_method"]["8k_t256_angle180_3scales"][GPU] is False,
          "within_arm_still_exact": lambda r: r["exactness"]["within_arm"]["8k_t256_angle180_3scales"][f"{GPU}_static"]["pass"],
          "parity_gate": gate("same_method_output_parity")}),
        ("GPU peak RSS 10 GB", "results/many128_pose-full_gpu_simd_frames-b0.json", rss,
         {"rss_gate": gate("rss_budget")}),
        ("frame_wall below total_ms", "results/many128_pose-full_gpu_simd_frames-b0.json", scope,
         {"sequence_fails": lambda r: not r["sequence"]["pass"]}),
        ("Session constructed after call 0", "results/controlled6-full_gpu_simd_frames-b0.json", construct,
         {"sequence_fails": lambda r: not r["sequence"]["pass"]}),
        ("later call without fresh decode", "results/many512_pose-hybrid_best_frames-b0.json", decode,
         {"sequence_fails": lambda r: not r["sequence"]["pass"]}),
        ("full GPU call with two CPU waits", "results/many512_pose-full_gpu_simd_frames-b0.json", route,
         {"route_gate": gate("route_and_residency")}),
        ("fine_effective_mode 2 instead of 4", "results/controlled6-full_gpu_simd_frames-b0.json", algorithm,
         {"algorithm_gate": gate("requested_algorithm_not_executed")}),
        ("published delta_percent +1e-6", summary_target, summary_value,
         {"one_mismatch": lambda r: [m["path"] for m in r["comparisons_with_summary"]["mismatches"]]
          == ["/cases/many128_pose/comparisons/frames_frame_wall/delta_percent"]}),
        ("published failed_gates emptied", summary_target, summary_gates,
         {"gates_fail": lambda r: not r["gates"]["pass"]}),
        ("published gt_evaluated_calls +1", summary_target, summary_counts,
         {"counts_fail": lambda r: not r["counts"]["pass"]}),
    ]
    phase_results = []
    for name, target, mutate, expectations in controls:
        hits = []

        def loader(path, target=target, mutate=mutate, hits=hits):
            path = Path(path)
            data = read_json(path)
            if f"{path.parent.name}/{path.name}" == target:
                mutate(data)
                hits.append(target)
            return data

        try:
            report = PhaseAudit("pilot", 1, loader=loader).run(round40)
            detected = {key: bool(check(report)) for key, check in expectations.items()}
            detected["all_checks_pass_false"] = report["all_checks_pass"] is False
            phase_results.append({"control": name, "target": target, "mutation_applied": len(hits),
                                  "detected": detected, "pass": bool(hits) and all(detected.values())})
        except Exception as error:  # a crash is a failed control, never a silent pass
            phase_results.append({"control": name, "target": target, "error": repr(error), "pass": False})
    return {
        "unit": unit,
        "pilot_mutations": phase_results,
        "all_detected": all(u["pass"] for u in unit) and all(p["pass"] for p in phase_results),
    }


def main():
    started = datetime.now(timezone.utc).isoformat()
    formal_manifest = read_json(RUN / "formal" / "manifest.json")
    pilot_manifest = read_json(RUN / "pilot" / "manifest.json")
    round40 = round40_section(formal_manifest)
    phases = {}
    for phase, blocks in (("formal", PROTOCOL_BLOCKS), ("pilot", 1)):
        phases[phase] = PhaseAudit(phase, blocks).run(round40)
    snapshot = snapshot_section({"formal": formal_manifest, "pilot": pilot_manifest})
    fixtures = fixtures_section(formal_manifest, pilot_manifest)
    build_records = build_records_section(formal_manifest, pilot_manifest)
    controls = negative_controls(round40)

    tools_dir = (ROOT / "cpp-core" / "tools").resolve()
    imported = sorted(
        name for name, module in list(sys.modules.items())
        if getattr(module, "__file__", None) and Path(module.__file__).resolve().is_relative_to(tools_dir)
    )
    report = {
        "independent": True,
        "harness_imported": bool(imported),
        "harness_modules_loaded": imported,
        "gpu_launched": False,
        "subprocesses": SUBPROCESSES,
        "script": rel(SCRIPT),
        "script_sha256": sha256_file(SCRIPT),
        "python": sys.version.split()[0],
        "started_utc": started,
        "finished_utc": datetime.now(timezone.utc).isoformat(),
        "protocol": {"path": rel(PROTOCOL_PATH), "sha256": sha256_file(PROTOCOL_PATH)},
        "formal": phases["formal"],
        "pilot": phases["pilot"],
        "shared_extras": {
            "source_snapshot": snapshot,
            "fixtures_and_truth": fixtures,
            "round40_inputs": round40,
            "build_records": build_records,
        },
        "negative_controls": controls,
        "notes": [
            "Worktree source drift (integrity.worktree_sources) is report-only, as the audit brief asks; "
            "the run fingerprints themselves are checked against the frozen snapshot and commit.",
            "time_budget gate failures are measurement results; the audit check is that the recomputed "
            "failure list equals the published failed_gates.",
        ],
    }
    report["all_checks_pass"] = (
        phases["formal"]["all_checks_pass"] and phases["pilot"]["all_checks_pass"]
        and snapshot["pass"] and fixtures["pass"] and round40["pass"] and build_records["pass"]
        and controls["all_detected"] and not imported
    )
    OUTPUT.write_text(json.dumps(report, indent=2, sort_keys=False) + "\n", encoding="utf-8")

    for phase in ("formal", "pilot"):
        data = phases[phase]
        gt = data["ground_truth"]["total"]
        print(f"[{phase}] all_checks_pass={data['all_checks_pass']}")
        for section in ("integrity", "order", "ground_truth", "sequence", "exactness", "gates", "counts"):
            print(f"  {section}: pass={data[section]['pass']}")
        print(f"  GT calls={gt['calls_evaluated']} fp/fn calls={gt['calls_with_fp_or_fn']} "
              f"max pos={gt['max_position_px']:.6f} ang={gt['max_angle_deg']:.6f} scale={gt['max_relative_scale']:.6f} "
              f"ambiguous={gt['ambiguous_truth_rows']}/{gt['ambiguous_prediction_rows']}")
        print(f"  counts={data['counts']['recomputed']}")
        print(f"  gates recomputed={len(data['gates']['recomputed_failed_gates'])} "
              f"published={len(data['gates']['published_failed_gates'])} only_mine={data['gates']['only_recomputed']} "
              f"only_published={data['gates']['only_published']}")
        cmp_report = data["comparisons_with_summary"]
        print(f"  compared={cmp_report['compared_values']} mismatches={len(cmp_report['mismatches'])} "
              f"missing={len(cmp_report['missing_in_published'])} max_diff={cmp_report['max_abs_numeric_difference_within_tolerance']} "
              f"not_bit_identical={cmp_report['values_not_bit_identical']} "
              f"of_which_selected={len(cmp_report['selected_values_not_bit_identical'])}")
        for item in cmp_report["not_bit_identical_paths"][:6]:
            print("    inexact", item)
        for item in cmp_report["mismatches"][:15]:
            print("    MISMATCH", item)
        for item in cmp_report["missing_in_published"][:15]:
            print("    MISSING", item)
        worktree = data["integrity"]["worktree_sources"]
        print(f"  worktree sources differ: code={worktree['differ_tools_tests_src_experiments_cmake']} "
              f"other={worktree['differ_other']} missing={worktree['missing']}")
        for case, entry in data["timing"].items():
            c = entry["comparisons"]["frames_frame_wall"]
            print(f"  {case}: frame_wall hybrid={c['hybrid_median_ms']:.6f} gpu={c['gpu_median_ms']:.6f} "
                  f"delta={c['delta_percent']:+.4f}% blocks_gpu_faster={c['gpu_faster_blocks']}/{c['blocks']} "
                  f"faster={c['faster']}")
    print(f"[shared] snapshot={snapshot['pass']} fixtures={fixtures['pass']} round40={round40['pass']} "
          f"build_records={build_records['pass']} harness_imported={bool(imported)}")
    failed_controls = [c for c in controls["unit"] + controls["pilot_mutations"] if not c["pass"]]
    print(f"[negative controls] unit={len(controls['unit'])} mutations={len(controls['pilot_mutations'])} "
          f"all_detected={controls['all_detected']} failed={failed_controls}")
    print(f"ALL_CHECKS_PASS={report['all_checks_pass']}")
    print(f"wrote {rel(OUTPUT)}")


if __name__ == "__main__":
    sys.setrecursionlimit(10000)
    main()
