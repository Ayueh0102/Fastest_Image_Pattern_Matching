"""Collect stage-41 validation evidence into cpp-core/docs/stage41-new-frame-cost/validation.json.

Run from the worktree root after the final gate, mutants, independent audit and replay.
Every value is read from a log or JSON produced by those steps.
"""
import json, re
from pathlib import Path
work = Path('build/stage41-new-frame-cost')
log = work/'validation'
out = Path('cpp-core/docs/stage41-new-frame-cost')
def text(name):
    return (log/name).read_text()
def ctest(name):
    match = re.search(r'(\d+)% tests passed, (\d+) tests failed out of (\d+)', text(name))
    return dict(passed=int(match[3])-int(match[2]), failed=int(match[2]), total=int(match[3]), log='validation/'+name)
def unittest_counts(name):
    body = text(name)
    ran = [int(value) for value in re.findall(r'Ran (\d+) tests', body)]
    return dict(ran=ran, ok=body.count('\nOK') == len(ran), log='validation/'+name)
manifests = {phase: json.loads((work/phase/'manifest.json').read_text()) for phase in ('pilot', 'formal')}
summaries = {phase: json.loads((out/f'{phase}-summary.json').read_text()) for phase in ('pilot', 'formal')}
audit = json.loads(text('independent-audit.json'))
replay = json.loads(text('replay-check.json'))
mutants = json.loads(text('mutants.log'))
final = text('final-gate.log')
hosts = {phase: dict(before=manifest['host']['before'], after=manifest['host']['after'],
                     executions=len(manifest['executions']),
                     executions_with_competing_processes=sum(bool(entry['host']['competing_processes']) for entry in manifest['executions']),
                     load_average_1min_range=[min(entry['host']['load_average'][0] for entry in manifest['executions']),
                                              max(entry['host']['load_average'][0] for entry in manifest['executions'])],
                     started_utc=manifest['started_utc'], finished_utc=manifest['finished_utc'])
         for phase, manifest in manifests.items()}
validation = dict(stage=41, date='2026-10-19',
    build=dict(directory='build/stage41-release', type='Release', options=['FPM_BUILD_GUI=ON', 'FPM_BUILD_EXPERIMENTS=ON', 'FPM_WITH_OPENCV=ON'],
               build_head=text('build-head.txt').strip(), configure_log='validation/configure.log', build_log='validation/build.log',
               compiled_sources_changed_after_build=False,
               note='The frozen commit 7270946 only adds two Python files to the build head; no compiled source changed.'),
    pre_measurement=dict(ctest=ctest('pre-formal-ctest.log'), python_harness=unittest_counts('pre-formal-python-harness.log'),
                         color_verify_metal=unittest_counts('pre-formal-color-verify.log'),
                         scope='Run after the build and before the pilot; no timing in progress.'),
    final_gate=dict(head=re.search(r'HEAD=(\w+)', final)[1], start=re.search(r'START=(\S+)', final)[1], end=re.search(r'END=(\S+)', final)[1],
                    ctest=ctest('final-gate.log'),
                    python_harness=dict(ran=unittest_counts('final-gate.log')['ran'][0], ok=unittest_counts('final-gate.log')['ok'], log='validation/final-gate.log'),
                    color_verify_metal=dict(ran=unittest_counts('final-gate.log')['ran'][1], ok=unittest_counts('final-gate.log')['ok'], log='validation/final-gate.log'),
                    exits={name: int(value) for name, value in re.findall(r'(\w+) exit=(\d+)', final)},
                    working_tree_note='Only cpp-core/tools/build_log_catalog.py (stage-41 directory mapping) and new evidence files differed from HEAD.',
                    log='validation/final-gate.log'),
    harness=dict(new_tests=26, test_file='cpp-core/tests/test_new_frame_cost_harness.py', mutants=mutants, mutants_log='validation/mutants.log'),
    datasets={phase: summaries[phase]['counts'] for phase in summaries},
    direct_gt_calls=sum(summary['counts']['gt_evaluated_calls'] for summary in summaries.values()),
    all_zero_fp_fn=all(summary['all_accuracy_pass'] for summary in summaries.values()),
    all_routes_pass=all(summary['all_routes_pass'] for summary in summaries.values()),
    all_repeat_exact=all(summary['all_repeat_exact'] for summary in summaries.values()),
    embedded_summary_reproduced={phase: json.dumps(manifests[phase]['summary'], sort_keys=True) == json.dumps(
        {key: value for key, value in summaries[phase].items() if key not in ('round40_estimate', 'round40_raw_sha256')}, sort_keys=True)
        for phase in summaries},
    host=hosts,
    independent_audit=dict(file='validation/independent-audit.json', script='validation/independent_audit.py',
                           independent=audit.get('independent'), harness_imported=audit.get('harness_imported'), gpu_launched=audit.get('gpu_launched'),
                           all_checks_pass=audit.get('all_checks_pass'),
                           mismatches={phase: (audit.get(phase) or {}).get('comparisons_with_summary', {}).get('mismatches') for phase in ('formal', 'pilot')}),
    archive_replay=replay,
    audit_observations=dict(
        gpu_utilization_samples_above_50_percent={phase: sum(bool(entry['host']['gpu_device_utilization_percent']) and max(entry['host']['gpu_device_utilization_percent']) > 50
            for entry in manifest['executions']) for phase, manifest in manifests.items()},
        gpu_utilization_note='Instantaneous ioreg samples taken right after the previous worker exits reflect that worker; competing-process records, not these values, establish that no other work ran.',
        static_warmup_algorithm_below_1000_ms=[dict(phase=phase, case=case['name'], arm=arm, block=block['block'], warmup_algorithm_ms=block['warmup_algorithm_ms'])
            for phase, summary in summaries.items() for case in summary['cases'] for arm, row in case['arms'].items() if row['mode'] == 'static'
            for block in row['blocks'] if block['warmup_algorithm_ms'] < 1000],
        static_warmup_note='The static control warms up for one second of runner wall time; the algorithm-time sum has no gate.',
        fingerprint_coverage='Manifest source fingerprints cover 272 of the 286 snapshot files (macos-cli, root CMakeLists.txt and similar fall outside the rule); runner and dylibs are hashed directly.',
        post_measurement_source_change='cpp-core/tools/build_log_catalog.py gained the stage-41 directory mapping after the measurement; it is not part of the runner.'),
    limitations=['Single Apple M4 Pro Metal device', 'Repeated identical frame, not a changing camera stream',
                 'No hardware counters for the extra per-frame time', 'Log catalog regenerated after packing; report and index edits only'])
(out/'validation.json').write_text(json.dumps(validation, indent=2, ensure_ascii=False, allow_nan=False)+'\n')
print(json.dumps({key: validation[key] for key in ('direct_gt_calls', 'all_zero_fp_fn', 'embedded_summary_reproduced')}, ensure_ascii=False))
print(json.dumps(validation['independent_audit'], ensure_ascii=False))
