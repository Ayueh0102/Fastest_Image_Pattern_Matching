"""Hand-written mutants of benchmark_new_frame_cost.py; each must make the harness tests fail.

Run from the worktree root. Each mutation must match exactly once; the file is restored afterwards.
"""
import json, subprocess, sys
from pathlib import Path
path = Path('cpp-core/tools/benchmark_new_frame_cost.py')
original = path.read_text()
mutants = {
 'timed_includes_warmup': ("timed = [row for _, _, rows, _ in sequences for row in rows[1+warmup:]]", "timed = [row for _, _, rows, _ in sequences for row in rows[1:]]"),
 'no_warmup_gate': ("if warmup_wall < WARMUP_MINIMUM_MS:", "if False:"),
 'no_parity': ("row['same_method_output_parity'] = all(outputs(call) == reference for call in calls[arm])", "row['same_method_output_parity'] = True"),
 'gt_measured_only': ("**memory_summary(calls, method), **accuracy_summary(calls, case['truth']),\n        route_valid=all(route for route, _ in routes), requested_algorithm_executed=all(executed for _, executed in routes),\n        sequence_route_valid", "**memory_summary(calls, method), **accuracy_summary(timed, case['truth']),\n        route_valid=all(route for route, _ in routes), requested_algorithm_executed=all(executed for _, executed in routes),\n        sequence_route_valid"),
 'estimate_inverted': ("((primary['delta_percent'] < 0) == (estimate < 0))", "((primary['delta_percent'] < 0) != (estimate < 0))"),
 'no_host_gate': ("if host_entry(entry.get('host')):", "if host_entry(entry.get('host')) and False:"),
 'rss_no_tolerance': ("hybrid_rss+max(8*1024**2, .1*hybrid_rss)", "hybrid_rss"),
 'time_no_tolerance': ("within_regression_budget=b[block_field] <= a[block_field]+max(2., .1*a[block_field]))", "within_regression_budget=b[block_field] <= a[block_field])"),
 'pose_rule_any': ("route &= row['pose_create_ms'] > 0 if refine and not gpu else row['pose_create_ms'] == 0", "route &= True"),
 'static_reuse_unchecked': ("record['pose_create_ms'] > 0 if index == 0 and refine and not gpu else record['pose_create_ms'] == 0)", "True)"),
 'job_keeps_source': ("    result.pop('source')\n", ""),
 'warmup_round': ("max(1, math.ceil(WARMUP_TARGET_MS/min(", "max(1, round(WARMUP_TARGET_MS/min("),
 'consistency_pooled_only': ("consistent = pooled != 0 and signs == {pooled}", "consistent = pooled != 0"),
 'drain_ignored': ("route, shape = worker['drained'], None", "route, shape = True, None"),
}
results = {}
try:
    for name, (old, new) in mutants.items():
        assert original.count(old) == 1, name
        path.write_text(original.replace(old, new))
        run = subprocess.run([sys.executable, '-m', 'unittest', 'cpp-core/tests/test_new_frame_cost_harness.py'], capture_output=True, text=True)
        results[name] = 'killed' if run.returncode else 'survived'
finally:
    path.write_text(original)
restored = path.read_text() == original
print(json.dumps(dict(mutants=results, killed=sum(value == 'killed' for value in results.values()), total=len(results), restored=restored), indent=2))
sys.exit(0 if restored and all(value == 'killed' for value in results.values()) else 1)
