"""Replay stage-41 summaries from the published archives with the frozen tool.

Run from the worktree root after archive_artifacts.py. Extracts source-snapshot.tar.gz
and raw-results.tar.gz into a fresh build/stage41-replay, checks every snapshot member
hash, reruns the frozen benchmark_new_frame_cost.py --summarize on the extracted pilot
and formal manifests and compares the bytes with the published summaries. No GPU run.
"""
import hashlib, json, shutil, subprocess, sys, tarfile
from pathlib import Path
docs = Path('cpp-core/docs/stage41-new-frame-cost')
replay = Path('build/stage41-replay')
if replay.exists():
    shutil.rmtree(replay)
(replay/'source').mkdir(parents=True)
with tarfile.open(docs/'source-snapshot.tar.gz') as tar:
    tar.extractall(replay/'source', filter='data')
with tarfile.open(docs/'raw-results.tar.gz') as tar:
    tar.extractall(replay/'raw', filter='data')
frozen = json.loads((replay/'source/source-sha256.json').read_text())
mismatched = [name for name, digest in frozen['files'].items()
              if hashlib.sha256((replay/'source'/name).read_bytes()).hexdigest() != digest]
head_changes = subprocess.run(['git', 'diff', '--name-only', frozen['commit'], 'HEAD', '--', 'cpp-core', 'CMakeLists.txt', 'LICENSE', 'vcpkg.json', 'macos-cli'],
                              capture_output=True, text=True, check=True).stdout.split()
worktree_changes = subprocess.run(['git', 'diff', '--name-only', '--', 'cpp-core/tools', 'cpp-core/tests', 'cpp-core/src', 'cpp-core/include', 'cpp-core/experiments'],
                                  capture_output=True, text=True, check=True).stdout.split()
tool = replay/'source/cpp-core/tools/benchmark_new_frame_cost.py'
results = {}
for phase in ('pilot', 'formal'):
    output = replay/f'{phase}-summary.json'
    run = subprocess.run([sys.executable, str(tool), '--summarize', str(replay/'raw'/phase/'manifest.json'),
                          '--round40-raw', 'cpp-core/docs/stage40-ncc-closure/raw-results.tar.gz', '--output', str(output)],
                         capture_output=True, text=True)
    results[phase] = dict(returncode=run.returncode, stderr=run.stderr[-2000:],
                          bytes_equal=run.returncode == 0 and output.read_bytes() == (docs/f'{phase}-summary.json').read_bytes())
report = dict(snapshot_files=len(frozen['files']), snapshot_hash_mismatches=mismatched, frozen_commit=frozen['commit'],
              committed_source_changes_since_freeze=head_changes, uncommitted_source_changes=worktree_changes,
              summaries=results, all_pass=not mismatched and all(row['bytes_equal'] for row in results.values()),
              scope='Frozen tool on extracted archives; summaries only. No GPU measurement rerun.')
Path('build/stage41-new-frame-cost/validation/replay-check.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
sys.exit(0 if report['all_pass'] else 1)
