"""Where the per-new-frame time goes: stage fields already present in every formal call.

Run from the worktree root. Reads build/stage41-new-frame-cost/formal (manifest, results) and
writes cpp-core/docs/stage41-new-frame-cost/stage-breakdown.json. No new measurement; these
are the runner's ordinary per-call fields of the measured calls (cold and warm-up excluded).
"""
import json, statistics
from pathlib import Path
base = Path('build/stage41-new-frame-cost/formal')
manifest = json.loads((base/'manifest.json').read_text())
warmup, blocks = manifest['warmup_calls'], manifest['blocks']
def measured(case, arm, block):
    worker = json.loads((base/'results'/f'{case}-{arm}-b{block}.json').read_text())
    return worker['runs'][1+warmup[case]:] if arm.endswith('_frames') else worker['runs']
def med(rows, value):
    return statistics.median(value(row) for row in rows)
result = dict(note='Medians over the measured calls of all six blocks; fields nested in total_ms. Not a hardware profile.', cases={})
for case in manifest['cases']:
    name, row = case['name'], {}
    for mode in ('frames', 'static'):
        rows = [call for block in range(blocks) for call in measured(name, f'hybrid_best_{mode}', block)]
        row[f'hybrid_best_{mode}'] = dict(total_ms=med(rows, lambda r: r['total_ms']), prepare_ms=med(rows, lambda r: r['prepare_ms']),
            proposal_ms=med(rows, lambda r: r['proposal_ms']), refine_ms=med(rows, lambda r: r['refine_ms']),
            pose_create_ms=med(rows, lambda r: r['pose_create_ms']), refine_minus_pose_create_ms=med(rows, lambda r: r['refine_ms']-r['pose_create_ms']),
            refinement_device_ms=med(rows, lambda r: r['refinement_device_ms']), nms_ms=med(rows, lambda r: r['nms_ms']))
        rows = [call for block in range(blocks) for call in measured(name, f'full_gpu_simd_{mode}', block)]
        row[f'full_gpu_simd_{mode}'] = dict(total_ms=med(rows, lambda r: r['total_ms']),
            device_ms=med(rows, lambda r: r['full_gpu']['device_ms']), wait_ms=med(rows, lambda r: r['full_gpu']['wait_ms']),
            encode_ms=med(rows, lambda r: r['full_gpu']['encode_ms']), upload_ms=med(rows, lambda r: r['full_gpu']['upload_ms']),
            block_device_ms=[med(measured(name, f'full_gpu_simd_{mode}', block), lambda r: r['full_gpu']['device_ms']) for block in range(blocks)])
    result['cases'][name] = row
Path('cpp-core/docs/stage41-new-frame-cost/stage-breakdown.json').write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
for name, row in result['cases'].items():
    print(name, {arm: {key: (round(value, 2) if isinstance(value, float) else value) for key, value in values.items() if key != 'block_device_ms'} for arm, values in row.items()})
