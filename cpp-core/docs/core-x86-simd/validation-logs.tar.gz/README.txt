core-x86-simd validation logs (2026-10-31)
pc-formal/   formal.bat logs on PTRI-PRO-4000 (builds, ctest incl. MSVC ASan, identity, A/B, mutants) and the post steps
             (experiments build/ctest of 8695027, profiling build). Logs from MSVC are cp950.
mac-formal/  formal-mac.sh logs (fe60159 and 8695027 pure core, identity, A/B), the 91-test research ctest at e8d1919,
             and the -ffp-contract=off diagnostic build of fe60159.
scripts/     every driver used: formal.bat, formal-mac.sh, x86_mutants.py, check_pgm.py, run_cli_cases.py,
             make_profile_tree.py, run_profile.py, cpuprobe.cpp, the PGM manifest.
profiles/    counter-instrumented copies (profiling only, not formal): x86 fe60159 / c74913c / 8695027, Mac fe60159.
preliminary/ run_cli_cases.py results before registration (12-digit CLI JSON; v1 = the c74913c core sources before the 160-row test, v2 = the 8695027
             working tree), and the first mutant run (which recorded only the last FAIL line).
