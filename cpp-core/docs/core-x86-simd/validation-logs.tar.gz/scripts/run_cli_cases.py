"""Run fpm_cli on the 17 compare_versions fixtures (PGM copies) in four modes; stdlib only, any OS.

Usage: python run_cli_cases.py FPM_CLI BUNDLE_DIR OUT_JSON [--repeats N]
Per case and mode: one warm-up call, then N measured calls (fresh process each). The first measured
call's matches are recorded; times are the CLI's own match_ms and learn_ms (decode excluded).
"""
import json, platform, subprocess, sys, time
from pathlib import Path

cli, bundle, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
repeats = int(sys.argv[sys.argv.index('--repeats') + 1]) if '--repeats' in sys.argv else 5
cases = json.loads((bundle / 'cases.json').read_text())
MODES = {'default': [], 'subpixel': ['--subpixel'], 'fast': ['--fast'], 'scalar': ['--no-simd']}
rows = []
for c in cases:
    base = [str(cli), '--src', str(bundle / 'pgm' / c['src']), '--tmpl', str(bundle / 'pgm' / c['tmpl']),
            '--target-num', str(c['count']), '--score', str(c['score']), '--angle', str(c['angle']),
            '--overlap', str(c['overlap']), '--min-area', str(c['area']), '--no-display']
    for mode, extra in MODES.items():
        calls = []
        for k in range(repeats + 1):
            r = subprocess.run(base + extra, capture_output=True, text=True)
            if r.returncode:
                calls.append(dict(error=r.stderr[-300:]))
                break
            calls.append(json.loads(r.stdout))
        ok = [x for x in calls[1:] if 'error' not in x]
        rows.append(dict(case=c['name'], mode=mode, error=calls[-1].get('error') if 'error' in calls[-1] else None,
                         backend=ok[0].get('backend') if ok else None, matches=ok[0]['matches'] if ok else None,
                         repeat_identical=all(x['matches'] == ok[0]['matches'] for x in ok) if ok else None,
                         match_ms=[x['match_ms'] for x in ok], learn_ms=[x['learn_ms'] for x in ok]))
        print(c['name'], mode, len(ok), flush=True)
out.write_text(json.dumps(dict(platform=platform.platform(), machine=platform.machine(), processor=platform.processor(),
                               python=platform.python_version(), cli=str(cli), repeats=repeats, rows=rows), indent=1))
