#!/bin/bash
# Formal x86 SIMD gate, Mac side: arm64 regression check of the same two commits.
# Usage: formal-mac.sh BEFORE_TAR AFTER_TAR   (run from the repo root)
set -u
R=build/x86simd-formal-mac
mkdir -p $R/src-before $R/src-after $R/out $R/logs
tar -xzf "$1" -C $R/src-before && tar -xzf "$2" -C $R/src-after || exit 2
log() { echo "$*" >> $R/logs/formal.log; }
lock() { ls "$HOME/Library/Application Support/Claude/side-session-notes/"*/timing-lock-*.txt 2>/dev/null && { log "timing lock present, refusing"; exit 3; }; return 0; }
log "start $(date -u +%FT%TZ) $(uptime)"
for n in before after; do
  lock
  cmake -S $R/src-$n/cpp-core -B $R/build-$n -DCMAKE_BUILD_TYPE=Release > $R/logs/$n-configure.log 2>&1 && \
  cmake --build $R/build-$n -j 8 > $R/logs/$n-build.log 2>&1 || { log "$n build failed"; exit 4; }
  ctest --test-dir $R/build-$n --output-on-failure > $R/logs/$n-ctest.log 2>&1; log "$n ctest $?"
done
lock
python3 $R/src-after/cpp-core/tools/check_backend_identity.py --lib before=$R/build-before/libfpm_c.dylib \
  --lib after=$R/build-after/libfpm_c.dylib --pgm-dir build/x86simd-transfer/fixtures-pgm \
  --output $R/out/mac-identity.json > $R/logs/identity.log 2>&1; log "identity $?"
lock
log "timing-start $(date -u +%FT%TZ) $(uptime)"
python3 $R/src-after/cpp-core/tools/benchmark_backend_ab.py --build before=$R/build-before --build after=$R/build-after \
  --rounds 8 --pgm-dir build/x86simd-transfer/fixtures-pgm --output $R/out/mac-ab-default.json > $R/logs/ab-default.log 2>&1
log "ab-default $? $(date -u +%FT%TZ) $(uptime)"
log "formal-finished"
