// Print the x86 SIMD features relevant to the dot product and rotation paths.
#include <cstdio>
#include <intrin.h>
#include <immintrin.h>
int main()
{
	int r[4];
	__cpuid(r, 1);
	const bool osxsave = r[2] >> 27 & 1, avx = r[2] >> 28 & 1, fma = r[2] >> 12 & 1, sse41 = r[2] >> 19 & 1;
	const bool ymm = osxsave && (_xgetbv(0) & 6) == 6;
	__cpuidex(r, 7, 0);
	const bool avx2 = r[1] >> 5 & 1, avx512f = r[1] >> 16 & 1, avx512vnni = r[2] >> 11 & 1;
	__cpuidex(r, 7, 1);
	const bool avxvnni = r[0] >> 4 & 1, vnniint8 = r[3] >> 4 & 1, vnniint16 = r[3] >> 10 & 1;
	std::printf("{\"sse41\":%d,\"avx\":%d,\"ymm_os\":%d,\"fma\":%d,\"avx2\":%d,\"avx512f\":%d,\"avx512_vnni\":%d,"
		"\"avx_vnni\":%d,\"avx_vnni_int8\":%d,\"avx_vnni_int16\":%d}\n",
		sse41, avx, ymm, fma, avx2, avx512f, avx512vnni, avxvnni, vnniint8, vnniint16);
}
