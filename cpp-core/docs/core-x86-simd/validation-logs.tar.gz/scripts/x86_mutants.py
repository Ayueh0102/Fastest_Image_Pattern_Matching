"""Compiled mutants for the x86 SIMD tiers (stdlib only; run from a vcvars64 shell).

Usage: python x86_mutants.py SOURCE_ROOT BUILD_PREFIX LOG_JSON
SOURCE_ROOT holds cpp-core/. For each tier cap (SSE2, AVX2, VNNI_INT8) one Ninja build
directory BUILD_PREFIX-<cap> is configured once. Each mutant edits one anchor (the text must
occur exactly once), rebuilds fpm_core_test for the cap whose code path it changes, runs it, and
restores the file. KILLED: the test fails or crashes. SURVIVED: it passes. INVALID: it does not
compile. ANCHOR: the anchor text was not found exactly once.
"""
import json
import subprocess
import sys
from pathlib import Path

root, prefix, log = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3])
I, N = 'cpp-core/src/image.cpp', 'cpp-core/src/ncc.cpp'
MUTANTS = [
    ('SSE2', 'S1 SSE2 warp inner x bound w instead of w-1', I,
     'const __m128d innerW = _mm_set1_pd(src.width - 1), innerH = _mm_set1_pd(src.height - 1);',
     'const __m128d innerW = _mm_set1_pd(src.width), innerH = _mm_set1_pd(src.height - 1);'),
    ('SSE2', 'S2 SSE2 warp sx re-associated: ax+(c*x-s*y)', I,
     'const __m128d px = _mm_sub_pd(_mm_add_pd(ax, _mm_mul_pd(vc, vx)), sy);',
     'const __m128d px = _mm_add_pd(ax, _mm_sub_pd(_mm_mul_pd(vc, vx), sy));'),
    ('SSE2', 'S3 SSE2 warp p10 takes the low byte', I,
     'const __m128d p10 = _mm_cvtepi32_pd(_mm_set_epi32(0, 0, qu >> 8, pu >> 8));',
     'const __m128d p10 = _mm_cvtepi32_pd(_mm_set_epi32(0, 0, qu & 255, pu >> 8));'),
    ('SSE2', 'S4 SSE2 warp result not rounded (+0.5 dropped)', I,
     'const __m128d value = _mm_add_pd(_mm_add_pd(_mm_mul_pd(top, ry), _mm_mul_pd(bottom, dy)), half);',
     'const __m128d value = _mm_add_pd(_mm_mul_pd(top, ry), _mm_mul_pd(bottom, dy));'),
    ('SSE2', 'S5 SSE2 dot: window 5 reads window 4', N,
     'a4 = sse2Dot16(a4, low, high, p + b + 4); a5 = sse2Dot16(a5, low, high, p + b + 5);',
     'a4 = sse2Dot16(a4, low, high, p + b + 4); a5 = sse2Dot16(a5, low, high, p + b + 4);'),
    ('SSE2', 'S6 SSE2 dot: source high half unpacked low', N,
     '_mm_madd_epi16(_mm_unpackhi_epi8(s, zero), high)));',
     '_mm_madd_epi16(_mm_unpacklo_epi8(s, zero), high)));'),
    ('SSE2', 'S7 SSE2 dot: lanes never flushed', N,
     '''		if ((pending += blocks) >= 256) {
			total[0] += laneSum128(a0); total[1] += laneSum128(a1);
			total[2] += laneSum128(a2); total[3] += laneSum128(a3);
			total[4] += laneSum128(a4); total[5] += laneSum128(a5);
			total[6] += laneSum128(a6); total[7] += laneSum128(a7);
			a0 = a1 = a2 = a3 = a4 = a5 = a6 = a7 = zero;''',
     '''		if ((pending += blocks) >= 1 << 30) {
			total[0] += laneSum128(a0); total[1] += laneSum128(a1);
			total[2] += laneSum128(a2); total[3] += laneSum128(a3);
			total[4] += laneSum128(a4); total[5] += laneSum128(a5);
			total[6] += laneSum128(a6); total[7] += laneSum128(a7);
			a0 = a1 = a2 = a3 = a4 = a5 = a6 = a7 = zero;'''),
    ('SSE2', 'P1 SSE2 pyrDown: o[k+1] replaced by o[k]', I,
     'const __m128i o1 = _mm_or_si128(_mm_srli_si128(o0, 2), _mm_slli_si128(o8, 14));',
     'const __m128i o1 = o0;'),
    ('SSE2', 'P2 SSE2 pyrDown: e[k+2] shifted one lane too far', I,
     'const __m128i e2 = _mm_or_si128(_mm_srli_si128(e0, 4), _mm_slli_si128(e8, 12));',
     'const __m128i e2 = _mm_or_si128(_mm_srli_si128(e0, 6), _mm_slli_si128(e8, 10));'),
    ('SSE2', 'P3 SSE2 pyrDown: rounding bias 127', I,
     'const __m128i bias = _mm_set1_epi32(128);',
     'const __m128i bias = _mm_set1_epi32(127);'),
    ('SSE2', 'P4 SSE2 pyrDown: centre row weight 4 instead of 6', I,
     '_mm_add_epi32(_mm_slli_epi32(center, 2), _mm_slli_epi32(center, 1))));',
     '_mm_slli_epi32(center, 2)));'),
    ('AVX2', 'A1 AVX2 warp inner y bound h instead of h-1', I,
     'const __m256d innerW = _mm256_set1_pd(src.width - 1), innerH = _mm256_set1_pd(src.height - 1);',
     'const __m256d innerW = _mm256_set1_pd(src.width - 1), innerH = _mm256_set1_pd(src.height);'),
    ('AVX2', 'A2 AVX2 warp lower neighbours swapped', I,
     'const __m256d p01 = _mm256_cvtepi32_pd(_mm_and_si128(lower, low)), p11 = _mm256_cvtepi32_pd(_mm_srli_epi32(lower, 8));',
     'const __m256d p11 = _mm256_cvtepi32_pd(_mm_and_si128(lower, low)), p01 = _mm256_cvtepi32_pd(_mm_srli_epi32(lower, 8));'),
    ('AVX2', 'A3 AVX2 warp top re-associated with dy', I,
     'const __m256d value = _mm256_add_pd(_mm256_add_pd(_mm256_mul_pd(top, ry), _mm256_mul_pd(bottom, dy)), half);',
     'const __m256d value = _mm256_add_pd(_mm256_mul_pd(top, ry), _mm256_add_pd(_mm256_mul_pd(bottom, dy), half));'),
    ('AVX2', 'A4 AVX2 dot: source read one byte late', N,
     '_mm256_cvtepu8_epi16(_mm_loadu_si128(reinterpret_cast<const __m128i*>(p))), block));',
     '_mm256_cvtepu8_epi16(_mm_loadu_si128(reinterpret_cast<const __m128i*>(p + 1))), block));'),
    ('AVX2', 'A5 AVX2 dot: lanes never flushed', N,
     '''		if ((pending += blocks) >= 256) {
			total[0] += laneSum256(a0);''',
     '''		if ((pending += blocks) >= 1 << 30) {
			total[0] += laneSum256(a0);'''),
    ('AVX2', 'A6 AVX2 dot: upper 128-bit half dropped from lane sums', N,
     'return laneSum128(_mm256_castsi256_si128(v)) + laneSum128(_mm256_extracti128_si256(v, 1));',
     'return laneSum128(_mm256_castsi256_si128(v));'),
    ('VNNI_INT8', 'V1 VNNI dot: window 7 reads window 6', N,
     'a6 = vnniDot16(a6, tb, p + b + 6); a7 = vnniDot16(a7, tb, p + b + 7);',
     'a6 = vnniDot16(a6, tb, p + b + 6); a7 = vnniDot16(a7, tb, p + b + 6);'),
    ('VNNI_INT8', 'V2 VNNI dot: lanes never flushed', N,
     '''		if ((pending += blocks) >= 256) {
			total[0] += laneSum128(a0); total[1] += laneSum128(a1);
			total[2] += laneSum128(a2); total[3] += laneSum128(a3);
			total[4] += laneSum128(a4); total[5] += laneSum128(a5);
			total[6] += laneSum128(a6); total[7] += laneSum128(a7);
			a0 = a1 = a2 = a3 = a4 = a5 = a6 = a7 = _mm_setzero_si128();''',
     '''		if ((pending += blocks) >= 1 << 30) {
			total[0] += laneSum128(a0); total[1] += laneSum128(a1);
			total[2] += laneSum128(a2); total[3] += laneSum128(a3);
			total[4] += laneSum128(a4); total[5] += laneSum128(a5);
			total[6] += laneSum128(a6); total[7] += laneSum128(a7);
			a0 = a1 = a2 = a3 = a4 = a5 = a6 = a7 = _mm_setzero_si128();'''),
    ('VNNI_INT8', 'V3 VNNI dot: source squared instead of times template', N,
     'return _mm_dpbuud_epi32(sum, _mm_loadu_si128(reinterpret_cast<const __m128i*>(p)), block);',
     'return _mm_dpbuud_epi32(sum, _mm_loadu_si128(reinterpret_cast<const __m128i*>(p)), _mm_loadu_si128(reinterpret_cast<const __m128i*>(p)));'),
]


def run(cmd, timeout=900):
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, errors='replace')


builds = {}
for cap in ('SSE2', 'AVX2', 'VNNI_INT8'):
    b = f'{prefix}-{cap.lower()}'
    r = run(['cmake', '-S', str(root / 'cpp-core'), '-B', b, '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release', f'-DFPM_X86_MAX_ISA={cap}'])
    if r.returncode:
        sys.exit(f'configure {cap} failed: {r.stdout[-400:]} {r.stderr[-400:]}')
    builds[cap] = b


def test(cap):
    b = builds[cap]
    r = run(['cmake', '--build', b, '--target', 'fpm_core_test'])
    if r.returncode:
        return 'INVALID', (r.stdout + r.stderr)[-300:]
    try:
        t = run([str(Path(b) / 'fpm_core_test.exe')], timeout=600)
    except subprocess.TimeoutExpired:
        return 'KILLED', 'timeout'
    if t.returncode:
        fails = [x.strip() for x in (t.stdout + t.stderr).splitlines() if x.startswith('FAIL')]
        return 'KILLED', f'exit {t.returncode}: ' + ' || '.join(fails)[:600]
    return 'SURVIVED', ''


results = []
for cap in builds:
    status = test(cap)
    results.append(dict(mutant=f'baseline {cap}', cap=cap, status=status[0], detail=status[1]))
    print('baseline', cap, status, flush=True)
    if status[0] != 'SURVIVED':
        sys.exit('baseline fails')
for cap, label, rel, old, new in MUTANTS:
    path = root / rel
    text = path.read_text()
    if text.count(old) != 1:
        results.append(dict(mutant=label, cap=cap, status='ANCHOR', detail=''))
        print('ANCHOR', label, flush=True)
        continue
    path.write_text(text.replace(old, new))
    try:
        status = test(cap)
    finally:
        path.write_text(text)
    results.append(dict(mutant=label, cap=cap, status=status[0], detail=status[1]))
    print(f'{status[0]:8s} {label} | {status[1]}', flush=True)
for cap in builds:  # restored tree must pass again
    status = test(cap)
    results.append(dict(mutant=f'restored {cap}', cap=cap, status=status[0], detail=status[1]))
counts = {}
for r in results:
    if not r['mutant'].startswith(('baseline', 'restored')):
        counts[r['status']] = counts.get(r['status'], 0) + 1
log.write_text(json.dumps(dict(results=results, totals=counts), indent=1))
print('totals', counts)
