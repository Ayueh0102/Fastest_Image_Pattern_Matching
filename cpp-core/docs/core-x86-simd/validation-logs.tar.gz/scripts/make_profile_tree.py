"""Copy cpp-core (without docs/tests data) and add per-function wall-time counters for a profiling build.

Usage: make_profile_tree.py SRC_CPP_CORE OUT_DIR
Counters wrap rotateCanvas, rotatedRoi, pyrDown (includes template learning), ncc, nccScreened,
selectPeaks and selectPeaksFast; the process prints one 'FPM_PROFILE {json}' line to stderr at exit.
Profiling only: never used for formal timing.
"""
import re
import shutil
import sys
from pathlib import Path

src, out = Path(sys.argv[1]), Path(sys.argv[2])
if out.exists():
    shutil.rmtree(out)
shutil.copytree(src, out, ignore=shutil.ignore_patterns('docs', '__pycache__'))
SLOTS = [('image.cpp', 'Canvas rotateCanvas('), ('image.cpp', 'Image rotatedRoi('), ('image.cpp', 'Image pyrDown('),
         ('ncc.cpp', 'ScoreMap ncc('), ('ncc.cpp', 'ScoreMap nccScreened('),
         ('ncc.cpp', 'std::vector<Peak> selectPeaks('), ('ncc.cpp', 'std::vector<Peak> selectPeaksFast(')]
NAMES = ['rotateCanvas', 'rotatedRoi', 'pyrDown', 'ncc', 'nccScreened', 'selectPeaks', 'selectPeaksFast']

h = out / 'src/internal.hpp'
text = h.read_text()
text = text.replace('#include <array>', '#include <array>\n#include <chrono>', 1)
text = text.replace('namespace fpm::detail {', '''namespace fpm::detail {
extern double profSeconds[8];
extern unsigned long long profCalls[8];
struct ProfScope {
	int slot;
	std::chrono::steady_clock::time_point start = std::chrono::steady_clock::now();
	explicit ProfScope(int s) : slot(s) {}
	~ProfScope() { profSeconds[slot] += std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count(); ++profCalls[slot]; }
};''', 1)
h.write_text(text)

for slot, (name, signature) in enumerate(SLOTS):
    path = out / 'src' / name
    lines = path.read_text().split('\n')
    hits = [i for i, line in enumerate(lines) if line.startswith(signature)]
    assert len(hits) == 1, (name, signature, hits)
    i = hits[0]
    while lines[i] != '{':
        i += 1
    lines.insert(i + 1, f'\tProfScope profScope({slot});')
    path.write_text('\n'.join(lines))

image = out / 'src/image.cpp'
text = image.read_text()
fields = ', '.join(f'\\"{n}\\":[%.6f,%llu]' for n in NAMES)
args = ', '.join(f'profSeconds[{i}], profCalls[{i}]' for i in range(len(NAMES)))
text = text.replace('#include <stdexcept>', '#include <stdexcept>\n#include <cstdio>', 1)
text += f'''
namespace fpm::detail {{
double profSeconds[8];
unsigned long long profCalls[8];
namespace {{
struct ProfPrinter {{
	~ProfPrinter() {{ std::fprintf(stderr, "FPM_PROFILE {{{fields}}}\\n", {args}); }}
}} profPrinter;
}}
}}
'''
image.write_text(text)
assert re.search(r'ProfScope profScope\(6\)', (out / 'src/ncc.cpp').read_text())
print('ok', out)
