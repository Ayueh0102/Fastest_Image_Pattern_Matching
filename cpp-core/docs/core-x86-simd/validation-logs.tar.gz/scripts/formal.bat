@echo off
rem Formal x86 SIMD gate on PTRI-PRO-4000; see cpp-core/docs/core-x86-simd/protocol.json.
rem Sources are git archives in C:\r51\formal\src-before and src-after. Progress: C:\r51\formal\logs\formal.log
set F=C:\r51\formal
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul
set "PATH=C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin;C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja;%PATH%"
set PY=C:\r50\venv\Scripts\python.exe
set PGM=C:\r51\bundle\pgm
set TOOLS=%F%\src-after\cpp-core\tools
cd /d %F%
echo start %DATE% %TIME% >> logs\formal.log
%PY% %F%\check_pgm.py %F%\pgm-manifest.json %PGM% > logs\pgm-check.log 2>&1
echo pgm-check %ERRORLEVEL% >> logs\formal.log
call :build before src-before
call :build after-auto src-after
call :build after-avx2 src-after "-DFPM_X86_MAX_ISA=AVX2"
call :build after-sse2 src-after "-DFPM_X86_MAX_ISA=SSE2"
call :build after-scalar src-after "-DFPM_DISABLE_SIMD=ON"
call :build after-asan-auto src-after "-DCMAKE_CXX_FLAGS=/DWIN32 /D_WINDOWS /EHsc /GR /fsanitize=address"
call :build after-asan-sse2 src-after "-DCMAKE_CXX_FLAGS=/DWIN32 /D_WINDOWS /EHsc /GR /fsanitize=address" "-DFPM_X86_MAX_ISA=SSE2"
%PY% %TOOLS%\check_backend_identity.py --lib before=build-before\fpm_c.dll --lib auto=build-after-auto\fpm_c.dll --lib avx2=build-after-avx2\fpm_c.dll --lib sse2=build-after-sse2\fpm_c.dll --lib scalar=build-after-scalar\fpm_c.dll --pgm-dir %PGM% --output out\identity.json > logs\identity.log 2>&1
echo identity %ERRORLEVEL% >> logs\formal.log
echo timing-start %DATE% %TIME% >> logs\formal.log
start /wait /b /affinity C03C02 %PY% %TOOLS%\benchmark_backend_ab.py --build before=build-before --build after=build-after-auto --rounds 8 --pgm-dir %PGM% --output out\ab-default.json > logs\ab-default.log 2>&1
echo ab-default %ERRORLEVEL% >> logs\formal.log
start /wait /b /affinity C03C02 %PY% %TOOLS%\benchmark_backend_ab.py --build before=build-before --build after=build-after-auto --rounds 8 --pgm-dir %PGM% --output out\ab-fast.json --extra --fast > logs\ab-fast.log 2>&1
echo ab-fast %ERRORLEVEL% >> logs\formal.log
start /wait /b /affinity C03C02 %PY% %TOOLS%\benchmark_backend_ab.py --build before=build-before --build after=build-after-auto --rounds 8 --pgm-dir %PGM% --output out\ab-subpixel.json --extra --subpixel > logs\ab-subpixel.log 2>&1
echo ab-subpixel %ERRORLEVEL% >> logs\formal.log
start /wait /b /affinity C03C02 %PY% %TOOLS%\benchmark_backend_ab.py --build sse2=build-after-sse2 --build auto=build-after-auto --rounds 8 --pgm-dir %PGM% --output out\ab-tier-sse2-auto.json > logs\ab-tier-sse2-auto.log 2>&1
echo ab-tier-sse2-auto %ERRORLEVEL% >> logs\formal.log
start /wait /b /affinity C03C02 %PY% %TOOLS%\benchmark_backend_ab.py --build avx2=build-after-avx2 --build auto=build-after-auto --rounds 8 --pgm-dir %PGM% --output out\ab-tier-avx2-auto.json > logs\ab-tier-avx2-auto.log 2>&1
echo ab-tier-avx2-auto %ERRORLEVEL% >> logs\formal.log
echo timing-end %DATE% %TIME% >> logs\formal.log
xcopy /e /i /q %F%\src-after\cpp-core %F%\src-mutants\cpp-core > nul
%PY% %F%\x86_mutants.py %F%\src-mutants %F%\build-m %F%\out\mutants.json > logs\mutants.log 2>&1
echo mutants %ERRORLEVEL% >> logs\formal.log
echo formal-finished >> logs\formal.log
exit /b 0

:build
cmake -S %F%\%2\cpp-core -B %F%\build-%1 -G Ninja -DCMAKE_BUILD_TYPE=Release %3 %4 > logs\%1-configure.log 2>&1
if errorlevel 1 (echo %1 configure-failed >> logs\formal.log & exit /b 1)
cmake --build %F%\build-%1 > logs\%1-build.log 2>&1
if errorlevel 1 (echo %1 build-failed >> logs\formal.log & exit /b 1)
ctest --test-dir %F%\build-%1 --output-on-failure > logs\%1-ctest.log 2>&1
echo %1 ctest %ERRORLEVEL% >> logs\formal.log
exit /b 0
