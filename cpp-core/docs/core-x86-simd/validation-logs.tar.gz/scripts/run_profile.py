"""Profiling only: run a counter-instrumented fpm_cli on the 17 fixtures (default and fast modes).

Usage: python run_profile.py FPM_CLI BUNDLE_DIR OUT_JSON [--repeats N]
Each call is a fresh process; per case the median of N calls of match_ms and of each counter.
pyrDown includes template learning, which match_ms excludes.
"""
import json, platform, statistics, subprocess, sys
from pathlib import Path

cli, bundle, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
repeats = int(sys.argv[sys.argv.index('--repeats') + 1]) if '--repeats' in sys.argv else 3
cases = json.loads((bundle / 'cases.json').read_text())
rows = []
for c in cases:
    base = [str(cli), '--src', str(bundle / 'pgm' / c['src']), '--tmpl', str(bundle / 'pgm' / c['tmpl']),
            '--target-num', str(c['count']), '--score', str(c['score']), '--angle', str(c['angle']),
            '--overlap', str(c['overlap']), '--min-area', str(c['area']), '--no-display']
    for mode, extra in (('default', []), ('fast', ['--fast'])):
        calls = []
        for _ in range(repeats):
            r = subprocess.run(base + extra, capture_output=True, text=True, check=True)
            line = next(x for x in r.stderr.splitlines() if x.startswith('FPM_PROFILE '))
            prof = json.loads(line[len('FPM_PROFILE '):])
            calls.append(dict(match_ms=json.loads(r.stdout)['match_ms'], **{k: v[0] * 1e3 for k, v in prof.items()},
                              calls={k: v[1] for k, v in prof.items()}))
        keys = [k for k in calls[0] if k != 'calls']
        rows.append(dict(case=c['name'], mode=mode, **{k: statistics.median(x[k] for x in calls) for k in keys},
                         calls=calls[0]['calls']))
        print(c['name'], mode, round(rows[-1]['match_ms'], 1), flush=True)
out.write_text(json.dumps(dict(platform=platform.platform(), processor=platform.processor(), cli=str(cli),
                               repeats=repeats, rows=rows), indent=1))
