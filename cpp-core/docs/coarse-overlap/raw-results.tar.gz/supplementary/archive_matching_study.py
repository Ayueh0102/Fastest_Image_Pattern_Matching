"""Freeze measured reports, exact source snapshots and diagnostics for relocation."""
import argparse,gzip,hashlib,json,shutil,tarfile
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('study');p.add_argument('report',type=Path);p.add_argument('destination',type=Path);p.add_argument('--summary',type=Path,required=True);args=p.parse_args()
root=Path.cwd().resolve();data=args.report.resolve().parent;destination=args.destination.resolve();destination.mkdir(parents=True,exist_ok=True)
folder=root/'build'/(args.study+'-archive');folder.mkdir(exist_ok=True)
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
def copy(src,dst):dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
report=json.loads(args.report.read_text());assert report['complete'] and report['integrity_passed']
allhash={**report['source_hashes'],**report['library_hashes'],**report['input_hashes']}
b=report['baseline_provenance'];allhash[b['manifest']]=b['manifest_sha256']
assert all(sha(path)==digest for path,digest in allhash.items())
workers=[]
for entry in report['execution_order']:
 assert sha(entry['job'])==entry['job_sha256'] and sha(entry['result'])==entry['result_sha256']
 worker=json.loads(Path(entry['result']).read_text());workers.append(worker)
 assert 'truth' not in json.loads(Path(entry['job']).read_text())['case']
 for r in worker['runs']:
  for k in ('host_pyramid_bytes','coarse_gpu_bytes','fine_gpu_bytes'):
   assert r['frame']['metrics'][k]==worker['first']['frame']['metrics'][k]
 assert all(r['output_sha256']==worker['first']['output_sha256'] and not r['profile_errors'] for r in worker['warmups'])
for name in ('formal.json','pilot.json'):
 path=data/name
 if path.exists():
  copy(path,folder/name)
  jobs=data/(Path(name).stem+'-jobs')
  if jobs.exists():shutil.copytree(jobs,folder/jobs.name,dirs_exist_ok=True)
copy(args.summary,folder/'replayed-summary.json')
copy(b['manifest'],folder/'baseline-provenance.json')
for path in sorted((root/'build').glob(args.study+'*.log')):copy(path,folder/'logs'/path.name)
source_map={}
for path,digest in report['source_hashes'].items():
 relative=Path(path).relative_to(root)
 target=folder/'measured-sources'/relative
 copy(path,target);assert sha(target)==digest;source_map[target.relative_to(folder).as_posix()]=digest
save(folder/'measured-source-sha256.json',source_map)
for case in report['cases']:
 if case['case'].get('metadata'):
  path=Path(case['case']['metadata']);copy(path,folder/'input-metadata'/path.name)
for path in sorted((root/'cpp-core/tests').glob('*')):
 if path.is_file():copy(path,folder/'supplementary/tests'/path.name)
copy(Path(__file__),folder/'supplementary/archive_matching_study.py')
(folder/'README.txt').write_text('''Measurements use frozen libraries/source manifests. Original absolute paths in
formal.json/job/worker records are preserved to keep hashes valid. Binaries and
large PNG inputs are omitted; binary/input hashes and deterministic scene
construction sources are retained. Original Test Images assets remain in Git.

Use the repository benchmark CLI --summarize /archive/formal.json --worker-root
/archive --output /tmp/replayed.json. All workers/jobs are read from the explicit
archive, not the original paths. The output must byte-match replayed-summary.json.
sha256.json authenticates every member except itself; artifact-sha256.json next
to the archive authenticates the compressed archive and its manifest.

All GT evaluation for formal runs occurs in the parent after worker termination;
no truth or generation metadata is passed to the matching workers. Setup/first,
warmup and measured calls are separate. Accuracy and integrity are separate
from speed; inspect per-case gains/regressions. device/wait/CPU times overlap;
RSS overlaps retained buffers. No hardware timeline capture is claimed.
''')
manifest={p.relative_to(folder).as_posix():sha(p) for p in sorted(folder.rglob('*')) if p.is_file() and p.name!='sha256.json'}
save(folder/'sha256.json',manifest)
archive=destination/'raw-results.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for file in sorted(folder.rglob('*')):
    if file.is_file():
     info=tar.gettarinfo(str(file),arcname=file.relative_to(folder).as_posix());info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
     with file.open('rb') as src:tar.addfile(info,src)
with tarfile.open(archive,'r:gz') as tar:
 assert set(tar.getnames())==set(manifest)|{'sha256.json'}
 for name,digest in manifest.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==digest
validation=dict(complete=True,integrity_passed=True,detection_all_passed=report['detection_all_passed'],
 worker_count=len(workers),first_calls=len(workers),measured_calls=sum(len(w['runs']) for w in workers),warmup_calls=sum(len(w['warmups']) for w in workers),
 all_sources_libraries_inputs_hashes_valid=True,all_jobs_workers_hashes_valid=True,
 all_measured_frame_capacities_equal_first=True,warmup_digests_match_first=True,formal_workers_have_no_truth=True,
 archive_files=len(manifest),archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,
 manifest_sha256=sha(folder/'sha256.json'),replayed_summary_sha256=sha(args.summary))
save(destination/'artifact-sha256.json',validation);print(json.dumps(validation,indent=2))
