Measurements use frozen libraries/source manifests. Original absolute paths in
formal.json/job/worker records are preserved to keep hashes valid. Binaries and
large PNG inputs are omitted; binary/input hashes and deterministic scene
construction sources are retained. Original Test Images assets remain in Git.

Use the repository benchmark CLI --summarize /archive/formal.json --worker-root
/archive --output /tmp/replayed.json. All workers/jobs are read from the explicit
archive, not the original paths. The output must byte-match replayed-summary.json.
sha256.json authenticates every member except itself; artifact-sha256.json next
to the archive authenticates the compressed archive and its manifest.

All GT evaluation for formal runs occurs in the parent after worker termination;
no truth or generation metadata is passed to the matching workers. Setup/first,
warmup and measured calls are separate. Accuracy and integrity are separate
from speed; inspect per-case gains/regressions. device/wait/CPU times overlap;
RSS overlaps retained buffers. No hardware timeline capture is claimed.
