Exact sparse response representation study. Three routes: frozen70727a8,
current8planes, currentcompactmask+2KiBlookup. Both current routes preserve the
same quantized score and full matching outputs. Performance gates and inherited
proposal-coverage failures are retained. This is CPU proposal work; backend1
uses existing Metal resident refinement. No GPU compact implementation claimed.

Offline replay (NumPy/OpenCV installed, no GPU required), from any directory:
python3 EXTRACT/formal/source-snapshot/cpp-core/tools/benchmark_sparse_compact.py \
 --summarize EXTRACT/formal/results.json --output /tmp/replayed.json

Original absolute paths in protocol are historical provenance. Archive includes
relative worker records, input images and metadata, measured-source snapshots,
baseline source archive, pilot if supplied, and validation logs. Binary hashes
are preserved; executable files are omitted. All member hashes in sha256.json.
