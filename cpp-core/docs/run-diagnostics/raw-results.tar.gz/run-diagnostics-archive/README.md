# Stage32 evidence

Two independently launched, serial phases: `reproduction` (12 workers, 48 calls) and `pose_memory` (16 workers, 32 calls). Both use two fresh processes per method/case, forward/reverse order, zero warmup. Repeats within a process are not independent process samples. The two pose cases reuse one synthetic 512-instance scene.

`source` contains the measured current C++/Metal/Python/Qt sources; `frozen-source` is baseline c3c59ee. `binaries` preserves the measured files, but dynamic-library install names may refer to original build directories. For independent execution, build from `source`; historical binary copies are provenance, not a portable installed app.

`input-paths.json` maps historical absolute input names to archived files. To run a job after extraction, copy its JSON and explicitly replace only source/template paths using this map. Do not modify measured jobs. Run from an empty output directory; formal drivers refuse overwriting.

Replay requires no GPU or original absolute input files:

```sh
python source/cpp-core/tools/benchmark_run_diagnostics.py --summarize reproduction/formal.json --output reproduction-replay.json
python source/cpp-core/tools/benchmark_run_diagnostics.py --summarize pose_memory/formal.json --output pose-memory-replay.json
```

Compare the generated summary bytes with each retained summary. Use a Python environment with NumPy and Pillow, as imported by the research evaluation helpers.

`historical-outlier` retains the stage31 formal/protocol/summary plus only the relevant many512_pose worker subset and detailed forensic extraction. It is sufficient to verify the original +48.34% comparison, not to replay the entire three-case stage31 report. The complete earlier experiment remains in the stage31 archive. Original historical failure is retained regardless of stage32 outcomes.

`run-diagnostics-pilot` validates diagnostic presence, exact outputs and warmup/soak rejection on a small scene; it is not formal performance data. `run-diagnostics-memory-compat` is a build-only diagnostic compatibility check, not another GPU measurement.

Timing: total_ms is the algorithm interval; resource wall_ms is the slightly wider Session.run call boundary, including return/destructor overhead. Process CPU usage may exceed wall time with multiple threads. Host ticks describe the whole machine, not process or GPU occupancy. Nested phase wall/device/wait clocks overlap and cannot be added; wait minus device is not a transfer measurement. Unavailable counters remain -1, never zero.

Shared host/GPU logical image bytes overlap: unique = host + gpu - shared. Conversion temporary is first-call capacity, not an additional retained buffer on repeats. Whole-process peak RSS is measured separately; do not sum it with these capacities.

The content manifest covers files except itself. Source hashes in each protocol identify measured source, independent of the pre-commit working_tree_commit. Test/build logs and archive reproduction checks are included separately from benchmark records.
