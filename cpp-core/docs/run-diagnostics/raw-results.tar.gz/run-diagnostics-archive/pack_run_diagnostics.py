import hashlib,io,json,shutil,subprocess,tarfile
from pathlib import Path
root=Path('/Users/Ayueh/Fastest_Image_Pattern_Matching');stage=root/'build/run-diagnostics-archive'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def cp(src,dst,expected=None):
 src,dst=Path(src),Path(dst)
 if expected:assert sha(src)==expected,str(src)
 dst.parent.mkdir(exist_ok=True,parents=True);shutil.copy2(src,dst)
reports={}
for phase,folder in [('reproduction','run-diagnostics-reproduction'),('pose_memory','run-diagnostics-pose-memory')]:
 raw=root/'build'/folder;report=json.loads((raw/'formal.json').read_text());reports[phase]=report
 assert report['complete'] and report['unchanged']
 assert json.loads((raw/'summary.json').read_text())['correctness_passed']
 shutil.copytree(raw,stage/phase,dirs_exist_ok=True)
formal=reports['reproduction'];assert formal['source_sha256']==reports['pose_memory']['source_sha256']
for p,h in formal['source_sha256'].items():cp(root/p,stage/'source'/p,h)
for name in subprocess.check_output(['git','ls-files','macos-cli','MatchTool'],cwd=root,text=True).splitlines():cp(root/name,stage/'source'/name)
for p in ['LICENSE','AGENTS.md','CMakeLists.txt','vcpkg.json','Test Images/Src7.bmp','Test Images/Dst7.bmp']:cp(root/p,stage/'source'/p)
paths=['cpp-core/CMakeLists.txt','cpp-core/src','cpp-core/include','cpp-core/experiments','cpp-core/tests','cpp-core/tools','cpp-core/examples','macos-cli','LICENSE']
blob=subprocess.check_output(['git','archive',formal['baseline_commit'],*paths],cwd=root)
with tarfile.open(fileobj=io.BytesIO(blob)) as tf:tf.extractall(stage/'frozen-source',filter='data')
mapping={}
inputs=dict(formal['input_sha256'])
pilot=json.loads((root/'build/run-diagnostics-pilot/current_direct.json').read_text())
inputs.update({pilot[key]:sha(pilot[key]) for key in ('source','template')})
for p,h in inputs.items():
 dst=Path('inputs')/Path(p).name;assert str(dst) not in mapping.values();cp(p,stage/dst,h);mapping[p]=str(dst)
(stage/'input-paths.json').write_text(json.dumps(mapping,indent=2)+'\n')
(stage/'input-sha256.json').write_text(json.dumps(inputs,indent=2)+'\n')
for p,h in formal['binary_sha256'].items():cp(p,stage/'binaries'/Path(p).relative_to(root/'build'),h)
cp(root/'cpp-core/docs/gray-loader/protocol.json',stage/'frozen-protocol.json',formal['baseline_protocol_sha256'])
cp(root/'build/run-diagnostics-forensics.json',stage/'historical-outlier/forensics.json')
old=root/'build/gray-loader-results'
for name in ['formal.json','protocol.json','summary.json']:cp(old/name,stage/'historical-outlier'/name)
for p in (old/'jobs').glob('many512_pose-*'):cp(p,stage/'historical-outlier/jobs'/p.name)
for p in (root/'build').glob('run-diagnostics*.log'):cp(p,stage/'logs'/p.name)
for folder in ['run-diagnostics','run-diagnostics-asan','gray-loader']:cp(root/'build'/folder/'CMakeCache.txt',stage/'logs'/(folder+'-CMakeCache.txt'))
for name in ['run-diagnostics-pilot','run-diagnostics-memory-compat']:
 shutil.copytree(root/'build'/name,stage/name,dirs_exist_ok=True)
cp(__file__,stage/'pack_run_diagnostics.py')
print('Staged',stage)
