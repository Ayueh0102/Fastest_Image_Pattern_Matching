import json,subprocess,sys
from pathlib import Path
root=Path('/Users/Ayueh/Fastest_Image_Pattern_Matching');stage=root/'build/run-diagnostics-archive';checks=stage/'archive-checks';checks.mkdir(exist_ok=True)
input_paths=json.loads((stage/'input-paths.json').read_text());pilot=stage/'run-diagnostics-pilot'
rows={}
for method in ['current_direct','probe_direct','combined']:
 original='current_direct' if method=='combined' else method
 job=json.loads((pilot/(original+'.json')).read_text())
 for key in ('source','template'):job[key]=str(stage/input_paths[job[key]])
 if method=='combined':job.update(pose_input_mode=1,pose_storage_mode=1)
 path=checks/(method+'.json');path.write_text(json.dumps(job,indent=2)+'\n')
 result=subprocess.run([str(root/'build/run-diagnostics-archive-build/experiments/fpm_native_pipeline_runner'),str(path)],capture_output=True,text=True)
 (checks/(method+'.result.json')).write_text(result.stdout);(checks/(method+'.stderr.txt')).write_text(result.stderr)
 assert result.returncode==0,result.stderr
 row=json.loads(result.stdout);ref=json.loads((pilot/(original+'.result.json')).read_text())
 for candidate,reference in zip([row['first'],*row['runs']],[ref['first'],*ref['runs']]):
  assert candidate['matches']==reference['matches'] and candidate['proposals']==reference['proposals']
 rows[method]=True
for phase in ['reproduction','pose_memory']:
 output=checks/(phase+'-replay.json')
 subprocess.run([sys.executable,str(stage/'source/cpp-core/tools/benchmark_run_diagnostics.py'),'--summarize',str(stage/phase/'formal.json'),'--output',str(output)],check=True)
 assert output.read_bytes()==(stage/phase/'summary.json').read_bytes()
(checks/'validation.json').write_text(json.dumps({'fresh_build_small_exact':rows,'relocated_replays_byte_identical':True},indent=2)+'\n')
print('Archive small exact and both relocated replays passed')
